/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM.h
 *
 * Description: Charging Manager enables the charging process between the supply equipment (EVSE) and the vehicle (EV)
 *
 * Author: Mahmoud Shaarawy,Mohannad Sabry
 ******************************************************************************/

#ifndef CHRGM_H_
#define CHRGM_H_

/* ID for the company in the AUTOSAR
 * for example Mahmoud Shaarawy's ID = 7022 */
#define CHRGM_VENDOR_ID                  (7022U)

/* ChrgM Module ID */
#define CHRGM_MODULE_ID                  (0U) /*Unknown*/

/* ChrgM Instance ID */
#define CHRGM_INSTANCE_ID                (0U)

/*
 * Module Version 1.0.0
 */
#define CHRGM_SW_MAJOR_VERSION           (1U)
#define CHRGM_SW_MINOR_VERSION           (0U)
#define CHRGM_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 1.0.0
 */
#define CHRGM_AR_RELEASE_MAJOR_VERSION   (1U)
#define CHRGM_AR_RELEASE_MINOR_VERSION   (0U)
#define CHRGM_AR_RELEASE_PATCH_VERSION   (0U)

/*
 * Macros for ChrgM Status
 */
#define CHRGM_INITIALIZED                (1U)
#define CHRGM_NOT_INITIALIZED            (0U)


/*******************************************************************************
 *                              Module Definitions                             *
 *******************************************************************************/

/* If required */


/*******************************************************************************
 *                               V2G Datatypes                                 *
 *******************************************************************************/

#include "V2G_Data_Types.h"

/*
 * AUTOSAR checking between Std Types and ChrgM Modules
 */

#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Std_Types.h does not match the expected version"
#endif


/* ChrgM Pre-Compile Configuration Header file */
#include "ChrgM_Cfg.h"

/* AUTOSAR Version checking between ChrgM_Cfg.h and ChrgM.h files */
#if ((CHRGM_CFG_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (CHRGM_CFG_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (CHRGM_CFG_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between ChrgM_Cfg.h and ChrgM.h files */
#if ((CHRGM_CFG_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (CHRGM_CFG_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (CHRGM_CFG_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Non AUTOSAR files */
#include "Common_Macros.h"

/*******************************************************************************
 *                             Imported Modules                                *
 *******************************************************************************/

#include "BswM.h"

/* AUTOSAR Version checking between BswM.h and ChrgM.h files */
#if ((BSWM_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (BSWM_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (BSWM_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between BswM.h and ChrgM.h files */
#if ((BSWM_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (BSWM_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (BSWM_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "ComStack_Types.h"

/* AUTOSAR Version checking between ComStack_Types.h and ChrgM.h files */
#if ((COMSTACK_TYPES_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (COMSTACK_TYPES_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (COMSTACK_TYPES_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between ComStack_Types.h and ChrgM.h files */
#if ((COMSTACK_TYPES_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (COMSTACK_TYPES_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (COMSTACK_TYPES_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "Csm/Csm.h"

/* AUTOSAR Version checking between Csm.h and ChrgM.h files */
#if ((CSM_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (CSM_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (CSM_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between Csm.h and ChrgM.h files */
#if ((CSM_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (CSM_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (CSM_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "Eth_GeneralTypes.h"

/* AUTOSAR Version checking between Eth_GeneralTypes.h and ChrgM.h files */
#if ((ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between Eth_GeneralTypes.h and ChrgM.h files */
#if ((ETH_GENERAL_TYPES_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (ETH_GENERAL_TYPES_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (ETH_GENERAL_TYPES_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "KeyM.h"

/* AUTOSAR Version checking between KeyM.h and ChrgM.h files */
#if ((KEYM_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (KEYM_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (KEYM_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between KeyM.h and ChrgM.h files */
#if ((KEYM_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (KEYM_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (KEYM_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "SoAd.h"

/* AUTOSAR Version checking between SoAd.h and ChrgM.h files */
#if ((SOAD_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (SOAD_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (SOAD_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between SoAd.h and ChrgM.h files */
#if ((SOAD_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (SOAD_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (SOAD_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "TcpIp.h"

/* AUTOSAR Version checking between TcpIp.h and ChrgM.h files */
#if ((TCPIP_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (TCPIP_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (TCPIP_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between TcpIp.h and ChrgM.h files */
#if ((TCPIP_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (TCPIP_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (TCPIP_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "PduR.h"

/* AUTOSAR Version checking between PduR.h and ChrgM.h files */
#if ((PDUR_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (PDUR_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (PDUR_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between PduR.h and ChrgM.h files */
#if ((PDUR_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (PDUR_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (PDUR_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif

/* SoAd Callback Functions */
#include "ChrgM_SoAd.h"

/* Main Function Rx */
#include "SchM_ChrgM.h"

/* Main Function Tx */
#include "ChrgM_SchM.h"

/* ChrgM Indication APIs */
#include "ChrgM_Externals.h"

#include "iso1EXIDatatypes.h"
#include "iso1EXIDatatypesEncoder.h"
#include "iso1EXIDatatypesDecoder.h"
#include "iso2EXIDatatypes.h"
#include "iso2EXIDatatypesEncoder.h"
#include "iso2EXIDatatypesDecoder.h"
#include "ByteStream.h"
#include <string.h>



/******************************************************************************
 *                      API Service Id Macros                                 *
 ******************************************************************************/

#define CHRGM_INIT_SID 									(uint8)0x01

#define CHRGM_START_PROCESS_SID 						(uint8)0x25

#define CHRGM_CP_LINE_STATUS_SID 						(uint8)0x1E

#define CHRGM_DATA_LINK_INDICATION_SID 					(uint8)0x02

#define CHRGM_ERROR_INDICATION 							(uint8)0x1D

#define CHRGM_MAIN_FUNCTION_RX_SID 						(uint8)0x24

#define CHRGM_MAIN_FUNCTION_TX_SID 						(uint8)0x23

#define CHRGM_PAYMENT_SERVICE_SELECTION_INDICATION_SID 	(uint8)0x15

#define CHRGM_SESSION_SETUP_INDICATION_SID 				(uint8)0x12

#define CHRGM_SESSION_STOP_INDICATION_SID 				(uint8)0x1C

#define CHRGM_V2GTP_COPY_RX_DATA 						(uint8)0x44

#define CHRGM_V2GTP_COPY_TX_DATA 						(uint8)0x43


/******************************************************************************
 *                 Callback Notification Service Id Macros                    *
 ******************************************************************************/

#define CHRGM_V2GTP_LOCAL_IP_ADDR_ASSIGNMENT_CHG_SID 	(uint8)0x18

#define CHRGM_V2GTP_RX_INDICATION_SID 					(uint8)0x45

#define CHRGM_V2GTP_SO_CON_MODE_CHG_SID 				(uint8)0x21

#define CHRGM_V2GTP_START_OF_RECEPTION_SID 				(uint8)0x46

#define CHRGM_V2GTP_TX_CONFIRMATION_SID 				(uint8)0x48


/*******************************************************************************
 *                               DET Error Codes                               *
 *******************************************************************************/

#define CHRGM_E_UNINIT 									(uint8)0x01

#define CHRGM_E_PARAM_POINTER 							(uint8)0x02

#define CHRGM_E_INV_ARG 								(uint8)0x03

#define CHRGM_E_INIT_FAILED 							(uint8)0x06


/*******************************************************************************
 *                               DEM Error Codes                               *
 *******************************************************************************/

#define CHRGM_E_NOBUFS 									(uint8)0x07


/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef float ChrgM_TimerType;

typedef uint32 ChrgMV2GTPPduPayloadTypeType;

typedef uint8 ChrgMV2GTPPduProtocolVersionType;

typedef uint32 ChrgMV2GTPPduHandleIdType;

typedef enum
{
	NOT_INITIALIZED,

	INIT,

	ASSIGNING_IP_ADDRESS,

	DISCOVERING_SECC,

	ESTABLISHING_TCP_TLS,

	ESTABLISHING_V2G_SESSION,

	V2G_SESSION_ONGOING,

	V2G_SESSION_PAUSED

}ChrgM_ModuleStateType;

typedef enum
{
	NO_MESSAGE,

	SUPPORTED_APP_PROTOCOL,

	SESSION_SETUP,

	SERVICE_DISCOVERY,

	SERVICE_DETAIL,

	PAYMENT_SELECTION,

	PAYMENT_DETAILS,

	AUTHORIZATION,

	CHARGE_PARAMETER_DISCOVERY,

	CABLE_CHECK,

	PRE_CHARGE,

	POWER_DELIVERY,

	CURRENT_DEMAND,

	WELDING_DETECTION,

	SESSION_STOP

}ChrgM_MessageStateType;

typedef struct
{
	ChrgMV2GTPPduPayloadTypeType ChgMV2GTPPduPayloadType;

	ChrgMV2GTPPduProtocolVersionType ChrgMV2GTPPduProtocolVersion;

	ChrgMV2GTPPduHandleIdType ChrgMV2GTPPduHandleId;

	/* ChrgMV2GTPPduRef Pointer to Pdu Structure Not defined yet */

}ChrgM_V2GTPPduType;

typedef struct
{
	/* Pointer ChrgMSoAdSocketConnectionRef */
}ChrgM_ServiceType;

typedef struct
{
	/* Pointer ChrgMV2GUdpSdpClientRef */
	/* Pointer ChrgMV2GSrcTcpDataRef */
	SoAd_ConfigType* ChrgMV2GSrcTcpDataRef;
	ChrgM_V2GTPPduType ChrgM_V2GTPPdu;
}ChrgM_V2GTPType;

typedef struct
{
	//ChrgM_ServiceType ChrgM_Service; /* Not used as IP Address is statically Configured */
	ChrgM_TimerType ChrgM_Timer[CHRGM_CONFIGURED_TIMERS];
	ChrgM_V2GTPType ChrgM_V2GTP;

} ChrgM_ConfigType;

/*******************************************************************************
 *                             Magic Numbers                                   *
 *******************************************************************************/
#define INACTIVE                                (0u)

#define ACTIVE                                  (1u)

#define SECC_PORT_NUMBER                        (15118)

#define PROTOCOL_VERSION                        (0x01)

#define INVERSE_PROTOCOL_VERSION                (0xFE)

#define V2G_MESSAGE_PAYLOAD_TYPE_VALUE          (0x8001)

#define SDP_RESPONSE_PAYLOAD_TYPE_VALUE         (0x9001)

#define SDP_REQUEST_PAYLOAD_TYPE_VALUE          (0x9000)

#define SDP_SECURITY_SIZE                       (1u)

#define SDP_TRANSPORT_PROTOCOL_SIZE             (1u)

#define SDP_PORT_NUMBER_SIZE                    (4u)

#define SDP_IP_ADDRESS_SIZE                     (16u)

#define SDP_IP_ADDRESS_ELEMENT_SIZE             (1u)

#define PROTOCOL_VERSION_SIZE                   (1u)

#define INVERSE_PROTOCOL_VERSION_SIZE           (1u)

#define PAYLOAD_TYPE_SIZE                       (2u)

#define PAYLOAD_LENGTH_SIZE                     (4u)

#define V2G_HEADER_SIZE                         (8u)

#define SESSION_ID_ZERO                         (0u)

#define SESSION_ID_SIZE                         (1u)

#define ELEMENT_USED_SIZE                       (1u)

#define MESSAGE_NAME_SIZE                       (1u)

#define RESPONSE_CODE_SIZE                 		(1u)

#define SCHEMA_ID_SIZE							(1u)

#define NUMBER_OF_PROTOCOLS_SIZE				(1u)

#define PROTOCOL_NAMESPACE_SIZE                 (1u)

#define MAJOR_VERSION_NUMBER_SIZE				(4u)

#define MINOR_VERSION_NUMBER_SIZE				(4u)

#define PRIORITY_SIZE							(1u)

/*******************************************************************************
 *                             Function Prototypes                             *
 *******************************************************************************/

void ChrgM_Init (const ChrgM_ConfigType* ConfigPtr);

void ChrgM_StartProcess (boolean Process);

void ChrgM_CpLineStatus (char CpLineStatus);

void ChrgM_DataLinkIndication (uint8 CtrlIdx, EthTrcv_LinkStateType TransceiverLinkState);

BufReq_ReturnType ChrgM_V2GTpCopyRxData (PduIdType id, const PduInfoType* info,PduLengthType bufferSize);

BufReq_ReturnType ChrgM_V2GTpCopyTxData (PduIdType id, const PduInfoType* info, const RetryInfoType* retry, PduLengthType* availableDataPtr);


/*******************************************************************************
 *                        Callback Notifications Prototypes                    *
 *******************************************************************************/

void ChrgM_V2GTpRxIndication (PduIdType id, Std_ReturnType result);

void ChrgM_V2GTpTxConfirmation (PduIdType id, Std_ReturnType result);

BufReq_ReturnType ChrgM_V2GTpStartOfReception (PduIdType id, const PduInfoType* info, PduLengthType TpSduLength, PduLengthType* bufferSizePtr);

/*******************************************************************************
 *                               Non SWS API'S                                 *
 *******************************************************************************/
#if(CHRGM_SDP_USED == STD_ON)
void ChrgM_SECCDiscoveryProtocolReq(SECCDiscoveryProtocolReqType* SECCDiscoveryProtocolData);

void ChrgM_SECCDiscoveryProtocolRes(void);
#endif
void ChrgM_SupportedAppProtocolReq(SupportedAppProtocolReqType* SupportedAppProtocolReqData);

void ChrgM_SessionSetupReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_ServiceDiscoveryReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_ServiceDetailReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_PaymentServiceSelectionReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_PaymentDetailsReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_AuthorizationReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_ChargeParameterDiscoveryReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_CableCheckReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_PreChargeReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_PowerDeliveryReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_CurrentDemandReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_WeldingDetectionReq(struct iso1EXIDocument* V2G_Document);

void ChrgM_SessionStopReq(struct iso1EXIDocument* V2G_Document);

Std_ReturnType ChrgM_EXIEncode(uint8 *output_buffer, uint32 *output_size);

Std_ReturnType ChrgM_EXIDecode(uint8 *input_buffer, uint32 input_size, struct iso1EXIDocument *V2G_Document);

Std_ReturnType ChrgM_ReadV2GTPHeader(void);

void ChrgM_WriteV2GTPHeader(void);

/*******************************************************************************
 *                       External Variables                                    *
 *******************************************************************************/

/* ChrgM Configuration Structure extern header file */
#include "ChrgM_PBCfg.h"

#endif /* CHRGM_H_ */
