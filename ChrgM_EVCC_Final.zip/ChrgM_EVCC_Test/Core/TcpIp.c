#include "TcpIp.h"
#include "EthIf.h"
#include "SoAd.h"
#include "SoAd_Cbk.h"
#include "Common_Macros.h"

// #define SERVER

#define TCPIP_MAIN_FUNCTION_PERIODICITY_MS		100 /* Not Standard */ /**************************/

#define TCPIP_TCP_HEADER_SIZE					sizeof(TcpHeader)
#define TCPIP_IPV6_HEADER_SIZE					sizeof(Ipv6Header)

static TcpIp_LocalAddr TcpIpLocalAddr_list[2];
static TcpIp_Buffer TcpIpBuffer[TcpIpTcpSocketMax];

#define TCPIP_INITIALIZED                       1U
#define TCPIP_NOT_INITIALIZED                   0U

static uint8 TcpIp_Status = TCPIP_NOT_INITIALIZED;

extern uint8 My_Phys_Addr[];
extern uint8 TX_Flag;
extern uint8 RX_Flag;

//uint8 test = 255;


const IPv6Addr IPV6_UNSPECIFIED_ADDR =
        IPV6_ADDR(0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000);


TcpIp_NdpCacheEntryType ndpCachelist[MAX_NUMBER_CHACHE] = {

                {
                        {0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0},
                        TCPIP_NDP_ENTRY_STATIC
                },
};


/* #ifdef SERVER
IPv6AddrType TcpIp_LocalAddrTable[MAX_NUMBER_ADDRESSES] = {
        {
                IPV6_ADDR(0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000),
                0,
                TCPIP_IPADDR_STATE_UNASSIGNED,
                -1
        }
};
#else
IPv6AddrType TcpIp_LocalAddrTable[MAX_NUMBER_ADDRESSES] = {
        {
                IPV6_ADDR(0x1000, 0x0000, 0x2000, 0x0000, 0x3000, 0x0000, 0x4000, 0x0000),
                0,
                TCPIP_IPADDR_STATE_UNASSIGNED,
                -1
        }
};
#endif*/

static uint16 TcpIp_BufferDataLen[TcpIpTcpSocketMax] = {0};
static TcpIp_SocketState TcpIp_lastSavedState[TcpIpTcpSocketMax] = {TCPIP_SOCKET_UNEXPECTED};

/********************************Private Functions***************************************/

/* The following function searches for the first tcp socket that is not used and returns the index of the socket */
static TcpIp_SocketIdType getAvailableSocket(){

	TcpIp_SocketIdType curInd;
	TcpIp_SocketIdType availableSocket = 100;

	for(curInd = 0; curInd < TcpIpTcpSocketMax; curInd++){
		if(FALSE == socket_list[curInd].used){
			availableSocket = curInd;
			break;
		}
	}
	return availableSocket;
}

#if TcpIpTcpRetransmissionTimeout != 0
/* The following function calculates the time for retrasmission. Returns TRUE if retransmission should occur and FALSE otherwise */
static boolean isTimeout(uint32 mainFunctionCntr, float32 retransmitTimeout)
{
	uint32 retransmitTimeoutMs = retransmitTimeout * 1000;

	if ((mainFunctionCntr * TCPIP_MAIN_FUNCTION_PERIODICITY_MS) >= retransmitTimeoutMs)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}
#endif

/* Gets the IPV6 + TCP header */
static Std_ReturnType TcpIp_GetPacketHeader(TcpIp_SocketIdType SocketId, uint8 flags, uint32 seqNum, uint8** bufPtr, uint16 DataLength){

	TcpHeader segment;
	uint8* segmentByte = (uint8*)&segment;

	/* Creating a temp variable for Ipv6 Header*/
	Ipv6Header* tempHeader = (Ipv6Header*)*(bufPtr);

    tempHeader->version = 6;
    tempHeader->trafficClassL = 0;
    tempHeader->trafficClassH = 0;
    tempHeader->flowLabelL = 0;
    tempHeader->flowLabelH = 0;
    tempHeader->payloadLen = DataLength;
    tempHeader->nextHeader = IPV6_TCP_HEADER;
    // HopLimit will be a constant which we don't know yet
    tempHeader->hopLimit = 64;
    // tempHeader->srcAddr = TcpIp_LocalAddrTable[0].ipv6addr;

    for (int i = 0; i < 4; i++){
    	tempHeader->srcAddr.map32[i] = TcpIp_LocalAddrTable[0].ipv6addr.map32[i];
    }

    for (int i = 0; i < 4; i++) {
        tempHeader->destAddr.map32[i] = socket_list[SocketId].remoteIpV6Address.addr[i];
    }

    for(int i = 0; i < TCPIP_IPV6_HEADER_SIZE; i++){
		(*bufPtr)[i] = ((uint8*)tempHeader)[i];
    }


	if(TcpIpTcpSocketMax <= SocketId)
	{
		return E_NOT_OK;
	}

	if(FALSE == socket_list[SocketId].used)
	{
		return E_NOT_OK;
	}

#if TcpIpIpV4Enabled == TRUE
	segment.srcPort = socket_list[SocketId].localIpV4Address.port;
	segment.destPort = socket_list[SocketId].remoteIpV4Address.port;
#endif

#if TcpIpIpV6Enabled == TRUE
	segment.srcPort = socket_list[SocketId].localIpV6Address.port;
	segment.destPort = socket_list[SocketId].remoteIpV6Address.port;
#endif

	segment.seqNum = seqNum;

	if((flags & TCPIP_ACK_FLAG))
	{
		segment.ackNum = socket_list[SocketId].curSeqNum + 1;
	}
	else{
		segment.ackNum = 0;
	}

	segment.headerLength = sizeof(TcpHeader) / 4;
	segment.flags = flags;
	segment.windowSize = DataLength - TCPIP_TCP_HEADER_SIZE;
	segment.checkSum = 0;
	segment.urgentPointer = 0;
	segment.reserved1 = 0;
	segment.reserved2 = 0;

	uint16 curSegByte = 0;
	for(uint16 curByte = TCPIP_IPV6_HEADER_SIZE; curByte < sizeof(TcpHeader) + TCPIP_IPV6_HEADER_SIZE; curByte++, curSegByte++){
		(*bufPtr)[curByte] = segmentByte[curSegByte];
	}

	return E_OK;

}

static Std_ReturnType TcpIp_GetPacket(TcpIp_SocketIdType SocketId, const uint8* DataPtr, uint32 AvailableLength){

	//Acquire the tcp buffer
	TcpIpBuffer[SocketId].acquired = TRUE;

	//Copy Data from Data ptr to tcp ip buffer
	uint16 bufferCtr = TcpIpBuffer[SocketId].bufferPtrIdx;
	uint16 dataCtr = 0;

	for(bufferCtr; dataCtr < (AvailableLength); bufferCtr++, dataCtr++){
		*(TcpIpBuffer[SocketId].tcpData + bufferCtr) = *(DataPtr+dataCtr);
	}

	TcpIpBuffer[SocketId].bufferPtrIdx = bufferCtr;
	dataCtr = 0;

	TcpIpBuffer[SocketId].buffReady = TRUE;

	return E_OK;
}



static Std_ReturnType TcpIp_DecodeTcpHeader(TcpIp_SocketIdType SocketId, const uint8* bufPtr){

	TcpHeader* segmentPtr;

	if(NULL_PTR == bufPtr){
		return E_NOT_OK;
	}
	uint8 dummy_arr[20];
for(int i = 0; i < 20; i++){
	dummy_arr[i] = bufPtr[i];
}

	segmentPtr = (TcpHeader*)bufPtr;

	if(segmentPtr->destPort != socket_list[SocketId].localIpV6Address.port){
		return E_NOT_OK;
	}

	if(socket_list[SocketId].state == TCPIP_SOCKET_LISTEN){
		socket_list[SocketId].remoteIpV6Address.port = segmentPtr->srcPort;
	}

	if(segmentPtr->srcPort != socket_list[SocketId].remoteIpV6Address.port){
		return E_NOT_OK;
	}

	socket_list[SocketId].curSeqNum = segmentPtr->seqNum;
	socket_list[SocketId].curAckNum = segmentPtr->ackNum;

	socket_list[SocketId].curFlags = segmentPtr->flags;

	// Make CheckSum

	return E_OK;
}


static Std_ReturnType TcpIp_DecodeIpV6Header(TcpIp_SocketIdType SocketId, const uint8* bufPtr)
{
	Ipv6Header* segmentPtr;

	if(NULL_PTR == bufPtr){
		return E_NOT_OK;
	}

	segmentPtr = (Ipv6Header*)bufPtr;

	if(segmentPtr->version != 6)
	{
		/* ONLY V6 IS ALLOWED */
		return E_NOT_OK;
	}

	if(socket_list[SocketId].state == TCPIP_SOCKET_LISTEN){
		for(uint8 addrIdx = 0; addrIdx < 4; addrIdx++)
		{
			socket_list[SocketId].remoteIpV6Address.addr[addrIdx] = segmentPtr->srcAddr.map32[addrIdx];
		}
	}

	for(uint8 addrIdx = 0; addrIdx < 4; addrIdx++)
	{
		if(segmentPtr->srcAddr.map32[addrIdx] != socket_list[SocketId].remoteIpV6Address.addr[addrIdx])
		{
			return E_NOT_OK;
		}
	}

	for(uint8 addrIdx = 0; addrIdx < 4; addrIdx++)
	{
		if(segmentPtr->destAddr.map32[addrIdx] != socket_list[SocketId].localIpV6Address.addr[addrIdx])
		{
			return E_NOT_OK;
		}
	}

	return E_OK;
}


static void TcpIp_EthIf_CopyToBuffer(uint8** ethifPtr, uint8** tcpPtr, uint16 length){

	for(uint16 curByte = 0; curByte < length; curByte++){
		(*ethifPtr)[curByte] = (*tcpPtr)[curByte];
	}

}

static void copyAddr(uint32 targetAddr[4], uint32 sourceAddr[4]){
    for(int i = 0; i < 4; i++)
        targetAddr[i] = sourceAddr[i];
}



/*******************************************************************************
 *                           RequestIpAddrAssignment                           *
 *******************************************************************************/


Std_ReturnType TcpIp_RequestIpAddrAssignment(

    TcpIp_LocalAddrIdType LocalAddrId,
    TcpIp_IpAddrAssignmentType Type,
    const TcpIp_SockAddrType* LocalIpAddrPtr,
    uint8 Netmask,
    const TcpIp_SockAddrType* DefaultRouterPtr
) {
    // Validate input parameters
    if (LocalIpAddrPtr == NULL_PTR || DefaultRouterPtr == NULL_PTR) {
        return E_NOT_OK;
    }

    // Check if TCP/IP stack is initialized
    if (TcpIp_Status == TCPIP_NOT_INITIALIZED || LocalAddrId >= MAX_NUMBER_ADDRESSES) {
        return E_NOT_OK;
    }

    // [SWS_TcpIp_00116]
    // Perform IP address assignment based on assignment type
    switch (Type) {
    case TCPIP_IPADDR_ASSIGNMENT_STATIC:
        // [SWS_TcpIp_00079]
        // Implement static assignment here:
        break;
    case TCPIP_IPADDR_ASSIGNMENT_DHCP:
        // Implement DHCP assignment here:
        break;
    case TCPIP_IPADDR_ASSIGNMENT_IPV6_ROUTER:
        // Implement IPv6 router assignment here:
        break;
    case TCPIP_IPADDR_ASSIGNMENT_LINKLOCAL_DOIP:
        // Implement link-local assignment with DoIP here:
        break;
    case TCPIP_IPADDR_ASSIGNMENT_ALL:
        // Implement assignment for all addresses here:
        break;
    case TCPIP_IPADDR_ASSIGNMENT_LINKLOCAL:
        // Check if link-local address is already assigned
        if (TcpIp_LocalAddrTable[LocalAddrId].state != TCPIP_IPADDR_STATE_ONHOLD || TcpIp_LocalAddrTable[LocalAddrId].ctrlIdx == (uint8)-1) {
            return E_NOT_OK;
        }
        // Generate link-local IPv6 address
        // Requirement [V2G20-050] [V2G20-051] [V2G20-052]
        // SETTING UP THE PREFIX FOR THE LINK LOCAL ADDRESS
        IPv6Addr linkIP = IPV6_ADDR(0xFE80, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000);
        // USED TO CARRY THE PHYSICAL ADDRESS IN BYTE ORDER
        uint8 physAddr[6];
        // WILL BE USED TO CARRY THE INTERFACE IDENTIFIER
        uint8 linkID[8];
        EthIf_GetPhysAddr(
            TcpIp_LocalAddrTable[LocalAddrId].ctrlIdx,
            (uint8*)physAddr
        );
        /* REQUIREMENT: [V2G20-050] */
        // IMPLEMENTING SLAAC USING EUI-64
        for (int i = 0, j = 0; i < sizeof(linkID) / sizeof(linkID[0]); i++) {
            if (i == 3) {
                linkID[i] = 0xFF;
                continue;
            }
            if (i == 4) {
                linkID[i] = 0xFE;
                continue;
            }
            // J AS AN INDEX FOR THE PHYSICAL ADDRESS
            linkID[i] = physAddr[j];
            j++;
        }
        // INVERTING THE 'u' BIT: THE NEXT TO LOWEST ORDER BIT IN THE FIRST OCTET
        TOGGLE_BIT(linkID[0], 1);
        // COPYING THE ID INTO THE IP ADDRESS
        for (int i = 8; i < 16; i++)
            linkIP.map8[i] = linkID[i - 8];
        // COPYING THE FORMED IP ADDRESS INTO THE LOCAL ADDRESS TABLE IDENTIFIED BY LOCAL ADDRESS ID
        for (int i = 0; i < 16; i++)
            TcpIp_LocalAddrTable[LocalAddrId].ipv6addr.map8[i] = linkIP.map8[i];

        TcpIp_LocalAddrTable[LocalAddrId].state = TCPIP_IPADDR_STATE_ASSIGNED;

        break;

    default:
        // Unknown assignment type
        return E_NOT_OK;
    }

    // Return success
    return E_OK;
}


/*******************************************************************************
 *                           ReleaseIpAddrAssignment                           *
 *******************************************************************************/


Std_ReturnType TcpIp_ReleaseIpAddrAssignment(TcpIp_LocalAddrIdType LocalAddrId) {
    // Check if TCP/IP stack is initialized

    if (TcpIp_Status == TCPIP_NOT_INITIALIZED) {
        return E_NOT_OK;
    }


    // Check if the provided LocalAddrId is within valid range
    if (LocalAddrId >= MAX_NUMBER_ADDRESSES) {
        return E_NOT_OK;
    }

    // Clear the IP address assignment entry for the specified LocalAddrId
    TcpIp_LocalAddrTable[LocalAddrId].state = TCPIP_IPADDR_STATE_UNASSIGNED;
    TcpIp_LocalAddrTable[LocalAddrId].ipv6addr = IPV6_UNSPECIFIED_ADDR;
    TcpIp_LocalAddrTable[LocalAddrId].ctrlIdx = -1;

    // Return success
    return E_OK;
}

/*******************************************************************************
 *                              ResetIpAssignment                              *
 *******************************************************************************/

Std_ReturnType TcpIp_ResetIpAssignment(void) {
    // Check if TCP/IP stack is initialized
    if (TcpIp_Status == TCPIP_NOT_INITIALIZED) {
        return E_NOT_OK;
    }

    // Reset all learned IP addresses to invalid values
    for (int i = 0; i < MAX_NUMBER_ADDRESSES; i++) {
        TcpIp_LocalAddrTable[i].ipv6addr = IPV6_UNSPECIFIED_ADDR;
        TcpIp_LocalAddrTable[i].state = TCPIP_IPADDR_STATE_ONHOLD;
    }

    // Return success
    return E_OK;
}


/*******************************************************************************
 *                                GetIpAddr                                    *
 *******************************************************************************/


Std_ReturnType TcpIp_GetIpAddr(
    TcpIp_LocalAddrIdType LocalAddrId,
    TcpIp_SockAddrType* IpAddrPtr,
    uint8* NetmaskPtr,
    TcpIp_SockAddrType* DefaultRouterPtr
) {
    /* Check if TCP/IP stack is initialized */
    if (TcpIp_Status != TCPIP_INITIALIZED) {
        return E_NOT_OK;
    }

    /* Validate LocalAddrId */
    if (LocalAddrId >= MAX_NUMBER_ADDRESSES) {
        return E_NOT_OK;
    }

    /* Check if the input IpAddrPtr is NULL_PTR */
    if (IpAddrPtr == NULL_PTR) {
        return E_NOT_OK;
    }

    /* Check if DefaultRouterPtr is provided and if its domain matches IpAddrPtr's domain */
    if (DefaultRouterPtr != NULL_PTR && DefaultRouterPtr->domain != IpAddrPtr->domain) {
        return E_NOT_OK;
    }


    /* Retrieve IPv6 address */
    if (IpAddrPtr->domain == TCPIP_AF_INET6) {
        TcpIp_SockAddrInet6Type* ipv6Ptr = (TcpIp_SockAddrInet6Type*)IpAddrPtr;
        copyAddr(ipv6Ptr->addr, TcpIp_LocalAddrTable[LocalAddrId].ipv6addr.map32);
    }
    else {
        return E_NOT_OK; // Unsupported domain
    }

    return E_OK;
}


/*******************************************************************************
 *                              TcpIpV6_Init                                   *
 *******************************************************************************/

void TcpIpV6_Init (const TcpIpV6_ConfigType* ConfigPtr){

	if(ConfigPtr != NULL_PTR){
	} else{
	 /*MISRA 2516*/
	}
}

/*******************************************************************************
 *                              GetPhysAddr                                    *
 *******************************************************************************/

Std_ReturnType TcpIp_GetPhysAddr (TcpIp_LocalAddrIdType LocalAddrId,uint8* PhysAddrPtr){

	if(TcpIp_LocalAddrTable[LocalAddrId].ctrlIdx != -1){

		EthIf_GetPhysAddr(TcpIp_LocalAddrTable[LocalAddrId].ctrlIdx, PhysAddrPtr);
		return E_OK;

	} else {
		return E_NOT_OK;
	}

}

/*******************************************************************************
 *                              GetRemotePhysAddr                              *
 *******************************************************************************/


TcpIp_ReturnType TcpIp_GetRemotePhysAddr (uint8 CtrlIdx, const TcpIp_SockAddrType* IpAddrPtr, uint8* PhysAddrPtr, boolean initRes){

	/*[SWS_TcpIp_00139]*/
	if(CtrlIdx == -1 || IpAddrPtr->domain != TCPIP_AF_INET6){
		return TCPIP_E_PHYS_ADDR_MISS;
	}
	/*[SWS_TcpIp_00138] */
	else {

		TcpIp_SockAddrInet6Type * socket;
		socket = (TcpIp_SockAddrInet6Type*)IpAddrPtr;
		boolean isEqualAddr = TRUE;
		uint8 LocalAddrId = 255;

		for(uint8 i = 0; i< sizeof(IPv6Addr)/sizeof(uint32); i++){
			int j;
			for (j = 0; j < 4; j++) {
				if ( ((IPv6Addr*)socket->addr)->map32[i] != ndpCachelist[0].Inet6Addr[j]) {
			        isEqualAddr = FALSE;
			    }
			}
		}
		if(isEqualAddr == TRUE && ndpCachelist[0].State==TCPIP_NDP_ENTRY_VALID){
			 PhysAddrPtr[0]=ndpCachelist[0].PhysAddr[0];
			 PhysAddrPtr[1]=ndpCachelist[0].PhysAddr[1];
			 PhysAddrPtr[2]=ndpCachelist[0].PhysAddr[2];
			 PhysAddrPtr[3]=ndpCachelist[0].PhysAddr[3];
			 PhysAddrPtr[4]=ndpCachelist[0].PhysAddr[4];
			 PhysAddrPtr[5]=ndpCachelist[0].PhysAddr[5];
			 return TCPIP_E_OK;
		}
		if(initRes == TRUE){
			ndpCachelist[0].State=TCPIP_NDP_ENTRY_STATIC;
			ndpCachelist[0].Inet6Addr[0]=socket->addr[0];
			ndpCachelist[0].Inet6Addr[1]=socket->addr[1];
			ndpCachelist[0].Inet6Addr[2]=socket->addr[2];
			ndpCachelist[0].Inet6Addr[3]=socket->addr[3];
			ndpCachelist[0].State=TCPIP_NDP_ENTRY_STALE;

	        for (int i = 0; i < MAX_NUMBER_ADDRESSES; i++) {
	            if (TcpIp_LocalAddrTable[i].state == TCPIP_IPADDR_STATE_ASSIGNED) {
	            	LocalAddrId = TcpIp_LocalAddrTable[i].LocalAddrId;
	                break;
	            }
	        }
	        if(LocalAddrId == 255){
	        	return TCPIP_E_PHYS_ADDR_MISS;
	        }

	        EthIf_GetPhysAddr(TcpIp_LocalAddrTable[LocalAddrId].ctrlIdx, PhysAddrPtr);
		}


		return TCPIP_E_PHYS_ADDR_MISS;
	}


}

/*******************************************************************************
 *                              GetCtrlIdx                                     *
 *******************************************************************************/


Std_ReturnType TcpIp_GetCtrlIdx (TcpIp_LocalAddrIdType LocalAddrId,uint8* CtrlIdxPtr){

	  for(int i=0;i<MAX_NUMBER_ADDRESSES;i++){
	        if(TcpIp_LocalAddrTable[i].LocalAddrId==LocalAddrId && TcpIp_LocalAddrTable[i].state != TCPIP_IPADDR_STATE_UNASSIGNED){
	            *CtrlIdxPtr=TcpIp_LocalAddrTable[i].ctrlIdx;
	            return E_OK;
	        }
	    }
	    return E_NOT_OK;
}

/*******************************************************************************
 *                              GetNdpCacheEntries                             *
 *******************************************************************************/


Std_ReturnType TcpIp_GetNdpCacheEntries (uint8 ctrlIdx,uint32* numberOfElements,TcpIp_NdpCacheEntryType* entryListPtr){

	if(numberOfElements != NULL_PTR){

		TcpIp_NdpCacheEntryType *entryList;
		uint8 counter = 0;
		entryList = entryListPtr;

		for(int i=0;i<MAX_NUMBER_CHACHE;i++)
		    {
		        if(ndpCachelist[i].State==TCPIP_NDP_ENTRY_VALID){
		            if(counter <*numberOfElements) {
		                entryList->State = ndpCachelist[i].State;
		                entryList->Inet6Addr[0] = ndpCachelist[i].Inet6Addr[0];
		                entryList->Inet6Addr[1] = ndpCachelist[i].Inet6Addr[1];
		                entryList->Inet6Addr[2] = ndpCachelist[i].Inet6Addr[2];
		                entryList->Inet6Addr[3] = ndpCachelist[i].Inet6Addr[3];

		                entryList->PhysAddr[0] = ndpCachelist[i].PhysAddr[0];
		                entryList->PhysAddr[0] = ndpCachelist[i].PhysAddr[0];
		                entryList->PhysAddr[0] = ndpCachelist[i].PhysAddr[0];
		                entryList->PhysAddr[0] = ndpCachelist[i].PhysAddr[0];
		                entryList++;
		            }
		            counter++;
		        }
		        if(*numberOfElements==counter && *numberOfElements!=0) break;
		    }
		    /* Requirement: [SWS_TCPIP_00274][SWS_TCPIP_00275] */
		if (*numberOfElements==0){
		     entryListPtr=NULL_PTR;
		}
		*numberOfElements=counter;

		 return E_OK;
	} else {
		return E_NOT_OK;
	}
}

/* Description: This service initializes the TCP/IP Stack */
void TcpIp_Init (const TcpIp_ConfigType* ConfigPtr){
	/*ConfigPtr: Pointer to the configuration data of the TcpIp module*/

}

/*********************************************************************************
Sync/Asyc: Async
Reentrance: Reentrant for different SocketIds. Non reentrant for the same SocketId
Parameters: SocketId: Socket handle identifying the local socket resource
			Abort: TRUE: connection will immediately be terminated by sending a
			RST-Segment and releasing all related resources.
			FALSE: connection will be terminated after performing a regular
			connection termination handshake and releasing all related resources
Description: By this API service the TCP/IP stack is requested to close the socket and release all related resources.
Requirements: @SWS_TcpIp_00109, @SWS_TcpIp_00110]
**********************************************************************************/
Std_ReturnType TcpIp_Close (TcpIp_SocketIdType SocketId, boolean Abort){
	if(TcpIpTcpSocketMax <= SocketId)
	{
		return E_NOT_OK;
	}
	else
	{

	}

	if(FALSE == socket_list[SocketId].used)
	{
		return E_NOT_OK;
	}
	else
	{

	}

	if(Abort)
	{
		socket_list[SocketId].state = TCPIP_SOCKET_ABORT;
	}
	else
	{
		socket_list[SocketId].state = TCPIP_SOCKET_TERMINATE;
	}

	return E_OK;
}


/* Description: TCP/IP stack is requested to allocate a new socket. Note: Each
accepted incoming TCP connection also allocates a socket resource.*/
Std_ReturnType TcpIp_SoAdGetSocket (TcpIp_DomainType Domain, TcpIp_ProtocolType Protocol, TcpIp_SocketIdType* SocketIdPtr)
{
	/*Domain: IP address family*/
	/*Protocol: Socket protocol as sub-family of parameter type.*/
	/*SocketIdPtr: Pointer to socket identifier representing the requested socket.
		This socket identifier must be provided for all further API calls
		which requires a SocketId. Note: SocketIdPtr is only valid if return
		value is E_OK.*/
	TcpIp_SocketIdType sockIndex;	/*Specifies the available Socket Index*/
	uint8 error_code;

	if(Domain != TCPIP_AF_INET && Domain != TCPIP_AF_INET6){
		/* Address family not supported by protocol family */
		error_code = TCPIP_E_AFNOSUPPORT;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}

	if (Protocol != TCPIP_IPPROTO_TCP && Protocol != TCPIP_IPPROTO_UDP){
		/* Protocol wrong type for socket */
		error_code = TCPIP_E_PROTOTYPE;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}

	sockIndex = getAvailableSocket();

	socket_list[sockIndex].domain = Domain;
	socket_list[sockIndex].protocol = Protocol;
	socket_list[sockIndex].socketId = sockIndex;
	socket_list[sockIndex].used = TRUE;
	socket_list[sockIndex].state = TCPIP_SOCKET_CLOSED;
	socket_list[sockIndex].startRetransmissionTimeout = FALSE;
	socket_list[sockIndex].retransmissionTimeout = TcpIpTcpRetransmissionTimeout;
	TcpIpBuffer[sockIndex].bufferPtrIdx = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
	TcpIpBuffer[sockIndex].acquired = FALSE;
	TcpIpBuffer[sockIndex].buffReady = FALSE;

	*SocketIdPtr = sockIndex;

	return E_OK;
}


/*********************************************************************************
Sync/Asyc: Sync
Reentrance: Reentrant for different SocketIds. Non reentrant for the same SocketId
Parameters: SocketId: Socket identifier of the related local socket resource
			LocalAddrId: IP address identifier representing the local IP address and EthIf
						controller to bind the socket to pointer to memory where the local
						port to which the socket shall be bound is specified
Description:  By this API service the TCP/IP stack is requested to bind a UDP or TCP socket to a local resource
Requirements: @SWS_TcpIp_00111, @SWS_TcpIp_00146, @SWS_TcpIp_00147, @SWS_TcpIp_00254
**********************************************************************************/
Std_ReturnType TcpIp_Bind (TcpIp_SocketIdType SocketId, TcpIp_LocalAddrIdType LocalAddrId, uint16* PortPtr)
{
	uint8 error_code;

	if(LocalAddrId != 0)
	{
		error_code = TCPIP_E_ADDRNOTAVAIL;
		/*
			Det Error
		*/
		return E_NOT_OK;
	}

	/*Check for Development Error*/
	/*Check if address is invalid*/

	for(uint8 i = 0; i < 4; i++)
	{
		socket_list[SocketId].localIpV6Address.addr[i] = TcpIp_LocalAddrTable[0].ipv6addr.map32[i];
	}

	/*Check if there is another socket already bound to the same port,
		protocol and local address for the TCP Protocol*/
	for(uint8 i = 0; i < TcpIpTcpSocketMax; i++)
	{
		if(socket_list[i].used)
		{
			if(i != SocketId)
			{
				uint8 ipv6_idx = 0;
				for(ipv6_idx = 0; ipv6_idx < 4; ipv6_idx++)
				{
					if(socket_list[i].localIpV6Address.addr[ipv6_idx] == socket_list[i].localIpV6Address.addr[ipv6_idx])
					{
						error_code = TCPIP_E_ADDRINUSE;
						/*
							Det Error
						*/
						return E_NOT_OK;
					}
					else
					{

					}
				}
			}
		}
	}

	socket_list[SocketId].TcpIpAddrId = LocalAddrId;
	socket_list[SocketId].localIpV6Address.port = *PortPtr;

	return E_OK;
}


/*********************************************************************************
Sync/Async: Asynchronous
Reentrance: Reentrant for different SocketIds. Non reentrant for the same SocketId
Parameters: SocketId: Socket identifier of the related local socket resource.
	   		RemoteAddrPtr: IP address and port of the remote host to connect to.
Description:  By this API service the TCP/IP stack is requested to establish a TCP connection to the configured peer
Requirements: @SWS_TcpIp_00112, @SWS_TcpIp_00129
**********************************************************************************/
Std_ReturnType TcpIp_TcpConnect (TcpIp_SocketIdType SocketId, const TcpIp_SockAddrType* RemoteAddrPtr){
	uint8 error_code;
	if(SocketId >= TcpIpTcpSocketMax){
		return E_NOT_OK;
	}

	if (RemoteAddrPtr == NULL_PTR){
		error_code = TCPIP_E_PARAM_POINTER;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}

	if(socket_list[SocketId].used == FALSE){
		error_code = TCPIP_E_INV_ARG;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}

	if(socket_list[SocketId].state != TCPIP_SOCKET_CLOSED){
		error_code = TCPIP_E_ISCONN;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}

	/*Check the Domain Type*/
#if TcpIpIpV4Enabled == TRUE
	/*IPV4 is used*/
	if(RemoteAddrPtr->domain == TCPIP_AF_INET){
		TcpIp_SockAddrInetType* remoteAdr = (TcpIp_SockAddrInetType*)RemoteAddrPtr;
		socket_list[SocketId].remoteIpV4Address.domain  = TCPIP_AF_INET;
		socket_list[SocketId].remoteIpV4Address.addr[0] = remoteAdr->addr[0];
		socket_list[SocketId].remoteIpV4Address.addr[1] = remoteAdr->addr[1];
		socket_list[SocketId].remoteIpV4Address.addr[2] = remoteAdr->addr[2];
		socket_list[SocketId].remoteIpV4Address.addr[3] = remoteAdr->addr[3];
		socket_list[SocketId].remoteIpV4Address.port = remoteAdr->port;
	}
	else{
		error_code = TCPIP_E_INV_ARG;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}
#endif

	/*IPV6 is used*/
#if TcpIpIpV6Enabled == TRUE
	if (RemoteAddrPtr->domain == TCPIP_AF_INET6){
		TcpIp_SockAddrInet6Type* remoteAdr = (TcpIp_SockAddrInet6Type*)RemoteAddrPtr;
		socket_list[SocketId].remoteIpV6Address.domain  = TCPIP_AF_INET6;
		socket_list[SocketId].remoteIpV6Address.addr[0] = remoteAdr->addr[0];
		socket_list[SocketId].remoteIpV6Address.addr[1] = remoteAdr->addr[1];
		socket_list[SocketId].remoteIpV6Address.addr[2] = remoteAdr->addr[2];
		socket_list[SocketId].remoteIpV6Address.addr[3] = remoteAdr->addr[3];
		socket_list[SocketId].remoteIpV6Address.port = remoteAdr->port;
	}
	else{
		error_code = TCPIP_E_INV_ARG;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}
#endif

	socket_list[SocketId].state = TCPIP_SOCKET_CONNECTED;
	socket_list[SocketId].curSeqNum = 0;
	socket_list[SocketId].curAckNum = 0;

	return E_OK;
}


/*********************************************************************************
Sync/Async: Asynchronous
Reentrance: Reentrant for different SocketIds. Non reentrant for the same SocketId
Parameters: SocketId: Socket identifier of the related local socket resource.
	   		MaxChannels: Maximum number of new parallel connections established on this listen connection.
Description:  By this API service the TCP/IP stack is requested to listen on the TCP socket specified by the socket identifier.
Requirements: @SWS_TcpIp_00113, @SWS_TcpIp_00114(DEVIATED..... No Parallel Connections)
**********************************************************************************/
Std_ReturnType TcpIp_TcpListen (TcpIp_SocketIdType SocketId, uint16 MaxChannels){

	uint8 error_code;
	if(SocketId >= TcpIpTcpSocketMax){
		return E_NOT_OK;
	}

	if(socket_list[SocketId].used == FALSE){
		error_code = TCPIP_E_INV_ARG;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}

	if(socket_list[SocketId].state != TCPIP_SOCKET_CLOSED){
		error_code = TCPIP_E_ISCONN;
		/*
			Call Det API
		 */
		return E_NOT_OK;
	}

	socket_list[SocketId].state = TCPIP_SOCKET_LISTEN;

	return E_OK;
}


/*********************************************************************************
Sync/Async: Asynchronous
Reentrance: Reentrant for different SocketIds. Non reentrant for the same SocketId
Parameters: SocketId: Socket identifier of the related local socket resource.
	   		DataPtr: Pointer to a linear buffer of AvailableLength bytes containing the
					 data to be transmitted. In case DataPtr is a NULL_PTR, TcpIp
					 shall retrieve data from upper layer via callback <Up>_CopyTx
					 Data().
			AvailableLength: Available data for transmission in bytes.
			ForceRetrieve: This parameter is only valid if DataPtr is a NULL_PTR. Indicates
						   	how the TCP/IP stack retrieves data from upper layer if DataPtr is
							a NULL_PTR. TRUE: the whole data indicated by availableLength
							shall be retrieved from the upper layer via one or multiple <Up>_
							CopyTxData() calls within the context of this transmit function.
							FALSE: The TCP/IP stack may retrieve up to availableLength
							data from the upper layer. It is allowed to retrieve less than
							availableLength bytes. Note: Not retrieved data will be provided
							by upper layer with the next call to TcpIp_TcpTransmit (along with new data if available).
Description:  This service requests transmission of data via TCP to a remote node. The transmission of the data is decoupled.
			Note: The TCP segment(s) are sent dependent on runtime factors (e.g. receive window) and
			configuration parameter (e.g. Nagle algorithm) .
Requirements: @SWS_TcpIp_00123, @SWS_TcpIp_00124, @SWS_TcpIp_00125 (DEVIATED... ForceRetrieve is not used, Nagle Algorithm is not used)
**********************************************************************************/
Std_ReturnType TcpIp_TcpTransmit (TcpIp_SocketIdType SocketId, const uint8* DataPtr, uint32 AvailableLength, boolean ForceRetrieve){

	//Check that socket id passed is within range
	if(SocketId >= TcpIpTcpSocketMax){
		return E_NOT_OK;
	}
	//Checking for socket state and making sure that it's in the connection established state
	if(TCPIP_SOCKET_ESTABLISHED != socket_list[SocketId].state){
		return E_NOT_OK;
	}
	//Check for segment size to be sent whether if its greater than buffer size
	if ((AvailableLength + TcpIpBuffer[SocketId].bufferPtrIdx) > TcpIpMaxSegmentSize){
		return E_NOT_OK;
	}

	if(DataPtr != NULL_PTR){
		TcpIp_GetPacket(SocketId, DataPtr, AvailableLength);
	}
	return E_OK;
}


void TcpIp_MainFunction(void){

	TcpIp_SocketIdType curInd;
	for(curInd = 0; curInd < TcpIpTcpSocketMax; curInd++)
	{
		if(FALSE == socket_list[curInd].used)
		{

		}
		else{
#if TcpIpTcpRetransmissionTimeout != 0
			if(TRUE == socket_list[curInd].startRetransmissionTimeout)
			{
				(socket_list[curInd].retransmissionCntr)++;
				if(TRUE == isTimeout(socket_list[curInd].retransmissionCntr, socket_list[curInd].retransmissionTimeout))
				{
					socket_list[curInd].retransmit = TRUE;
				}
				else
				{
					socket_list[curInd].retransmit = FALSE;
				}
			}
#endif

			/* 3 way handshake Client */
			if(TCPIP_SOCKET_CONNECTED == socket_list[curInd].state){
				uint8* bufPtr = NULL_PTR;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_SYN_FLAG, 1, &bufPtr, TCPIP_TCP_HEADER_SIZE);
			
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);

				socket_list[curInd].state = TCPIP_SOCKET_SYN_SENT;

				socket_list[curInd].startRetransmissionTimeout = TRUE;
			}

			/* 3 way handshake Client */
			if(TCPIP_SOCKET_SYN_ACK_REC == socket_list[curInd].state){
				uint8* bufPtr;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_ACK_FLAG, 3, &bufPtr, TCPIP_TCP_HEADER_SIZE);
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);

				TX_Flag = 1;
				for(uint32 i = 0; i < 2000000; i++);
				socket_list[curInd].state = TCPIP_SOCKET_ESTABLISHED;
				SoAd_TcpConnected (curInd);
			}

			/* 3 way handshake Server */
			if(TCPIP_SOCKET_SYN_REC == socket_list[curInd].state){
				uint8* bufPtr;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_SYN_FLAG | TCPIP_ACK_FLAG, 2, &bufPtr, TCPIP_TCP_HEADER_SIZE);
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);

				socket_list[curInd].state = TCPIP_SOCKET_SYN_ACK_SENT;

				socket_list[curInd].startRetransmissionTimeout = TRUE;
			}

			/* Transmission */
			if(TCPIP_SOCKET_ESTABLISHED == socket_list[curInd].state){

				if(TcpIpBuffer[curInd].buffReady){
					//Get the ethif to allocate it's buffer
					TcpIp_BufferDataLen[curInd] = TcpIpBuffer[curInd].bufferPtrIdx;
					uint8* ptr = (TcpIpBuffer[curInd].tcpData);
					TcpIp_GetPacketHeader(curInd, 0, 4/*Sequence number*/, &ptr, TcpIpBuffer[curInd].bufferPtrIdx - TCPIP_IPV6_HEADER_SIZE);
					uint8* bufPtr;
					Eth_BufIdxType bufIdx;
					uint16 length = TcpIpBuffer[curInd].bufferPtrIdx;
					EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
					TcpIp_EthIf_CopyToBuffer(&bufPtr, &ptr, TcpIpBuffer[curInd].bufferPtrIdx);
					EthIf_Transmit(0, bufIdx, 0x867, TRUE, TcpIpBuffer[curInd].bufferPtrIdx, My_Phys_Addr);
					TcpIpBuffer[curInd].bufferPtrIdx = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE; /*Return To initial Value After Packet is sent*/
					socket_list[curInd].state = TCPIP_SOCKET_TRANSMIT_DONE;

					socket_list[curInd].startRetransmissionTimeout = TRUE;
				}
			}

			/* Sending ACK after Reception */
			if(TCPIP_SOCKET_RECPETION_SEND_ACK == socket_list[curInd].state){
				uint8* bufPtr;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_ACK_FLAG, 3, &bufPtr, TCPIP_TCP_HEADER_SIZE);
				TX_Flag = 1;
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);

				for(uint32 i = 0; i < 2000000; i++);
				socket_list[curInd].state = TCPIP_SOCKET_ESTABLISHED;
			}

			/* Termination (Requester) */
			if(TCPIP_SOCKET_ABORT == socket_list[curInd].state){
				uint8* bufPtr;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_RST_FLAG, 2, &bufPtr, TCPIP_TCP_HEADER_SIZE);
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);

				socket_list[curInd].state = TCPIP_SOCKET_CLOSED;
				socket_list[curInd].used = FALSE;
			}

			/* Termination (Requester) */
			if(TCPIP_SOCKET_TERMINATE == socket_list[curInd].state){
				uint8* bufPtr;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_FIN_FLAG, 2, &bufPtr, TCPIP_TCP_HEADER_SIZE);
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);

				socket_list[curInd].state = TCPIP_SOCKET_FIN_WAIT_1;

				socket_list[curInd].startRetransmissionTimeout = TRUE;
			}

			/* Termination (Requester) */
			if(TCPIP_SOCKET_FINAL_ACK == socket_list[curInd].state){
				uint8* bufPtr;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &bufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_ACK_FLAG, 2, &bufPtr, TCPIP_TCP_HEADER_SIZE);
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);

				socket_list[curInd].state = TCPIP_SOCKET_CLOSED;
				socket_list[curInd].used = FALSE;
			}

			/* Termination (Responser) */
			if(TCPIP_SOCKET_CLOSE_WAIT == socket_list[curInd].state){
				uint8* ackBufPtr;
				uint8* finBufPtr;
				Eth_BufIdxType bufIdx;
				uint16 length = TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE;
				EthIf_ProvideTxBuffer(0, 0x867, 0, &bufIdx, &ackBufPtr, &length);
				TcpIp_GetPacketHeader(curInd, TCPIP_ACK_FLAG, 2, &ackBufPtr, TCPIP_TCP_HEADER_SIZE);
				EthIf_Transmit(0, bufIdx, 0x867, TRUE, TCPIP_TCP_HEADER_SIZE + TCPIP_IPV6_HEADER_SIZE, My_Phys_Addr);
				
				socket_list[curInd].state = TCPIP_SOCKET_FINAL_ACK_WAIT;

				socket_list[curInd].startRetransmissionTimeout = TRUE;
			}

			/* Retransmission */
			if(TRUE == socket_list[curInd].retransmit)
			{
				/* Retransmit SYN */
				if(TCPIP_SOCKET_SYN_SENT == socket_list[curInd].state)
				{
					socket_list[curInd].state = TCPIP_SOCKET_CONNECTED;
					socket_list[curInd].retransmissionCntr = 0;
					socket_list[curInd].retransmit = FALSE;
				}
				/* Retransmit SYN ACK */
				else if(TCPIP_SOCKET_SYN_ACK_SENT == socket_list[curInd].state)
				{
					socket_list[curInd].state = TCPIP_SOCKET_SYN_REC;
					socket_list[curInd].retransmissionCntr = 0;
					socket_list[curInd].retransmit = FALSE;
				}
				/* Retransmit Data */
				else if(TCPIP_SOCKET_TRANSMIT_DONE == socket_list[curInd].state)
				{
					TcpIpBuffer[curInd].bufferPtrIdx = TcpIp_BufferDataLen[curInd];
					socket_list[curInd].state = TCPIP_SOCKET_ESTABLISHED;
					socket_list[curInd].retransmissionCntr = 0;
					socket_list[curInd].retransmit = FALSE;					
				}
				/* Retransmit FIN */
				else if(TCPIP_SOCKET_FIN_WAIT_1 == socket_list[curInd].state)
				{
					socket_list[curInd].state = TCPIP_SOCKET_TERMINATE;
					socket_list[curInd].retransmissionCntr = 0;
					socket_list[curInd].retransmit = FALSE;
				}
				/* Retransmit ACK-FIN */
				else if(TCPIP_SOCKET_FINAL_ACK_WAIT == socket_list[curInd].state)
				{
					socket_list[curInd].state = TCPIP_SOCKET_CLOSE_WAIT;
					socket_list[curInd].retransmissionCntr = 0;
					socket_list[curInd].retransmit = FALSE;					
				}
			}
		}
	}
}

void TcpIp_RxIndication (uint8 CtrlIdx, Eth_FrameType FrameType,
	boolean IsBroadcast, const uint8* PhysAddrPtr, const uint8* DataPtr, uint16 LenByte){

	TcpIp_SocketIdType curInd;

	uint8* ptr = DataPtr;
	uint8 dummmmmmy[60];
	for(int i = 0; i < 60; i++){
	dummmmmmy[i] = DataPtr[i];
	}
	ptr = ptr + TCPIP_IPV6_HEADER_SIZE;

	for(curInd = 0; curInd < TcpIpTcpSocketMax; curInd++){
		if(FALSE == socket_list[curInd].used){

		}
		else{
			/* 3 way Handshake Client */
			if(TCPIP_SOCKET_SYN_SENT == socket_list[curInd].state){
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){

					if((socket_list[curInd].curFlags & TCPIP_SYN_FLAG) && (socket_list[curInd].curFlags & TCPIP_ACK_FLAG)){
						socket_list[curInd].state = TCPIP_SOCKET_SYN_ACK_REC;

						socket_list[curInd].startRetransmissionTimeout = FALSE;
						socket_list[curInd].retransmissionCntr = 0;
						socket_list[curInd].retransmit = FALSE;
					}
					else{
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
						TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_SYN_SENT;
					}

				}
			}

			/* 3 way Handshake Server */
			else if(TCPIP_SOCKET_LISTEN == socket_list[curInd].state){
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){

					if(socket_list[curInd].curFlags & TCPIP_SYN_FLAG){
						socket_list[curInd].state = TCPIP_SOCKET_SYN_REC;
					}
					else{
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
						TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_LISTEN;
					}
				}
			}

			/* 3 way Handshake Server */
			else if(TCPIP_SOCKET_SYN_ACK_SENT == socket_list[curInd].state){
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){

					if(socket_list[curInd].curFlags & TCPIP_ACK_FLAG){
						socket_list[curInd].state = TCPIP_SOCKET_ESTABLISHED;

						socket_list[curInd].startRetransmissionTimeout = FALSE;
						socket_list[curInd].retransmissionCntr = 0;
						socket_list[curInd].retransmit = FALSE;

						SoAd_TcpAccepted(curInd, curInd, (TcpIp_SockAddrType*)&socket_list[curInd].remoteIpV6Address);
					}
					else{
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
						TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_SYN_ACK_SENT;
					}

				}
			}

			/* Transmission done with ACK */
			else if(TCPIP_SOCKET_TRANSMIT_DONE == socket_list[curInd].state){
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){

					if(socket_list[curInd].curFlags & TCPIP_ACK_FLAG){
						RX_Flag = 0;
						socket_list[curInd].state = TCPIP_SOCKET_ESTABLISHED;
						TcpIpBuffer[curInd].acquired = FALSE;
						TcpIpBuffer[curInd].buffReady = FALSE;
						SoAd_TxConfirmation(curInd, LenByte);

						socket_list[curInd].startRetransmissionTimeout = FALSE;
						socket_list[curInd].retransmissionCntr = 0;
						socket_list[curInd].retransmit = FALSE;
					}
					else{
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
						TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_TRANSMIT_DONE;
					}

				}
			}

			/* Reception */
			else if(TCPIP_SOCKET_ESTABLISHED == socket_list[curInd].state)
			{
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){
					if((socket_list[curInd].curFlags & TCPIP_FIN_FLAG) || (socket_list[curInd].curFlags & TCPIP_RST_FLAG)){
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
					}
					else{
						TcpIp_SockAddrType* genericAddress = (TcpIp_SockAddrType*)&(socket_list[curInd].remoteIpV6Address);
						SoAd_RxIndication(curInd, genericAddress, DataPtr+TCPIP_TCP_HEADER_SIZE+TCPIP_IPV6_HEADER_SIZE, LenByte);
					}
				}
				else
				{
					socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
					TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_ESTABLISHED;
				}

			}

			/* Termination (Requester) */
			else if(TCPIP_SOCKET_FIN_WAIT_1 == socket_list[curInd].state){
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){

					if(socket_list[curInd].curFlags & TCPIP_ACK_FLAG){
						socket_list[curInd].state = TCPIP_SOCKET_FIN_WAIT_2;

						socket_list[curInd].startRetransmissionTimeout = FALSE;
						socket_list[curInd].retransmissionCntr = 0;
						socket_list[curInd].retransmit = FALSE;
					}
					else{
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
						TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_FIN_WAIT_1;
					}

				}
			}

			/* Termination (Requester) */
			else if(TCPIP_SOCKET_FIN_WAIT_2 == socket_list[curInd].state){
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){

					if(socket_list[curInd].curFlags & TCPIP_FIN_FLAG){
						socket_list[curInd].state = TCPIP_SOCKET_FINAL_ACK;
					}
					else{
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
						TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_FIN_WAIT_2;
					}

				}
			}

			/* Termination (Responser) */
			else if(TCPIP_SOCKET_FINAL_ACK_WAIT == socket_list[curInd].state){
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				 E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE)){

					if(socket_list[curInd].curFlags & TCPIP_ACK_FLAG){
						socket_list[curInd].state = TCPIP_SOCKET_CLOSED;
						socket_list[curInd].used = FALSE;

						socket_list[curInd].startRetransmissionTimeout = FALSE;
						socket_list[curInd].retransmissionCntr = 0;
						socket_list[curInd].retransmit = FALSE;
					}
					else{
						socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
						TcpIp_lastSavedState[curInd] = TCPIP_SOCKET_FINAL_ACK_WAIT;
					}

				}
			}
			else{
				if(E_OK == TcpIp_DecodeIpV6Header(curInd, DataPtr) &&
				E_OK == TcpIp_DecodeTcpHeader(curInd, DataPtr + TCPIP_IPV6_HEADER_SIZE))
				{
					socket_list[curInd].state = TCPIP_SOCKET_UNEXPECTED;
				}
				else
				{
					/* Discard Corrupt Data */
				}
			}

			/* Received Unexpected */
			if(socket_list[curInd].state == TCPIP_SOCKET_UNEXPECTED)
			{
				/* Received FIN for termination handshake */
				if(socket_list[curInd].curFlags & TCPIP_FIN_FLAG){

					socket_list[curInd].state = TCPIP_SOCKET_CLOSE_WAIT;

				}
				/* Received RST for immediate termination */
				else if(socket_list[curInd].curFlags & TCPIP_RST_FLAG){

					socket_list[curInd].state = TCPIP_SOCKET_CLOSED;
					socket_list[curInd].used = FALSE;

				}
				else{
					/* Discard Corrupt Data and return to last saved state */
					socket_list[curInd].state = TcpIp_lastSavedState[curInd];
				}

			}
			else{

			}
		}
	}
}

/*********************************************************************************
Sync/Async: Asynchronous
Reentrance: Reentrant for different SocketIds. Non reentrant for the same SocketId
Parameters: SocketId: Socket identifier of the related local socket resource.
	   		DataPtr: Pointer to a linear buffer of AvailableLength bytes containing the
					 data to be transmitted. In case DataPtr is a NULL_PTR, TcpIp
					 shall retrieve data from upper layer via callback <Up>_CopyTx
					 Data().
			Length: Number of bytes finally consumed by the upper layer.
Description: By this API service the reception of socket data is confirmed to the TCP/IP stack.
Requirements: @SWS_TcpIp_00115(DEVIATED...)
**********************************************************************************/
Std_ReturnType TcpIp_TcpReceived (TcpIp_SocketIdType SocketId, uint32 Length){
	if(TcpIpTcpSocketMax <= SocketId)
	{
		return E_NOT_OK;
	}
	if((TCPIP_SOCKET_CLOSED == socket_list[SocketId].state) || (FALSE == socket_list[SocketId].used))
	{
		return E_NOT_OK;
	}
	socket_list[SocketId].state = TCPIP_SOCKET_RECPETION_SEND_ACK;

	return E_OK;
}
