/******************************************************************************
*
* Module: Wireless Ethernet
*
* File Name: Weth.c
*
* Description: Source File For the Wireless Ethernet Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/

#include "WEth.h"

#if (WETH_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
/* AUTOSAR checking between Det.h and WEth.h
*
*/


#if ((DET_AR_MAJOR_VERSION != WETH_AR_RELEASE_MAJOR_VERSION)\
||  (DET_AR_MINOR_VERSION != WETH_AR_RELEASE_MINOR_VERSION)\
  ||  (DET_AR_PATCH_VERSION != WETH_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Det.h does not match the expected version"
#endif

#endif

#include "EthIf_Callbacks.h"
/* AUTOSAR checking between EthIf_Callbacks.h and WEth.h
*
*/
#include "Compiler.h"

#if ((ETHIF_CALLLBACKS_AR_RELEASE_MAJOR_VERSION != WETH_AR_RELEASE_MAJOR_VERSION)\
||  (ETHIF_CALLLBACKS_AR_RELEASE_MINOR_VERSION != WETH_AR_RELEASE_MINOR_VERSION)\
  ||  (ETHIF_CALLLBACKS_AR_RELEASE_PATCH_VERSION != WETH_AR_RELEASE_PATCH_VERSION))
#error "The AR version of EthIf_Callbacks.h does not match the expected version"
#endif


#include "stm32f4xx_hal.h"

/*******************************************************************************
*                      Global Variables                                    *
*******************************************************************************/

/*Variable for Storing Configuration Struct*/
STATIC const WEth_ConfigType* Weth_Stored_Config_Struct;
/*Variable for Storing Initializtion State*/
STATIC WEth_State_Type WEth_Init_State = WETH_UINITIALIZED;
/*Variable for Storing Controllers Current Mode*/
STATIC Eth_ModeType WEth_Controller_Current_Mode[ WETH_CONTROLLER_SIZE] = {ETH_MODE_DOWN};
/*Variable for Storing Controllers Previous Mode*/
STATIC Eth_ModeType WEth_Controller_Previous_Mode[WETH_CONTROLLER_SIZE] = {ETH_MODE_DOWN};
/*Variable used For Transmission Buffering*/
uint8 WEth_Tx_Buffers[WETH_TX_MAX_BUFFER_NUM][WETH_TX_MAX_BUFFER_SIZE];
/*Variable used For Reserving Transmission Buffers*/
STATIC boolean WEth_Tx_Flag[WETH_TX_MAX_BUFFER_NUM] = {FREE_BUFFER};
/*Variable used For Storing the Transmission Buffer to be confirmed*/
STATIC boolean BufIdx_Unconfirmed[WETH_TX_MAX_BUFFER_NUM];
/*Variable used For Storing the Transmission Buffers which confirmation is enabled*/
STATIC boolean Tx_Confirm_flag[WETH_TX_MAX_BUFFER_NUM] = {FALSE};
/*Variable used For Storing the Transmission Result of Buffers*/
STATIC Std_ReturnType Tx_transmit_result[WETH_TX_MAX_BUFFER_NUM] = {E_NOT_OK};
/*Variable used For Recieve Buffers*/
uint8 WEth_Rx_Buffers[WETH_RX_MAX_BUFFER_SIZE];
/*Variable used For Recieve Buffers Sizes*/
uint16 Weth_Rx_Buffers_Size;
/*Variable used For Fragmented Recieve Buffers*/
STATIC uint8 WEth_Rx_Buffer_Fragmented[WETH_RX_MAX_BUFFER_SIZE+15];
/*Variable used For Storing the A Controllers Mac Address*/
uint8 Controllers_MAC_Addr[WETH_CONTROLLER_SIZE][MAC_ADDR_SIZE];

//extern SPI_HandleTypeDef hspi5;
extern SPI_HandleTypeDef hspi2;
//extern UART_HandleTypeDef huart4;
uint8_t temp_arr[WETH_TX_MAX_BUFFER_SIZE+2];
uint8_t flag = 0;
uint8_t RX_Size_Flag = 0;
/*******************************************************************************
*                      Function Definitions                                    *
*******************************************************************************/

/************************************************************************************
* Service Name: WEth_Init
* Service ID[hex]: 0x01
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CfgPtr - Pointer to post-build configuration data
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Initializes the Wireless Ethernet Driver.
* Requirements: SWS_WEth_00027,SWS_WEth_00028, SWS_WEth_00029,
*  			 ,SWS_WEth_00031
************************************************************************************/

void WEth_Init (const WEth_ConfigType* CfgPtr)
{
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* check if the input configuration pointer is not a NULL_PTR */
  if (NULL_PTR == CfgPtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_INIT_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  /* Requirement: SWS_WEth_00028 */
  Weth_Stored_Config_Struct = CfgPtr;
  
  /* Requirement: SWS_WEth_00029 */
  
  WEth_Init_State = WETH_INITIALIZED;
  
  /* Requirement: SWS_WEth_00034 ??*/
  for (uint8 i = 0 ; i < WETH_CONTROLLER_SIZE ; i++)
  {
    for (uint8 j = 0; j < MAC_ADDR_SIZE ; j++)
    {
      Controllers_MAC_Addr[i][j] = Weth_Stored_Config_Struct->CtrlConfig[i].WEthCtrlPhyAddress[j];
    }
  }
  HAL_SPI_DeInit(&hspi2);

  //!!!!!!!!!!!CONFIGURE SPI!!!!!!!!;

  HAL_SPI_Init(&hspi2);
#if (ETHIF_ENABLE_TX_INTERRUPT == STD_ON)
  SET_TRANSMIT_INTERRUPT_CALLBACK (WEth_TxIrqHdlr);
#endif
  
#if (ETHIF_ENABLE_RX_INTERRUPT == STD_ON)
  SET_RECIEVE_INTERRUPT_CALLBACK (WEth_RxIrqHdlr);
#endif
}


/************************************************************************************
* Service Name: WEth_SetControllerMode
* Service ID[hex]: 0x03
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 		       CtrlMode - ETH_MODE_DOWN: disable the controller
* 						   ETH_MODE_ACTIVE: enable the controller
* Parameters (inout): None
* Parameters (out): None
* Return value:Std_ReturnType - E_OK: success
E_NOT_OK: controller mode could not be changed
* Description:  Enables / disables the indexed controller
* Requirements: SWS_WEth_00041,SWS_WEth_00042, SWS_WEth_00043,
*  			 ,SWS_WEth_00044,SWS_WEth_00045,SWS_WEth_00168
************************************************************************************/

Std_ReturnType WEth_SetControllerMode (uint8 CtrlId,Eth_ModeType CtrlMode)
{
  Std_ReturnType return_value = E_NOT_OK;
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00043*/
  /* Requirement: SWS_WEth_00045*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_SET_CONTROLLER_MODE_SID ,WETH_E_UNINIT);
    return return_value;
  }
  /* Requirement: SWS_WEth_00044*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_SET_CONTROLLER_MODE_SID ,WETH_E_INV_CTRL_ID);
    return return_value;
  }
#endif
  
  /* Requirement: SWS_WEth_00042*/
  if (CtrlMode == ETH_MODE_DOWN)
  {
    WEth_Controller_Previous_Mode [CtrlId] = WEth_Controller_Current_Mode[CtrlId];
    WEth_Controller_Current_Mode[CtrlId] = CtrlMode;
    for (uint8 i= 0 ; i<WETH_TX_MAX_BUFFER_NUM;i++)
    {
      WEth_Tx_Flag[i] = FREE_BUFFER;
    }
    HAL_SPI_MspDeInit(&hspi2);
    
    return_value = E_OK;
  }
  
  else if (CtrlMode == ETH_MODE_ACTIVE)
  {
    WEth_Controller_Previous_Mode [CtrlId] = WEth_Controller_Current_Mode[CtrlId];
    WEth_Controller_Current_Mode[CtrlId] = CtrlMode; 
    HAL_SPI_Init(&hspi2);
    
    return_value = E_OK;
  }
  // is this Correct??? or IN MAIN FUNCTION
  //EthIf_CtrlModeIndication(CtrlId , WEth_Controller_Current_Mode[CtrlId]);
  return return_value;
}

/************************************************************************************
* Service Name: WEth_GetControllerMode
* Service ID[hex]: 0x04
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): CtrlModePtr - ETH_MODE_DOWN: the controller is disabled
* 								   ETH_MODE_ACTIVE: the controller is enabled
* Return value:Std_ReturnType - E_OK: success
E_NOT_OK:  controller mode could not be obtained

* Description:  Obtains the state of the indexed controller
* Requirements: SWS_WEth_00046,SWS_WEth_00047, SWS_WEth_00048,
*  			 ,SWS_WEth_00049,SWS_WEth_00050,SWS_WEth_00051
************************************************************************************/

Std_ReturnType WEth_GetControllerMode (uint8 CtrlId,Eth_ModeType* CtrlModePtr)
{
  Std_ReturnType return_value = E_NOT_OK;
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00048*/
  /* Requirement: SWS_WEth_00051*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_UNINIT);
    return return_value;
  }
  /* Requirement: SWS_WEth_00049*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_INV_CTRL_ID);
    return return_value;
    
  }
  /* Requirement: SWS_WEth_00050*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == CtrlModePtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_PARAM_POINTER);
    return return_value;
  }
#endif
  /* Requirement: SWS_WEth_00047*/
  *CtrlModePtr = WEth_Controller_Current_Mode[CtrlId];
  return_value = E_OK;
  
  return return_value;
}

/************************************************************************************
* Service Name: WEth_GetPhysAddr
* Service ID[hex]: 0x08
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): PhysAddrPtr - Physical source address (MAC address) in network byte order
* Return value: None
* Description:  Obtains the physical source address used by the indexed controller.
* Requirements: SWS_WEth_00052,SWS_WEth_00053, SWS_WEth_00054,
*  			 ,SWS_WEth_00055,SWS_WEth_00056,SWS_WEth_00057
************************************************************************************/
void WEth_GetPhysAddr (uint8 CtrlId,uint8* PhysAddrPtr)
{
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00054*/
  /* Requirement: SWS_WEth_00057*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_UNINIT);
  }
  /* Requirement: SWS_WEth_00055*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_INV_CTRL_ID);
    
  }
  /* Requirement: SWS_WEth_00056*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == PhysAddrPtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  for (uint8 i = 0; i < MAC_ADDR_SIZE ; i++)
  {
    PhysAddrPtr[i] = Controllers_MAC_Addr[CtrlId][i];
  }
  
}

/************************************************************************************
* Service Name: WEth_SetPhysAddr
* Service ID[hex]: 0x13
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					PhysAddrPtr - Pointer to memory containing the physical source address (MAC address) in network byte order.
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Sets the physical source address used by the indexed controller
* Requirements: SWS_WEth_00151,SWS_WEth_00139, SWS_WEth_00140,
*  			 ,SWS_WEth_00141,SWS_WEth_00142,SWS_WEth_00143
************************************************************************************/
void WEth_SetPhysAddr (uint8 CtrlId,const uint8* PhysAddrPtr)
{
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00140*/
  /* Requirement: SWS_WEth_00143*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_UNINIT);
  }
  /* Requirement: SWS_WEth_00141*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_INV_CTRL_ID);
    
  }
  /* Requirement: SWS_WEth_00142*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == PhysAddrPtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_CONTROLLER_MODE_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  /* Requirement: SWS_WEth_00139*/
  for (uint8 i = 0; i < MAC_ADDR_SIZE ; i++)
  {
    Controllers_MAC_Addr[CtrlId][i] = PhysAddrPtr[i];
  }
}

/************************************************************************************
* Service Name: WEth_ProvideTxBuffer
* Service ID[hex]: 0x09
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					Priority Priority value used for selection of different wireless transmit queues
* Parameters (inout): LenBytePtr In: desired length in bytes, out: granted length in bytes
* Parameters (out): BufIdPtr - Index to the granted buffer resource. To be used for subsequent requests.
* 					 BufPtr - Pointer to the granted buffer.
* Return value: BufReq_ReturnType BUFREQ_OK: success
BUFREQ_E_NOT_OK: default error detected
BUFREQ_E_BUSY: all buffers in use
BUFREQ_E_OVFL: requested buffer too large
* Description: Provides access to a transmit buffer of the specified controller
* Requirements: SWS_WEth_00077,SWS_WEth_00078, SWS_WEth_00137
*  			 ,SWS_WEth_00079,SWS_WEth_00080,SWS_WEth_00081
*  			 ,SWS_WEth_00083,SWS_WEth_00084,SWS_WEth_00085,
*  			 ,SWS_WEth_00086,
************************************************************************************/
BufReq_ReturnType WEth_ProvideTxBuffer (uint8 CtrlId,uint8 Priority,Eth_BufIdxType* BufIdPtr,uint8** BufPtr,uint16* LenBytePtr)
{
  BufReq_ReturnType return_value = BUFREQ_E_NOT_OK;
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00081*/
  /* Requirement: SWS_WEth_00086*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_PROVIDE_TX_BUFFER_SID ,WETH_E_UNINIT);
    return return_value;
  }
  /* Requirement: SWS_WEth_00082*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_PROVIDE_TX_BUFFER_SID ,WETH_E_INV_CTRL_ID);
    return return_value;
    
  }
  /* Requirement: SWS_WEth_00083*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == BufIdPtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_PROVIDE_TX_BUFFER_SID ,WETH_E_PARAM_POINTER);
    return return_value;
  }
  /* Requirement: SWS_WEth_00084*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == BufPtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_PROVIDE_TX_BUFFER_SID ,WETH_E_PARAM_POINTER);
    return return_value;
  }
  /* Requirement: SWS_WEth_00085*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == LenBytePtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_PROVIDE_TX_BUFFER_SID ,WETH_E_PARAM_POINTER);
    return return_value;
  }
#endif
  
  boolean Busy_Flag = TRUE;
  /*Checking if Buffer size required greater that available Buffers*/
  if (*LenBytePtr > WETH_TX_MAX_BUFFER_SIZE)
  {
    /* Requirement: SWS_WEth_00079*/
    *LenBytePtr = WETH_TX_MAX_BUFFER_SIZE;
    return_value = BUFREQ_E_OVFL;
  }
  else
  {
    for (uint8 i = 0; i <WETH_TX_MAX_BUFFER_NUM ; i++)
    {
      /*Checking for un-reserved buffers*/
      if (WEth_Tx_Flag[i] == FREE_BUFFER)
      {
        /* Requirement: SWS_WEth_00078*/
        WEth_Tx_Flag[i] = RESERVED_BUFFER;
        
        *BufIdPtr = i;
        *BufPtr=(uint8 *)WEth_Tx_Buffers[i];
     //   *LenBytePtr =WETH_TX_MAX_BUFFER_SIZE;
        
        Busy_Flag = FALSE;
        return_value = BUFREQ_OK;
        break;
      }
    }
    if (Busy_Flag == TRUE)
    {
      /* Requirement: SWS_WEth_00080*/
      return_value = BUFREQ_E_BUSY;
    }
  }
  return return_value;
}

/************************************************************************************
* Service Name: WEth_Transmit
* Service ID[hex]: 0x14
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					BufId - Index to the granted buffer resource. To be used for subsequent requests.
* 					FrameType - Ethernet frame type
* 					TxConfirmation - Activates transmission confirmation
* 					LenByte - Data length in byte (802.11 Header + Body, not including FCS)
* 					PhysAddrPtr - Physical target address (MAC address) in network byte order
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: transmission failed
* Description: Triggers transmission of a previously filled transmit buffer
* Requirements:  SWS_WEth_00087,SWS_WEth_00088, SWS_WEth_00138
*  			 ,SWS_WEth_00090,SWS_WEth_00091,SWS_WEth_00092
*  			 ,SWS_WEth_00093,SWS_WEth_00129,SWS_WEth_00094,
************************************************************************************/
Std_ReturnType WEth_Transmit (uint8 CtrlId,Eth_BufIdxType BufId,Eth_FrameType FrameType,boolean TxConfirmation,uint16 LenByte,const uint8* PhysAddrPtr)
{
  Std_ReturnType return_value = E_NOT_OK;
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00090*/
  /* Requirement: SWS_WEth_00094*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TRANSMIT_SID ,WETH_E_UNINIT);
    return return_value;
  }
  /* Requirement: SWS_WEth_00091*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TRANSMIT_SID ,WETH_E_INV_CTRL_ID);
    return return_value;
    
  }
  /* Requirement: SWS_WEth_00092*/
  /* check if the input parameter is invalid*/
  if (BufId >= WETH_TX_MAX_BUFFER_NUM)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TRANSMIT_SID ,WETH_E_INV_PARAM);
    return return_value;
  }
  /* Requirement: SWS_WEth_00093*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == PhysAddrPtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TRANSMIT_SID ,WETH_E_PARAM_POINTER);
    return return_value;
  }
  /* Requirement: SWS_WEth_00129*/
  /* check if the mode is inactive */
  if (WEth_Controller_Current_Mode[CtrlId] != ETH_MODE_ACTIVE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TRANSMIT_SID ,WETH_E_INV_MODE);
    return return_value;
  }
#endif
  
  uint8_t y = 60;




   //HAL_UART_Transmit(&huart4,&y,sizeof(uint8_t),2000);

  uint8_t test[1500 + 2] = {0};
  test[0] = LenByte & 0x00FF;
  test[1] = LenByte >> 8;

  for(uint16_t i = 0; i < LenByte; i++)
  {
	  test[i+2] = WEth_Tx_Buffers[BufId][i];
  }

  BufIdx_Unconfirmed[BufId] = TRUE;
  
  Tx_Confirm_flag[BufId] = TxConfirmation;
  
  /* Requirement: SWS_WEth_00088*/
  //return_value = Fragment (&WEth_Tx_Buffers[BufId][0] , LenByte);
  //xx = WEth_Tx_Buffers[BufId][10];
  //HAL_SPI_Transmit(&hspi5, LenByte, sizeof(LenByte),1000);
  //return_value = HAL_SPI_Transmit_IT(&hspi5, WEth_Tx_Buffers[BufId], LenByte);
  for(uint16_t i = 0; i< 10000; i++);
  flag = 1;
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);
  return_value = HAL_SPI_Transmit_IT(&hspi2, test, LenByte + 2);
  Tx_transmit_result[BufId] = return_value;
  Tx_Confirm_flag[BufId]=FALSE;
  BufIdx_Unconfirmed[BufId]=FALSE;
  WEth_Tx_Flag[BufId]=FREE_BUFFER;


  return return_value;
}

/************************************************************************************
* Service Name: WEth_TxConfirmation
* Service ID[hex]: 0x02
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Triggers transmission of a previously filled transmit buffer
* Requirements:  SWS_WEth_00100,SWS_WEth_00101,SWS_WEth_00102
*  			 ,SWS_WEth_00103,SWS_WEth_00104,SWS_WEth_00134
*  			 ,SWS_WEth_00105,SWS_WEth_10063
************************************************************************************/

// Called by SPI.
void WEth_TxConfirmation (uint8 CtrlId)
{
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00103*/
  /* Requirement: SWS_WEth_00105*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TX_CONFIRMATION_SID ,WETH_E_UNINIT);
  }
  /* Requirement: SWS_WEth_00104*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TX_CONFIRMATION_SID ,WETH_E_INV_CTRL_ID);
    
  }
  /* Requirement: SWS_WEth_00134*/
  /* check if the mode is inactive */
  if (WEth_Controller_Current_Mode[CtrlId] != ETH_MODE_ACTIVE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_TX_CONFIRMATION_SID ,WETH_E_INV_MODE);
  }
#endif
  
  

  // from isr of transmit CALLED or SET FLAGGG
  for (uint8 i = 0; i < WETH_TX_MAX_BUFFER_NUM ; i++)
  {
    if (WEth_Tx_Flag[i] == TRUE)
    {
      //OR LOOP WITH i
      if ( (Tx_Confirm_flag[i] == TRUE) && (BufIdx_Unconfirmed[i] == TRUE ) )
      {
        Tx_Confirm_flag[i] = FALSE;
        BufIdx_Unconfirmed[i] = FALSE;
        /* Requirement: SWS_WEth_00101*/
        //OR MAKE IT PTR_2_FUNC
        EthIf_TxConfirmation(CtrlId,i , Tx_transmit_result[i]);
        
        
        /*Requirement: SWS_WEth_00102*/
        //RELEASE BUFFER;
        WEth_Tx_Flag[i] = FREE_BUFFER;
        
      }
      else
      {
        
      }
    }
  }
}

/************************************************************************************
* Service Name: WEth_Receive
* Service ID[hex]: 0x05
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): RxStatusPtr - Indicates whether a frame has been received and if so, whether more frames are available or frames got lost.
* Return value: None
* Description: Triggers frame reception
* Requirements:  SWS_WEth_00095,SWS_WEth_00096,SWS_WEth_00097
*  			 ,SWS_WEth_00132,SWS_WEth_00153,SWS_WEth_00099
*  			 ,SWS_WEth_10061
************************************************************************************/
void WEth_Receive (uint8 CtrlId,Eth_RxStatusType* RxStatusPtr)
{
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_00097*/
  /* Requirement: SWS_WEth_00099*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_RECEIVE_SID ,WETH_E_UNINIT);
  }
  /* Requirement: SWS_WEth_00098*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_RECEIVE_SID ,WETH_E_INV_CTRL_ID);
    
  }
  /* Requirement: SWS_WEth_00132*/
  /* check if the mode is inactive */
  if (WEth_Controller_Current_Mode[CtrlId] != ETH_MODE_ACTIVE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_RECEIVE_SID ,WETH_E_INV_MODE);
  }
  /* check if the input pointer is not a NULL_PTR */
  if ( RxStatusPtr == NULL_PTR)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_RECEIVE_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  
  
  /* Requirement: SWS_WEth_00096*/
  
#if (ETHIF_ENABLE_RX_INTERRUPT == STD_ON)
  *RxStatusPtr = ETH_RECEIVED;
  Defragment(WEth_Rx_Buffers , WETH_TX_MAX_BUFFER_SIZE );
#else
  //READ SPI REGS FOR DATA;
  //if (There_is_data_from_spi_regs == TRUE)
  //{


  if(flag == 0)
  {
	  flag = 1;
	  //for(uint32_t j = 0; j < 200000; j++);
	  //HAL_SPI_Receive_IT(&hspi5,temp_arr,1002);
	  HAL_SPI_Receive_IT(&hspi2,temp_arr,2);
	  //hspi5.RxXferCount = 1005;

  }


  uint32_t itsource = hspi2.Instance->CR2;
  uint32_t itflag   = hspi2.Instance->SR;


  //HAL_SPI_Receive_IT(&hspi5,WEth_Rx_Buffers,WETH_TX_MAX_BUFFER_SIZE);
  //HAL_SPI_Receive_IT(&hspi5,temp_arr,WETH_TX_MAX_BUFFER_SIZE+2);
  if ((SPI_CHECK_FLAG(itflag, SPI_FLAG_OVR) == RESET) &&
      (SPI_CHECK_FLAG(itflag, SPI_FLAG_RXNE) != RESET) && (SPI_CHECK_IT_SOURCE(itsource, SPI_IT_RXNE) != RESET))
  {
    *RxStatusPtr = ETH_RECEIVED;
    //Defragment(WEth_Rx_Buffers , WETH_TX_MAX_BUFFER_SIZE );
    HAL_SPI_Receive_IT(&hspi2,WEth_Rx_Buffers,WETH_TX_MAX_BUFFER_SIZE);
  }

  //}
  else
  {
    *RxStatusPtr = ETH_NOT_RECEIVED;
  }
#endif
  /*
  	 itsource = hspi5.Instance->CR2;
     itflag   = hspi5.Instance->SR;
  /*READ SPI AGAIN REGS if MORE DATA??;
    if (More_Data_Is_Available_from_spi_regs == TRUE)*//*
	if ((SPI_CHECK_FLAG(itflag, SPI_FLAG_OVR) == RESET) &&
	(SPI_CHECK_FLAG(itflag, SPI_FLAG_RXNE) != RESET) && (SPI_CHECK_IT_SOURCE(itsource, SPI_IT_RXNE) != RESET))
    {
      *RxStatusPtr = ETH_RECEIVED_MORE_DATA_AVAILABLE;
    }
    else
    {
      
    }*/
  /* Requirement: SWS_WEth_00153*/
  //EthIf_RxIndication(CtrlId ,0x8947 ,TRUE , Weth_Stored_Config_Struct->CtrlConfig[CtrlId].WEthCtrlPhyAddress , WEth_Rx_Buffers  , WETH_TX_MAX_BUFFER_SIZE );
  
}

/* !!!!ARE THESE FUNCS NEEDED!!!!*/
/************************************************************************************
* Service Name: WEth_GetBufWRxParams
* Service ID[hex]: 0x34
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					RxParamIds - IDs of the Parameter that are requested Parameters.
* 					NumParams - Number of Parameters that are requested
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: failed reading parameters
* Description: Read out values related to the receive direction for a received packet. For example, this could
be RSSI or Channel belonging to one single packet.This API is valid only within the context of
WEth_Receive
* Requirements:  SWS_WEth_10062,SWS_WEth_10039,SWS_WEth_10040
*  			 ,SWS_WEth_10041,SWS_WEth_10042
************************************************************************************/
Std_ReturnType WEth_GetBufWRxParams (uint8 CtrlId,const WEth_BufWRxParamIdType* RxParamIds,uint32* ParamValues,uint8 NumParams)
{
  Std_ReturnType return_value = E_NOT_OK;
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_10039*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WRX_PARAMS_SID ,WETH_E_UNINIT);
  }
  /* Requirement: SWS_WEth_10040*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WRX_PARAMS_SID ,WETH_E_INV_CTRL_ID);
    
  }
  /* Requirement: SWS_WEth_10041*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == RxParamIds)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WRX_PARAMS_SID ,WETH_E_PARAM_POINTER);
  }
  /* Requirement: SWS_WEth_10042*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == ParamValues)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WRX_PARAMS_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  //COPIED FROM OLD PROJECT
  // WHAT ARE THESE VALUES?????
  for(uint8 i=0;i<NumParams;i++)
  {
    if(RxParamIds[i] == WETH_BUFWRXPID_RSSI )
    {
      ParamValues[i] = 120;
    }
    else if(RxParamIds[i] == WETH_BUFWRXPID_CHANNEL_ID)
    {
      ParamValues[i] = 10;
    }
    else if(RxParamIds[i] == WETH_BUFWRXPID_FREQ)
    {
      ParamValues[i] = WETH_BUFWRXPID_FREQ;
    }
    else if(RxParamIds[i]== WETH_BUFWRXPID_TRANSACTION_ID_32)
    {
      //ParamValues[i] = TRANSACTION_ID_32;
      //TRANSACTION_ID_32++;
    }
    else if (RxParamIds[i] == WETH_BUFWRXPID_ANTENNA_ID)
    {
      ParamValues[i] = 22;
    }
  }
  return return_value;
}


/************************************************************************************
* Service Name: WEth_GetBufWTxParams
* Service ID[hex]: 0x35
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					TxParamIds - IDs of the Parameter that are requested Parameters.
* 					NumParams - Number of Parameters that are requested
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: failed reading parameters
* Description: Read out values related to the transmit direction for a transmitted packet. For example, this
could be transaction ID belonging to one single packet.This API is valid only within the context
of WEth_TxConfirmation.
* Requirements:  SWS_WEth_10044,SWS_WEth_10046,SWS_WEth_10047
*  			 ,SWS_WEth_10048,SWS_WEth_10049
************************************************************************************/
Std_ReturnType WEth_GetBufWTxParams (uint8 CtrlId,const WEth_BufWTxParamIdType* TxParamIds,uint32* ParamValues,uint8 NumParams)
{
  Std_ReturnType return_value = E_NOT_OK;
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_10046*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WTX_PARAMS_SID ,WETH_E_UNINIT);
  }
  /* Requirement: SWS_WEth_10047*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WTX_PARAMS_SID ,WETH_E_INV_CTRL_ID);
    
  }
  /* Requirement: SWS_WEth_10048*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == TxParamIds)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WTX_PARAMS_SID ,WETH_E_PARAM_POINTER);
  }
  /* Requirement: SWS_WEth_10049*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == ParamValues)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_BUF_WTX_PARAMS_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  
  //COPIED FROM OLD PROJECT
  // WHAT ARE THESE VALUES?????
  for(uint8 i=0;i<NumParams;i++)
  {
    if(TxParamIds[i] == WETH_BUFWTXPID_POWER )
    {
      ParamValues[i] = 10;
    }
    else if(TxParamIds[i] == WETH_BUFWTXPID_CHANNEL_ID)
    {
      ParamValues[i] = 10;
    }
    else if(TxParamIds[i] == WETH_BUFWTXPID_QUEUE_ID)
    {
      ParamValues[i] = 5;
    }
    else if(TxParamIds[i]== WETH_BUFWTXPID_TRANSACTION_ID_16)
    {
      //ParamValues[i] = TransactionID[BufIdxAfterConfirmation];
    }
  }
  
  
  return return_value;
}

/************************************************************************************
* Service Name: WEth_SetBufWTxParams
* Service ID[hex]: 0x36
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					BufId - Index of the buffer resource
* 					TxParamIds - IDs of the Parameter that are requested Parameters.
* 					ParamValues - Values of the Parameters that are provided to the transmit radio
* 					NumParams - Number of Parameters that are requested
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: failed reading parameters
* Description: Set values related to the transmit direction for a specific buffer (packet to be sent). For example,
this can be the desired transmit power or the channel belonging to one single packet.
* Requirements:  SWS_WEth_10051,SWS_WEth_10053,SWS_WEth_10054
*  			 ,SWS_WEth_10055,SWS_WEth_10056,SWS_WEth_10057
************************************************************************************/

Std_ReturnType WEth_SetBufWTxParams (uint8 CtrlId,Eth_BufIdxType BufId,const WEth_BufWTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams)
{
  Std_ReturnType return_value = E_NOT_OK;
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_10053*/
  /* Check if the WEth Module is Initialized */
  if (WETH_UINITIALIZED == WEth_Init_State)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_SET_BUF_WTX_PARAMS_SID ,WETH_E_UNINIT);
  }
  /* Requirement: SWS_WEth_10054*/
  /*Check that the parameter CtrlId is valid */
  if (CtrlId >= WETH_CONTROLLER_SIZE)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_SET_BUF_WTX_PARAMS_SID ,WETH_E_INV_CTRL_ID);
    
  }
  /* Requirement: SWS_WEth_10055*/
  /* check if the input parameter is invalid*/
  if (BufId >= WETH_TX_MAX_BUFFER_NUM)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_SET_BUF_WTX_PARAMS_SID ,WETH_E_INV_PARAM);
  }
  /* Requirement: SWS_WEth_10056*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == TxParamIds)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_SET_BUF_WTX_PARAMS_SID ,WETH_E_PARAM_POINTER);
  }
  /* Requirement: SWS_WEth_10057*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == ParamValues)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_SET_BUF_WTX_PARAMS_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  //COPIED FROM OLD PROJECT
  // WHAT ARE THESE VALUES?????
  for(int i=0;i<NumParams;i++){
    if(TxParamIds[i]==WETH_BUFWTXPID_POWER){
      uint8 power=ParamValues[i];
      power++;	/* To overcome "unused variable" warning. */
    }
    else if(TxParamIds[i]==WETH_BUFWTXPID_CHANNEL_ID){
      uint8 ChannelID=ParamValues[i];
      ChannelID++;	/* To overcome "unused variable" warning. */
    }
    else if(TxParamIds[i]==WETH_BUFWTXPID_QUEUE_ID){
      uint8 Buffer=ParamValues[i];
      Buffer++;	/* To overcome "unused variable" warning. */
    }
    else if(TxParamIds[i]==WETH_BUFWTXPID_TRANSACTION_ID_16){
      //TransactionID[BufId]=ParamValues[i];
    }
  }
  
  return return_value;
}
/* !!!!ARE THESE FUNCS NEEDED!!!!*/


/************************************************************************************
* Service Name: WEth_GetVersionInfo
* Service ID[hex]: 0x0d
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): None
* Parameters (inout): None
* Parameters (out): VersionInfoPtr - Pointer to where to store the version information of this module.
* Return value: None
* Description: Returns the version information of this module.
* Requirements:  SWS_WEth_00106,SWS_WEth_00136
**************************************************	**********************************/
#if (WETH_WETH_VERSION_INFO_API	== STD_ON)
void WEth_GetVersionInfo (Std_VersionInfoType* VersionInfoPtr)
{
#if (WETH_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_WEth_10053*/
  /* check if the input pointer is not a NULL_PTR */
  if (NULL_PTR == VersionInfoPtr)
  {
    Det_ReportError(WETH_MODULE_ID, WETH_INSTANCE_ID, WETH_GET_VERSION_INFO_SID ,WETH_E_PARAM_POINTER);
  }
#endif
  VersionInfoPtr->moduleID = WETH_MODULE_ID;
  VersionInfoPtr->sw_major_version = WETH_SW_MAJOR_VERSION; // OR WETH_AR_RELEASE_MAJOR_VERSION
  VersionInfoPtr->sw_minor_version = WETH_SW_MINOR_VERSION; // OR WETH_AR_RELEASE_MINOR_VERSION
  VersionInfoPtr->sw_patch_version = WETH_SW_PATCH_VERSION; // OR WETH_AR_RELEASE_PATCH_VERSION
  VersionInfoPtr->vendorID = WETH_VENDOR_ID;
  
}
#endif

/*******************************************************************************
*                      Scheduled Functions Prototypes                         	*
*******************************************************************************/
/************************************************************************************
* Service Name: WEth_MainFunction
* Service ID[hex]: 0x0a
* Description: Support for indirect transmissions (extended frame timing constraints) and mechanisms for
channel selection when using multiple channels. Used for polling state changes. Calls EthIf_
CtrlModeIndication when the controller mode changed.
* Requirements:  SWS_WEth_00171
************************************************************************************/

void WEth_MainFunction (void)
{
  for (uint8 i = 0; i <WETH_CONTROLLER_SIZE; i++)
  {
    if (WEth_Controller_Current_Mode[i] != WEth_Controller_Previous_Mode[i])
    {
      EthIf_CtrlModeIndication(i , WEth_Controller_Current_Mode[i]);
    }
    else
    {
      
    }
  }
  
}
/*******************************************************************************
*                      Private Functions Prototypes                         	*
*******************************************************************************/

/************************************************************************************
* Service Name: Fragment
* Description: The Function is used to fragment data into Frames of 250 Bytes
* WARNING: This Function is Hardware Specific to this project as the MTU of the Wireless Module On ESP is 250 Bytes.
************************************************************************************/
Std_ReturnType Fragment(uint8* data ,uint16 Lenbyte)
{
  Std_ReturnType Value = E_NOT_OK ;
  boolean Is_Segmented = FALSE;
  uint8 Last_Fragment_Size = Lenbyte % 247;
  uint8 Fragments_num = Lenbyte / 247;
  boolean Header_Added = FALSE;
  uint16 dataCounter = 0;
  
  uint8 My_data[MAX_FRAG_SIZE][250];
  uint8 Last_Fragment_Data[MAX_LAST_FRAG_SIZE];
  
  if (Lenbyte > 247 )
  {
    Is_Segmented = TRUE;
    
    for (uint8 i = 0; i < Fragments_num ; i++ )
    {
      for (uint8 j = 0; j < 250 ; j++ , dataCounter++)
      {
        if (!Header_Added)
        {
          My_data[i][j] =  (Is_Segmented ) ;
          j++;
          My_data[i][j] = Fragments_num;
          j++;
          My_data[i][j] = i;
          j++;
          
          Header_Added = TRUE;
          
        }
        My_data[i][j] = data[dataCounter];
        
        
      }
      Header_Added = FALSE;
      
      
           //TRANSMIT 250 bytes Fragment_Data
#if (ETHIF_ENABLE_TX_INTERRUPT == STD_ON)
      
      Value = HAL_SPI_Transmit_IT(&hspi5,My_data[i] , 250);
#else
      Value = HAL_SPI_Transmit(&hspi2,My_data[i] , 250, 1000);
#endif
       
      
      if (Value == FALSE)
      {
        return Value;
      }
      else
      {
        
      }
    }
    
    if (Last_Fragment_Size != 0)
    {
      for (uint8 j = 0; j < (Last_Fragment_Size +3) ; j++ , dataCounter++)
      {
        if (!Header_Added)
        {
          Last_Fragment_Data[j] = 0x02 | (Is_Segmented ) ;
          j++;
          Last_Fragment_Data[j] = Fragments_num;
          j++;
          Last_Fragment_Data[j] = Last_Fragment_Size;
          j++;
          Header_Added = TRUE;
        }
        Last_Fragment_Data[j] = data[dataCounter];
        
        
      }
      Header_Added = FALSE;
         //TRANSMIT  Last_Fragment_Data
#if (ETHIF_ENABLE_TX_INTERRUPT == STD_ON)
      
      Value = HAL_SPI_Transmit_IT(&hspi5,Last_Fragment_Data , Last_Fragment_Size);
#else
      Value = HAL_SPI_Transmit(&hspi2,Last_Fragment_Data , Last_Fragment_Size, 1000);
#endif
       
      if (Value == FALSE)
      {
        return Value;
      }
      else
      {
      }
      
    }
  }
  
  else
  {
    Is_Segmented = FALSE;
    if (Last_Fragment_Size != 0)
    {
      for (uint8 j = 0; j < (Last_Fragment_Size +3) ; j++ , dataCounter++)
      {
        if (!Header_Added)
        {
          Last_Fragment_Data[j] = 0x02 | (Is_Segmented ) ;
          j++;
          Last_Fragment_Data[j] = Fragments_num;
          j++;
          Last_Fragment_Data[j] = Last_Fragment_Size;
          j++;
          Header_Added = TRUE;
        }
        Last_Fragment_Data[j] = data[dataCounter];
        
      }
      
      Header_Added = FALSE;
      //TRANSMIT  Last_Fragment_Data
         
#if (ETHIF_ENABLE_TX_INTERRUPT == STD_ON)
      
      Value = HAL_SPI_Transmit_IT(&hspi5,Last_Fragment_Data , Last_Fragment_Size);
#else
      Value = HAL_SPI_Transmit(&hspi2,Last_Fragment_Data , Last_Fragment_Size, 1000);
#endif
      
      if (Value == FALSE)
      {
        return Value;
      }
      else
      {
      }
    }
  }
  
  return Value;
}

/************************************************************************************
* Service Name: Defragment
* Description: The Function is used to Reassembly of data.
* WARNING: This Function is Hardware Specific to this project as the MTU of the Wireless Module On ESP is 250 Bytes.
************************************************************************************/
Std_ReturnType Defragment(uint8* data_out , uint16 Lenbyte ) //,size data in and out ,,ADD ARRAY SIZE)
{
  Std_ReturnType Value = E_NOT_OK ;
  //uint8 counter = 0;
  boolean Is_Last_Fragment = FALSE;
  boolean Is_Segmented = FALSE;
  //boolean Header_Removed = FALSE;
  uint8 FragmentsNumber = 0;
  uint8 FragmentIdx = 0;
  uint16 dataCounter = 0;
  uint8 Last_Frag_size = 0;
  
  //Recieve 1015 Bytes Fragmented data.
#if (ETHIF_ENABLE_RX_INTERRUPT == STD_ON)
  Value = HAL_SPI_Receive_IT (&hspi5 , WEth_Rx_Buffer_Fragmented , WETH_RX_MAX_BUFFER_SIZE+15 , 1000);
#else
  Value = HAL_SPI_Receive_IT(&hspi2 , WEth_Rx_Buffer_Fragmented , WETH_RX_MAX_BUFFER_SIZE+15);
#endif
  
  Is_Segmented = WEth_Rx_Buffer_Fragmented[dataCounter];
  Is_Last_Fragment = (WEth_Rx_Buffer_Fragmented[dataCounter] >> 1);
  dataCounter++;
  FragmentsNumber = WEth_Rx_Buffer_Fragmented[dataCounter];
  dataCounter++;
  
  
  //static uint8 Recieved_Data[FragmentsNumber+1][247];
  if (Is_Segmented == TRUE)
  {
    FragmentIdx = WEth_Rx_Buffer_Fragmented[dataCounter];
    dataCounter++;
    
    while(FragmentIdx < FragmentsNumber)
    {
      if (Is_Last_Fragment == FALSE)
      {
        for (uint16 i = (FragmentIdx*247) ; i <(FragmentIdx+1)*247; i++ , dataCounter++ )
        {
          data_out[i] = WEth_Rx_Buffer_Fragmented[dataCounter];
        }
      }
      
      Is_Segmented = WEth_Rx_Buffer_Fragmented[dataCounter];
      Is_Last_Fragment = (WEth_Rx_Buffer_Fragmented[dataCounter] >> 1);
      dataCounter++;
      FragmentsNumber = WEth_Rx_Buffer_Fragmented[dataCounter];
      dataCounter++;
      if (Is_Last_Fragment == FALSE)
      {
        FragmentIdx = WEth_Rx_Buffer_Fragmented[dataCounter];
        dataCounter++;
      }
      else
      {
        Last_Frag_size = WEth_Rx_Buffer_Fragmented[dataCounter];
        dataCounter++;
        break;
      }
    }
    
    if (Last_Frag_size != 0 )
    {
      for (uint16 i = (FragmentsNumber*247) ; i <((FragmentsNumber*247)+Last_Frag_size) ; i++ , dataCounter++ )
      {
        data_out[i] = WEth_Rx_Buffer_Fragmented[dataCounter];
      }
      
    }
  }
  else
  {
    
    Last_Frag_size = WEth_Rx_Buffer_Fragmented[dataCounter];
    dataCounter++;
    
    for (uint8 i = 0 ; i <Last_Frag_size ; i++ , dataCounter++ )
    {
      data_out[i] = WEth_Rx_Buffer_Fragmented[dataCounter];
    }
  }
  
  return Value;
}

/*******************************************************************************
*                      ISR Functions                                            *
*******************************************************************************/

/************************************************************************************
* Service Name: WEth_TxIrqHdlr
* Description: The Function is called by the hardware when a Transmission Interrupt Occurs.
************************************************************************************/
void WEth_TxIrqHdlr (void)
{
  WEth_TxConfirmation(1);
}

/************************************************************************************
* Service Name: WEth_RxIrqHdlr
* Description: The Function is called by the hardware when a Recieve Interrupt Occurs.
************************************************************************************/
void WEth_RxIrqHdlr (void)
{
  Eth_RxStatusType Dummy_Rx_Status_Ptr;
  //WEth_Receive (0,&Dummy_Rx_Status_Ptr);
  EthIf_RxIndication(0 ,0x8947 ,TRUE , Weth_Stored_Config_Struct->CtrlConfig[0].WEthCtrlPhyAddress , WEth_Rx_Buffers  , Weth_Rx_Buffers_Size );

}

















