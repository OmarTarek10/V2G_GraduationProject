/******************************************************************************
*
* Module: Wireless Ethernet
*
* File Name: WEth_PbCfg.c
*
* Description: Source File For the Wireless Ethernet Module Post Build Configurations
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/ 


#ifndef WETH_PBCFG_H_
#define WETH_PBCFG_H_

#include "Std_Types.h"

#define WETH_CONTROLLER_SIZE	(1U)

#define WETH_CTRL_ID_1 			(0U)


#define WETH_TX_MAX_BUFFER_SIZE	(1000UL)
#define WETH_TX_MAX_BUFFER_NUM	(5U)

#define WETH_RX_MAX_BUFFER_SIZE	(1000UL)
#define WETH_RX_MAX_BUFFER_NUM	(5U)

#define MAC_ADDR_SIZE			(6U)

/*******************************************************************************
*                              Module Data Types                              *
*******************************************************************************/

typedef struct {
  uint8 WEthCtrlId;
  uint8* WEthCtrlPhyAddress; /*Multiplicity 0..1*/
  uint16 WEthCtrlRxBufLenByte; /*0 .. 1522*/
  uint16 WEthCtrlTxBufLenByte; /*0 .. 1522*/
  uint8 WEthRxBufTotal;
  uint8 WEthTxBufTotal;
  
}WEth_CtrlConfigType_s;


typedef struct {
  WEth_CtrlConfigType_s CtrlConfig[WETH_CONTROLLER_SIZE];
}WEth_ConfigType;

/*******************************************************************************
*                      External Variables                                    *
*******************************************************************************/

extern WEth_ConfigType WEthConfigurationSet;

#endif /* WETH_PBCFG_H_ */
