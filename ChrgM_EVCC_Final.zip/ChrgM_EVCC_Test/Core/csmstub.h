 /******************************************************************************
 *
 * Module: CryptoStack
 *
 * File Name: csmstub.h
 *
 * Description: Stub to use for IpSec
 *
 * Author: Kareem Azab
 *
 *******************************************************************************/

#ifndef CSMSTUB_H_
#define CSMSTUB_H_


#include "Std_Types.h"

/* CsmKey */
typedef struct {
	uint8 key[32];
	uint8 keylen;

} CsmKeyStub;
/******************************/


typedef struct {

} CsmJobStub;

#endif /* CSMSTUB_H_ */
