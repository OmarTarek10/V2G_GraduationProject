/******************************************************************************
 *
 * Module: CanIf
 *
 * File Name: CanIf.h
 *
 * Description: Stub for PduR
 *
 * Author: Kareem Azab
 ******************************************************************************/
#ifndef CANIF_H_
#define CANIF_H_




#include "Std_Types.h"
#include "ComStack_Types.h"


Std_ReturnType CanIf_Transmit (PduIdType TxPduId,const PduInfoType* PduInfoPtr);





#endif /* CANIF_H_ */
