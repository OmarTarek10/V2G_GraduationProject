/******************************************************************************
*
* Module: Ethernet Interface
*
* File Name: EthIf.h
*
* Description: Header File For the Ethernet Interface Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/
#ifndef ETHIF_H_
#define ETHIF_H_


/* Id for the company in the AUTOSAR
* for example Ahmed Ehab El Gowely's ID = 1000 :) */
#define ETHIF_VENDOR_ID    (1000U)

/* ETHIF Module Id */
#define ETHIF_MODULE_ID    (65U)

/* ETHIF Instance Id */
#define ETHIF_INSTANCE_ID  (0U)

/*
* Module Version 1.0.0
* Requirement: SWS_EthIf_00006
*/
#define ETHIF_SW_MAJOR_VERSION           (1U)
#define ETHIF_SW_MINOR_VERSION           (0U)
#define ETHIF_SW_PATCH_VERSION           (0U)

/*
* AUTOSAR Version R22-11
*/
#define ETHIF_AR_RELEASE_MAJOR_VERSION   (1U)
#define ETHIF_AR_RELEASE_MINOR_VERSION   (0U)
#define ETHIF_AR_RELEASE_PATCH_VERSION   (0U)

#include "EthIf_Cfg.h"
#include "EthIf_PbCfg.h"


/* Standard AUTOSAR types */
#include "Std_Types.h"

/* AUTOSAR checking between Std_Types.h and EthIf.h
* * Requirement: SWS_EthIf_00007
*/
#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
  ||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Std_Types.h does not match the expected version"
#endif

#include "Eth_GeneralTypes.h"

/* AUTOSAR checking between Eth_GeneralTypes.h and EthIf.h
* * Requirement: SWS_EthIf_00007
*/
#if ((ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
||  (ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
  ||  (ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Eth_GeneralTypes.h does not match the expected version"
#endif

#include "WEth_GeneralTypes.h"
/* AUTOSAR checking between WEth_GeneralTypes.h and EthIf.h
* * Requirement: SWS_EthIf_00007
*/
#if ((WETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
  ||  (WETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
  ||  (WETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
#error "The AR version ofWEth_GeneralTypes.h does not match the expected version"
#endif

/******************************************************************************
*                      API Service Id Macros                                 *
******************************************************************************/

/* Service ID for EthIf Init */
#define ETHIF_INIT_SID				(0x01U)
/*Service ID for EthIf set Controller mode */
#define ETHIF_SET_CONTROLLER_MODE_SID 	        (0x03U)
/*Service ID for EthIf get Controller mode */
#define ETHIF_GET_CONTROLLER_MODE_SID 	        (0x04U)
/*Service ID for EthIf get Physical Address  */
#define ETHIF_GET_PHYS_ADDR_SID 		(0x08U)
/*Service ID for EthIf get Physical Address  */
#define ETHIF_SET_PHYS_ADDR_SID 		(0x0DU)
/*Service ID for EthIf get Controller Index List  */
#define ETHIF_GET_CTRL_IDX_LIST_SIC		(0x44U)
/*Service ID for EthIf that Read out values related to the receive direction of the transceiver for a received packet*/
#define ETHIF_GET_BUF_WRX_PARAMS_SID	        (0x32U)
/*Service ID for EthIf that Read out values related to the transmit direction of the transceiver for a transmitted packet*/
#define ETHIF_GET_BUF_WTX_PARAMS_SID	        (0x31U)
/*Service ID for EthIf that Set values related to the transmit direction of the transceiver for a specific buffer(packet to be sent)*/
#define ETHIF_SET_BUF_WTX_PARAMS_SID 	        (0x33U)
/* Service ID for EthIf ProvideTxBuffer*/
#define ETHIF_PROVIDE_TX_BUFFER_SID 	        (0x09U)
/*  Service ID for EthIf Transmit */
#define ETHIF_TRANSMIT_SID 			(0x0AU)
/*Service ID for EthIf Get Version Info */
#define ETHIF_GET_VERSION_INFO_SID 		(0x0BU)
/*  Service ID for EthIf Receive indication  */
#define ETHIF_RX_INDICATION_SID  		(0x10U)
/*Service ID for EthIf transmission confirmation */
#define ETHIF_TX_CONFIRMATION_SID 		(0x11U)
/*Service ID for EthIf Called asynchronously when mode has been read out */
#define ETHIF_CTRL_MODE_INDICATION_SID 	        (0x0EU)
/*******************************************************************************
*                      DET Error Codes                                        *
*******************************************************************************/
/* API service called with invalid controller index */
#define ETHIF_E_INV_CTRL_IDX		        (0x01U)

/* API service called when EthIf module was not initialized */
#define ETHIF_E_UNINIT				(0x05U)

/* API service called with invalid pointer in parameter list */
#define ETHIF_E_PARAM_POINTER		        (0x06U)

/* API service called with invalid parameter */
#define ETHIF_E_INV_PARAM			(0x07U)

/* EthIf_Init called with an invalid configuration pointer */
#define ETHIF_E_INIT_FAILED			(0x08U)

/* Invalid port index */
#define ETHIF_E_INV_PORT_IDX		        (0x09U)

/*******************************************************************************
*                              Module Data Types                              *
*******************************************************************************/

typedef enum
{
  ETHIF_UINITIALIZED, ETHIF_INITIALIZED
}EthIf_State_Type;

typedef uint8 EthIf_SwitchPortGroupIdxType;
typedef uint8 EthIf_MeasurementIdxType;

typedef struct
{
  uint32 HighestSignalQuality;
  uint32 LowestSignalQuality;
  uint32 ActualSignalQuality;
}EthIf_SignalQualityResultType;

/*******************************************************************************
*                      Function Prototypes                                    *
*******************************************************************************/
/************************************************************************************
* Service Name: EthIf_Init
* Service ID[hex]: 0x01
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CfgPtr - Pointer to post-build configuration data
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Function to Initialize the Ethernet Interface module.
* Requirements: SWS_EthIf_00024,SWS_EthIf_00025, SWS_EthIf_00114
************************************************************************************/
void EthIf_Init (const EthIf_ConfigType* CfgPtr);

/************************************************************************************
* Service Name: EthIf_SetControllerMode
* Service ID[hex]: 0x03
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
* CtrlMode - ETH_MODE_DOWN: disable the controller
ETH_MODE_ACTIVE: enable the controller
ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST: enable thecontroller and request a wake-up on the network.
ETH_MODE_TX_OFFLINE: disable transmission handling in EthIf. Please note, the according Ethernet controller is not affected.
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller mode could not be changed
* Description:  Enables / disables the indexed controller
* Requirements: SWS_EthIf_00034, SWS_EthIf_00114
************************************************************************************/
Std_ReturnType EthIf_SetControllerMode (uint8 CtrlIdx,Eth_ModeType CtrlMode);

/************************************************************************************
* Service Name: EthIf_GetControllerMode
* Service ID[hex]: 0x04
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
* Parameters (inout): None
* Parameters (out): CtrlMode - ETH_MODE_DOWN: disable the controller
ETH_MODE_ACTIVE: enable the controller
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description:  Obtains the state of the indexed controller
* Requirements: SWS_EthIf_00039
************************************************************************************/
Std_ReturnType EthIf_GetControllerMode (uint8 CtrlIdx,Eth_ModeType* CtrlModePtr);
/************************************************************************************
* Service Name: EthIf_GetPhysAddr
* Service ID[hex]: 0x08
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
* Parameters (inout): None
* Parameters (out): PhysAddrPtr Physical source address (MAC address) in network byte order.
* Return value: None
* Description:  Obtains the physical source address used by the indexed controller
* Requirements: SWS_EthIf_00061
************************************************************************************/
void EthIf_GetPhysAddr (uint8 CtrlIdx,uint8* PhysAddrPtr);

/************************************************************************************
* Service Name: EthIf_SetPhysAddr
* Service ID[hex]: 0x0D
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant for the same CtrlIdx, reentrant for different
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
PhysAddrPtr - Pointer to memory containing the physical source address (MACaddress) in network byte order.
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Obtains the physical source address used by the indexed controller
* Requirements: SWS_EthIf_00132
************************************************************************************/
void EthIf_SetPhysAddr (uint8 CtrlIdx,const uint8* PhysAddrPtr);

/************************************************************************************
* Service Name: EthIf_GetCtrlIdxList
* Service ID[hex]: 0x44
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): None
* Parameters (inout): NumberOfCtrlIdx - in: maximum number of controllers in CtrlIdxListPtr, 0 to return
*                                           the number of controllers but without filling CtrlIdxListPtr.
*                                       out: number of active controllers.
* Parameters (out): CtrlIdxListPtr - List of active controller indexes
* Return value: Std_ReturnType E_OK: success
                               E_NOT_OK: failure
* Description:  Returns the number and index of all active Ethernet controllers
* Requirements: SWS_EthIf_91053
************************************************************************************/
Std_ReturnType EthIf_GetCtrlIdxList (uint8* NumberOfCtrlIdx,uint8* CtrlIdxListPtr);

/* !!!!ARE THESE FUNCS NEEDED!!!!*/
/************************************************************************************
* Service Name: EthIf_GetBufWRxParams
* Service ID[hex]: 0x32
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
RxParamIds - IDs of the Parameters to read
NumParams - Number of Parameters
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description:  Read out values related to the receive direction of the transceiver for a received packet. For
example, this could be RSSI or Channel belonging to one single packet.
* Requirements: SWS_EthIf_91002
* Note: The function requires previous reception (EthIf_RxIndication).
************************************************************************************/
Std_ReturnType EthIf_GetBufWRxParams (uint8 CtrlIdx,const WEth_BufWRxParamIdType* RxParamIds,uint32* ParamValues,uint8 NumParams);
/************************************************************************************
* Service Name: EthIf_GetBufWTxParams
* Service ID[hex]: 0x31
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
TxParamIds - IDs of the Parameters to read
NumParams - Number of Parameters
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description: Read out values related to the transmit direction of the transceiver for a transmitted packet. For
example, this could be transaction ID belonging to one single packet.
* Requirements: SWS_EthIf_91054
* Note: The function requires previous transmission (EthIf_Transmit).
************************************************************************************/
Std_ReturnType EthIf_GetBufWTxParams (uint8 CtrlIdx,const WEth_BufWTxParamIdType* TxParamIds,uint32* ParamValues,uint8 NumParams);
/************************************************************************************
* Service Name: EthIf_SetBufWTxParams
* Service ID[hex]: 0x33
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
BufIdx - Index of the buffer resource
TxParamIds - IDs of the Parameters to read
ParamValues - Values of the Parameters requested
NumParams - Number of Parameters
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description: Set values related to the transmit direction of the transceiver for a specific buffer (packet to be
sent). For example, this can be the desired transmit power or the channel belonging to one
single packet.
* Requirements: SWS_EthIf_91017
* Note: The function requires previous buffer request (EthIf_ProvideTxBuffer)
************************************************************************************/
Std_ReturnType EthIf_SetBufWTxParams (uint8 CtrlIdx,Eth_BufIdxType BufIdx,const WEth_BufWTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams);
/* !!!!ARE THESE FUNCS NEEDED!!!!*/

/************************************************************************************
* Service Name: EthIf_ProvideTxBuffer
* Service ID[hex]: 0x09
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
FrameType - Ethernet Frame Type (EtherType)
Priority - Priority value which shall be used for the 3-bit PCP field of theVLAN tag
ParamValues - Values of the Parameters requested
NumParams - Number of Parameters
* Parameters (inout): LenBytePtr - in: desired length in bytes, out: granted length in bytes
* Parameters (out): BufIdxPtr - Index to the granted buffer resource. To be used for subsequent requests
* 					 BufPtr - Pointer to the granted buffer
* Return value: BufReq_ReturnType BUFREQ_OK: success
BUFREQ_E_NOT_OK: development error detected
BUFREQ_E_BUSY: all buffers in use
BUFREQ_E_OVFL: requested buffer too large
* Description: Provides access to a transmit buffer of the specified Ethernet controller.
* Requirements: SWS_EthIf_00067
************************************************************************************/
BufReq_ReturnType EthIf_ProvideTxBuffer (uint8 CtrlIdx,Eth_FrameType FrameType,uint8 Priority,Eth_BufIdxType* BufIdxPtr,uint8** BufPtr,uint16* LenBytePtr);

/************************************************************************************
* Service Name: EthIf_Transmit
* Service ID[hex]: 0x0A
* Sync/Async: Synchronous
* Reentrancy: Reentrant for different buffer indexes and Ctrl indexes
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
BufIdx - Index of the buffer resource
FrameType - Ethernet frame type
TxConfirmation - Activates transmission confirmation
LenByte - Data length in byte
PhysAddrPtr - Physical target address (MAC address) in network byte order
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description: Triggers transmission of a previously filled transmit buffer.
* Requirements: SWS_EthIf_00075
************************************************************************************/
Std_ReturnType EthIf_Transmit (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Eth_FrameType FrameType,boolean TxConfirmation,uint16 LenByte,const uint8* PhysAddrPtr);

/************************************************************************************
* Service Name: EthIf_GetVersionInfo
* Service ID[hex]: 0x0B
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): None
* Parameters (inout): None
* Parameters (out): VersionInfoPtr Version information of this module
* Return value: None
* Description: Returns the version information of this module
* Requirements: SWS_EthIf_00082
************************************************************************************/
void EthIf_GetVersionInfo (Std_VersionInfoType* VersionInfoPtr);

/*******************************************************************************
*                      Callback Functions Prototypes                          *
*******************************************************************************/
/************************************************************************************
* Service Name: EthIf_RxIndication
* Service ID[hex]: 0x10
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the physical Ethernet controller within the context of the Ethernet Interface
* 					FrameType - Frame type of received Ethernet frame
* 					IsBroadcast - parameter to indicate a broadcast frame
* 					PhysAddrPtr - Pointer to Physical source address (MAC address in network byte order) of received Ethernet frame
* 					DataPtr - Pointer to payload of received Ethernet frame
* 					LenByte - Length (bytes) of the payload in received frame.
* Parameters (inout): None
* Parameters (out):  None
* Return value: None
* Description: Handles a received frame received by the indexed controller
* Requirements: SWS_EthIf_00085
************************************************************************************/
void EthIf_RxIndication (uint8 CtrlIdx,Eth_FrameType FrameType,boolean IsBroadcast,const uint8* PhysAddrPtr,const Eth_DataType* DataPtr,uint16 LenByte);

/************************************************************************************
* Service Name: EthIf_TxConfirmation
* Service ID[hex]: 0x11
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the physical Ethernet controller within the context of the Ethernet Interface
* 					BufIdx - Index of the transmitted buffer
* 					Result E_OK: The transmission was successful, E_NOT_OK: The transmission failed.
* Parameters (inout): None
* Parameters (out):  None
* Return value: None
* Description: Confirms frame transmission by the indexed controller
* Requirements: SWS_EthIf_00091
************************************************************************************/
void EthIf_TxConfirmation (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result);

/************************************************************************************
* Service Name: EthIf_CtrlModeIndication
* Service ID[hex]: 0x0E
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant for the same CtrlIdx, reentrant for different
* Parameters (in): CtrlIdx - Index of the physical Ethernet controller within the context of the Ethernet Interface
* 					CtrlMode - Notified Ethernet controller mode
* Parameters (inout): None
* Parameters (out):  None
* Return value: None
* Description:Called asynchronously when mode has been read out. Triggered by previous <EthDrv>_SetControllerMode call. Can directly be called within the trigger functions.
* Requirements: SWS_EthIf_00231
************************************************************************************/
void EthIf_CtrlModeIndication (uint8 CtrlIdx,Eth_ModeType CtrlMode);

/*******************************************************************************
*                      Scheduled Functions Prototypes                          *
*******************************************************************************/
#if (ETHIF_ENABLE_RX_INTERRUPT == STD_OFF)
/************************************************************************************
* Service Name: EthIf_MainFunctionRx
* Service ID[hex]: 0x20
* Description:The function checks for new received frames and issues reception indications in polling mode.
* Requirements: SWS_EthIf_00097
************************************************************************************/
void EthIf_MainFunctionRx (void);
#endif

#if (ETHIF_ENABLE_TX_INTERRUPT == STD_OFF)
/************************************************************************************
* Service Name: EthIf_MainFunctionTx
* Service ID[hex]: 0x21
* Description:The function issues transmission confirmations in polling mode. It checks also for transceiverstate changes.
* * Requirements: SWS_EthIf_00113
************************************************************************************/
void EthIf_MainFunctionTx (void);
#endif


#endif /* ETHIF_H_ */
