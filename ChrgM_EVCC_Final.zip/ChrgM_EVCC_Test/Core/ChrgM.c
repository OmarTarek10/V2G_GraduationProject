/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM.c
 *
 * Description: Charging Manager enables the charging process between the supply equipment (EVSE) and the vehicle (EV)
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM.h"

#if (CHRGM_DEV_ERROR_DETECT == STD_ON)

#include "Det.h"
/*
 * AUTOSAR Version checking between Det and ChrgM Modules
 */

#if ((DET_AR_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		|| (DET_AR_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		|| (DET_AR_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Det.h does not match the expected version"
#endif

#endif /* (CHRGM_DEV_ERROR_DETECT == STD_ON) */

static uint8 ChrgM_Status = CHRGM_NOT_INITIALIZED;

/*******************************************************************************
 *                              Module variables                               *
 *******************************************************************************/
uint8 MessageBuffer[BUFFER_SIZE];
uint8 *MessageBuffer_Ptr = MessageBuffer;

struct iso1EXIDocument V2G_EXI_Document;
struct iso1EXIDocument* ChrgM_DocumentPtr;

V2GMessageHeaderType V2G_Response_Header;
MessageHeaderType Response_Header;
SECCDiscoveryProtocolReqType SECCDiscoveryProtocolReq_Message;
SECCDiscoveryProtocolResType SECCDiscoveryProtocolRes_Message;
SupportedAppProtocolReqType SupportedAppProtocolReq_Message;
SupportedAppProtocolResType SupportedAppProtocolRes_Message;

ChrgM_MessageStateType ChrgM_RequestedMessage = NO_MESSAGE;
ChrgM_ModuleStateType ChrgM_ModuleState = NOT_INITIALIZED;
EthTrcv_LinkStateType ChrgM_TransceiverLinkState = ETHTRCV_LINK_STATE_DOWN;
TcpIp_IpAddrStateType ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
SoAd_SoConModeType ChrgM_UDPSoConMode = SOAD_SOCON_OFFLINE;
SoAd_SoConModeType ChrgM_TCPSoConMode = SOAD_SOCON_OFFLINE;

ChrgM_ModuleStateType ChrgM_TxErrorState = NOT_INITIALIZED;
ChrgM_ModuleStateType ChrgM_RxErrorState = NOT_INITIALIZED;
ChrgM_ErrorStatusType ChrgM_TxErrorStatus = NO_ERROR_STATUS;
ChrgM_ErrorStatusType ChrgM_RxErrorStatus = NO_ERROR_STATUS;
boolean ChrgM_SECCTimerElapsed = TRUE;
boolean ChrgM_CommunicationSetupTimerElapsed = FALSE;
boolean ChrgM_ValidSECCReceived = FALSE;
boolean ChrgM_MessageRequested = FALSE;
boolean ChrgM_MessageReceived = FALSE;
boolean ChrgM_ReceptionSuccessful = FALSE;
boolean ChrgM_TxConfirmationReceived = FALSE;
boolean ChrgM_TransmissionSuccessful = FALSE;
boolean ChrgM_ReceptionDone = TRUE;
//boolean ChrgM_MessageTimerStarted = FALSE;
boolean ChrgM_MessageTimerElapsed = FALSE;
boolean ChrgM_OngoingTimerStarted = FALSE;
boolean ChrgM_OngoingTimerElapsed = FALSE;
boolean ChrgM_DataWritten = FALSE;
boolean ChrgM_DataEncoded = FALSE;
boolean ChrgM_DataEncrypted = FALSE;
boolean ChrgM_PdurRequestSuccessful = FALSE;

uint8 ChrgM_SECCCounter = 0;

boolean ChrgM_ProcessStarted = FALSE;
boolean ChrgM_OpenUDPSocketRequested = FALSE;
boolean ChrgM_OpenTCPSocketRequested = FALSE;
boolean ChrgM_SocketIndicationReceived = FALSE;
boolean ChrgM_IpAddressIndicationReceived = FALSE;

uint8 ChrgM_CpLine = INACTIVE;

boolean Message_Received_Indication = TRUE;

/* Initialise variable to store Payload length */
PayloadLengthType Sent_Payload = 0;
PayloadLengthType Received_Payload = 0;

PduInfoType ChrgM_PduInfo;
PduIdType ChrgM_PduID;
SoAd_SoConIdType ChrgM_SocketConID;


/*******************************************************************************
 *                              Module Functions                               *
 *******************************************************************************/

/************************************************************************************
 * Service Name: ChrgM_Init
 * Service ID[hex]: 0x01
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): ConfigPtr - Pointer to Initialization Configuration Structure
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This service initializes the ChrgM module
 * Requirments:[SRS_BSW_00310],[SRS_BSW_00101],[SRS_BSW_00358],[SRS_BSW_00414]
 ************************************************************************************/
void ChrgM_Init (const ChrgM_ConfigType* ConfigPtr)
{
	/* Initialize Module Variables */
	ChrgM_ModuleState = INIT;
	ChrgM_RequestedMessage = NO_MESSAGE;
	ChrgM_Status = CHRGM_INITIALIZED;
	/* SocketID */
	ChrgM_SocketConID = ConfigPtr->ChrgM_V2GTP.ChrgMV2GSrcTcpDataRef->SoAd_SockConnGroup->SoAd_SocketConnection.SoAdSocketId;
	/* ChrgM PDU ID*/
	ChrgM_PduID = ConfigPtr->ChrgM_V2GTP.ChrgM_V2GTPPdu.ChrgMV2GTPPduHandleId;
	/* PDU Pointer to Socket ID */
	//ChrgM_PduInfo.MetaDataPtr = 1; /* Should be a pointer from PduR routing table */
	/* PDU Pointer to Data Buffer */
	ChrgM_PduInfo.SduDataPtr = MessageBuffer;
	/* PDU Length variable with message type */
	ChrgM_PduInfo.SduLength = 0;
#if(CHRGM_SDP_USED == STD_ON)
	/* Initialize SDP Message depending on Pre-Compile configurations */
#if(CHRGM_V2G_TCP_TRANSPORT_PROTOCOL == STD_ON)
	SECCDiscoveryProtocolReq_Message.SECCTransportProtocol = TCP;
#else
	SECCDiscoveryProtocolReq_Message.SECCTransportProtocol = UDP;
#endif

#if(CHRGM_V2G_TLS_SECURITY == STD_ON && CHRGM_V2G_TCP_TRANSPORT_PROTOCOL == STD_ON)
	SECCDiscoveryProtocolReq_Message.SECCSecurity = TLS;
#else
	SECCDiscoveryProtocolReq_Message.SECCSecurity = NO_TLS;
#endif
#endif
	/* Initialise EXI Document with zeros */
	memset(&V2G_EXI_Document, 0, sizeof(V2G_EXI_Document));
	static volatile SupportedAppProtocolReqType* SupportedAppProtocolReq_MessagePtr = &SupportedAppProtocolReq_Message;
	/* Initialise SupportedAppProtocol Message */
	SupportedAppProtocolReq_Message.MessageName = SUPPORTED_APP_PROTOCOL_MESSAGE;
	SupportedAppProtocolReq_Message.NumberOfProtocols = 2;
	for(uint8 i = 1; i < SupportedAppProtocolReq_Message.NumberOfProtocols+1; i++)
	{
		SupportedAppProtocolReq_Message.AppProtocol[i-1].ProtocolNamespaceLength = 8;
		for(uint8 j = 0; j < SupportedAppProtocolReq_Message.AppProtocol[i-1].ProtocolNamespaceLength; j++)
		{
			SupportedAppProtocolReq_Message.AppProtocol[i-1].ProtocolNamespace[j] = i*5;
		}
		SupportedAppProtocolReq_Message.AppProtocol[i-1].VersionNumberMajor = i*5;
		SupportedAppProtocolReq_Message.AppProtocol[i-1].VersionNumberMinor = i*5;
		SupportedAppProtocolReq_Message.AppProtocol[i-1].Priority = i*5;
		SupportedAppProtocolReq_Message.AppProtocol[i-1].SchemaID = i*5;
	}

	/* Manual Call for now */
	ChrgM_DataLinkIndication(0, ETHTRCV_LINK_STATE_ACTIVE);
}

/********************************************************************************************************************************
 * Service Name: ChrgM_StartProcess
 * Service ID[hex]: 0x25
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): Process - It is a boolean value to start the Charge Process
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This API gets called by the upper layer to start the Charging Process
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00017],[CP_SWS_ChrgM_00018],[CP_SWS_ChrgM_00020],[CP_SWS_ChrgM_00021],
			  [CP_SWS_ChrgM_00022],[CP_SWS_ChrgM_00023],[CP_SWS_ChrgM_00024],[CP_SWS_ChrgM_00025],[CP_SWS_ChrgM_00026]
 *********************************************************************************************************************************/
void ChrgM_StartProcess(boolean Process)
{
	ChrgM_ProcessStarted = Process;
}

/************************************************************************************
 * Service Name: ChrgM_CpLineStatus
 * Service ID[hex]: 0x1E
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): CpLineStatus - This it the status of the CP line
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Upper layer calls this API to inform ChrgM about CP line status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00020],[CP_SWS_ChrgM_00022],[CP_SWS_ChrgM_00024]
 ************************************************************************************/
void ChrgM_CpLineStatus (char CpLineStatus)
{
	ChrgM_CpLine = CpLineStatus;
}

/************************************************************************************
 * Service Name: ChrgM_DataLinkIndication
 * Service ID[hex]: 0x02
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the Ethernet Interface
 * 				   TransceiverLinkState - Actual transceiver link state of the specific network handle
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This API is called by the EthSM to inform the ChrgM about the state of the data link connection
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00020],[CP_SWS_ChrgM_00022],[CP_SWS_ChrgM_00024]
 ************************************************************************************/
void ChrgM_DataLinkIndication (uint8 CtrlIdx, EthTrcv_LinkStateType TransceiverLinkState)
{
	ChrgM_TransceiverLinkState = TransceiverLinkState;
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpCopyRxData
 * Service ID[hex]: 0x44
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in):  PduIdType id,
					 const PduInfoType* info,

 * Parameters (inout): None
 * Parameters (out): PduLengthType* bufferSizePtr
 * Return value: BufReq_ReturnType
 * Description: This function is called to provide the received data of an I-PDU segment (N-PDU) to the upper
   layer. Each call to this function provides the next part of the I-PDU data. The size of the
   remaining buffer is written to the position indicated by bufferSizePtr.
 ************************************************************************************/
BufReq_ReturnType ChrgM_V2GTpCopyRxData (PduIdType id, const PduInfoType* info, PduLengthType bufferSize)
{
	BufReq_ReturnType BufReq_Return = BUFREQ_OK;

	if (ChrgM_ModuleState == CHRGM_NOT_INITIALIZED)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_UNINIT);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	else if (info == NULL_PTR/* || bufferSizePtr == NULL_PTR*/)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_PARAM_POINTER);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	if (info->SduDataPtr == NULL_PTR || info->SduLength == 0)
	{
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	else if(bufferSize < info->SduLength)
	{
		/* Not enough space available */
		BufReq_Return = BUFREQ_E_NOT_OK;
	}
	else
	{
		memcpy(MessageBuffer, info->SduDataPtr, info->SduLength);

		//Received_Payload = info->SduLength - V2G_HEADER_SIZE;

		//*bufferSizePtr = *bufferSizePtr - info->SduLength;
	}

	return BufReq_Return;
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpCopyTxData
 * Service ID[hex]: 0x43
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in):  PduIdType id,
					 const PduInfoType* info,
					 const RetryInfoType* retry,

 * Parameters (inout): None
 * Parameters (out): PduLengthType* availableDataPtr
 * Return value: BufReq_ReturnType
 * Description: This function is called to acquire the transmit data of an I-PDU segment (N-PDU). Each call to
   this function provides the next part of the I-PDU data unless retry->TpDataState is TP_
   DATARETRY. In this case the function restarts to copy the data beginning at the offset from the
   current position indicated by retry->TxTpDataCnt. The size of the remaining data is written to
   the position indicated by availableDataPtr.
 ************************************************************************************/

BufReq_ReturnType ChrgM_V2GTpCopyTxData (PduIdType id, const PduInfoType* info, const RetryInfoType* retry, PduLengthType* availableDataPtr)
{
	BufReq_ReturnType BufReq_Return = BUFREQ_OK;

	if (ChrgM_ModuleState == CHRGM_NOT_INITIALIZED)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_UNINIT);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	else if (info == NULL_PTR || availableDataPtr == NULL_PTR || retry == NULL_PTR)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_PARAM_POINTER);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	if (*availableDataPtr < info->SduLength)
	{
		/* Not enough space available */
		BufReq_Return =  BUFREQ_E_BUSY;
	}
	else
	{
		/* If the retry parameter is not NULL, we need to handle the data copying accordingly */
		if (retry != NULL_PTR && retry->TpDataState == TP_DATARETRY)
		{
			/* Retry copy from where it previously failed (indicated by retry->TxTpDataCnt) */
			//memcpy(ChrgM_transmitBuffer + retry->TxTpDataCnt, info->SduDataPtr, info->SduLength);
		}
		else
		{
			/* Normal copy operation */
			//memcpy(ChrgM_transmitBuffer, info->SduDataPtr, info->SduLength);
		}
		/* Update the available buffer size */
		*availableDataPtr -= info->SduLength;
	}

	/* Return success */
	return BufReq_Return;
}

/*******************************************************************************
 *                        Callback Notifications Definitions                   *
 *******************************************************************************/


/************************************************************************************
 * Service Name: ChrgM_V2GTpRxIndication
 * Service ID[hex]: 0x45
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): id - Identification of the received I-PDU
 	 	 	 	   result - E_OK: The PDU was received.
 	 	 	 	 	 	 	E_NOT_OK: Reception of the PDU failed.
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Called by the lower layer after an I-PDU has been received or after the final I-PDU has been
			   received in case of segmentation
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_V2GTpRxIndication (PduIdType id, Std_ReturnType result)
{
	ChrgM_MessageReceived = TRUE;
	if(result == E_OK)
	{
		ChrgM_ReceptionSuccessful = TRUE;
	}
	else if(result == E_NOT_OK)
	{
		ChrgM_ReceptionSuccessful = FALSE;
	}
	else
	{
		/* Do Nothing */
	}
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpTxConfirmation
 * Service ID[hex]: 0x48
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): id - Identification of the transmitted I-PDU
                   result - E_OK: The PDU was transmitted
                   	   	    E_NOT_OK: Transmission of the PDU failed
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: The lower layer calls this API of the ChrgM to inform the ChrgM about the status of the
			   transmitted PDU
 * Requirments:[CP_RS_ChrgM_00012],[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_V2GTpTxConfirmation (PduIdType id, Std_ReturnType result)
{
	ChrgM_TxConfirmationReceived = TRUE;
	if(result == E_OK)
	{
		ChrgM_TransmissionSuccessful = TRUE;
	}
	else if(result == E_NOT_OK)
	{
		ChrgM_TransmissionSuccessful = FALSE;
	}
	else
	{
		/* Do Nothing */
	}
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpStartOfReception
 * Service ID[hex]: 0x46
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): id - Identification of the I-PDU
				   info - Pointer to a PduInfoType structure containing the payload data
				          (without protocol information) and payload length of the first
				          frame or single frame of a transport protocol I-PDU reception, and
				          the MetaData related to this PDU
				   TpSduLength - Total length of the N-SDU to be received
 * Parameters (inout): None
 * Parameters (out): bufferSizePtr - Available receive buffer in the receiving module. This parameter
									will be used to compute the Block Size (BS) in the transport protocol module
 * Return value: BufReq_ReturnType - BUFREQ_OK: Connection has been accepted. bufferSizePtr
											   indicates the available receive buffer; reception is continued. If no
											   buffer of the requested size is available, a receive buffer size of 0
											   shall be indicated by bufferSizePtr
									BUFREQ_E_NOT_OK: Connection has been rejected; reception is
												     aborted. bufferSizePtr remains unchanged
									BUFREQ_E_OVFL: No buffer of the required length can be provided;
												   reception is aborted. bufferSizePtr remains unchanged
 * Description: This function is called at the start of receiving an N-SDU, The service shall provide the currently
 	 	 	   available maximum buffer size when invoked with TpSduLength equal to 0
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
BufReq_ReturnType ChrgM_V2GTpStartOfReception (PduIdType id, const PduInfoType* info, PduLengthType TpSduLength, PduLengthType* bufferSizePtr)
{
	if (ChrgM_ModuleState == CHRGM_NOT_INITIALIZED) {
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_UNINIT);
#endif
		return BUFREQ_E_NOT_OK;
	}

	if (info == NULL_PTR || bufferSizePtr == NULL_PTR) {
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_PARAM_POINTER);
#endif

	}

	return BUFREQ_OK;
}

/*******************************************************************************
 *                               Non SWS API'S                                 *
 *******************************************************************************/
#if(CHRGM_SDP_USED == STD_ON)
/************************************************************************************
 * Service Name: ChrgM_SECCDiscoveryProtocolReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): SECCDiscoveryProtocolReq - SECC Discovery Protocol Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending SECC Discovery Protocol Message
 * Requirments:
 ************************************************************************************/
void ChrgM_SECCDiscoveryProtocolReq(SECCDiscoveryProtocolReqType* SECCDiscoveryProtocolData)
{
	Message_Received_Indication = FALSE;
	/* Set Data Pointer to to data buffer while leaving space for V2GTP Header */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;
	/* V2G Payload Body */
	/* SECC Security */
	*((uint8*)MessageBuffer_Ptr) = SECCDiscoveryProtocolData->SECCSecurity;
	MessageBuffer_Ptr +=  SDP_SECURITY_SIZE;
	/* SECC Transport Protocol */
	*((uint8*)MessageBuffer_Ptr) = SECCDiscoveryProtocolData->SECCTransportProtocol;
	MessageBuffer_Ptr += SDP_TRANSPORT_PROTOCOL_SIZE;
	/* Calculate Payload Length */
	Sent_Payload = MessageBuffer_Ptr - MessageBuffer - V2G_HEADER_SIZE;
}
#endif
/************************************************************************************
 * Service Name: ChrgM_SupportedAppProtocolReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): SupportedAppProtocolReqType - SupportAppProtocol Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending SupportedAppProtocolReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_SupportedAppProtocolReq(SupportedAppProtocolReqType* SupportedAppProtocolReqData)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to SupportedAppProtocol Message */
	ChrgM_RequestedMessage = SUPPORTED_APP_PROTOCOL;
	/* Set Data Pointer to to data buffer while leaving space for V2GTP Header */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;
	/* Send header and Message data to buffer */
	/* V2G Payload Header */
	/* Session ID */
	*((uint8*)MessageBuffer_Ptr) = SESSION_ID_ZERO;
	MessageBuffer_Ptr += SESSION_ID_SIZE;
	/* Notification use is not available for EV */
	*((uint8*)MessageBuffer_Ptr) = NOT_USED;
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	/* Signature */
	*((uint8*)MessageBuffer_Ptr) = NOT_USED;
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;

	/* V2G Payload Body */
	/* Message Name */
	*((uint8*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->MessageName;
	MessageBuffer_Ptr += MESSAGE_NAME_SIZE;
	/* Number of Protocols to be sent */
	*((uint8*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->NumberOfProtocols;
	MessageBuffer_Ptr += NUMBER_OF_PROTOCOLS_SIZE;
	uint8 Index = SupportedAppProtocolReqData->NumberOfProtocols;
	for(uint8 i = 0; i < Index; i++)
	{
		/* Protocol Name */
		uint8 j = 0;
		*((uint8*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->AppProtocol[i].ProtocolNamespaceLength;
		MessageBuffer_Ptr += PROTOCOL_NAMESPACE_SIZE;
		while(j < SupportedAppProtocolReqData->AppProtocol[i].ProtocolNamespaceLength)
		{
			*((uint8*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->AppProtocol[i].ProtocolNamespace[j];
			MessageBuffer_Ptr += PROTOCOL_NAMESPACE_SIZE;
			j++;
		}
		/* Major Version Number */
		*((uint32*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->AppProtocol[i].VersionNumberMajor;
		MessageBuffer_Ptr += MAJOR_VERSION_NUMBER_SIZE;
		/* Minor Version Number */
		*((uint32*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->AppProtocol[i].VersionNumberMinor;
		MessageBuffer_Ptr += MINOR_VERSION_NUMBER_SIZE;
		/* SchemaID */
		*((uint8*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->AppProtocol[i].SchemaID;
		MessageBuffer_Ptr += SCHEMA_ID_SIZE;
		/* Priority */
		*((uint8*)MessageBuffer_Ptr) = SupportedAppProtocolReqData->AppProtocol[i].Priority;
		MessageBuffer_Ptr += PRIORITY_SIZE;
	}

	/* Calculate Payload Length */
	Sent_Payload = MessageBuffer_Ptr - MessageBuffer - V2G_HEADER_SIZE;
}

/************************************************************************************
 * Service Name: ChrgM_SessionSetupReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): SessionSetupReqData - SessionSetupReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending SessionSetupReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_SessionSetupReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Session Setup Message */
	ChrgM_RequestedMessage = SESSION_SETUP;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDiscoveryReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): ServiceDiscoveryReqData - ServiceDiscoveryReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending ServiceDiscoveryReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_ServiceDiscoveryReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Service Discovery Message */
	ChrgM_RequestedMessage = SERVICE_DISCOVERY;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDetailReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): ServiceDetailReqData - ServiceDetailReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending ServiceDetailReq Message
 * Requirments:
 ************************************************************************************/
//void ChrgM_ServiceDetailReq(ServiceDetailReqType* ServiceDetailReqData, MessageHeaderType* Request_Header)
//{
//
//}

/************************************************************************************
 * Service Name: ChrgM_PaymentServiceSelectionReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): PaymentServiceSelectionReqData - PaymentServiceSelectionReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending PaymentServiceSelectionReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_PaymentServiceSelectionReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Payment Selection Message */
	ChrgM_RequestedMessage = PAYMENT_SELECTION;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_PaymentDetailsReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): PaymentDetailsReqData - PaymentDetailsReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending PaymentDetailsReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_PaymentDetailsReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Payment Details Message */
	ChrgM_RequestedMessage = PAYMENT_DETAILS;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_AuthorizationReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): AuthorizationReqData - AuthorizationReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending AuthorizationReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_AuthorizationReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Authorization Message */
	ChrgM_RequestedMessage = AUTHORIZATION;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_ChargeParameterDiscoveryReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): ChargeParameterDiscoveryReqData - ChargeParameterDiscoveryReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending ChargeParameterDiscoveryReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_ChargeParameterDiscoveryReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Charge Parameter Discovery Message */
	ChrgM_RequestedMessage = CHARGE_PARAMETER_DISCOVERY;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_CableCheckReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): CableCheckReqData - CableCheckReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending CableCheckReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_CableCheckReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Cable Check Message */
	ChrgM_RequestedMessage = CABLE_CHECK;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_PreChargeReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): PreChargeReqData - PreChargeReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending PreChargeReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_PreChargeReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Pre Charge Message */
	ChrgM_RequestedMessage = PRE_CHARGE;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_PowerDeliveryReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): PowerDeliveryReqData - PowerDeliveryReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending PowerDeliveryReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_PowerDeliveryReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Power Delivery Message */
	ChrgM_RequestedMessage = POWER_DELIVERY;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_CurrentDemandReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): CurrentDemandReqData - CurrentDemandReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending CurrentDemandReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_CurrentDemandReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Current Demand Message */
	ChrgM_RequestedMessage = CURRENT_DEMAND;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_WeldingDetectionReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): WeldingDetectionReqData - WeldingDetectionReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending WeldingDetectionReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_WeldingDetectionReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Welding Detection Message */
	ChrgM_RequestedMessage = WELDING_DETECTION;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_SessionStopReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): SessionStopReqData - SessionStopReq Data to be sent
 * 					MessageHeaderType - Body header to be sent
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for sending SessionStopReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_SessionStopReq(struct iso1EXIDocument* V2G_Document)
{
	Message_Received_Indication = FALSE;
	/* Set Module Message State to Session Stop Message */
	ChrgM_RequestedMessage = SESSION_STOP;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}
#if(CHRGM_SDP_USED == STD_ON)
/************************************************************************************
 * Service Name: ChrgM_SECCDiscoveryProtocolRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving SECC Discovery Protocol Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_SECCDiscoveryProtocolRes(void)
{
	/* Set Pointer to location of V2G Payload */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;
	/* Read data from buffer */
	/* V2g Payload */
	/* IP Address */
	for(uint8 i = 0; i < SDP_IP_ADDRESS_SIZE; i++)
	{
		SECCDiscoveryProtocolRes_Message.SECCIPAddress[i] = *((uint8*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += SDP_IP_ADDRESS_ELEMENT_SIZE;
	}
	/* Port Number */
	SECCDiscoveryProtocolRes_Message.SECCPortNumber = *((uint32*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += SDP_PORT_NUMBER_SIZE;
	/* SECC Security*/
	SECCDiscoveryProtocolRes_Message.SECCSecurity = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += SDP_SECURITY_SIZE;
	/* SECC Transport Protocol */
	SECCDiscoveryProtocolRes_Message.SECCTransportProtocol = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += SDP_TRANSPORT_PROTOCOL_SIZE;
}
#endif
/************************************************************************************
 * Service Name: ChrgM_SupportedAppProtocolRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving SupportedAppProtocolRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_SupportedAppProtocolRes(void)
{
	/* Set Pointer to location of V2G Payload */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;

	/* Read data from buffer */
	/* V2g Payload */
	/* V2G Payload Header */
	/* Session ID */
	Response_Header.SessionID = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += SESSION_ID_SIZE;
	Response_Header.NotificationUsed = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	//	if(Response_Header.NotificationUsed == USED)
	//	{
	//		/* Fault Code */
	//		Response_Header.Notification.FaultCode = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += FAULT_CODE_SIZE;
	//		Response_Header.Notification.FaultMsgUsed = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	//		/* Check if Notification Message element is used */
	//		if(Response_Header.Notification.FaultMsgUsed == USED)
	//		{
	//			/* Fault Message */
	//			uint8 Index = 0;
	//			while(Index < FAULT_MESSAGE_SIZE - 1 && *((uint8*)MessageBuffer_Ptr) != '\0')
	//			{
	//				Response_Header.Notification.FaultMsg[Index] = *((uint8*)MessageBuffer_Ptr);
	//				MessageBuffer_Ptr += FAULT_MESSAGE_ELEMENT_SIZE;
	//				Index++;
	//			}
	//			/* Insert NULL Character */
	//			Response_Header.Notification.FaultMsg[Index] = *((uint8*)MessageBuffer_Ptr);
	//			MessageBuffer_Ptr += FAULT_MESSAGE_ELEMENT_SIZE;
	//		}
	//		else
	//		{
	//			/* Do Nothing */
	//		}
	//	}
	//	else
	//	{
	//		/* Do Nothing */
	//	}
	//
		Response_Header.SignatureUsed = *((uint8*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	//	/* Check if Signature element is used*/
	//	if(Response_Header.SignatureUsed == USED)
	//	{
	//		/* Canonicalization Method Algorithm */
	//		Response_Header.Signature.SignedInfo.CanonicalizationMethod.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += CANONICALIZATION_ALGORITHM_SIZE;
	//		/* HMAC Output Length */
	//		Response_Header.Signature.SignedInfo.SignatureMethod.HMACOutputLength = *((uint32*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += SIGNATURE_HMAC_SIZE;
	//		/* Signature Method Algorithm */
	//		Response_Header.Signature.SignedInfo.SignatureMethod.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += SIGNATURE_ALGORITHM_SIZE;
	//		/* Transform Algorithm */
	//		Response_Header.Signature.SignedInfo.Reference.Transforms.Transform.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += TRANSFORM_ALGORITHM_SIZE;
	//		/* Digest Method Algorithm */
	//		Response_Header.Signature.SignedInfo.Reference.DigestMethod.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += DIGEST_METHOD_ALGORITHM_SIZE;
	//		/* Reference Digest Value */
	//		Response_Header.Signature.SignedInfo.Reference.DigestValue = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += DIGEST_VALUE_SIZE;
	//		/* Reference ID */
	//		Response_Header.Signature.SignedInfo.Reference.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += REFERENCE_ID_SIZE;
	//		/* Signed Info ID */
	//		Response_Header.Signature.SignedInfo.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += SIGNED_INFO_ID_SIZE;
	//		/* Signature Value ID */
	//		Response_Header.Signature.SignatureValue.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += SIGNATURE_VALUE_ID_SIZE;
	//		/* Key Info ID */
	//		Response_Header.Signature.KeyInfo.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += KEY_INFO_ID_SIZE;
	//		/* Object ID */
	//		Response_Header.Signature.Object.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += OBJECT_ID_SIZE;
	//		/* Signature ID */
	//		Response_Header.Signature.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += SIGNATURE_ID_SIZE;
	//	}
	//	else
	//	{
	//		/* Do Nothing */
	//	}

	/* V2G Payload Body */
	/* Message Name */
	SupportedAppProtocolRes_Message.MessageName = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += MESSAGE_NAME_SIZE;
	/* Response Code */
	SupportedAppProtocolRes_Message.ResponseCode = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += RESPONSE_CODE_SIZE;
	SupportedAppProtocolRes_Message.SchemaIDUsed = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	/* Check if Schema ID element is used */
	if(SupportedAppProtocolRes_Message.SchemaIDUsed == USED)
	{
		/* Schema ID */
		SupportedAppProtocolRes_Message.SchemaID = *((uint8*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += SCHEMA_ID_SIZE;
	}
	else
	{
		/* Do Nothing */
	}
}

/************************************************************************************
 * Service Name: ChrgM_WriteV2GTPHeader
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy:
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function is responsible for writing the V2GTP Message Header
 * Requirments:
 ************************************************************************************/
void ChrgM_WriteV2GTPHeader(void)
{
	/* Set Data Pointer to first byte of Data Buffer */
	MessageBuffer_Ptr = &MessageBuffer[0];
	/* Write V2GTP header*/
	/* Protocol Version */
	*((uint8*)MessageBuffer_Ptr) = PROTOCOL_VERSION;
	MessageBuffer_Ptr += PROTOCOL_VERSION_SIZE;
	/* Inverse Protocol Version */
	*((uint8*)MessageBuffer_Ptr) = INVERSE_PROTOCOL_VERSION;
	MessageBuffer_Ptr += INVERSE_PROTOCOL_VERSION_SIZE;
	/* Payload Type depending on SDP or V2G Message */
	if(ChrgM_ModuleState == DISCOVERING_SECC)
	{
		*((uint16*)MessageBuffer_Ptr) = SDP_REQUEST_PAYLOAD_TYPE_VALUE;
		MessageBuffer_Ptr += PAYLOAD_TYPE_SIZE;
	}
	else
	{
		*((uint16*)MessageBuffer_Ptr) = V2G_MESSAGE_PAYLOAD_TYPE_VALUE;
		MessageBuffer_Ptr += PAYLOAD_TYPE_SIZE;
	}
	/* Payload Length */
	*((uint32*)MessageBuffer_Ptr) = Sent_Payload;
	MessageBuffer_Ptr += PAYLOAD_LENGTH_SIZE;

	/* Store PDU Length */
	ChrgM_PduInfo.SduLength = Sent_Payload + V2G_HEADER_SIZE;
}

/************************************************************************************
 * Service Name: ChrgM_ReadV2GTPHeader
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy:
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): Std_ReturnType - Validation if there is an error or not
 * Return value: None
 * Description: This function is responsible for reading and checking V2GTP Header errors
 * Requirments:
 ************************************************************************************/
Std_ReturnType ChrgM_ReadV2GTPHeader(void)
{
	Std_ReturnType Header_Check = E_OK;
	/* Set Data Pointer to first byte of Data Buffer */
	MessageBuffer_Ptr = MessageBuffer;
	/* V2G Header */
	/* Protocol Version */
	V2G_Response_Header.ProtocolVersion = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += PROTOCOL_VERSION_SIZE;
	/* Inverse Protocol Version */
	V2G_Response_Header.InverseProtocolVersion = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += INVERSE_PROTOCOL_VERSION_SIZE;
	/* Payload Type */
	V2G_Response_Header.PayloadType = *((uint16*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += PAYLOAD_TYPE_SIZE;
	/* Payload Length */
	V2G_Response_Header.PayloadLength = *((uint32*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += PAYLOAD_LENGTH_SIZE;

	Received_Payload = V2G_Response_Header.PayloadLength;

	/* Check Protocol Version */
	if(V2G_Response_Header.ProtocolVersion != PROTOCOL_VERSION && V2G_Response_Header.InverseProtocolVersion != INVERSE_PROTOCOL_VERSION)
	{
		Header_Check = E_NOT_OK;
	}
	/* Check Payload Length */
	else if(V2G_Response_Header.PayloadLength != Received_Payload)
	{
		Header_Check = E_NOT_OK;
	}
	/* Check Payload Type */
	else
	{
		if(ChrgM_ModuleState == DISCOVERING_SECC)
		{
			if(V2G_Response_Header.PayloadType != SDP_RESPONSE_PAYLOAD_TYPE_VALUE)
			{
				Header_Check = E_NOT_OK;
			}
			else
			{
				/* Do Nothing */
			}
		}
		else
		{
			if(V2G_Response_Header.PayloadType != V2G_MESSAGE_PAYLOAD_TYPE_VALUE)
			{
				Header_Check = E_NOT_OK;
			}
			else
			{
				/* Do Nothing */
			}
		}
	}

	return Header_Check;
}

/************************************************************************************
 * Service Name: ChrgM_EXIEncode
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different instances. Non reentrant for the same instance
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the XML Encoding required
 * Requirments:
 ************************************************************************************/
Std_ReturnType ChrgM_EXIEncode(uint8 *output_buffer, uint32 *output_size)
{
	int errn = 0;
	bitstream_t oStream;
	size_t pos = 0;

	/* Setup output stream */
	oStream.size = BUFFER_SIZE;
	oStream.data = output_buffer;
	oStream.pos = &pos;
	oStream.buffer = 0;
	oStream.capacity = 8;

#if DEPLOY_ISO1_CODEC == SUPPORT_YES
	errn = encode_iso1ExiDocument(&oStream, ChrgM_DocumentPtr);
	*output_size = pos;
	if (errn == 0)
	{
		return E_OK;
	}
	else
	{
		return E_NOT_OK;
	}
#endif /* DEPLOY_ISO1_CODEC == SUPPORT_YES */
}

/************************************************************************************
 * Service Name: ChrgM_EXIDecode
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different instances. Non reentrant for the same instance
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the XML Decoding required
 * Requirments:
 ************************************************************************************/
Std_ReturnType ChrgM_EXIDecode(uint8 *input_buffer, uint32 input_size, struct iso1EXIDocument *V2G_Document)
{
	int errn = 0;
	bitstream_t iStream;
	size_t pos = 0; // Initialize the position to the start of the buffer

	/* Setup input stream */
	iStream.size = input_size;
	iStream.data = input_buffer;
	iStream.pos = &pos;  // Set pos as the pointer to the current position
	iStream.buffer = 0;
	iStream.capacity = 0;

#if DEPLOY_ISO1_CODEC == SUPPORT_YES
	errn = decode_iso1ExiDocument(&iStream, V2G_Document);
	if (errn == 0)
	{
		return E_OK;
	}
	else
	{
		return E_NOT_OK;
	}
#endif /* DEPLOY_ISO1_CODEC == SUPPORT_YES */
}


