/*
 * EthIf_Deviation_Sheet.h
 *
 *  Created on: 29 Oct 2023
 *      Author: Omen
 */

#ifndef ETHIF_DEVIATION_SHEET_H_
#define ETHIF_DEVIATION_SHEET_H_

/************************************************************************************
* Service Name: EthIf_Init
* Requirements: SWS_EthIf_00116
*  If development error detection is enabled: the function shall
check the parameter CfgPtr for containing a valid configuration. If the check fails,
the function shall raise the development error ETHIF_E_INIT_FAILED
************************************************************************************/

/************************************************************************************
* Service Name: EthIf_SetControllerMode
* Requirements: [SWS_EthIf_00266],[SWS_EthIf_00478],[SWS_EthIf_00264],[SWS_EthIf_00272],[SWS_EthIf_00479],[SWS_EthIf_00480],
* [SWS_EthIf_00481],[SWS_EthIf_00482],[SWS_EthIf_00483],[SWS_EthIf_00484],[SWS_EthIf_00485],[SWS_EthIf_00265].
************************************************************************************/
/************************************************************************************
* Service Name: EthIf_ProvideTxBuffer
* Requirements: [SWS_EthIf_00147],
************************************************************************************/
/************************************************************************************
* Service Name:  EthIf_Transmit
* Requirements: [SWS_EthIf_00250],
************************************************************************************/
/************************************************************************************
* Service Name:  EthIf_RxIndication
* Requirements: [SWS_EthIf_00151],[SWS_EthIf_00145]
************************************************************************************/

#endif /* ETHIF_DEVIATION_SHEET_H_ */
