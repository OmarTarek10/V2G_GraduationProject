/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_Externals.h
 *
 * Description: Header file for external ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef CHRGM_EXTERNALS_H_
#define CHRGM_EXTERNALS_H_

#include "V2G_Data_Types.h"

void ChrgM_ErrorIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_PaymentServiceSelectionIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_SessionSetupIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_SessionStopIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_SupportedAppProtocolIndication(ChrgM_ResponseCodeType ResponseCode);

void ChrgM_ServiceDiscoveryIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_ServiceDetailIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_PaymentDetailsIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_AuthorizationIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_ChargeParameterDiscoveryIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_CableCheckIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_PreChargeIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_PowerDeliveryIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_CurrentDemandIndication (ChrgM_ResponseCodeType ResponseCode);

void ChrgM_WeldingDetectionIndication (ChrgM_ResponseCodeType ResponseCode);

#endif /* CHRGM_EXTERNALS_H_ */
