 /******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_PBCfg.c
 *
 * Description: Post Build Configuration Source file - ChrgM Driver
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM.h"

/*
 * Module Version 1.0.0
 */
#define CHRGM_PBCFG_SW_MAJOR_VERSION              (1U)
#define CHRGM_PBCFG_SW_MINOR_VERSION              (0U)
#define CHRGM_PBCFG_SW_PATCH_VERSION              (0U)

/*
 * AUTOSAR Version 1.0.0
 */
#define CHRGM_PBCFG_AR_RELEASE_MAJOR_VERSION     (1U)
#define CHRGM_PBCFG_AR_RELEASE_MINOR_VERSION     (0U)
#define CHRGM_PBCFG_AR_RELEASE_PATCH_VERSION     (0U)

/* AUTOSAR Version checking between ChrgM_PBcfg.c and ChrgM.h files */
#if ((CHRGM_PBCFG_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
 ||  (CHRGM_PBCFG_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
 ||  (CHRGM_PBCFG_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
  #error "The AR version of PBcfg.c does not match the expected version"
#endif

/* Software Version checking between ChrgM_PBcfg.c and ChrgM.h files */
#if ((CHRGM_PBCFG_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
 ||  (CHRGM_PBCFG_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
 ||  (CHRGM_PBCFG_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
  #error "The SW version of PBcfg.c does not match the expected version"
#endif

const ChrgM_ConfigType ChrgM_Configuration = {
		//0, /* Not used as IP Address is statically configured */
		.ChrgM_Timer =
		{
				V2G_EVCC_COMMUNICATION_SETUP_TIMER_VALUE,
				V2G_EVCC_SDP_TIMER_VALUE,
				V2G_EVCC_CABLE_CHECK_TIMER_VALUE,
				V2G_EVCC_PRE_CHARGE_TIMER_VALUE,
				V2G_EVCC_ONGOING_TIMER_VALUE,
				CHRGM_V2G_EVCC_SUPPORTED_APP_PROTOCOL_TIMER_VALUE,
				CHRGM_V2G_EVCC_SESSION_SETUP_TIMER_VALUE,
				CHRGM_V2G_EVCC_SERVICE_DISCOVERY_TIMER_VALUE,
				CHRGM_V2G_EVCC_PAYMENT_SERVICE_SELECTION_TIMER_VALUE,
				CHRGM_V2G_EVCC_PAYMENT_DETAILS_TIMER_VALUE,
				CHRGM_V2G_EVCC_AUTHORIZATION_TIMER_VALUE,
				CHRGM_V2G_EVCC_CHARGE_PARAMETER_DISCOVERY_TIMER_VALUE,
				CHRGM_V2G_EVCC_POWER_DELIVERY_TIMER_VALUE,
				CHRGM_V2G_EVCC_CURRENT_DEMAND_TIMER_VALUE,
				CHRGM_V2G_EVCC_WELDING_DETECTION_TIMER_VALUE,
				CHRGM_V2G_EVCC_SESSION_STOP_TIMER_VALUE,
		},
		.ChrgM_V2GTP =
		{
				/* Pointer ChrgMV2GUdpSdpClientRef */
				.ChrgMV2GSrcTcpDataRef = &SoAdConfigPtr,
				.ChrgM_V2GTPPdu =
				{
						.ChgMV2GTPPduPayloadType = V2G_MESSAGE_PAYLOAD_TYPE_VALUE,
						.ChrgMV2GTPPduProtocolVersion = PROTOCOL_VERSION,
						.ChrgMV2GTPPduHandleId = 1 /* Static for now should be pointer from Pdu Structure */
						/* ChrgMV2GTPPduRef Pointer to Pdu Structure */
				}
		}
};
