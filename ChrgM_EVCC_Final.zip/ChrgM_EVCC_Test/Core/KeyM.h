/******************************************************************************
 *
 * Module: KeyM
 *
 * File Name: KeyM.h
 *
 * Description:
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef KEYM_H_
#define KEYM_H_

/* ID for the company in the AUTOSAR
 * for example Mahmoud Shaarawy's ID = 7022 */
#define KEYM_VENDOR_ID                  (7022U)

/* KeyM Module ID */
#define KEYM_MODULE_ID                  (109U)

/* KeyM Instance ID */
#define KEYM_INSTANCE_ID                (0U)

/*
 * Module Version 1.0.0
 */
#define KEYM_SW_MAJOR_VERSION           (1U)
#define KEYM_SW_MINOR_VERSION           (0U)
#define KEYM_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 1.0.0
 */
#define KEYM_AR_RELEASE_MAJOR_VERSION   (1U)
#define KEYM_AR_RELEASE_MINOR_VERSION   (0U)
#define KEYM_AR_RELEASE_PATCH_VERSION   (0U)

/*
 * Macros for keyM Status
 */
#define KEYM_INITIALIZED                (1U)
#define KEYM_NOT_INITIALIZED            (0U)


/* Standard AUTOSAR types */
#include "Std_Types.h"

/*
 * AUTOSAR checking between Std Types and KeyM Modules
 */

#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != KEYM_AR_RELEASE_MAJOR_VERSION)\
||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != KEYM_AR_RELEASE_MINOR_VERSION)\
||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != KEYM_AR_RELEASE_PATCH_VERSION))
 #error "The AR version of Std_Types.h does not match the expected version"
#endif


/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef struct
{
	uint32 certDataLength;
	void* certData;
}KeyM_CertDataType;

typedef uint16 KeyM_CertificateIdType;


/*******************************************************************************
 *                              Mandatory Interfaces                           *
 *******************************************************************************/

Std_ReturnType KeyM_GetCertificate (KeyM_CertificateIdType CertId, KeyM_CertDataType* CertificateDataPt);

Std_ReturnType KeyM_SetCertificate (KeyM_CertificateIdType CertId, const KeyM_CertDataType* CertificateDataPtr);

Std_ReturnType KeyM_VerifyCertificate (KeyM_CertificateIdType CertId);




#endif /* KEYM_H_ */
