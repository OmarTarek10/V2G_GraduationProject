 /******************************************************************************
 *
 * Module: TcpIp
 *
 * File Name: IpSec.h
 *
 * Description: Source file for the IP Security
 *
 * Author: Kareem Azab
 *
 *******************************************************************************/




#include "IpSec.h"
#include "TcpIp_Cfg.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "Crypto_GeneralTypes.h"
#include "Csm/Csm.h"
#include "CryIf/CryIf.h"
#include "cpu_endian.h"
#include "CryptoDriver/Crypto_Cfg.h"




#define MAX_SA_CACHE_SIZE 	10
#define MAX_SPD_ENTRIES		10
#define SA_REQ_TIMOUT		5




SecurityAssociation saCache[MAX_SA_CACHE_SIZE];
IpsecSpdEntry spdEntries[MAX_SPD_ENTRIES];
uint8 numEntries = 0;
Table_State_Type CacheState=NOT_INIT_TABLE;
Table_State_Type SpdState=NOT_INIT_TABLE;

CsmKeyStub private={
		{0xc3, 0xc7, 0xb5, 0x8f, 0x5d, 0x17, 0xef, 0x50, 0xbc, 0x5f, 0xfa, 0xff, 0x7a, 0x9f, 0x0d, 0x66, 0x0e, 0x51, 0xba,
				0xc5, 0xdb, 0x54, 0xe0, 0x01, 0x40, 0xdc, 0x6f, 0xc4, 0xe1, 0x0d, 0xde, 0x03},
		32
};

CsmKeyStub public={
		{0x3f, 0xee, 0xfe, 0xcd, 0xb3, 0x4b, 0xeb, 0xcf, 0x10, 0x5f, 0xd5, 0x45, 0x88, 0xaf, 0xd2, 0x43, 0x3a, 0x3b, 0xa3, 0xa5, 0x01, 0x7a, 0x9b, 0x02,
				0x25, 0xc5, 0x43, 0x50, 0x07, 0x54, 0x14, 0x58},
		32
};




CsmKeyStub shared={
		{0x5d, 0xd6, 0x12, 0x29, 0xce, 0xd9, 0x2d, 0xb4, 0x76, 0x8e, 0x6a, 0xe1, 0x43, 0x63, 0xeb, 0x1e, 0xec, 0x55, 0x25, 0x32, 0xd8, 0x24, 0x7f,
				0xa9, 0x70, 0x63, 0xb8, 0x1e, 0xac, 0x3a, 0x31, 0x33},
		32
};

IPv6Addr addr={.map8={0x20,0x01,0x0D,0xB8,0x85,0xA3,0x00,0x00,0x00,0x00,0x8A,0x2E,0x03,0x70,0x73,0x34}};

/*******************************************************************************
 *                              Local APIs handles the SA caching                *
 *******************************************************************************/

void initializeSACache() {
    for (uint8 i = 0; i < MAX_SA_CACHE_SIZE; i++) {
        saCache[i].initiatorSpi = 0;
        saCache[i].responderSpi = 0;
        saCache[i].address = (IPv6Addr){0}; // Assuming IPv6Addr is a struct that can be zeroed out like this
        saCache[i].remotePort = 0;
        saCache[i].encAlgId = 0; // Assuming 0 is an invalid/unused ID
        saCache[i].prfAlgId = 0; // Assuming 0 is an invalid/unused ID
        saCache[i].authAlgId = 0; // Assuming 0 is an invalid/unused ID
        saCache[i].dhGroupNum = 0; // Assuming 0 is an invalid/unused group number
    }
    CacheState = INIT_TABLE;
}



Std_ReturnType addSA(uint64 initiatorSpi) {
    for (uint8 i = 0; i < MAX_SA_CACHE_SIZE; i++) {
        if (saCache[i].initiatorSpi == 0) { // Assuming 0 means the slot is unused
            saCache[i].initiatorSpi = initiatorSpi;
            return E_OK; // Success
        }
    }
    return E_NOT_OK; // Cache full
}


// Function to find an SA in the cache by SPI
SecurityAssociation* findSA(uint64_t initiatorSpi) {
    for (uint8 i = 0; i < MAX_SA_CACHE_SIZE; i++) {
        if (saCache[i].initiatorSpi == initiatorSpi) {
            return &saCache[i];
        }
    }
    return NULL; // Not found
}




// Function to check if an SA exists in the cache
Std_ReturnType saExists(uint64_t spi) {
    return (findSA(spi) != NULL) ? E_OK : E_NOT_OK;
}


/****************************************************************************************************/





/*******************************************************************************
 *                Local APIs handles the Security Policy Database               *
 *******************************************************************************/
uint8 areIPv6AddrsEqual(const IPv6Addr addr1, const IPv6Addr addr2) {
    for (uint8 i = 0; i < 16; i++) {
        if (addr1.map8[i] != addr2.map8[i]) {
            return 0;
        }
    }
    return 1;
}

void initializeSpdTable() {
    for (uint8 i = 0; i < MAX_SPD_ENTRIES; ++i) {
        spdEntries[i].mode = IPSEC_MODE_TRANSPORT;
        spdEntries[i].protocol = IPSEC_PROTOCOL_ESP;
        spdEntries[i].flag = 0;
        spdEntries[i].seq = 0;
        spdEntries[i].spi = 0;
    }

    numEntries=0;
    SpdState=INIT_TABLE;


}

// Function to add an entry to the SPD array
Std_ReturnType addSpdEntry(IPv6Addr addr) {
    if (numEntries >= MAX_SPD_ENTRIES) {
        return E_NOT_OK;  // Array is full
    }
    for (uint8 i = 0; i < MAX_SA_CACHE_SIZE; i++) {
        if (spdEntries[i].flag == 0) { // Assuming 0 means the slot is unused
            spdEntries[i].addr =addr ;
            spdEntries[i].policyAction=IPSEC_POLICY_ACTION_PROTECT;
            spdEntries[i].flag=1;
            spdEntries[i].spi=rand();

            numEntries++;
            return E_OK; // Success
        }
    }

    return E_NOT_OK;  // Success
}

// Function to find an entry in the SPD array
IpsecSpdEntry* findSpdEntry(IPv6Addr addr) {
    for (uint8 i = 0; i < numEntries; i++) {
        if (areIPv6AddrsEqual(spdEntries[i].addr, addr)) {
            return &spdEntries[i];
        }
    }
    return NULL;  // Not found
}



Std_ReturnType spdExists(IPv6Addr addr) {
    return (findSpdEntry(addr)  != NULL) ? E_OK : E_NOT_OK;
}

/****************************************************************************************************/

Std_ReturnType IKEV2_SA_Req(SecurityAssociation* SA,uint8 * request ){

	Std_ReturnType ret=E_OK;

	uint8 * ptr = request;
	uint8 len=0;


	IKEv2Header * header;





  	/*******************************************************
  	 *                     Adding the IKEV2 header          *
  	 *******************************************************/

  	  header=(IKEv2Header *) ptr;


      header->initiator_spi = HTONLL(SA->initiatorSpi);
      header->responder_spi = 0; // Typically 0 in SA_INIT since responder SPI not yet known
      header->next_payload = IKE_PAYLOAD_TYPE_SA; // The payload type for SA, typically defined in a specification header
      header->majorVersion=2; // IKEv2 is version 2.0, sometimes represented
      header->minorVersion=0;
      header->exchange_type = IKE_EXCHANGE_TYPE_SA_INIT; // Defined as per the specification, typically an enum or macro
      header->flags = IKE_HEADER_FLAG_INITIATOR; // This could include other flags, often combined with a bitwise OR
      header->message_id = 0; // The first message in an IKE exchange has a message ID of 0

      ptr += sizeof(IKEv2Header);
     len += sizeof(IKEv2Header);



  	/*******************************************************
  	 *                     Adding the SA Payload         *
  	 *******************************************************/


  	   IKE_Payload_Header * sa_header = (IKE_Payload_Header *) ptr;
  	   sa_header->nextPayload =IKE_PAYLOAD_TYPE_KE;
  	   sa_header->critical=0;
  	   sa_header->reserved=0;


  	   ptr += sizeof(IKE_Payload_Header);
  	  len += sizeof(IKE_Payload_Header);





  	  IKE_Proposal * proposal=(IKE_Proposal *)ptr;

  	  proposal->lastSubstruc=0;
  	  proposal->reserved=0;

  	  proposal->proposalNum=1;
  	  proposal->protocolId=1;
  	  proposal->spiSize=0;
  	  proposal->numTransforms=3;



  	  ptr += sizeof(IKE_Proposal);
 	  len += sizeof(IKE_Proposal);





  	  IKE_Transform * E_transform = (IKE_Transform *)ptr;
  	  E_transform->lastSubstruc=3;
  	  E_transform->reserved1=0;
  	  E_transform->reserved2=0;
  	  E_transform->transformType=1;
  	  E_transform->transformId=HTONS(IKE_E_TRANSFORM_ID);
  	  SA->encAlgId=IKE_E_TRANSFORM_ID;
  	  E_transform->transformLength=HTONS((sizeof(IKE_Transform)));

  	  ptr += sizeof(IKE_Transform);
 	  len += sizeof(IKE_Transform);

	  IKE_Transform_Attr * E_attr=(IKE_Transform_Attr *)ptr;
  	  E_attr->type=HTONS( (uint16)0x8000|(uint16)14);
  	  E_attr->length=HTONS(32);

  	  ptr += sizeof(IKE_Transform_Attr);
 	  len += sizeof(IKE_Transform_Attr);

  	  IKE_Transform * Int_transform = (IKE_Transform *)ptr;
  	  Int_transform->lastSubstruc=3;
  	  Int_transform->reserved1=0;
  	  Int_transform->reserved2=0;
  	  Int_transform->transformType=3;
  	  Int_transform->transformId=HTONS(IKE_TRANSFORM_AUTH_AES_CMAC_96);
  	  Int_transform->transformLength=HTONS(sizeof(IKE_Transform));

  	  ptr += sizeof(* Int_transform);
 	  len += sizeof(* Int_transform);



  	  IKE_Transform *  DH_transform = (IKE_Transform *)ptr;
  	  DH_transform->lastSubstruc=0;
  	  DH_transform->reserved1=0;
  	  DH_transform->reserved2=0;
  	  DH_transform->transformType=4;
  	  DH_transform->transformId=HTONS(IKE_TRANSFORM_DH_256_BIT_RANDOM_ECP_GROUP);
  	  SA->dhGroupNum=IKE_TRANSFORM_DH_256_BIT_RANDOM_ECP_GROUP;
  	  DH_transform->transformLength=HTONS(sizeof(IKE_Transform));

  	  ptr += sizeof(* DH_transform);
 	  len += sizeof(* DH_transform);

  	 proposal->proposalLength=HTONS(sizeof(IKE_Proposal)+sizeof(*DH_transform)+sizeof(*Int_transform)+sizeof(*E_transform)+sizeof(IKE_Transform_Attr));

  	 sa_header->payloadLength=HTONS(NTOHS(proposal->proposalLength) +sizeof(IKE_Payload_Header));






  		/*******************************************************
  		 *                     Adding the KE Payload         *
  		 *******************************************************/


  	 IKE_Payload_Header * ke_header = (IKE_Payload_Header *) ptr;
  	 ke_header->nextPayload =IKE_PAYLOAD_TYPE_LAST;
  	 ke_header->critical=0;
  	 ke_header->reserved=0;

  	 ptr += sizeof(IKE_Payload_Header);
  	 len += sizeof(IKE_Payload_Header);



  	 IKE_KE_Payload * KE_Payload = (IKE_KE_Payload *) ptr;
  	 KE_Payload->dhGroupNum=HTONS(IKE_TRANSFORM_DH_256_BIT_RANDOM_ECP_GROUP);
  	 KE_Payload->reserved=HTONS(0);

  	 for(uint8 i=0;i<public.keylen;i++)
  	 {
  		 KE_Payload->keyExchangeData[i]=public.key[i];
  	 }


  	ke_header->payloadLength=HTONS((sizeof(* KE_Payload)+sizeof(IKE_Payload_Header)));

  	 len += sizeof(* KE_Payload);
  	 header->length=HTONL(len);





	return ret;
}



Std_ReturnType IKEV2_SA_Res(SecurityAssociation* SA,uint8 * request){

	Std_ReturnType ret=E_OK;
	uint8 * ptr = request;
	uint8 len=0;



	IKEv2Header * header;




  	/*******************************************************
  	 *                     Adding the IKEV2 header          *
  	 *******************************************************/

  	header=(IKEv2Header *) ptr;

      header->initiator_spi = HTONLL(SA->initiatorSpi);
      header->responder_spi = HTONLL(SA->responderSpi); // Typically 0 in SA_INIT since responder SPI not yet known
      header->next_payload = IKE_PAYLOAD_TYPE_SA; // The payload type for SA, typically defined in a specification header
      header->majorVersion=2; // IKEv2 is version 2.0, sometimes represented
      header->minorVersion=0;
      header->exchange_type = IKE_EXCHANGE_TYPE_SA_INIT; // Defined as per the specification, typically an enum or macro
      header->flags = IKE_HEADER_FLAG_RESPONSE; // This could include other flags, often combined with a bitwise OR
      header->message_id = 0; // The first message in an IKE exchange has a message ID of 0

      ptr += sizeof(IKEv2Header);
     len += sizeof(IKEv2Header);



  	/*******************************************************
  	 *                     Adding the SA Payload         *
  	 *******************************************************/


  	   IKE_Payload_Header * sa_header = (IKE_Payload_Header *) ptr;
  	   sa_header->nextPayload =IKE_PAYLOAD_TYPE_KE;
  	   sa_header->critical=0;
  	   sa_header->reserved=0;


  	   ptr += sizeof(IKE_Payload_Header);
  	  len += sizeof(IKE_Payload_Header);





  	  IKE_Proposal * proposal=(IKE_Proposal *)ptr;

  	  proposal->lastSubstruc=0;
  	  proposal->reserved=0;

  	  proposal->proposalNum=1;
  	  proposal->protocolId=1;
  	  proposal->spiSize=0;
  	  proposal->numTransforms=3;



  	  ptr += sizeof(IKE_Proposal);
 	  len += sizeof(IKE_Proposal);






  	  IKE_Transform * E_transform = (IKE_Transform *)ptr;
  	  E_transform->lastSubstruc=3;
  	  E_transform->reserved1=0;
  	  E_transform->reserved2=0;
  	  E_transform->transformType=1;
  	  E_transform->transformId=HTONS(IKE_E_TRANSFORM_ID);
  	  E_transform->transformLength=HTONS((sizeof(IKE_Transform)));

  	  ptr += sizeof(IKE_Transform);
 	  len += sizeof(IKE_Transform);


  	  IKE_Transform_Attr * E_attr=(IKE_Transform_Attr *)ptr;
  	  E_attr->type=HTONS( (uint16)0x8000|(uint16)14);
  	  E_attr->length=HTONS(32);
  	  ptr += sizeof(IKE_Transform_Attr);
 	  len += sizeof(IKE_Transform_Attr);

  	  IKE_Transform * Int_transform = (IKE_Transform *)ptr;
  	  Int_transform->lastSubstruc=3;
  	  Int_transform->reserved1=0;
  	  Int_transform->reserved2=0;
  	  Int_transform->transformType=3;
  	  Int_transform->transformId=HTONS(IKE_TRANSFORM_AUTH_AES_CMAC_96);
  	  Int_transform->transformLength=HTONS(sizeof(IKE_Transform));

  	  ptr += sizeof(* Int_transform);
 	  len += sizeof(* Int_transform);



  	  IKE_Transform *  DH_transform = (IKE_Transform *)ptr;
  	  DH_transform->lastSubstruc=0;
  	  DH_transform->reserved1=0;
  	  DH_transform->reserved2=0;
  	  DH_transform->transformType=4;
  	  DH_transform->transformId=HTONS(IKE_TRANSFORM_DH_256_BIT_RANDOM_ECP_GROUP);
  	  DH_transform->transformLength=HTONS(sizeof(IKE_Transform));

  	  ptr += sizeof(* DH_transform);
 	  len += sizeof(* DH_transform);

  	 proposal->proposalLength=HTONS(sizeof(IKE_Proposal)+sizeof(*DH_transform)+sizeof(*Int_transform)+sizeof(*E_transform)+sizeof(IKE_Transform_Attr));

  	 sa_header->payloadLength=HTONS(NTOHS(proposal->proposalLength) +sizeof(IKE_Payload_Header));






  		/*******************************************************
  		 *                     Adding the KE Payload         *
  		 *******************************************************/


  	 IKE_Payload_Header * ke_header = (IKE_Payload_Header *) ptr;
  	 ke_header->nextPayload =IKE_PAYLOAD_TYPE_LAST;
  	 ke_header->critical=0;
  	 ke_header->reserved=0;

  	 ptr += sizeof(IKE_Payload_Header);
  	 len += sizeof(IKE_Payload_Header);



  	 IKE_KE_Payload * KE_Payload = (IKE_KE_Payload *) ptr;
  	 KE_Payload->dhGroupNum=HTONS(IKE_TRANSFORM_DH_256_BIT_RANDOM_ECP_GROUP);
  	 KE_Payload->reserved=HTONS(0);

  	 for(uint8 i=0;i<public.keylen;i++)
  	 {
  		 KE_Payload->keyExchangeData[i]=public.key[i];
  	 }


  	ke_header->payloadLength=HTONS((sizeof(* KE_Payload)+sizeof(IKE_Payload_Header)));

  	 len += sizeof(* KE_Payload);
  	 header->length=HTONL(len);



	return ret;
}





Std_ReturnType IKEV2_Auth_Req(SecurityAssociation* SA, uint8 * request){


	Std_ReturnType ret=E_OK;
	uint8 * ptr = request;
	uint8 len=0;
	uint8 data[256];
	uint32 data_len = 0;
	uint8 * dataptr=data;
    uint8 ciphertext[256];
    uint32 cipher_len = 0;

	IKEv2Header * header;



	/*******************************************************
	 *                     Adding the IKEV2 header          *
	 *******************************************************/

		header=(IKEv2Header *) ptr;

		header->initiator_spi = HTONLL(SA->initiatorSpi);
		header->responder_spi = HTONLL(SA->responderSpi);
	    header->majorVersion=2; // IKEv2 is version 2.0, sometimes represented
	    header->minorVersion=0;
		header->exchange_type = IKE_EXCHANGE_TYPE_AUTH;
		header->flags = IKE_HEADER_FLAG_INITIATOR;
		header->message_id = HTONL(1);

		ptr += sizeof(IKEv2Header);
	   len += sizeof(IKEv2Header);

	/*******************************************************
	 *                     Adding the ID Payload         *
	 *******************************************************/

	   IKE_Payload_Header * id_header = (IKE_Payload_Header *) dataptr;
	   id_header->nextPayload =IKE_PAYLOAD_TYPE_AUTH;
	   id_header->critical=0;
	   id_header->reserved=0;


	   dataptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	  IKE_Id_Payload * Id_Payload = (IKE_Id_Payload * )dataptr;
	  Id_Payload->idType= IKE_ID_TYPE_IPV6_ADDR;
	  Id_Payload->reserved[0]=0;
	  Id_Payload->reserved[1]=0;
	  Id_Payload->reserved[2]=0;

	  for(uint8 i=0;i<16;i++)
	  {
		  Id_Payload->idData[i]=addr.map8[i];

	  }

	  id_header->payloadLength=HTONS(sizeof(IKE_Id_Payload)+sizeof(IKE_Payload_Header));

	  dataptr += sizeof(IKE_Id_Payload);
	  len += sizeof(IKE_Id_Payload);



	  /*******************************************************
	   *                  Adding the Auth Payload         *
		 *******************************************************/

	   IKE_Payload_Header * auth_header = (IKE_Payload_Header *) dataptr;
	   auth_header->nextPayload =IKE_PAYLOAD_TYPE_TSI;
	   auth_header->critical=0;
	   auth_header->reserved=0;


	   dataptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	   IKE_Auth_Payload * Auth_Payload = (IKE_Auth_Payload * )dataptr;
	   Auth_Payload->authMethod=IKE_AUTH_METHOD_SHARED_KEY;
	   Auth_Payload->reserved[0]=0;
	   Auth_Payload->reserved[1]=0;
	   Auth_Payload->reserved[2]=0;

	   /*****
	    * *prf(Shared Secret, "Key Pad for IKEv2")=
	    * *
	    * *Hashed value=7GxqpTpA0PUBCcZwYUtRS06UPJsndANePg0UjUbkyMM=
	    * encoded value={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
	    *  0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3}
	    * *
	    * *
	    * **/

	   uint8 encoded[]={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
			     0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3};

	   for(uint8 i=0;i<32;i++)
	   {
		   Auth_Payload->authData[i]=encoded[i];
	   }

	   auth_header->payloadLength=HTONS(sizeof(IKE_Payload_Header)+sizeof(IKE_Auth_Payload));

	   dataptr += sizeof(IKE_Auth_Payload);
	   len += sizeof(IKE_Auth_Payload);

	  /*******************************************************
		 *                     Adding the Tsl Payload         *
		 *******************************************************/
	  IKE_Payload_Header * ts_header = (IKE_Payload_Header *) dataptr;
	   ts_header->nextPayload =IKE_PAYLOAD_TYPE_LAST;
	   ts_header->critical=0;
	   ts_header->reserved=0;

	   dataptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);



	   IKE_Ts Ts;
	   Ts.tsType=IKE_TS_TYPE_IPV6_ADDR_RANGE;
	   Ts.ipProtocolId=IKE_IP_PROTOCOL_ID_ICMPV6;
	   Ts.selectorLength=sizeof(IKE_Ts);
	   Ts.startPort=0;
	   Ts.endPort=65535;
	   //start address
	   //end address



	   IKE_Ts_Payload * Ts_Payload = (IKE_Ts_Payload * )dataptr;

	   Ts_Payload->numTs=1;
	   Ts_Payload->reserved[0]=0;
	   Ts_Payload->reserved[1]=0;
	   Ts_Payload->reserved[2]=0;
	   Ts_Payload->trafficSelectors=Ts;

	   ts_header->payloadLength=HTONS(sizeof(IKE_Payload_Header)+sizeof(IKE_Ts_Payload));

	   dataptr += sizeof(IKE_Ts_Payload);
	   len += sizeof(IKE_Ts_Payload);

	   data_len=len-sizeof(IKEv2Header);
	   cipher_len=data_len;
	   ret=Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, data, data_len, ciphertext, &cipher_len);
	   if(ret==E_NOT_OK)
	   {
		   return ret;
	   }

	   else
	   {
		   //MISRA Rule
	   }

	   memcpy(ptr, ciphertext, cipher_len);
	   header->length=HTONL(len);


	   return ret;

}

Std_ReturnType IKEV2_Auth_Res(SecurityAssociation* SA,uint8 * request){


	Std_ReturnType ret=E_OK;
	uint8 * ptr = request;
	uint8 len=0;
	uint8 data[256];
	uint32 data_len = 0;
	uint8 * dataptr=data;
    uint8 ciphertext[256];
    uint32 cipher_len = 0;



	IKEv2Header * header;



	/*******************************************************
	 *                     Adding the IKEV2 header          *
	 *******************************************************/

		header=(IKEv2Header *) ptr;

		header->initiator_spi = HTONLL(SA->initiatorSpi);
		header->responder_spi = HTONLL(SA->responderSpi);
	    header->majorVersion=2; // IKEv2 is version 2.0, sometimes represented
	    header->minorVersion=0;
		header->exchange_type = IKE_EXCHANGE_TYPE_AUTH;
		header->flags = IKE_HEADER_FLAG_RESPONSE;
		header->message_id = 1;

		ptr += sizeof(IKEv2Header);
	   len += sizeof(IKEv2Header);

	/*******************************************************
	 *                     Adding the ID Payload         *
	 *******************************************************/

	   IKE_Payload_Header * id_header = (IKE_Payload_Header *) dataptr;
	   id_header->nextPayload =IKE_PAYLOAD_TYPE_AUTH;
	   id_header->critical=0;
	   id_header->reserved=0;


	   dataptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	  IKE_Id_Payload * Id_Payload = (IKE_Id_Payload * )dataptr;
	  Id_Payload->idType= IKE_ID_TYPE_IPV6_ADDR;
	  Id_Payload->reserved[0]=0;
	  Id_Payload->reserved[1]=0;
	  Id_Payload->reserved[2]=0;
	  for(uint8 i=0;i<16;i++)
	  {
		  Id_Payload->idData[i]=addr.map8[i];

	  }
	  id_header->payloadLength=HTONS(sizeof(* Id_Payload)+sizeof(IKE_Payload_Header));

	  dataptr += sizeof(IKE_Id_Payload);
	  len += sizeof(IKE_Id_Payload);



	  /*******************************************************
	   *                  Adding the Auth Payload         *
		 *******************************************************/

	   IKE_Payload_Header * auth_header = (IKE_Payload_Header *) dataptr;
	   auth_header->nextPayload =IKE_PAYLOAD_TYPE_TSI;
	   auth_header->critical=0;
	   auth_header->reserved=0;


	   dataptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	   IKE_Auth_Payload * Auth_Payload = (IKE_Auth_Payload * )dataptr;
	   Auth_Payload->authMethod=IKE_AUTH_METHOD_SHARED_KEY;
	   Auth_Payload->reserved[0]=0;
	   Auth_Payload->reserved[1]=0;
	   Auth_Payload->reserved[2]=0;

	   /*****
	    * *prf(Shared Secret, "Key Pad for IKEv2")=
	    * *
	    * *Hashed value=7GxqpTpA0PUBCcZwYUtRS06UPJsndANePg0UjUbkyMM=
	    * encoded value={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
	    *  0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3}
	    * *
	    * *
	    * **/

	   uint8 encoded[]={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
			     0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3};

	   for(uint8 i=0;i<32;i++)
	   {
		   Auth_Payload->authData[i]=encoded[i];
	   }

	   auth_header->payloadLength=HTONS(sizeof(IKE_Payload_Header)+sizeof(IKE_Auth_Payload));

	   dataptr += sizeof(IKE_Auth_Payload);
	   len += sizeof(IKE_Auth_Payload);



	  /*******************************************************
		 *                     Adding the Tsl Payload         *
		 *******************************************************/
	  IKE_Payload_Header * ts_header = (IKE_Payload_Header *) dataptr;
	   ts_header->nextPayload =IKE_PAYLOAD_TYPE_LAST;
	   ts_header->critical=0;
	   ts_header->reserved=0;

	   dataptr += sizeof(IKE_Payload_Header);

	   len += sizeof(IKE_Payload_Header);



	   IKE_Ts Ts;
	   Ts.tsType=IKE_TS_TYPE_IPV6_ADDR_RANGE;
	   Ts.ipProtocolId=IKE_IP_PROTOCOL_ID_ICMPV6;
	   Ts.selectorLength=sizeof(IKE_Ts);
	   Ts.startPort=0;
	   Ts.endPort=65535;
	   //start address
	   //end address



	   IKE_Ts_Payload * Ts_Payload = (IKE_Ts_Payload * )dataptr;

	   Ts_Payload->numTs=1;
	   Ts_Payload->reserved[0]=0;
	   Ts_Payload->reserved[1]=0;
	   Ts_Payload->reserved[2]=0;
	   Ts_Payload->trafficSelectors=Ts;

	   dataptr += sizeof(IKE_Ts_Payload);
	   len += sizeof(IKE_Ts_Payload);

	   data_len=len-sizeof(IKEv2Header);
	   cipher_len=data_len;
	   ret=Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, data, data_len, ciphertext, &cipher_len);
	   if(ret==E_NOT_OK)
	   {
		   return ret;
	   }

	   else
	   {
		   //MISRA Rule
	   }

	   memcpy(ptr, ciphertext, cipher_len);


	   header->length=HTONL(len);


	   return ret;
}



Std_ReturnType IKEV2_Req(IPv6Addr addr){

	Std_ReturnType ret =E_OK;

	uint8 request[IKE_MAX_INIT_MESSAGE_SIZE];

	if(CacheState==NOT_INIT_TABLE)
	{
		initializeSACache();
	}
	else
	{
		//MISRA Rule
	}

	/*
	 * uint8 * buffer;
	 * uint8 * ptr;
	 * Eth_BufIdxType BufIdx;
	 * BufReq_ReturnType buff;
	 * uint16 LenByte
	 *
	 *Eth_DataType response=NULL;
	 * Eth_DataType response
	 * */

	uint64 spi= (uint64)rand() << 32 | rand();
	ret=addSA(spi);

	if(ret == E_NOT_OK)
	{
		return ret;
	}
	else
	{
		//MISRA Rule
	}

	SecurityAssociation * sa=findSA(spi);

	sa->address=addr;


//	ret = IKEV2_SA_Req(sa,request);

	if(ret == E_NOT_OK)
	{
		return ret;
	}
	else
	{
		//MISRA Rule
	}


    /*
     *
     * buff = EthIf_ProvideTxBuffer();
     *
     *
     * if (buff != BUFREQ_OK){
        return E_NOT_OK;
         }
     *
     *
     *
     *
     *
     * buff =EthIf_Transmit();
     * if (buff != BUFREQ_OK){
        return E_NOT_OK;
         }


      	  EthIf_RxIndication();

      */

//    while(time(NULL)<= sa_req.starttime + SA_REQ_TIMOUT /* && response == NULL*/)
//    {
//    	//EthIf_RxIndication();
//    }

    /*
     * decrypt response
     *  if(response==NULL)
     *  {
     *  	return E_NOT_OK;
     *  }
     *
     *
     *
     * */


	uint8 req2[IKE_MAX_INIT_MESSAGE_SIZE];

	ret=IKEV2_Auth_Req(sa,req2);

	if(ret == E_NOT_OK)
	{
		return ret;
	}
	else
	{
		//MISRA Rule
	}


	/*
	     *
	     * buff = EthIf_ProvideTxBuffer();
	     *
	     *
	     * if (buff != BUFREQ_OK){
	        return E_NOT_OK;
	         }
	     *
	     *
	     *
	     *
	     *
	     * buff =EthIf_Transmit();
	     * if (buff != BUFREQ_OK){
	        return E_NOT_OK;
	         }


	      	  EthIf_RxIndication();

	      */

	//    while(time(NULL)<= sa_req.starttime + SA_REQ_TIMOUT /* && response == NULL*/)
	//    {
	//    	//EthIf_RxIndication();
	//    }

	    /*
	     *
	     *
	     *decrypt response
	     *  if(response==NULL)
	     *  {
	     *  	return E_NOT_OK;
	     *  }
	     *
	     *
	     *
	     * */

	return ret;

}




Std_ReturnType IKEV2_Res(uint8 * data,uint8 * request)
{

	Std_ReturnType ret=E_OK;
	uint8 * ptr =data;
	IKEv2Header * header;



	header=(IKEv2Header *) ptr;

	ret=addSA(NTOHLL(header->initiator_spi));
	if(ret==E_NOT_OK)
	{
		return ret;
	}
	else
	{
		//MISRA Rule
	}

	SecurityAssociation * sa=findSA(NTOHLL(header->initiator_spi));
	uint64 res_spi= (uint64)rand() << 32 | rand();
	sa->responderSpi=res_spi;

//	s

	if(ret==E_NOT_OK)
	{
		return ret;
	}
	else
	{
		// MISRA Rule
	}

	ret=IKEV2_Auth_Res(sa, request);
	return ret;

}

Std_ReturnType IpSec_Init(IPv6Addr addr)
{
	Std_ReturnType ret=E_OK;


	if(SpdState==NOT_INIT_TABLE)
	{
		initializeSpdTable();

	}
	else
	{
		//MISRA Rule
	}

	if(spdExists(addr)==E_NOT_OK)
	{
		ret=addSpdEntry(addr);
	}

	else
	{
		//MISRA Rule
	}

	  Csm_ConfigType validConfig;
	  validConfig.dummy = 42; // Initialize with valid configuration values

	  Csm_Init(&validConfig);
	  CryIf_ConfigType validConfigCryIf;
	  // Initialize with valid configuration values, if applicable

	  CryIf_Init(NULL);

	  encryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily = CRYPTO_ALGOFAM_AES;
	  decryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily = CRYPTO_ALGOFAM_AES;

 return ret;

}


Std_ReturnType espEncryptPacket(uint8 * data,uint8 datalen,uint8 *packet,uint8 *packet_len)
{
	Std_ReturnType ret=E_OK;

	uint8 len=0;
	uint8 * ptr=packet;

	EspHeader * header =(EspHeader *) ptr;

	header->spi=HTONL(1);
	header->seqNum=HTONL(1);
//	spd->seq+=1;

	len+=sizeof(EspHeader);

    uint8 ciphertext[256];
    uint32 cipher_len = datalen;


    // Encrypt the plaintext
    ret= Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, data, datalen, ciphertext, &cipher_len);
    if(ret==E_NOT_OK)
    {
    	return ret;
    }

	// encrypt data payload
	memcpy(ptr + sizeof(EspHeader), ciphertext, cipher_len);

	len+=cipher_len;

	ptr+=sizeof(EspHeader) + cipher_len;



	EspTrailer * trailer =(EspTrailer *) ptr;

    uint8 hash[256];
    uint32 hash_len = 32;

    ret = Csm_Hash(2, CRYPTO_OPERATIONMODE_START, data, datalen, hash, &hash_len);
    if(ret==E_NOT_OK)
    {
    	return ret;
    }


	trailer->padLength=0;
	trailer->nextHeader=41;

	memcpy(ptr + sizeof(EspTrailer), hash, hash_len);
	len+=sizeof(sizeof(EspTrailer));
	len += hash_len;

	*packet_len=len;

	return ret;
}

Std_ReturnType espDecryptPacket(uint8 * data, uint8 data_len,const uint8 *packet){
	Std_ReturnType ret=E_OK;
    uint8 hash[32];
    uint32 hash_len = sizeof(hash);

	uint8 * ptr=packet;
	uint8 length=data_len-sizeof(EspHeader)-hash_len-sizeof(EspTrailer);

	//Need to check for the seq and the spd

	ptr += sizeof(EspHeader);

	uint8 decrypted[256];
	uint32 decrpted_len;

	ret= Csm_Decrypt(1, CRYPTO_OPERATIONMODE_START, ptr, length, decrypted, &decrpted_len);

    if(ret==E_NOT_OK)
    {
    	return ret;
    }
    ptr+=data_len;
    ptr+=sizeof(EspTrailer);

	//compare hash


    ret = Csm_Hash(2, CRYPTO_OPERATIONMODE_START, decrypted, decrpted_len, hash, &hash_len);

    uint8 hash_check[256];

    memcpy(hash_check, ptr, hash_len);

    for(uint8 i =0;i<32;i++)
    {
    	if(hash[i]!=hash_check[i])
    	{
    		ret=E_NOT_OK;
    		return ret;
    	}
    }


	memcpy(data, decrypted, length);





	return ret;


}

Std_ReturnType IKEV2_Auth_Req_test(SecurityAssociation* SA,uint8 * request,uint8 * length)
{


	Std_ReturnType ret=E_OK;
	uint8 * ptr = request;
	uint8 len=0;


	IKEv2Header * header;



	/*******************************************************
	 *                     Adding the IKEV2 header          *
	 *******************************************************/

		header=(IKEv2Header *) ptr;

		header->initiator_spi = HTONLL(SA->initiatorSpi);
		header->responder_spi = HTONLL(SA->responderSpi);
	    header->majorVersion=2; // IKEv2 is version 2.0, sometimes represented
	    header->minorVersion=0;
		header->exchange_type = IKE_EXCHANGE_TYPE_AUTH;
		header->flags = IKE_HEADER_FLAG_INITIATOR;
		header->message_id = HTONL(1);

		ptr += sizeof(IKEv2Header);
	   len += sizeof(IKEv2Header);

	/*******************************************************
	 *                     Adding the ID Payload         *
	 *******************************************************/

	   IKE_Payload_Header * id_header = (IKE_Payload_Header *) ptr;
	   id_header->nextPayload =IKE_PAYLOAD_TYPE_AUTH;
	   id_header->critical=0;
	   id_header->reserved=0;


	   ptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	  IKE_Id_Payload * Id_Payload = (IKE_Id_Payload * )ptr;
	  Id_Payload->idType= IKE_ID_TYPE_IPV6_ADDR;
	  Id_Payload->reserved[0]=0;
	  Id_Payload->reserved[1]=0;
	  Id_Payload->reserved[2]=0;

	  for(uint8 i=0;i<16;i++)
	  {
		  Id_Payload->idData[i]=addr.map8[i];

	  }

	  id_header->payloadLength=HTONS(sizeof(IKE_Id_Payload)+sizeof(IKE_Payload_Header));

	  ptr += sizeof(IKE_Id_Payload);
	  len += sizeof(IKE_Id_Payload);



	  /*******************************************************
	   *                  Adding the Auth Payload         *
		 *******************************************************/

	   IKE_Payload_Header * auth_header = (IKE_Payload_Header *) ptr;
	   auth_header->nextPayload =IKE_PAYLOAD_TYPE_TSI;
	   auth_header->critical=0;
	   auth_header->reserved=0;


	   ptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	   IKE_Auth_Payload * Auth_Payload = (IKE_Auth_Payload * )ptr;
	   Auth_Payload->authMethod=IKE_AUTH_METHOD_SHARED_KEY;
	   Auth_Payload->reserved[0]=0;
	   Auth_Payload->reserved[1]=0;
	   Auth_Payload->reserved[2]=0;

	   /*****
	    * *prf(Shared Secret, "Key Pad for IKEv2")=
	    * *
	    * *Hashed value=7GxqpTpA0PUBCcZwYUtRS06UPJsndANePg0UjUbkyMM=
	    * encoded value={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
	    *  0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3}
	    * *
	    * *
	    * **/

	   uint8 encoded[]={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
			     0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3};

	   for(uint8 i=0;i<32;i++)
	   {
		   Auth_Payload->authData[i]=encoded[i];
	   }

	   auth_header->payloadLength=HTONS(sizeof(IKE_Payload_Header)+sizeof(IKE_Auth_Payload));

	   ptr += sizeof(IKE_Auth_Payload);
	   len += sizeof(IKE_Auth_Payload);

	  /*******************************************************
		 *                     Adding the Tsl Payload         *
		 *******************************************************/
	  IKE_Payload_Header * ts_header = (IKE_Payload_Header *) ptr;
	   ts_header->nextPayload =IKE_PAYLOAD_TYPE_LAST;
	   ts_header->critical=0;
	   ts_header->reserved=0;

	   ptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);



	   IKE_Ts Ts;
	   Ts.tsType=IKE_TS_TYPE_IPV6_ADDR_RANGE;
	   Ts.ipProtocolId=IKE_IP_PROTOCOL_ID_ICMPV6;
	   Ts.selectorLength=sizeof(IKE_Ts);
	   Ts.startPort=0;
	   Ts.endPort=65535;
	   //start address
	   //end address



	   IKE_Ts_Payload * Ts_Payload = (IKE_Ts_Payload * )ptr;

	   Ts_Payload->numTs=1;
	   Ts_Payload->reserved[0]=0;
	   Ts_Payload->reserved[1]=0;
	   Ts_Payload->reserved[2]=0;
	   Ts_Payload->trafficSelectors=Ts;

	   ts_header->payloadLength=HTONS(sizeof(IKE_Payload_Header)+sizeof(IKE_Ts_Payload));

	   ptr += sizeof(IKE_Ts_Payload);
	   len += sizeof(IKE_Ts_Payload);


	   header->length=HTONL(len);
	   *length=len;


	   return ret;


}

Std_ReturnType IKEV2_Auth_Res_test(SecurityAssociation* SA,uint8 * request,uint8 * length)
{

	Std_ReturnType ret=E_OK;
	uint8 * ptr = request;
	uint8 len=0;




	IKEv2Header * header;



	/*******************************************************
	 *                     Adding the IKEV2 header          *
	 *******************************************************/

		header=(IKEv2Header *) ptr;

		header->initiator_spi = HTONLL(SA->initiatorSpi);
		header->responder_spi = HTONLL(SA->responderSpi);
	    header->majorVersion=2; // IKEv2 is version 2.0, sometimes represented
	    header->minorVersion=0;
		header->exchange_type = IKE_EXCHANGE_TYPE_AUTH;
		header->flags = IKE_HEADER_FLAG_RESPONSE;
		header->message_id = 1;

		ptr += sizeof(IKEv2Header);
	   len += sizeof(IKEv2Header);

	/*******************************************************
	 *                     Adding the ID Payload         *
	 *******************************************************/

	   IKE_Payload_Header * id_header = (IKE_Payload_Header *) ptr;
	   id_header->nextPayload =IKE_PAYLOAD_TYPE_AUTH;
	   id_header->critical=0;
	   id_header->reserved=0;


	   ptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	  IKE_Id_Payload * Id_Payload = (IKE_Id_Payload * )ptr;
	  Id_Payload->idType= IKE_ID_TYPE_IPV6_ADDR;
	  Id_Payload->reserved[0]=0;
	  Id_Payload->reserved[1]=0;
	  Id_Payload->reserved[2]=0;
	  for(uint8 i=0;i<16;i++)
	  {
		  Id_Payload->idData[i]=addr.map8[i];

	  }
	  id_header->payloadLength=HTONS(sizeof(* Id_Payload)+sizeof(IKE_Payload_Header));

	  ptr += sizeof(IKE_Id_Payload);
	  len += sizeof(IKE_Id_Payload);



	  /*******************************************************
	   *                  Adding the Auth Payload         *
		 *******************************************************/

	   IKE_Payload_Header * auth_header = (IKE_Payload_Header *) ptr;
	   auth_header->nextPayload =IKE_PAYLOAD_TYPE_TSI;
	   auth_header->critical=0;
	   auth_header->reserved=0;


	   ptr += sizeof(IKE_Payload_Header);
	   len += sizeof(IKE_Payload_Header);

	   IKE_Auth_Payload * Auth_Payload = (IKE_Auth_Payload * )ptr;
	   Auth_Payload->authMethod=IKE_AUTH_METHOD_SHARED_KEY;
	   Auth_Payload->reserved[0]=0;
	   Auth_Payload->reserved[1]=0;
	   Auth_Payload->reserved[2]=0;

	   /*****
	    * *prf(Shared Secret, "Key Pad for IKEv2")=
	    * *
	    * *Hashed value=7GxqpTpA0PUBCcZwYUtRS06UPJsndANePg0UjUbkyMM=
	    * encoded value={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
	    *  0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3}
	    * *
	    * *
	    * **/

	   uint8 encoded[]={0xec, 0x6c, 0x6a, 0xa5, 0x3a, 0x40, 0xd0, 0xf5, 0x01, 0x09, 0xc6, 0x70, 0x61, 0x4b, 0x51, 0x4b, 0x4e,
			     0x94, 0x3c, 0x9b, 0x27, 0x74, 0x03, 0x5e, 0x3e, 0x0d, 0x14, 0x8d, 0x46, 0xe4, 0xc8, 0xc3};

	   for(uint8 i=0;i<32;i++)
	   {
		   Auth_Payload->authData[i]=encoded[i];
	   }

	   auth_header->payloadLength=HTONS(sizeof(IKE_Payload_Header)+sizeof(IKE_Auth_Payload));

	   ptr += sizeof(IKE_Auth_Payload);
	   len += sizeof(IKE_Auth_Payload);



	  /*******************************************************
		 *                     Adding the Tsl Payload         *
		 *******************************************************/
	  IKE_Payload_Header * ts_header = (IKE_Payload_Header *) ptr;
	   ts_header->nextPayload =IKE_PAYLOAD_TYPE_LAST;
	   ts_header->critical=0;
	   ts_header->reserved=0;

	   ptr += sizeof(IKE_Payload_Header);

	   len += sizeof(IKE_Payload_Header);



	   IKE_Ts Ts;
	   Ts.tsType=IKE_TS_TYPE_IPV6_ADDR_RANGE;
	   Ts.ipProtocolId=IKE_IP_PROTOCOL_ID_ICMPV6;
	   Ts.selectorLength=sizeof(IKE_Ts);
	   Ts.startPort=0;
	   Ts.endPort=65535;
	   //start address
	   //end address



	   IKE_Ts_Payload * Ts_Payload = (IKE_Ts_Payload * )ptr;

	   Ts_Payload->numTs=1;
	   Ts_Payload->reserved[0]=0;
	   Ts_Payload->reserved[1]=0;
	   Ts_Payload->reserved[2]=0;
	   Ts_Payload->trafficSelectors=Ts;
	   ts_header->payloadLength=HTONS(sizeof(IKE_Payload_Header)+sizeof(IKE_Ts_Payload));

	   ptr += sizeof(IKE_Ts_Payload);
	   len += sizeof(IKE_Ts_Payload);


	   header->length=HTONL(len);

	   *length=len;

	   return ret;

}


