/******************************************************************************
 *
 * Module: Com
 *
 * File Name: Com.h
 *
 * Description: Stub for PduR
 *
 * Author: Kareem Azab
 ******************************************************************************/

#ifndef COM_H_
#define COM_H_


#include "Std_Types.h"
#include "ComStack_Types.h"





Std_ReturnType Com_TriggerTransmit (PduIdType TxPduId,PduInfoType* PduInfoPtr);

void Com_RxIndication (PduIdType RxPduId,const PduInfoType* PduInfoPtr);


void Com_TxConfirmation (PduIdType TxPduId,Std_ReturnType result);


#endif /* COM_H_ */
