/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: SchM_ChrgM.c
 *
 * Description: Source file for Scheduler ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM.h"

extern uint8 MessageBuffer[BUFFER_SIZE];
extern struct iso1EXIDocument V2G_EXI_Document;
extern ChrgM_ModuleStateType ChrgM_ModuleState;
extern ChrgM_ErrorStatusType ChrgM_TxErrorStatus;
extern ChrgM_ErrorStatusType ChrgM_RxErrorStatus;
extern ChrgM_ModuleStateType ChrgM_TxErrorState;
extern ChrgM_ModuleStateType ChrgM_RxErrorState;
extern EthTrcv_LinkStateType ChrgM_TransceiverLinkState;
extern boolean ChrgM_ProcessStarted;
extern boolean ChrgM_CommunicationSetupTimerElapsed;
extern uint8 ChrgM_CpLine;
extern boolean ChrgM_IpAddressIndicationReceived;
extern TcpIp_IpAddrStateType ChrgM_IpAddressState;
extern boolean ChrgM_OpenUDPSocketRequested;
extern boolean ChrgM_SocketIndicationReceived;
extern SoAd_SoConModeType ChrgM_UDPSoConMode;
extern boolean ChrgM_ValidSECCReceived;
extern boolean ChrgM_SECCTimerElapsed;
extern uint8 ChrgM_SECCCounter;
extern boolean ChrgM_PdurRequestSuccessful;
extern boolean ChrgM_DataWritten;
extern boolean ChrgM_DataEncoded;
extern boolean ChrgM_DataEncrypted;
extern boolean ChrgM_TxConfirmationReceived;
extern boolean ChrgM_TransmissionSuccessful;
extern boolean ChrgM_OpenTCPSocketRequested;
extern SoAd_SoConModeType ChrgM_TCPSoConMode;
extern ChrgM_MessageStateType ChrgM_RequestedMessage;
extern SECCDiscoveryProtocolReqType SECCDiscoveryProtocolReq_Message;
extern SECCDiscoveryProtocolResType SECCDiscoveryProtocolRes_Message;
extern SupportedAppProtocolResType SupportedAppProtocolRes_Message;
extern boolean ChrgM_MessageTimerElapsed;
extern boolean ChrgM_OngoingTimerStarted;
extern boolean ChrgM_OngoingTimerElapsed;
extern SoAd_SoConIdType ChrgM_SocketConID;
extern PduInfoType ChrgM_PduInfo;
extern PduIdType ChrgM_PduID;
extern boolean ChrgM_MessageRequested;
extern boolean ChrgM_MessageReceived;
extern boolean ChrgM_ReceptionSuccessful;
extern boolean ChrgM_ReceptionDone;
extern PayloadLengthType Received_Payload;

/************************************************************************************
 * Service Name: ChrgM_MainFunction_Rx
 * Service ID[hex]: 0x24
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different instances. Non reentrant for the same instance
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the processing of the AUTOSAR ChrgM module’s receive processing
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_MainFunction_Rx (void)
{
	if(ChrgM_ModuleState != NOT_INITIALIZED)
	{
		if(ChrgM_RxErrorStatus == NO_ERROR_STATUS)
		{
			switch(ChrgM_ModuleState)
			{
			case NOT_INITIALIZED:
			case INIT:
			case ASSIGNING_IP_ADDRESS:
			case ESTABLISHING_TCP_TLS:
				/* Do Nothing */
				break;

			case DISCOVERING_SECC:
#if(CHRGM_SDP_USED == STD_ON)
				if(ChrgM_CommunicationSetupTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_MessageReceived == TRUE)
					{
						/* Reset SDP Timer */
						if(ChrgM_ReceptionSuccessful == TRUE)
						{
							if(ChrgM_ReadV2GTPHeader() == E_OK)
							{
								if(ChrgM_EXIDecode() == E_OK)
								{
									ChrgM_MessageReceived = FALSE;
									ChrgM_SECCDiscoveryProtocolRes();
									if(SECCDiscoveryProtocolRes_Message.SECCPortNumber == SECC_PORT_NUMBER
											&& SECCDiscoveryProtocolRes_Message.SECCTransportProtocol == SECCDiscoveryProtocolReq_Message.SECCTransportProtocol
											&& SECCDiscoveryProtocolRes_Message.SECCSecurity == SECCDiscoveryProtocolReq_Message.SECCSecurity) /* Fadel IP Address Check */
									{
										ChrgM_CommunicationSetupTimerElapsed = FALSE;
										ChrgM_ValidSECCReceived = TRUE;
									}
									else
									{
										/* Elapse Timer manually to resend SDP */
										ChrgM_SECCTimerElapsed = TRUE;
									}
								}
								else
								{
									/* Do Nothing */
								}

							}
							else
							{
								/* V2GTP Header Error */
							}
						}
						else
						{
							/* Reception Error */
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_CommunicationSetupTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_EVCC_CommunicationSetupTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_RX;
					ChrgM_RxErrorStatus = SET_BY_RX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
#endif /* CHRGM SDP USED*/
				break;

			case ESTABLISHING_V2G_SESSION:
				if(ChrgM_MessageTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_MessageReceived == TRUE)
					{
						//ChrgM_MessageTimerStarted = FALSE;
						/* Reset Message Timer */
						if(ChrgM_ReceptionSuccessful == TRUE)
						{
							if(/*Csm_Decrypt(1, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Received_Payload) == E_OK*/1) /* Decrypt Data */
							{
								if(ChrgM_ReadV2GTPHeader() == E_OK)
								{
									if(ChrgM_RequestedMessage == SUPPORTED_APP_PROTOCOL)
									{
										ChrgM_SupportedAppProtocolIndication(SupportedAppProtocolRes_Message.ResponseCode);
										if(SupportedAppProtocolRes_Message.ResponseCode == OK)
										{
											ChrgM_RequestedMessage = NO_MESSAGE;
											/* Start Sequence Timer */
										}
										else
										{
											ChrgM_TxErrorStatus = SET_BY_RX;
											ChrgM_RxErrorStatus = SET_BY_RX;
											ChrgM_TxErrorState = ChrgM_ModuleState;
											ChrgM_RxErrorState = ChrgM_ModuleState;
										}
									}
									else if(ChrgM_RequestedMessage == SESSION_SETUP)
									{
										/* Reset V2G Document Data */
										memset(&V2G_EXI_Document, 0, sizeof(V2G_EXI_Document));
										if(ChrgM_EXIDecode(MessageBuffer + V2G_HEADER_SIZE, Received_Payload, &V2G_EXI_Document) == E_OK)
										{
											ChrgM_SessionSetupIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.SessionSetupRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.SessionSetupRes.ResponseCode == OK)
											{
												/* Reset Communication Setup Timer */
												/* Start Sequence Timer */
												ChrgM_RequestedMessage = NO_MESSAGE;
												ChrgM_ModuleState = V2G_SESSION_ONGOING;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}

										}
										else
										{
											/* Do Nothing */
										}
									}
									else
									{
										/* Do Nothing */
									}
									ChrgM_MessageRequested = FALSE;
									ChrgM_MessageReceived = FALSE;
									ChrgM_ReceptionSuccessful = FALSE;
								}
								else
								{
									ChrgM_ErrorIndication(V2G_Header_Check_Error);
									ChrgM_TxErrorStatus = SET_BY_RX;
									ChrgM_RxErrorStatus = SET_BY_RX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
								}

							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							/* Reception Error */
						}
						ChrgM_ReceptionDone = TRUE;
						/* Reset Buffer Data */
						memset(MessageBuffer, 0, BUFFER_SIZE);
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_MessageTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_EVCC_MsgTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(V2G_EVCC_CommunicationSetupTimeout);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_RX;
					ChrgM_RxErrorStatus = SET_BY_RX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;

			case V2G_SESSION_ONGOING:
				if(ChrgM_MessageTimerElapsed == FALSE && ChrgM_OngoingTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_MessageReceived == TRUE)
					{
						//ChrgM_MessageTimerStarted = FALSE;
						/* Reset Message Timer */
						if(ChrgM_ReceptionSuccessful == TRUE)
						{
							if(/*Csm_Decrypt(1, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Received_Payload) == E_OK*/1) /* Decrypt Data */
							{
								if(ChrgM_ReadV2GTPHeader() == E_OK)
								{
									/* Reset V2G Document Data */
									memset(&V2G_EXI_Document, 0, sizeof(V2G_EXI_Document));
									if(ChrgM_EXIDecode(MessageBuffer + V2G_HEADER_SIZE, Received_Payload, &V2G_EXI_Document) == E_OK)
									{
										switch(ChrgM_RequestedMessage)
										{
										case SERVICE_DISCOVERY:
											ChrgM_ServiceDiscoveryIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.ServiceDiscoveryRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.ServiceDiscoveryRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case PAYMENT_SELECTION:
											ChrgM_PaymentServiceSelectionIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PaymentServiceSelectionRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PaymentServiceSelectionRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case PAYMENT_DETAILS:
											ChrgM_PaymentDetailsIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PaymentDetailsRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PaymentDetailsRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case AUTHORIZATION:
											if((EVSEProcessingType)V2G_EXI_Document.V2G_Message.Body.AuthorizationRes.EVSEProcessing == Ongoing)
											{
												if(ChrgM_OngoingTimerStarted == FALSE)
												{
													/* Start Ongoing Timer */
													ChrgM_OngoingTimerStarted = TRUE;
												}
												else
												{
													/* Do Nothing */
												}
											}
											else
											{
												if(ChrgM_OngoingTimerStarted == TRUE)
												{
													/* Reset Ongoing Timer */
													ChrgM_OngoingTimerStarted = FALSE;
												}
												else
												{
													/* Do Nothing */
												}

												ChrgM_AuthorizationIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.AuthorizationRes.ResponseCode);
												if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.AuthorizationRes.ResponseCode == OK)
												{
													ChrgM_RequestedMessage = NO_MESSAGE;
												}
												else
												{
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											break;

										case CHARGE_PARAMETER_DISCOVERY:
											if((EVSEProcessingType)V2G_EXI_Document.V2G_Message.Body.ChargeParameterDiscoveryRes.EVSEProcessing == Ongoing)
											{
												if(ChrgM_OngoingTimerStarted == FALSE)
												{
													/* Start Ongoing Timer */
													ChrgM_OngoingTimerStarted = TRUE;
												}
												else
												{
													/* Do Nothing */
												}
											}
											else
											{
												if(ChrgM_OngoingTimerStarted == TRUE)
												{
													/* Reset Ongoing Timer */
													ChrgM_OngoingTimerStarted = FALSE;
												}
												else
												{
													/* Do Nothing */
												}

												ChrgM_ChargeParameterDiscoveryIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.ChargeParameterDiscoveryRes.ResponseCode);
												if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.ChargeParameterDiscoveryRes.ResponseCode == OK)
												{
													ChrgM_RequestedMessage = NO_MESSAGE;
												}
												else
												{
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											break;

										case CABLE_CHECK:
											if((EVSEProcessingType)V2G_EXI_Document.V2G_Message.Body.CableCheckRes.EVSEProcessing == Ongoing)
											{
												if(ChrgM_OngoingTimerStarted == FALSE)
												{
													/* Start Ongoing Timer */
													ChrgM_OngoingTimerStarted = TRUE;
												}
												else
												{
													/* Do Nothing */
												}
											}
											else
											{
												if(ChrgM_OngoingTimerStarted == TRUE)
												{
													/* Reset Ongoing Timer */
													ChrgM_OngoingTimerStarted = FALSE;
												}
												else
												{
													/* Do Nothing */
												}

												ChrgM_CableCheckIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.CableCheckRes.ResponseCode);
												if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.CableCheckRes.ResponseCode == OK)
												{
													ChrgM_RequestedMessage = NO_MESSAGE;
												}
												else
												{
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											break;

										case PRE_CHARGE:
											ChrgM_PreChargeIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PreChargeRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PreChargeRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case POWER_DELIVERY:
											ChrgM_PowerDeliveryIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PowerDeliveryRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.PowerDeliveryRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case CURRENT_DEMAND:
											ChrgM_CurrentDemandIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.CurrentDemandRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.CurrentDemandRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case WELDING_DETECTION:
											ChrgM_WeldingDetectionIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.WeldingDetectionRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.WeldingDetectionRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case SESSION_STOP:
											ChrgM_SessionStopIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.SessionStopRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.SessionStopRes.ResponseCode == OK)
											{
												ChrgM_RequestedMessage = NO_MESSAGE;
												ChrgM_ModuleState = V2G_SESSION_PAUSED;
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										default:
											/* Do Nothing, Det Error */
											break;
										}

										ChrgM_MessageRequested = FALSE;
										ChrgM_MessageReceived = FALSE;
										ChrgM_ReceptionSuccessful = FALSE;
									}
									else
									{
										/* Do Nothing */
									}
								}
								else
								{
									ChrgM_ErrorIndication(V2G_Header_Check_Error);
									ChrgM_TxErrorStatus = SET_BY_RX;
									ChrgM_RxErrorStatus = SET_BY_RX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							/* Reception Error */
						}
						ChrgM_ReceptionDone = TRUE;
						/* Reset Buffer Data */
						memset(MessageBuffer, 0, BUFFER_SIZE);
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_MessageTimerElapsed == TRUE)
					{
						if(ChrgM_RequestedMessage == PRE_CHARGE)
						{
							ChrgM_ErrorIndication(V2G_EVCC_PrechargeTimeout);
						}
						else if(ChrgM_RequestedMessage == CABLE_CHECK)
						{
							ChrgM_ErrorIndication(V2G_EVCC_CableCheckTimeout);
						}
						else
						{
							ChrgM_ErrorIndication(V2G_EVCC_MsgTimeout);
						}
					}
					else if(ChrgM_OngoingTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_EVCC_OngoingTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(V2G_EVCC_CommunicationSetupTimeout);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_RX;
					ChrgM_RxErrorStatus = SET_BY_RX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;

			case V2G_SESSION_PAUSED:
				if(ChrgM_MessageTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_MessageReceived == TRUE)
					{
						//ChrgM_MessageTimerStarted = FALSE;
						/* Reset Message Timer */
						if(ChrgM_ReceptionSuccessful == TRUE)
						{
							if(/*Csm_Decrypt(1, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Received_Payload) == E_OK*/1)
							{
								if(ChrgM_ReadV2GTPHeader() == E_OK)
								{
									/* Reset V2G Document Data */
									memset(&V2G_EXI_Document, 0, sizeof(V2G_EXI_Document));
									if(ChrgM_EXIDecode(MessageBuffer + V2G_HEADER_SIZE, Received_Payload, &V2G_EXI_Document) == E_OK)
									{
										switch(ChrgM_RequestedMessage)
										{
										case SESSION_STOP:
											ChrgM_SessionStopIndication((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.SessionStopRes.ResponseCode);
											if((ChrgM_ResponseCodeType)V2G_EXI_Document.V2G_Message.Body.SessionStopRes.ResponseCode == OK)
											{
												/* End ChrgM Process, wait for Start Process again */
												ChrgM_RequestedMessage = NO_MESSAGE;
												ChrgM_MessageReceived = FALSE;
												ChrgM_ReceptionSuccessful = FALSE;
												SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
												SoAd_ReleaseIpAddrAssignment();
												ChrgM_ModuleState = INIT;
												/* Reset Sequence Timer */
											}
											else
											{
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;
										default:
											/* Do Nothing, Det Error */
											break;
										}
										ChrgM_MessageRequested = FALSE;
										ChrgM_MessageReceived = FALSE;
										ChrgM_ReceptionSuccessful = FALSE;
									}
									else
									{
										/* Do Nothing */
									}
								}
								else
								{
									ChrgM_ErrorIndication(V2G_Header_Check_Error);
									ChrgM_TxErrorStatus = SET_BY_RX;
									ChrgM_RxErrorStatus = SET_BY_RX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							/* Reception Error */
						}
						ChrgM_ReceptionDone = TRUE;
						/* Reset Buffer Data */
						memset(MessageBuffer, 0, BUFFER_SIZE);
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_MessageTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_EVCC_MsgTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_RX;
					ChrgM_RxErrorStatus = SET_BY_RX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;
			default:
				/* Do Nothing, Det Error */
				break;
			}
		}
		else
		{
			/* Do Nothing*/
		}

		if(ChrgM_RxErrorStatus == SET_BY_RX || ChrgM_RxErrorStatus == SET_BY_TX)
		{
			switch(ChrgM_RxErrorState)
			{
			case INIT:
			case ASSIGNING_IP_ADDRESS:
			case ESTABLISHING_TCP_TLS:
				/* Do Nothing */
				break;

			case DISCOVERING_SECC:
				ChrgM_RxErrorState = INIT;
				if(ChrgM_TxErrorStatus == SET_BY_RX)
				{
					ChrgM_SECCCounter = 0;
					ChrgM_ModuleState = INIT;
					ChrgM_ProcessStarted = FALSE;
					ChrgM_ValidSECCReceived = FALSE;
					ChrgM_DataEncrypted = FALSE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_ReceptionSuccessful = FALSE;
					/* Reset Communication Setup Timer */
					ChrgM_CommunicationSetupTimerElapsed = FALSE;
					/* Reset SDP Timer */
					ChrgM_SECCTimerElapsed = TRUE;
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE); /* UDP Socket */
					SoAd_ReleaseIpAddrAssignment();
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_RxErrorStatus = NO_ERROR_STATUS;
				break;

			case ESTABLISHING_V2G_SESSION:
			case V2G_SESSION_ONGOING:
			case V2G_SESSION_PAUSED:
				ChrgM_RxErrorState = INIT;
				if(ChrgM_TxErrorStatus == SET_BY_RX)
				{
					ChrgM_ModuleState = INIT;
					ChrgM_RequestedMessage = NO_MESSAGE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataEncrypted = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_MessageRequested = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_ReceptionDone = TRUE;
					ChrgM_ReceptionSuccessful = FALSE;
					/* Reset Message Timer */
					ChrgM_MessageTimerElapsed = FALSE;
					//ChrgM_MessageTimerStarted = FALSE;
					/* Reset Ongoing Timer */
					ChrgM_OngoingTimerElapsed = FALSE;
					ChrgM_OngoingTimerStarted = FALSE;
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE); /* TCP Socket */
					SoAd_ReleaseIpAddrAssignment();
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_RxErrorStatus = NO_ERROR_STATUS;
				break;

			default:
				/* Do Nothing, Det Error */
				break;
			}
		}
		else
		{
			/* Do Nothing */
		}
	}
	else
	{
		/* Do Nothing, Det Error */
	}
}
