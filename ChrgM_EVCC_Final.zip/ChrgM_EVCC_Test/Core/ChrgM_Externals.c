/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_Externals.c
 *
 * Description: Header file for external ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM_Externals.h"

/* Service SWC */
#include "Rte_ServiceSwc.h"

extern struct iso1EXIDocument V2G_EXI_Document;
extern boolean Message_Received_Indication;
extern SECCDiscoveryProtocolResType SECCDiscoveryProtocolRes_Message;
extern SupportedAppProtocolResType SupportedAppProtocolRes_Message;

ChrgM_ErrorHandlerType Error_Indication = CHRGM_NoError;

/************************************************************************************
 * Service Name: ChrgM_ErrorIndication
 * Service ID[hex]: 0x1D
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ErrorHandler - Defines the type of error
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about errors
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_ErrorIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	switch(ErrorHandler)
	{
	case V2G_Header_Check_Error:
	case V2G_EVCC_CommunicationSetupTimeout:
	case V2G_EVCC_MsgTimeout:
	case V2G_EVCC_CableCheckTimeout:
	case V2G_EVCC_OngoingTimeout:
	case V2G_EVCC_PrechargeTimeout:
	case CHRGM_EthLinkDown:
	case CHRGM_CpLineInactive:
	case CHRGM_IPAddressUnassigned:
	case CHRGM_SocketOffline:
	case CHRGM_InvalidSECC:
		GetResponse(FALSE, NULL_PTR, ErrorHandler);
		break;
	default:
		/* Do Nothing */
		break;
	}
}

/************************************************************************************
 * Service Name: ChrgM_PaymentServiceSelectionIndication
 * Service ID[hex]: 0x15
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Payment method offered by SECC
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PaymentServiceSelectionIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK || ResponseCode == OK_CertificateExpiresSoon)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_UnknownSession:
			Error_Indication = CHRGM_UnknownSession;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		case FAILED_PaymentSelectionInvalid:
			Error_Indication = CHRGM_PaymentSelectionInvalid;
			break;
		case FAILED_ServiceSelectionInvalid:
			Error_Indication = CHRGM_ServiceSelectionInvalid;
			break;
		case FAILED_NoChargeServiceSelected:
			Error_Indication = CHRGM_NoChargeServiceSelected;
			break;
		default:
			break;
		}

		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_SessionSetupIndication
 * Service ID[hex]: 0x12
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about V2G session setup information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_SessionSetupIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK || ResponseCode == OK_NewSessionEstablished || ResponseCode == OK_OldSessionJoined)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_SessionStopIndication
 * Service ID[hex]: 0x1C
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs the upper layer about status of V2G session
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_SessionStopIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_UnknownSession:
			Error_Indication = CHRGM_UnknownSession;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_SupportedAppProtocolIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Supported App Protocol Status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_SupportedAppProtocolIndication(ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDiscoveryIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Service Discovery information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_ServiceDiscoveryIndication(ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_UnknownSession:
			Error_Indication = CHRGM_UnknownSession;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDetailIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Service Details information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
//void ChrgM_ServiceDetailIndication(ChrgM_ResponseCodeType ResponseCode)
//{
//	Message_Received_Indication = TRUE;
//
//	if(ResponseCode == OK)
//	{
//		GetResponse(Message_Received_Indication, &Response_Header, &ServiceDetailRes_Message, CHRGM_NoError);
//	}
//	else
//	{
//		/*Inform the upper layer with an error message*/
//		switch (ResponseCode)
//		{
//		case FAILED:
//			Error_Indication = CHRGM_FAILED);
//			break;
//		case FAILED_SequenceError:
//			Error_Indication = CHRGM_SequenceError);
//			break;
//		case FAILED_UnknownSession:
//			Error_Indication = CHRGM_UnknownSession);
//			break;
//		case FAILED_SignatureError:
//			Error_Indication = CHRGM_SignatureError);
//			break;
//		case FAILED_ServiceIDInvalid:
//			Error_Indication = CHRGM_InvalidServiceID);
//			break;
//		default:
//			break;
//		}
//		GetResponse(Message_Received_Indication, &Response_Header, &ServiceDiscoveryRes_Message, Error_Indication);
//	}
//}

/************************************************************************************
 * Service Name: ChrgM_PaymentDetailsIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Payment Details
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PaymentDetailsIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_UnknownSession:
			Error_Indication = CHRGM_UnknownSession;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		case FAILED_CertificateExpired:
			Error_Indication = CHRGM_CertificateExpired;
			break;
		case FAILED_CertificateRevoked:
			Error_Indication = CHRGM_CertificateRevoked;
			break;
		case FAILED_NoCertificateAvailable:
			Error_Indication = CHRGM_NoCertificateAvailable;
			break;
		case FAILED_CertificateNotAllowedAtThisEVSE:
			Error_Indication = CHRGM_CertificateNotAllowedAtThisEVSE;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_AuthorizationIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Authorization
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_AuthorizationIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_UnknownSession:
			Error_Indication = CHRGM_UnknownSession;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		case FAILED_ChallengeInvalid:
			Error_Indication = CHRGM_ChallengeInvalid;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_ChargeParameterDiscoveryIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Charging Parameters
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_ChargeParameterDiscoveryIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_UnknownSession:
			Error_Indication = CHRGM_UnknownSession;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		case FAILED_WrongEnergyTransferMode:
			Error_Indication = CHRGM_WrongEnergyTransferMode;
			break;
		case FAILED_WrongChargeParameter:
			Error_Indication = CHRGM_WrongChargeParameter;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_CableCheckIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Cable check status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_CableCheckIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else if(ResponseCode == FAILED)
	{
		/*Inform the upper layer with an error message*/
		Error_Indication = CHRGM_FAILED;
		/* Call Indication API with error */
	}
	else
	{
		/*Do nothing*/
	}
	GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);

}

/************************************************************************************
 * Service Name: ChrgM_PreChargeIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about PreCharge Information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PreChargeIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else if(ResponseCode == FAILED)
	{
		/*Inform the upper layer with an error message*/
		Error_Indication = CHRGM_FAILED;
		/* Call Indication API with error */
	}
	else
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_PowerDeliveryIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about PowerDelivery Information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PowerDeliveryIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else
	{
		/*Inform the upper layer with an error message*/
		switch (ResponseCode)
		{
		case FAILED:
			Error_Indication = CHRGM_FAILED;
			break;
		case FAILED_SequenceError:
			Error_Indication = CHRGM_SequenceError;
			break;
		case FAILED_UnknownSession:
			Error_Indication = CHRGM_UnknownSession;
			break;
		case FAILED_SignatureError:
			Error_Indication = CHRGM_SignatureError;
			break;
		case FAILED_ChargingProfileInvalid:
			Error_Indication = CHRGM_ChargingProfileInvalid;
			break;
		case FAILED_TariffSelectionInvalid:
			Error_Indication = CHRGM_TariffSelectionInvalid;
			break;
		case FAILED_PowerDeliveryNotApplied:
			Error_Indication = CHRGM_PowerDeliveryNotApplied;
			break;
		case FAILED_ContactorError:
			Error_Indication = CHRGM_ContactorError;
			break;
		default:
			break;
		}
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_CurrentDemandIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Current Demand
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_CurrentDemandIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else if(ResponseCode == FAILED)
	{
		/*Inform the upper layer with an error message*/
		Error_Indication = CHRGM_FAILED;
		/* Call Indication API with error */
	}
	else
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
	}
}

/************************************************************************************
 * Service Name: ChrgM_WeldingDetectionIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Welding Detection Status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_WeldingDetectionIndication (ChrgM_ResponseCodeType ResponseCode)
{
	Message_Received_Indication = TRUE;

	if(ResponseCode == OK)
	{
		GetResponse(Message_Received_Indication, &V2G_EXI_Document, CHRGM_NoError);
	}
	else if(ResponseCode==FAILED)
	{
		/*Inform the upper layer with an error message*/
		Error_Indication = CHRGM_FAILED;
		/* Call Indication API with error */
	}
	else
	{
		/*Do nothing*/
	}
	GetResponse(Message_Received_Indication, &V2G_EXI_Document, Error_Indication);
}
