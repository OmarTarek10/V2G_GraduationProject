
/******************************************************************************
*
* Module: Wireless Ethernet
*
* File Name: WEth_Cfg.h
*
* Description: Header File For the Wireless Ethernet Module General Configurations
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/
#ifndef WETH_CFG_H_
#define WETH_CFG_H_

/*
* SWS Item: [ECUC_WEth_00003]
* Description: Switches the development error detection and notification on or off.
• true: detection and notification is enabled.
• false: detection and notification is disabled.
* Multiplicity: 1
* Type: EcucBooleanParamDef
*/
#define WETH_DEV_ERROR_DETECT  					(STD_ON)


/*
* SWS Item: [ECUC_WEth_00036]
* Description: Enables / Disables WEth_GetWEtherStats_32 and WEth_GetWEtherStats_64 API.
* Multiplicity: 1
* Type: EcucBooleanParamDef
*/
#define WETH_GET_WETHER_STATS_API				(STD_OFF)

/*
* SWS Item: [ECUC_WEth_00018]
* Description: Specifies the InstanceId of this module instance. If only one instance is present it shall
have the Id 0.
* Multiplicity: 1
* Type: EcucIntegerParamDef
*/
#define WETH_INDEX								(0U)

/*
* SWS Item: [ECUC_WEth_00022]
* Description: Specifies the period of main function WEth_MainFunction in seconds. Wireless
Ethernet driver does not require this information but the BSW scheduler.
* Multiplicity: 1
* Type: EcucFloatParamDef
*/
#define WETH_MAIN_FUNCTION_PERIOD				(0.1U)

/*
* SWS Item: [ECUC_WEth_00019]
* Description: Enables/Disables optional API WEth_UpdatePhysAddrFil
* Multiplicity: 1
* Type: EcucBooleanParamDef
*/
#define WETH_UPDATE_PHYS_ADDR_FILTER			(STD_OFF)

/*
* SWS Item: [ECUC_WEth_00004]
* Description: Enables / Disables version info API
* Multiplicity: 1
* Type: EcucBooleanParamDef
*/
#define WETH_VERSION_INFO_API					(STD_OFF)



/*
* SWS Item: [ECUC_WEth_00038]
* Description: Maps the Wireless Ethernet driver to zero or multiple ECUC partitions to make the
modules API available in this partition. The Wireless Ethernet driver will operate as an
independent instance in each of the partitions.
* Multiplicity: 0..*
* Type: Reference to EcucPartition
*/
/*Constrains: [SWS_WEth_CONSTR_00241] The module will operate as an independent instance
in each of the partitions, means the called API will only target the partition it is called
in.
[SWS_WEth_CONSTR_00242] If WEthEcucPartitionRef references one or more
ECUC partitions, WEthCtrlEcucPartitionRef shall have a multiplicity of one and reference one of these ECUC partitions as well.
*/
#define WEthEcucPartitionRef					/*???????*/
/*scope: ECU*/






#endif /* WETH_CFG_H_ */
