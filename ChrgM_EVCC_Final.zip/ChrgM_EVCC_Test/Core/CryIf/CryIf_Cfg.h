/*
 ============================================================================
 Name        : CryIf_Cfg.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

/*******************************************************************************
 *                   CryIfGeneral Container Configuration Parameters            *
 *******************************************************************************/

/* Pre-compile option for Development Error Detect
 * SWS Item:
 * */
#define CRYIF_DEV_ERROR_DETECT              (STD_OFF)

/* Pre-compile option for Version Info API
 * SWS Item:
 * */
#define CRYIF_VERSION_INFO_API                (STD_OFF)

#define MAX_NUMBER_OF_CHANNELS				(5U)


