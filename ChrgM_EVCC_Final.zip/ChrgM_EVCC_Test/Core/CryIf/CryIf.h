/*
 ============================================================================
 Name        : CryIf.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================

 */

#ifndef CRYIF_H
#define CRYIF_H

#include "../CryptoDriver/Crypto.h"

#define CRYPTODRIVER1		0X01

#define CRYIF_KEY_ID2		0x02
#define CRYIF_KEY_ID3		0x03
#define CRYIF_KEY_ID4		0x04
#define CRYIF_KEY_ID5		0x05
#define CRYIF_KEY_ID6		0x06

#define CYIFCHANNEL1		0x01

#define MAX_NUMBER_OF_CHANNELS	0x02

/******************************************************************************
 *                      API Service Id Macros                                 *
 ******************************************************************************/
#define CRYIF_INIT_SID 							0x00
#define CRYIF_GETVERSIONINFO_SID				0X01
#define CRYIF_PROCESSJOB_SID					0X03
#define CRYIF_KEYEXCHANGECALCSECRET				0x04
#define CRYIF_KEYEXCHANGECALCPUBVAL				0x05

/*******************************************************************************
 *                      ID - VersionInfo                                       *
 ******************************************************************************/

#define CRYIF_MODULE_ID       (uint8)(1U)
#define CRYIF_VENDOR_ID       (uint8)(2U)

/*
 * Module Version 1.0.0
 */
#define CRYIF_SW_MAJOR_VERSION                   (1U)
#define CRYIF_SW_MINOR_VERSION                   (0U)
#define CRYIF_SW_PATCH_VERSION                   (0U)

/*
 * AUTOSAR Version 4.0.3
 */
#define CRYIF_AR_RELEASE_MAJOR_VERSION           (4U)
#define CRYIF_AR_RELEASE_MINOR_VERSION           (7U)
#define CRYIF_AR_RELEASE_PATCH_VERSION           (0U)

/*******************************************************************************
 *                      DEV Error Codes                                        *
 ******************************************************************************/

#define CRYIF_E_UNINIT 						0x00
#define CRYIF_E_INIT_FAILED 			 	0x01
#define CRYIF_E_PARAM_POINTER 				0x02
#define CRYIF_E_PARAM_HANDLE 				0x03
#define CRYIF_E_PARAM_VALUE 				0x04
#define CRYIF_E_KEY_SIZE_MISMATCH 			0x05

/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef struct {
	uint8 dummy;
} CryIf_ConfigType;

typedef enum {
	CRYIF_STATE_UNINIT, CRYIF_STATE_INIT
} CryIf_StateType;

typedef struct {

	uint32 CryIfChannelId;
	CryptoDriverObject CryIfDriverObjectRef;

} CryIfChannel;

typedef struct {
	uint32 CryIfKeyId;
	CryptoKey CryIfKeyRef;

}CryIfKey;



/*******************************************************************************
 *                      Function Prototypes                                    *
 *******************************************************************************/

void CryIf_Init (const CryIf_ConfigType* configPtr);
void CryIf_GetVersionInfo (Std_VersionInfoType* versioninfo);
Std_ReturnType CryIf_ProcessJob (uint32 channelId,Crypto_JobType* job);
Std_ReturnType CryIf_KeyExchangeCalcSecret (uint32 cryIfKeyId, const uint8* partnerPublicValuePtr, uint32 partnerPublicValueLength);
Std_ReturnType CryIf_KeyExchangeCalcPubVal (uint32 cryIfKeyId, uint8* publicValuePtr, uint32* publicValueLengthPtr);

#endif //CRYIF_H

