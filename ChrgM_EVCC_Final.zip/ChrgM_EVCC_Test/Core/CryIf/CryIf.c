/*
 ============================================================================
 Name        : CryIf.c
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "../Std_Types.h"
#include "../Compiler.h"
#include "CryIf.h"
#include "CryIf_Cfg.h"

static CryIf_StateType CryIf_State = CRYIF_STATE_UNINIT;

/************************************************************************************
 * Service Name: CryIf_Init
 * Service ID[hex]: 0x00
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): const CryIf_ConfigType* configPtr
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Initializes the CRYIF module.
 ************************************************************************************/

void CryIf_Init (const CryIf_ConfigType* configPtr){

#if (CRYIF_DEV_ERROR_DETECT == STD_ON)
	if( configPtr!= NULL_PTR)
	{
		Det_ReportError(CRYIF_MODULE_ID, CRYIF_INSTANCE_ID, CRYIF_INIT_SID, CRYIF_E_INIT_FAILED);
	}
	else
#endif
	{
		CryIf_State=CRYIF_STATE_INIT;
	}

}

/************************************************************************************
 * Service Name: CryIf_GetVersionInfo
 * Service ID[hex]: 0x01
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): Std_VersionInfoType* versioninfo
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Returns the version information of this module.
 ************************************************************************************/
#if (CRYIF_VERSION_INFO_API == STD_ON)
void CryIf_GetVersionInfo (Std_VersionInfoType* versioninfo){

	if (versioninfo == NULL_PTR) {
#if (CRYIF_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CRYIF_MODULE_ID, CRYIF_INSTANCE_ID, CRYIF_GETVERSIONINFO_SID,
		CRYIF_E_PARAM_POINTER);
#endif

	} else {

		versioninfo->vendorID = NULL;
		versioninfo->moduleID = CRYIF_MODULE_ID;
		versioninfo->sw_major_version = CRYIF_SW_MAJOR_VERSION;
		versioninfo->sw_minor_version = CRYIF_SW_MINOR_VERSION;
		versioninfo->sw_patch_version = CRYIF_SW_PATCH_VERSION;
		versioninfo->ar_major_version = CRYIF_AR_RELEASE_MAJOR_VERSION;
		versioninfo->ar_minor_version = CRYIF_AR_RELEASE_MINOR_VERSION;
		versioninfo->ar_patch_version = CRYIF_AR_RELEASE_PATCH_VERSION;
	}

}
#endif



/************************************************************************************
 * Service Name: CryIf_ProcessJob
 * Service ID[hex]: 0x03
 * Sync/Async: Synchronous or Asynchronous depending on the configuration
 * Reentrancy: Reentrant
 * Parameters (in): uint32 channelId
 * Parameters (inout): Crypto_JobType* job
 * Parameters (out): None
 * Return value: Std_- ReturnType
 * Description: This interface dispatches the received jobs to the configured crypto driver object.
 ************************************************************************************/

Std_ReturnType CryIf_ProcessJob (uint32 channelId, Crypto_JobType* job){

#if (CRYIF_DEV_ERROR_DETECT == STD_ON)


	/*
	 * [SWS_CryIf_00027] ⌈ If development error detection for the CRYIF is enabled: The
function CryIf_ProcessJob shall report CRYIF_E_UNINIT to the DET and return
E_NOT_OK if the module is not yet initialized.

	 */

	if (CryIf_State == CRYIF_STATE_UNINIT) {

		Det_ReportError(CRYIF_MODULE_ID, CRYIF_INSTANCE_ID,
		CRYIF_PROCESSJOB_SID,
		CRYIF_E_UNINIT);

		return E_NOT_OK;
	}

	/*
	 * [SWS_CryIf_00028] ⌈ If development error detection for the CRYIF is enabled: The
function CryIf_ProcessJob shall report CRYIF_E_PARAM_HANDLE to the DET
and return E_NOT_OK if the parameter channelId is out or range.
⌋
	 */

	if (channelId > MAX_NUMBER_OF_CHANNELS){

		Det_ReportError(CRYIF_MODULE_ID, CRYIF_INSTANCE_ID,
		CRYIF_PROCESSJOB_SID,
		CRYIF_E_PARAM_HANDLE);

		return E_NOT_OK;
	}

	/*
	 * [SWS_CryIf_00029] ⌈ If development error detection for the CRYIF is enabled: The
function CryIf_ProcessJob shall report CRYIF_E_PARAM_POINTER to the DET
and return E_NOT_OK if the parameter job is a null pointer.

	*/

	if (job == NULL_PTR){

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CRYIF_PROCESSJOB_SID,
		CSM_E_PARAM_POINTER);

		return E_NOT_OK;

	}
#endif

	Std_ReturnType cryifprocessjobresult = Crypto_ProcessJob(CRYPTODRIVER1, job);

	return cryifprocessjobresult;

}

/************************************************************************************
 * Service Name: CryIf_KeyExchangeCalcSecret
 * Service ID[hex]: 0x0b
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): uint32 cryIfKeyId,
					const uint8* partnerPublicValuePtr,
					uint32 partnerPublicValueLength
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: Std_- ReturnType
 * Description: This function shall dispatch the key exchange common shared secret calculation
function to the configured crypto driver object.
 ************************************************************************************/

Std_ReturnType CryIf_KeyExchangeCalcSecret (
uint32 cryIfKeyId,
const uint8* partnerPublicValuePtr,
uint32 partnerPublicValueLength
){

#if (CRYIF_DEV_ERROR_DETECT == STD_ON)

	/*
		 * [SWS_CryIf_00027] ⌈ If development error detection for the CRYIF is enabled: The
	function CryIf_ProcessJob shall report CRYIF_E_UNINIT to the DET and return
	E_NOT_OK if the module is not yet initialized.

		 */

	if (CryIf_State == CRYIF_STATE_UNINIT) {

		Det_ReportError(CRYIF_MODULE_ID, CRYIF_INSTANCE_ID,
		CRYIF_KEYEXCHANGECALCSECRET_SID,
		CRYIF_E_UNINIT);

		return E_NOT_OK;
	}

	/*
	 * [SWS_CryIf_00092] ⌈ If development error detection for the CRYIF module is
		enabled: The function CryIf_KeyExchangeCalcSecret shall report
		CRYIF_E_PARAM_POINTER to the DET and return E_NOT_OK if the parameter
		partnerPublicValuePtr is a null pointer.
		⌋ (SRS_CryptoStack_00034)
	 *
	 * */

	if (partnerPublicValuePtr == NULL_PTR){

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CRYIF_KEYEXCHANGECALCSECRET_SID,
		CSM_E_PARAM_POINTER);

		return E_NOT_OK;

	}

	/*
	 * [SWS_CryIf_00094] ⌈ If development error detection for the CRYIF module is
		enabled: The function CryIf_KeyExchangeCalcSecret shall report
		CRYIF_E_PARAM_VALUE to the DET and return E_NOT_OK if
		partnerPubValueLength is zero.
		⌋ (SRS_CryptoStack_00034)
	 * */

	if (partnerPublicValueLength == NULL){

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CRYIF_KEYEXCHANGECALCSECRET_SID,
		CSM_E_PARAM_VALUE);

		return E_NOT_OK;

	}


#endif

	Std_ReturnType result = Crypto_KeyExchangeCalcSecret(cryIfKeyId, partnerPublicValuePtr, partnerPublicValueLength);
	return result;

}

/************************************************************************************
 * Service Name: CryIf_KeyExchangeCalcPubVal
 * Service ID[hex]: 0x0a
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): uint32 cryIfKeyId,
					const uint8* partnerPublicValuePtr,
					uint32 partnerPublicValueLength
 * Parameters (inout): uint32 partnerPublicValueLength
 * Parameters (out): const uint8* partnerPublicValuePtr,
 * Return value: Std_- ReturnType
 * Description: This function shall dispatch the key exchange public value calculation function to the
configured crypto driver object.
 ************************************************************************************/

Std_ReturnType CryIf_KeyExchangeCalcPubVal (
uint32 cryIfKeyId,
uint8* publicValuePtr,
uint32* publicValueLengthPtr
) {

#if (CRYIF_DEV_ERROR_DETECT == STD_ON)

	/*
		 * [SWS_CryIf_00027] ⌈ If development error detection for the CRYIF is enabled: The
	function CryIf_ProcessJob shall report CRYIF_E_UNINIT to the DET and return
	E_NOT_OK if the module is not yet initialized.

		 */

	if (CryIf_State == CRYIF_STATE_UNINIT) {

		Det_ReportError(CRYIF_MODULE_ID, CRYIF_INSTANCE_ID,
		CRYIF_KEYEXCHANGECALCPUBVAL,
		CRYIF_E_UNINIT);

		return E_NOT_OK;
	}

	/*
	 * [SWS_CryIf_00092] ⌈ If development error detection for the CRYIF module is
		enabled: The function CryIf_KeyExchangeCalcSecret shall report
		CRYIF_E_PARAM_POINTER to the DET and return E_NOT_OK if the parameter
		partnerPublicValuePtr is a null pointer.
		⌋ (SRS_CryptoStack_00034)
	 *
	 * */

	if (publicValuePtr == NULL_PTR){

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CRYIF_KEYEXCHANGECALCPUBVAL,
		CSM_E_PARAM_POINTER);

		return E_NOT_OK;

	}

	/*
	 * [SWS_CryIf_00094] ⌈ If development error detection for the CRYIF module is
		enabled: The function CryIf_KeyExchangeCalcSecret shall report
		CRYIF_E_PARAM_VALUE to the DET and return E_NOT_OK if
		partnerPubValueLength is zero.
		⌋ (SRS_CryptoStack_00034)
	 * */

	if (publicValueLengthPtr == NULL){

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CRYIF_KEYEXCHANGECALCPUBVAL,
		CSM_E_PARAM_VALUE);

		return E_NOT_OK;

	}


#endif

	Std_ReturnType result = Crypto_KeyExchangeCalcPubVal(cryIfKeyId, publicValuePtr, publicValueLengthPtr);
	return result;


}



