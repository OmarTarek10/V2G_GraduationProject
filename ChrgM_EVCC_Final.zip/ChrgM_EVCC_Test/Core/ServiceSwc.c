/*
 * ServiceSwc.c
 *
 *  Created on: Feb 24, 2024
 *      Author:  Mohannad Sabry
 */
#include "Std_Types.h"
#include "V2G_Data_Types.h"
#include "Rte_ServiceSwc.h"
#include "ChrgM.h"

/*
 *Runnable that used to call and send data to api's in chrgM Module
*/
void  CallV2gState(uint8 Func_Name, void* V2G_EXI_Document){
	switch(Func_Name){
		// StartProcess Need to take a boolean value
		case SUPPORTED_APP_PROTOCOL_MESSAGE: ChrgM_StartProcess(TRUE);
		                   break;
		case SESSION_SETUP_MESSAGE:ChrgM_SessionSetupReq(V2G_EXI_Document);
		                   break;
		case SERVICE_DISCOVERY_MESSAGE:ChrgM_ServiceDiscoveryReq(V2G_EXI_Document);
		                   break;
		case PAYMENT_SELECTION_MESSAGE:ChrgM_PaymentServiceSelectionReq(V2G_EXI_Document);
		                   break;
		case PAYMENT_DETAILS_MESSAGE:ChrgM_PaymentDetailsReq(V2G_EXI_Document);
		                   break;
		case AUTHORIZATION_MESSAGE:ChrgM_AuthorizationReq(V2G_EXI_Document);
		                   break;
		case CHARGE_PARAMETER_DISCOVERY_MESSAGE:ChrgM_ChargeParameterDiscoveryReq(V2G_EXI_Document);
		                   break;
		case CABLE_CHECK_MESSAGE:ChrgM_CableCheckReq(V2G_EXI_Document);
		                   break;
		case PRE_CHARGE_MESSAGE:ChrgM_PreChargeReq(V2G_EXI_Document);
		                   break;
		case POWER_DELIVERY_MESSAGE:ChrgM_PowerDeliveryReq(V2G_EXI_Document);
		                   break;
		case CURRENT_DEMAND_MESSAGE:ChrgM_CurrentDemandReq(V2G_EXI_Document);
		                   break;
		case WELDING_DETECTION_MESSAGE:ChrgM_WeldingDetectionReq(V2G_EXI_Document);
		                   break;
		case SESSION_STOP_MESSAGE:ChrgM_SessionStopReq(V2G_EXI_Document);
		                   break;
	}

}
/*
 *Runnable that was called by ChrgM to send Response to application Swc
*/
void  GetResponse(uint8 Indication, void* V2G_EXI_Document, uint8 ChrgM_Error){
	Rte_Call_ServiceSwc_RP_CS_Response_GetData(Indication,V2G_EXI_Document,ChrgM_Error);
}

void CallCpLine(uint8 CpLineStatus){
	ChrgM_CpLineStatus(CpLineStatus);
}

