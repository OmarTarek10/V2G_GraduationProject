/*
 ============================================================================
 Name        : Crypto_GeneralTypes.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Header file for type definitions of CSM
 ============================================================================
 */

#ifndef CRYPTO_GENERALTYPES_H
#define CRYPTO_GENERALTYPES_H

#include <stdint.h>
#include "Std_Types.h"
#include "Rte_Csm_Type.h"

/*******************************************************************************
 *                          Pre-Processors Definition                          *
 *******************************************************************************/

#define CRYPTO_E_BUSY        		  	((Std_ReturnType)0x02U)
#define CRYPTO_E_ENTROPY_EXHAUSTED    	((Std_ReturnType)0x04U)
#define CRYPTO_E_KEY_READ_FAIL        	((Std_ReturnType)0x06U)
#define CRYPTO_E_KEY_WRITE_FAIL       	((Std_ReturnType)0x07U)
#define CRYPTO_E_KEY_NOT_AVAILABLE    	((Std_ReturnType)0x08U)
#define CRYPTO_E_KEY_NOT_VALID        	((Std_ReturnType)0x09U)
#define CRYPTO_E_KEY_SIZE_MISMATCH    	((Std_ReturnType)0x0AU)
#define CRYPTO_E_JOB_CANCELED         	((Std_ReturnType)0x0CU)
#define CRYPTO_E_KEY_EMPTY        	  	((Std_ReturnType)0x0DU)
#define CRYPTO_E_CUSTOM_ERROR         	((Std_ReturnType)0x0EU)




typedef enum {

	CRYPTO_ALGOFAM_NOT_SET,
	CRYPTO_ALGOFAM_SHA1,
	CRYPTO_ALGOFAM_SHA2_224,
	CRYPTO_ALGOFAM_SHA2_256,
	CRYPTO_ALGOFAM_SHA2_384,
	CRYPTO_ALGOFAM_SHA2_512,
	CRYPTO_ALGOFAM_SHA2_512_224,
	CRYPTO_ALGOFAM_SHA2_512_256,
	CRYPTO_ALGOFAM_SHA3_224,
	CRYPTO_ALGOFAM_SHA3_256,
	CRYPTO_ALGOFAM_SHA3_384,
	CRYPTO_ALGOFAM_SHA3_512,
	CRYPTO_ALGOFAM_SHAKE128,
	CRYPTO_ALGOFAM_SHAKE256,
	CRYPTO_ALGOFAM_RIPEMD160,
	CRYPTO_ALGOFAM_BLAKE_1_256,
	CRYPTO_ALGOFAM_BLAKE_1_512,
	CRYPTO_ALGOFAM_BLAKE_2s_256,
	CRYPTO_ALGOFAM_BLAKE_2s_512,
	CRYPTO_ALGOFAM_3DES,
	CRYPTO_ALGOFAM_AES,
	CRYPTO_ALGOFAM_CHACHA,
	CRYPTO_ALGOFAM_RSA,
	CRYPTO_ALGOFAM_ED25519,
	CRYPTO_ALGOFAM_BRAINPOOL,
	CRYPTO_ALGOFAM_ECCNIST,
	CRYPTO_ALGOFAM_RNG,
	CRYPTO_ALGOFAM_SIPHASH,
	CRYPTO_ALGOFAM_ECCANSI,
	CRYPTO_ALGOFAM_ECCSEC,
	CRYPTO_ALGOFAM_DRBG,
	CRYPTO_ALGOFAM_FIPS186,
	CRYPTO_ALGOFAM_PADDING_PKCS7,
	CRYPTO_ALGOFAM_PADDING_ONEWITHZEROS,
	CRYPTO_ALGOFAM_PBKDF2,
	CRYPTO_ALGOFAM_KDFX963,
	CRYPTO_ALGOFAM_DH,
	CRYPTO_ALGOFAM_SM2,
	CRYPTO_ALGOFAM_EEA3,
	CRYPTO_ALGOFAM_SM3,
	CRYPTO_ALGOFAM_EIA3,
	CRYPTO_ALGOFAM_HKDF,
	CRYPTO_ALGOFAM_ECDSA,
	CRYPTO_ALGOFAM_POLY1305,
	CRYPTO_ALGOFAM_X25519,
	CRYPTO_ALGOFAM_ECDH,
	CRYPTO_ALGOFAM_CUSTOM,

}Crypto_AlgorithmFamilyType;

typedef enum  {

	CRYPTO_ALGOMODE_NOT_SET,
	CRYPTO_ALGOMODE_ECB,
	CRYPTO_ALGOMODE_CBC,
	CRYPTO_ALGOMODE_CFB,
	CRYPTO_ALGOMODE_OFB,
	CRYPTO_ALGOMODE_CTR,
	CRYPTO_ALGOMODE_GCM,
	CRYPTO_ALGOMODE_XTS,
	CRYPTO_ALGOMODE_RSAES_OAEP,
	CRYPTO_ALGOMODE_RSAES_PKCS1_v1_5,
	CRYPTO_ALGOMODE_RSASSA_PSS,
	CRYPTO_ALGOMODE_RSASSA_PKCS1_v1_5,
	CRYPTO_ALGOMODE_8ROUNDS,
	CRYPTO_ALGOMODE_12ROUNDS,
	CRYPTO_ALGOMODE_20ROUNDS,
	CRYPTO_ALGOMODE_HMAC,
	CRYPTO_ALGOMODE_CMAC,
	CRYPTO_ALGOMODE_GMAC,
	CRYPTO_ALGOMODE_CTRDRBG,
	CRYPTO_ALGOMODE_SIPHASH_2_4,
	CRYPTO_ALGOMODE_SIPHASH_4_8,
	CRYPTO_ALGOMODE_PXXXR1,
	CRYPTO_ALGOMODE_CUSTOM


}Crypto_AlgorithmModeType;

typedef enum  {
	CRYPTO_REDIRECT_CONFIG_PRIMARY_INPUT,
	CRYPTO_REDIRECT_CONFIG_SECONDARY_INPUT,
	CRYPTO_REDIRECT_CONFIG_TERTIARY_INPUT,
	CRYPTO_REDIRECT_CONFIG_PRIMARY_OUTPUT,
	CRYPTO_REDIRECT_CONFIG_SECONDARY_OUTPUT

}Crypto_InputOutputRedirectionConfigType;

typedef enum  {

	CRYPTO_HASH,
	CRYPTO_MACGENERATE,
	CRYPTO_MACVERIFY,
	CRYPTO_ENCRYPT,
	CRYPTO_DECRYPT,
	CRYPTO_AEADENCRYPT,
	CRYPTO_AEADDECRYPT,
	CRYPTO_SIGNATUREGENERATE,
	CRYPTO_SIGNATUREVERIFY,
	CRYPTO_RANDOMGENERATE,
	CRYPTO_RANDOMSEED,
	CRYPTO_KEYGENERATE,
	CRYPTO_KEYDERIVE,
	CRYPTO_KEYEXCHANGECALCPUBVAL,
	CRYPTO_KEYEXCHANGECALCSECRET,
	CRYPTO_KEYSETVALID,
	CRYPTO_KEYSETINVALID,
	CRYPTO_CUSTOM_SERVICE

}Crypto_ServiceInfoType;

typedef enum  {
	CRYPTO_JOBSTATE_IDLE,
	CRYPTO_JOBSTATE_ACTIVE,
}Crypto_JobStateType;



typedef enum {
	CRYPTO_PROCESSING_ASYNC,
	CRYPTO_PROCESSING_SYNC

}Crypto_ProcessingType;

typedef enum  {
	CRYPTO_OPERATIONMODE_START,
	CRYPTO_OPERATIONMODE_UPDATE,
	CRYPTO_OPERATIONMODE_FINISH,
	CRYPTO_OPERATIONMODE_SINGLECALL

} Crypto_OperationModeType;

typedef struct  {

	uint8_t redirectionConfig;
	uint32_t inputKeyId;
	uint32_t inputKeyElementId;
	uint32_t secondaryInputKeyId;
	uint32_t secondaryInputKeyElementId;
	uint32_t tertiaryInputKeyId;
	uint32_t tertiaryInputKeyElementId;
	uint32_t outputKeyId;
	uint32_t outputKeyElementId;
	uint32_t secondaryOutputKeyId;
	uint32_t secondaryOutputKeyElementId;

}Crypto_JobRedirectionInfoType;

typedef struct {
	const uint8* inputPtr;
	uint32 inputLength;
	const uint8* secondaryInputPtr;
	uint32 secondaryInputLength;
	const uint8* tertiaryInputPtr;
	uint32 tertiaryInputLength;
	uint8* outputPtr;
	uint32* outputLengthPtr;
	uint8* secondaryOutputPtr;
	uint32* secondaryOutputLengthPtr;
	Crypto_VerifyResultType* verifyPtr;
	Crypto_OperationModeType mode;
	uint32 cryIfKeyId;
	uint32 targetCryIfKeyId;

}Crypto_JobPrimitiveInputOutputType ;

typedef struct {

	Crypto_AlgorithmFamilyType family;
	Crypto_AlgorithmFamilyType secondaryFamily;
	uint32_t keyLength;
	Crypto_AlgorithmModeType mode;

}Crypto_AlgorithmInfoType ;

typedef struct {
	uint32 resultLength;
	const Crypto_AlgorithmInfoType algorithm;
	const Crypto_ServiceInfoType service;

} Crypto_PrimitiveInfoType;

typedef struct {
	uint32 callbackId;
	const Crypto_PrimitiveInfoType* primitiveInfo;
	uint32 cryIfKeyId;
	Crypto_ProcessingType processingType;

}Crypto_JobPrimitiveInfoType ;

typedef struct {
	uint32 jobId;
	uint32 jobPriority;
}Crypto_JobInfoType;

typedef struct {
	uint32 jobId;
	Crypto_JobStateType jobState;
	Crypto_JobInfoType jobInfo;
	Crypto_JobPrimitiveInputOutputType jobPrimitiveInputOutput;
	const Crypto_JobPrimitiveInfoType* jobPrimitiveInfo;
	Crypto_JobRedirectionInfoType* jobRedirectionInfoRef;
	uint32 cryptoKeyId;
	uint32 targetCryptoKeyId;
	const uint32 jobPriority;

}Crypto_JobType ;

#endif //CRYPTO_GENERALTYPES_H




















