#include "Std_Types.h"
#include "RTE_ConnectionCheckSwc.h"



/*
 *Runnable that used to get PinStatus from Ecu Abstract Swc and send it to Application Swc
*/
void GetConnectionStatus(void){
	uint8 Connection_Status;
	Rte_Call_ConnectionCheckSwc_RP_CS_PinStatus_GetPinStatus(&Connection_Status);
	Rte_Write_ConnectionCheckSwc_PP_SR_ConnectionStatus_ConnectionStatus(Connection_Status);
}
