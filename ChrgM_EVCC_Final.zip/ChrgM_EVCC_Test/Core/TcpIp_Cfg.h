#ifndef TCPIP_CFG_H_
#define TCPIP_CFG_H_

#include "Std_Types.h"

/**=====================================================**/
/** TCPIP General Container **/
/*Memory size in bytes reserved for TCP/IP buffers*/
#define TcpIpBufferMemory		1500

/*Switches the development error detection and notification on or off*/
#define TcpIpDevErrorDetect		(STD_ON)

/*Switches the reporting of security events to the IdsM*/
#define TcpIpEnableSecurityEventReporting	(STD_OFF)

/*Period of TcpIp_MainFunction in [s]*/
#define TcpIpMainFunctionPeriod		0

/*In order to customize the TcpIp Stack to the specific needs of the user it can be scaled according to the scalability classes.
SC1 IPv4 - In-Vehicle and Diagnostic Communication
SC2 IPv6 - In-Vehicle and Diagnostic Communication
SC3 IPv4 and IPv6 (Dual Stack) - In-Vehicle and Diagnostic Communication */
#define TcpIpScalabilityClass	(SC1)

/*Enables or disables support of TCP (Transmission Control Protocol)*/
#define TcpIpTcpEnabled			(TRUE)

/*Maximum number of TCP sockets*/
#define TcpIpTcpSocketMax		(2)

/*Enables or disables support of UDP (User Datagram Protocol)*/
#define TcpIpUdpEnabled			(FALSE)

/*Maximum number of UDP sockets*/
#define TcpIpUdpSocketMax		(0)

/*If true the TcpIp_GetVersionInfo API is available*/
#define TcpIpVersionInfoApi		(FALSE)
/**=====================================================**/

/**=====================================================**/
/** TcpIpSocketOwner Container **/
/*This parameter specifies the type of the upper layer module*/
#define TcpIpSocketOwnerUpperLayerType	SOAD
/**=====================================================**/

/**=====================================================**/
/** TcpIpIpV4General Container **/
#define TcpIpIpV4Enabled		(FALSE)
/**=====================================================**/

/**=====================================================**/
/** TcpIpIpV6General Container **/
#define TcpIpIpV6Enabled		(TRUE)
/**=====================================================**/


/**=====================================================**/
/** TcpIpTcpConfig Container **/
/*The maximal time an acknowledgment is delayed for transmission in seconds.*/
#define TcpIpDelayedAckTimeout		(0.5)	//Range [0 .. 0.5], Default [0.5]

/*Enables or disables support of TCP congestion avoidance algorithm*/
#define TcpIpTcpCongestionAvoidanceEnabled	(TRUE)

/*Enables or disables support of TCP Fast Recovery */
#define TcpIpTcpFastRecoveryEnabled			(FALSE)

/*Enables or disables support of TCP Fast Retransmission*/
#define TcpIpTcpFastRetransmitEnabled		(FALSE)

/*Timeout in [s] to receive a FIN from the remote node (after this node has initiated connection termination)*/
#define TcpIpTcpFinWait2Timeout				(0)	//Range [0 .. INF]

/*Maximum Segment size*/			//kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk
#define TcpIpMaxSegmentSize					(1500)

/*Maximum number of times that a TCP segment is retransmitted before the TCP
connection is closed.This parameter also applies for FIN retransmissions*/
#define TcpIpTcpMaxRtx						(0)	//Range [0 .. 255]

/*Maximum segment lifetime in [s]. */
#define TcpIpTcpMsl							(0)	//Range [0 .. INF]

/*Enables or disables support of Nagle’s algorithm*/
#define TcpIpTcpNagleEnabled				(TRUE)

/*Default value of maximum receive window in bytes*/
#define TcpIpTcpReceiveWindowMax			(0)	//Range [0 .. 65535]

/*Timeout in [s] before an unacknowledged TCP segment is sent again. If the timeout is disabled or set to INF,no TCP segments shall be retransmitted. */
#define TcpIpTcpRetransmissionTimeout		(0)	//Range [0.001 .. INF]

/*Enables or disables support of TCP slow start algorithm */
#define TcpIpTcpSlowStartEnabled			(TRUE)

/*Maximum number of times that a TCP SYN is retransmitted. Note: SYN will be retried after TcpIpTcpRetransmissionTimeout. The connection will be dropped if no matching connection request has been received after the last TCP SYN has been sent and TcpIp TcpRetransmissionTimeout has been expired.*/
#define TcpIpTcpSynMaxRtx					(0)	//Range [0 .. 255]

/*Timeout in [s] to complete a remotely initiated TCP connection establishment, i.e.maximum time waiting in SYN-RECEIVED for a confirming connection request
acknowledgment after having both received and sent a connection request.*/
#define TcpIpTcpSynReceivedTimeout			(0)	//Range [0 .. INF]
/**=====================================================**/



/*******************************************************************************
 *                              TcpIpV6 General Configuration                  *
 *******************************************************************************/

#define TCPIP_DHCPV6_CLIENT_ENABLED 									FALSE
#define TCPIP_IPV6_ENABLED 												TRUE
#define TCPIP_IPV6_PATH_MTU_DISCOVERY_ENABLED 							FALSE
#define TCPIP_NDP_ADDRESS_RESOLUTION_UNRECHABILITY_DETECTION_ENABLED 	TRUE
#define TCPIP_NDP_PREFIX_AND_ROUTER_DISCOVERY_ENABLED 					TRUE


/*******************************************************************************
 *                              TcpIpIcmpV6 General Configuration              *
 *******************************************************************************/

#define TCPIP_ICMPV6_ECHO_REPLY_ENABLED 								STD_ON
#if (TCPIP_ICMPV6_ECHO_REPLY_ENABLED == STD_ON)


#define TCPIP_ICMPV6_ECHO_REPLY_AVOID_FRAGMENTATION 					TRUE
#endif

#define TCPIP_ICMPV6_MSG_DESTINATION_UNREACHABLE_ENABLED 				TRUE
#define TCPIP_ICMPV6_MSG_PARAMETER_PROBLEM_ENABLED 						TRUE



/*******************************************************************************
 *                             TcpIpIpV6FragmentationConfig            *
 *******************************************************************************/

#define TCP_IP_IPV6_REASSEMBLY_BUFFER_COUNT				255
#define TCPIP_IPV6_REASSEMBLY_BUFFER_SIZE				1500
#define TCPIP_IPV6_REASSEMBLY_SEGMENT_COUNT				5
#define TCPIP_IPV6_REASSEMBLY_TIMEOUT					60
#define TCPIP_IPV6_TX_FRAGMENT_BUFFER_COUNT				2

/*******************************************************************************
 *                             TcpIpIpV6MtuConfig           *
 *******************************************************************************/

#define TCPIP_IPV6_PATH_MTU_ENABLED						FALSE
#if TCPIP_IPV6_PATH_MTU_ENABLED	==TRUE
#define TCPIP_IPV6_PATH_MTU_TIMEOUT						600
#endif


/*******************************************************************************
 *                             TcpIpNdpArNudConfig           *
 *******************************************************************************/

#define TCPIP_NDP_DEFAULT_REACHABLE_TIME						30
#define TCPIP_NDP_DEFAULT_RETRANS_TIMER							1
#define TCPIP_NDP_DEFENSIVE_PROCESSING							FALSE
#define TCPIP_NDP_DELAY_FIRST_PROBE_TIME						5
#define TCPIP_NDP_MAX_NEIGHBOR_CACHE_SIZE						5
#define TCPIP_NDP_MAX_RANDOM_FACTOR								15
#define TCPIP_NDP_MIN_RANDOM_FACTOR								5
#define TCPIP_NDP_NEIGHBOR_UNREACHABILITY_DETECTION_ENABLED		TRUE
#define TCPIP_NDP_NUM_MULTICAST_SOLICITATIONS					3
#define TCPIP_NDP_NUM_UNICAST_SOLICITATIONS						3
#define TCPIP_NDP_PACKET_QUEUE_ENABLED							TRUE
#define TCPIP_NDP_RANDOM_REACHABLE_TIME_ENABLED					TRUE


/*******************************************************************************
 *                         TcpIpNdpPrefixRouterDiscoveryConfig           *
 *******************************************************************************/
#if (TCPIP_NDP_PREFIX_AND_ROUTER_DISCOVERY_ENABLED == TRUE)
#define TCPIP_NDP_DEFAULT_ROUTER_LIST_SIZE						2
#define TCPIP_NDP_DESTINATION_CACHE_SIZE						5
#define TCPIP_NDP_DYNAMIC_HOP_LIMIT_ENABLED						TRUE
#define TCPIP_NDP_DYNAMIC_REACHABLE_TIME_ENABLED				TRUE
#define TCPIP_NDP_DYNAMIC_RETRANS_TIME_ENABLED					TRUE
#define TCPIP_NDP_MAX_RTR_SOLICITATION_DELAY					1
#define TCPIP_NDP_MAX_RTR_SOLICITATIONS							3
#define TCPIP_NDP_PREFIX_LIST_SIZE								5
#define TCPIP_NDP_RND_RTR_SOLICITATION_DELAY_ENABLED			TRUE
#define TCPIP_NDP_RTR_SOLICITATION_INTERVAL						4
#endif

/*******************************************************************************
 *                         TcpIpNdpSlaacConfig           *
 *******************************************************************************/
#define TCPIP_NDP_SLAAC_DAD_NUMBER_OF_TRANSMISSIONS				1
#define TCPIP_NDP_SLAAC_DAD_RETRANSMISSION_DELAY				1


/*******************************************************************************
 *                         TcpIpIpSecConfigSet           *
 *******************************************************************************/

#define TCPIP_IPSEC_AUDIT_EVENT_CALLOUT_FUNCTION
#define TCPIP_IPSEC_CALLOUT_HEADER_FILE
#define TCPIP_IPSEC_SPD_CALLOUT_FUNCTION
#define TCPIP_REMOTE_DEVICE_NUM

/*******************************************************************************
 *                         TcpIpEncryptionAlgorithm           *
 *******************************************************************************/
#define TCPIP_ENCRYPTION_TRANSFORM_IDENTIFIER				TCPIP_IPSEC_TRANSFORM_ENCR_DES


/*******************************************************************************
 *                         TcpIpIntegrityAlgorithm           *
 *******************************************************************************/
#define TCPIP_INTEGRITY_TRANSFORM_IDENTIFIER				TCPIP_IPSEC_TRANSFORM_AUTH_HMAC_SHA2_256_128


/*******************************************************************************
 *                         TcpIpSpdEntry           *
 *******************************************************************************/

#define TCPIP_IPSEC_HEADER_TYPE								TCPIP_IPSEC_HDR_AH


/*******************************************************************************
 *                         IKEGeneral           *
 *******************************************************************************/
#define IKE_VERSION_INFO_API								FALSE

/*******************************************************************************
 *                         IKEMessageFormat           *
 *******************************************************************************/
#define IKE_MAX_ATTRIBUTES_PER_TRANSFORM					2
#define IKE_MAX_CERT_PAYLOADS_PER_MESSAGE					4
#define IKE_MAX_DELETE_PAYLOADS_PER_MESSAGE					2
#define IKE_MAX_INIT_MESSAGE_SIZE							512
#define IKE_MAX_NONCE_SIZE									64
#define IKE_MAX_NOTIFY_PAYLOADS_PER_MESSAGE					10
#define IKE_MAX_PAYLOADS_PER_MESSAGE						20
#define IKE_MAX_PROPOSALS_PER_SA_PAYLOAD					5
#define IKE_MAX_SPIS_PER_DELETE_PAYLOAD						2
#define IKE_MAX_TRAFFIC_SELECTORS_PER_TS_PAYLOAD			2
#define IKE_MAX_TRANSFORMS_PER_PROP							5

/*******************************************************************************
 *                         IKEConnections           *
 *******************************************************************************/
#define IKE_CONNECTION_TIMEOUT								30
#define IKE_FRAGMENT_SIZE									1280
#define IKE_MAX_NUM_FRAGMENTS								3
#define IKE_REASSEMBLING_TIMEOUT							0.5
#define IKE_RETRANSMIT_BASE									1.3
#define IKE_RETRANSMIT_TIMEOUT								1.5
#define IKE_RETRANSMIT_TRIES								10

/*******************************************************************************
 *                         IKEConnection           *
 *******************************************************************************/
#define IKE_AUTO_START										FALSE
#define IKE_CONNECTION_ID									0
#define IKE_DPD_DELAY										30
#define IKE_IKE_LIFETIME									86400
#define IKE_IKE_MARGIN_TIME									600
#define IKE_REMOTE_PORT										500

/*******************************************************************************
 *                         IKEChildSaProposal           *
 *******************************************************************************/
#define IKE_SECURITY_PROTOCOL								IKE_PROTOCOL_AH
#define IKE_USE_EXTENDED_SEQUENCE_NUMBERS					TRUE


/*******************************************************************************
 *                         IKESignatureAuthenticationVariant           *
 *******************************************************************************/
#define IKE_HASH_ALGORITHM									IKE_HASH_ALGO_SHA2_256
#define IKE_SIGNATURE_ALGORITHM								IKE_SIGNATURE_ECDSA
#define IKE_SIGNATURE_LENGTH								96


/*******************************************************************************
 *                         IKETransforms           *
 *******************************************************************************/
#define IKE_DH_TRANSFORM_ID								IKE_TRANSFORM_DH_256_BIT_RANDOM_ECP_GROUP
#define	IKE_E_TRANSFORM_ID								IKE_TRANSFORM_ENCR_AES_CBC
#define IKE_KEY_LENGTH									256
#define IKE_I_TRANSFORM_ID								IKE_TRANSFORM_AUTH_AES_CMAC_96
#define IKE_PRF_TRANSFORM_ID							IKE_TRANSFORM_PRF_HMAC_SHA2_256

/*******************************************************************************
 *                         IKECertificates           *
 *******************************************************************************/
#define IKE_MAX_PUBLIC_KEY_LENGTH						512
#define IKE_MAX_SUBJECT_NAME_SIZE						256

#endif
