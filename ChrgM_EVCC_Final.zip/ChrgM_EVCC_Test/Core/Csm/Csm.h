/*
 ============================================================================
 Name        : CSM.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Header file for CSM module
 ============================================================================
 */

#include "../Std_Types.h"
#include "../CryIf/CryIf.h"
#include "../Crypto_GeneralTypes.h"
#include "../CryIf/Cryif.h"
#include "../CryptoDriver/Crypto.h"

/*
 * Macros for Csm Status
 */
#define CSM_INITIALIZED (1U)
#define CSM_NOT_INITIALIZED (0U)

/******************************************************************************
 *                      API Service Id Macros                                 *
 ******************************************************************************/
#define CSM_INIT_SID 							0x00
#define CSM_GETVERSIONINFO_SID					0X01
#define CSM_SIGNATURE_GENERATE_SID 				0x76
#define CSM_SIGNATURE_VERIFY_SID 				0x64
#define CSM_ENCRYPT_SID 						0x5e
#define CSM_DECRYPT_SID 						0x5f
#define CSM_KEYEXCHANGECALCSECRET_SID			0x6d

/*******************************************************************************
 *                      ID - VersionInfo                                       *
 ******************************************************************************/

#define CSM_MODULE_ID       (uint8)(1U)
#define CSM_VENDOR_ID       (uint8)(2U)

/*
 * Module Version 1.0.0
 */
#define CSM_SW_MAJOR_VERSION                   (1U)
#define CSM_SW_MINOR_VERSION                   (0U)
#define CSM_SW_PATCH_VERSION                   (0U)

/*
 * AUTOSAR Version 4.0.3
 */
#define CSM_AR_RELEASE_MAJOR_VERSION           (1U)
#define CSM_AR_RELEASE_MINOR_VERSION           (0U)
#define CSM_AR_RELEASE_PATCH_VERSION           (0U)

/*******************************************************************************
 *                      DET Error Codes                                        *
 ******************************************************************************/
#define CSM_E_PARAM_POINTER 				0x01
#define CSM_E_PARAM_HANDLE 					0x04
#define CSM_E_UNINIT 						0x05
#define CSM_E_INIT_FAILED 					0x07
#define CSM_E_PROCESSING_MOD 				0x08
#define CSM_E_SERVICE_TYPE 					0x09


#define CSM_E_QUEUE_FULL 					0x01

/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef struct {
	uint8 dummy;
} Csm_ConfigType;

typedef enum {
	CSM_STATE_UNINIT, CSM_STATE_INIT
} Csm_StateType;

/*******MainFunction DataTypes***********/

typedef struct {
	const float32 CsmMainFunctionPeriod;

}CsmMainFunction;

/*******Key DataTypes***********/

typedef struct {
	uint32 CsmKeyId;
	boolean CsmKeyUsePort;
	CryIfKey *CsmKeyRef;

}CsmKey;

/*******Key DataTypes***********/

typedef struct {
	uint32 CsmQueueSize;
	CryIfChannel *CsmChannelRef;
	CsmMainFunction *CsmQueueMainFunctionRef;
	Crypto_JobInfoType jobInfo[4];
	uint8 currentjobs;
	uint8 capacity;
	uint8 front, rear;

}CsmQueue;

/*******HASH DataTypes**************/

typedef Crypto_AlgorithmModeType CsmHashAlgorithmMode;

typedef Crypto_AlgorithmFamilyType CsmHashAlgorithmFamily;

typedef Crypto_AlgorithmFamilyType CsmHashAlgorithmSecondaryFamily;


typedef struct {
	CsmHashAlgorithmFamily family;
	CsmHashAlgorithmMode mode;
	CsmHashAlgorithmSecondaryFamily secondFamily;
	uint32 keyLength;
} CsmHashConfig;

/*******Cipher DataTypes**************/

typedef Crypto_AlgorithmModeType Csm3DESAlgorithmMode;

typedef Crypto_AlgorithmFamilyType Csm3DESAlgorithmFamily;

typedef Crypto_AlgorithmFamilyType Csm3DEShAlgorithmSecondaryFamily;

typedef struct {
	CsmHashAlgorithmFamily family;
	CsmHashAlgorithmMode mode;
	CsmHashAlgorithmSecondaryFamily secondFamily;
	uint32 keyLength;
} CsmSignatureGenerateConfig;

typedef struct {
	CsmHashAlgorithmFamily family;
	CsmHashAlgorithmMode mode;
	CsmHashAlgorithmSecondaryFamily secondFamily;
	uint32 keyLength;
} CsmSignatureVerifyConfig;

typedef struct {
	CsmHashAlgorithmFamily family;
	CsmHashAlgorithmMode mode;
	CsmHashAlgorithmSecondaryFamily secondFamily;
	uint32 keyLength;
} CsmAESConfig;

/********Primitives**********************/

/* CsmPrimitives */
typedef struct {
	CsmSignatureGenerateConfig SignatureGenerateConfig;
	CsmSignatureVerifyConfig SignatureVerifyConfig;
	CsmHashConfig HashConfig;
	CsmAESConfig EncryptConfig;
	CsmAESConfig DecryptConfig;


} CsmPrimitives;

/*******InOutRedirection DataTypes***********/

typedef struct {
	uint32 CsmInputKeyElementId;
	uint32 CsmOutputKeyElementId;
	uint32 CsmSecondaryInputKeyElementId;
	uint32 CsmSecondaryOutputKeyElementId;
	uint32 CsmTertiaryInputKeyElementId;
	CsmKey CsmInputKeyRef;
	CsmKey CsmOutputKeyRef;
	CsmKey CsmSecondaryInputKeyRef;
	CsmKey CsmSecondaryOutputKeyRef;
	CsmKey CsmTertiaryInputKeyRef;

}CsmInOutRedirection;

/***********Signature*****************/
typedef Crypto_AlgorithmModeType CsmSignatureGenerateAlgorithmMode;

typedef Crypto_AlgorithmFamilyType CsmSignatureGenerateAlgorithmFamily;


typedef Crypto_AlgorithmFamilyType CsmSignatureGenerateAlgorithmSecondaryFamily;


/************Verify******************/

/* CsmSignatureVerify */


typedef Crypto_AlgorithmFamilyType CsmSignatureVerifyAlgorithmFamilyType;

typedef Crypto_AlgorithmModeType CsmSignatureVerifyAlgorithmModeType;

typedef CsmSignatureGenerateAlgorithmSecondaryFamily CsmSignatureVerifyAlgorithmSecondaryFamilyType;



/*******Job DataTypes***********/

typedef Crypto_ProcessingType CsmProcessingModeType;
typedef void (*CsmCallback)(Crypto_JobType *job, Crypto_ResultType result);

typedef enum {
	CRYPTO_USE_FNC, //Port is not used.
	CRYPTO_USE_PORT, //Port is used.
	CRYPTO_USE_PORT_OPTIMIZED, //DATA_REFERENCE is used.

}CsmJobInterfaceUsePortType;

typedef struct {
	uint32 CsmJobId;
	CsmJobInterfaceUsePortType CsmJobInterfaceUsePort;
	uint32 CsmJobPriority;
	CsmJobInterfaceUsePortType CsmJobServiceInterfaceContextUsePort;
	CsmProcessingModeType CsmProcessingMode;
	CsmInOutRedirection CsmInOutRedirectionRef;
	CsmKey *CsmJobKeyRef;
	CsmCallback *CsmJobPrimitiveCallbackRef;
	CsmPrimitives *CsmJobPrimitiveRef;
	CsmQueue *CsmJobQueueRef;

}CsmJob;


typedef struct {
	Crypto_JobInfoType jobInfo[4];
	uint8 currenjobs;
	uint8 capacity;
	uint8 front, rear;
} Crypto_QueueType;



/*******************************************************************************
 *                      Function Prototypes                                    *
 *******************************************************************************/

void Csm_Init(const Csm_ConfigType* configPtr);
void Csm_GetVersionInfo(Std_VersionInfoType* versioninfo);
Std_ReturnType Csm_Encrypt (uint32 jobId, Crypto_OperationModeType mode, const uint8* dataPtr, uint32 dataLength, uint8* resultPtr, uint32* resultLengthPtr);
Std_ReturnType Csm_Decrypt (uint32 jobId, Crypto_OperationModeType mode, const uint8* dataPtr, uint32 dataLength, uint8* resultPtr, uint32* resultLengthPtr);
Std_ReturnType Csm_SignatureGenerate (uint32 jobId, Crypto_OperationModeType mode, const uint8* dataPtr, uint32 dataLength, uint8* signaturePtr, uint32* signatureLengthPtr);
Std_ReturnType Csm_SignatureVerify (uint32 jobId, Crypto_OperationModeType mode, const uint8* dataPtr, uint32 dataLength, const uint8* signaturePtr, uint32 signatureLength, Crypto_VerifyResultType* verifyPtr);
Std_ReturnType Csm_Hash(uint32 jobId, Crypto_OperationModeType mode, const uint8* dataPtr, uint32 dataLength, uint8* resultPtr, uint32* resultLengthPtr);
















