/*
 * UL_Callbacks.h
 *
 *  Created on: 3 Dec 2023
 *      Author: Omen
 */

#ifndef UL_CALLBACKS_H_
#define UL_CALLBACKS_H_

extern void Tcpip_RxIndication (uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast,const uint8* PhysAddrPtr, const Eth_DataType* DataPtr, uint16 LenByte);
extern void ChargeM_RxIndication (uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast,const uint8* PhysAddrPtr, const Eth_DataType* DataPtr, uint16 LenByte);
extern void Tcpip_TxConfirmation (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result);
extern void ChargeM_TxConfirmation (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result);

#endif /* UL_CALLBACKS_H_ */
