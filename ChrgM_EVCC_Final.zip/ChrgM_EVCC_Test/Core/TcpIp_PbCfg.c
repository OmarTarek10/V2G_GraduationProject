#include "TcpIp.h"

#define CLIENT

TcpIp_SocketType socket_list[TcpIpTcpSocketMax] = {0};
TcpIp_LocalAddr TcpIpLocalAddr_list[2] = { 0};

//Tcp ip buffer (should probably be protected by mutex by os as it says acquire buffer in seq diagram).
TcpIp_Buffer TcpIpBuffer[TcpIpTcpSocketMax];

TcpIp_ConfigType TcpIpTcpConfig = {};

#ifdef SERVER
IPv6AddrType TcpIp_LocalAddrTable[MAX_NUMBER_ADDRESSES] = {
        {
                IPV6_ADDR(0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000),
                0,
                TCPIP_IPADDR_STATE_UNASSIGNED,
                -1
        }
};
#else
IPv6AddrType TcpIp_LocalAddrTable[MAX_NUMBER_ADDRESSES] = {
        {
                IPV6_ADDR(0x1000, 0x0000, 0x2000, 0x0000, 0x3000, 0x0000, 0x4000, 0x0000),
                0,
                TCPIP_IPADDR_STATE_UNASSIGNED,
                -1
        }
};
#endif
