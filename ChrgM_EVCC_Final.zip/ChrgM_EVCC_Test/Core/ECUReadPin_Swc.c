/*
 * ECUReadPin_Swc.c
 *
 * Created on: Feb 24, 2024
 * Author:  Mohannad Sabry,Mahmoud Sharawy
 */
#include "Std_Types.h"
#include "Rte_ECUReadPin_Swc.h"
#include "stm32f4xx_hal.h"


/*
 -Runnable that Get the pin value and return it to Sensor Actuator Swc.
*/

void GetPinStatus(uint8* PinStatus)
{
    *PinStatus= HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_9);
}

