/******************************************************************************
*
* Module: Ethernet Interface
*
* File Name: EthIf_PbCfg.h
*
* Description: Header File For the Ethernet Interface Post Build Configurations Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/

#ifndef ETHIF_PBCFG_H_
#define ETHIF_PBCFG_H_

#include "Std_Types.h"
#include "Eth_GeneralTypes.h"
/*
* EthIfController
*  Macro Configurations
*/
#define ETH_IF_CONTROLLER_SIZE				(1U)
#define ETH_IF_CTRL_IDX_1        			(0U) // For TCP for EXAMPLE
// #define ETH_IF_CTRL_IDX_2        			(1U) // For EthSm for EXAMPLE

#define	ETH_IF_PHYS_CONTROLLER_IDX_1		(0U)

/*
#define ETH_IF_OWNER_SIZE					(2U)
#define ETH_IF_OWNER_IDX_1					(0U) // State Manager for example
#define ETH_IF_OWNER_IDX_2					(1U) // TCP for example

//#define ETH_IF_RX_CALLBACK_IND_SIZE			(1U)
//#define ETH_IF_RX_CALLBACK_IND_IDX_1		(0U)

//#define ETH_IF_LINK_STATE_IND_SIZE			(1U)
//#define ETH_IF_LINK_STATE_IND_IDX_1			(0U)

//#define ETH_IF_TX_CALL_BACK_IND_SIZE		(1U)
//#define ETH_IF_TX_CALL_BACK_IND_IDX_1		(0U)
*/


/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef enum
{
	HW_MACSEC,NO_MACSEC,SW_MACSEC
}EthIfMacSecSupport_Type;

typedef void  (*EthIf_RxIndication_Ptr) (uint8 CtrlIdx,Eth_FrameType FrameType,boolean IsBroadcast,const uint8* PhysAddrPtr,const Eth_DataType* DataPtr,uint16 LenByte);

typedef void  (*EthIf_TxConfirmation_Ptr) (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result);

typedef void(*PTR_2_FUNC)(void);


typedef struct {

	uint8 EthIfPhysControllerIdx;
        /*
	//Symbolic name reference to WEthCtrlConfig EthIfWEthCtrlRef
	//?????????????????
	
        //WEth_CtrlConfigType_s EthIfWEthCtrlRef; //WEthCtrlConfig_Type EthIfWEthCtrlRef;
	
        //?????????????????????????????????
*/
	
}EthIfPhysController_s;

typedef struct {
	uint8 EthIfCtrlIdx;
	uint16 EthIfCtrlMtu;
	EthIfMacSecSupport_Type EthIfMacSecSupport;
	uint32 EthIfMaxTxBufsTotal;
	boolean Is_PhysController;
	EthIfPhysController_s EthIfPhysControllerRef;//Symbolic name reference to EthIfPhysController ?? EthIfPhysControllerRef;
}EthIfController_s;

typedef struct {
	uint16 EthIfFrameType;
	uint8 EthIfOwner;
}EthIfFrameOwnerConfig_s;

typedef struct {
	EthIf_RxIndication_Ptr EthIfRxIndicationFunction;
}EthIfRxIndicationConfig_s;

typedef struct {
	EthIf_TxConfirmation_Ptr	EthIfTxConfirmationFunction;
}EthIfTxConfirmationConfig_s;


typedef struct {
	EthIfController_s ControllerConfigStructs[ETH_IF_CONTROLLER_SIZE];
	EthIfFrameOwnerConfig_s OwnerConfigStructs [ETH_IF_CONTROLLER_SIZE];
	EthIfRxIndicationConfig_s RxInd_Func_Structs [ETH_IF_CONTROLLER_SIZE];
	EthIfTxConfirmationConfig_s TxInd_Func_Structs [ETH_IF_CONTROLLER_SIZE];
}EthIf_ConfigType;

/*******************************************************************************
 *                      External Variables                                    *
 *******************************************************************************/
extern EthIf_ConfigType EthIfConfigurationSet;

#endif /* ETHIF_PBCFG_H_ */
