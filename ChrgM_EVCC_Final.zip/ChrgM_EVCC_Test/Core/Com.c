/******************************************************************************
 *
 * Module: Com
 *
 * File Name: Com.c
 *
 * Description: Stub for PduR
 *
 * Author: Kareem Azab
 ******************************************************************************/



#include "Com.h"




Std_ReturnType Com_TriggerTransmit (PduIdType TxPduId,PduInfoType* PduInfoPtr)
{
	return E_OK;
}

void Com_RxIndication (PduIdType RxPduId,const PduInfoType* PduInfoPtr)
{
	//stub
}


void Com_TxConfirmation (PduIdType TxPduId,Std_ReturnType result)
{
	//stub
}
