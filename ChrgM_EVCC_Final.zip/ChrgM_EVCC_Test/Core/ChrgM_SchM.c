/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_SchM.c
 *
 * Description: Source file for Scheduler ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM.h"

extern uint8 MessageBuffer[BUFFER_SIZE];
extern struct iso1EXIDocument V2G_EXI_Document;
extern ChrgM_ModuleStateType ChrgM_ModuleState;
extern ChrgM_ErrorStatusType ChrgM_TxErrorStatus;
extern ChrgM_ErrorStatusType ChrgM_RxErrorStatus;
extern ChrgM_ModuleStateType ChrgM_TxErrorState;
extern ChrgM_ModuleStateType ChrgM_RxErrorState;
extern EthTrcv_LinkStateType ChrgM_TransceiverLinkState;
extern boolean ChrgM_ProcessStarted;
extern boolean ChrgM_CommunicationSetupTimerElapsed;
extern uint8 ChrgM_CpLine;
extern boolean ChrgM_IpAddressIndicationReceived;
extern TcpIp_IpAddrStateType ChrgM_IpAddressState;
extern boolean ChrgM_OpenUDPSocketRequested;
extern boolean ChrgM_SocketIndicationReceived;
extern SoAd_SoConModeType ChrgM_UDPSoConMode;
extern boolean ChrgM_ValidSECCReceived;
extern boolean ChrgM_SECCTimerElapsed;
extern uint8 ChrgM_SECCCounter;
extern boolean ChrgM_PdurRequestSuccessful;
extern boolean ChrgM_DataWritten;
extern boolean ChrgM_DataEncoded;
extern boolean ChrgM_DataEncrypted;
extern boolean ChrgM_TxConfirmationReceived;
extern boolean ChrgM_TransmissionSuccessful;
extern boolean ChrgM_OpenTCPSocketRequested;
extern SoAd_SoConModeType ChrgM_TCPSoConMode;
extern ChrgM_MessageStateType ChrgM_RequestedMessage;
extern SECCDiscoveryProtocolReqType SECCDiscoveryProtocolReq_Message;
extern SupportedAppProtocolReqType SupportedAppProtocolReq_Message;
extern boolean ChrgM_MessageTimerElapsed;
extern boolean ChrgM_OngoingTimerStarted;
extern boolean ChrgM_OngoingTimerElapsed;
extern SoAd_SoConIdType ChrgM_SocketConID;
extern PduInfoType ChrgM_PduInfo;
extern PduIdType ChrgM_PduID;
extern boolean ChrgM_MessageRequested;
extern boolean ChrgM_MessageReceived;
extern boolean ChrgM_ReceptionDone;
extern boolean ChrgM_ReceptionSuccessful;
extern PayloadLengthType Sent_Payload;

/************************************************************************************
 * Service Name: ChrgM_MainFunction_Tx
 * Service ID[hex]: 0x23
 * Sync/Async:
 * Reentrancy:
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the processing of the AUTOSAR ChrgM module’s transmit processing
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_MainFunction_Tx (void)
{
	if(ChrgM_ModuleState != NOT_INITIALIZED)
	{
		if(ChrgM_TxErrorStatus == NO_ERROR_STATUS)
		{
			switch(ChrgM_ModuleState)
			{
			case NOT_INITIALIZED:
				/* Not Possible, Remove warning */
				break;
			case INIT:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_ProcessStarted == TRUE)
				{
					if(SoAd_RequestIpAddrAssignment() == E_OK)
					{
						ChrgM_ModuleState = ASSIGNING_IP_ADDRESS;
						/* Call Function Manually since IP is static to proceed with states */
						ChrgM_V2GTpLocalIpAddrAssignmentChg (0, TCPIP_IPADDR_STATE_ASSIGNED);
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					/* Do Nothing */
				}
				break;

			case ASSIGNING_IP_ADDRESS:
				if(ChrgM_CommunicationSetupTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE && ChrgM_ProcessStarted == TRUE)
				{
					if(ChrgM_IpAddressIndicationReceived == TRUE)
					{
						if(ChrgM_IpAddressState == TCPIP_IPADDR_STATE_ASSIGNED)
						{
#if(CHRGM_SDP_USED == STD_ON)
							if(ChrgM_OpenUDPSocketRequested == FALSE)
							{
								SoAd_OpenSoCon(ChrgM_SocketConID); /* UDP Socket */
								ChrgM_OpenUDPSocketRequested = TRUE;
							}
							else
							{
								if(ChrgM_SocketIndicationReceived == TRUE)
								{
									if(ChrgM_UDPSoConMode == SOAD_SOCON_ONLINE)
									{
										ChrgM_ModuleState = DISCOVERING_SECC;
										ChrgM_OpenUDPSocketRequested = FALSE;
										ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
										ChrgM_UDPSoConMode = SOAD_SOCON_OFFLINE;
										ChrgM_ProcessStarted = FALSE;
										ChrgM_IpAddressIndicationReceived = FALSE;
										ChrgM_SocketIndicationReceived = FALSE;
									}
									else
									{
										ChrgM_ErrorIndication(CHRGM_SocketOffline);
										ChrgM_TxErrorStatus = SET_BY_TX;
										ChrgM_RxErrorStatus= SET_BY_TX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
									}
								}
								else
								{
									/* Do Nothing */
								}
							}
#else
							ChrgM_ModuleState = DISCOVERING_SECC;
							ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
							ChrgM_IpAddressIndicationReceived = FALSE;
#endif
						}
						else
						{
							ChrgM_ErrorIndication(CHRGM_IPAddressUnassigned);
							ChrgM_TxErrorStatus = SET_BY_TX;
							ChrgM_RxErrorStatus = SET_BY_TX;
							ChrgM_TxErrorState = ChrgM_ModuleState;
							ChrgM_RxErrorState = ChrgM_ModuleState;
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_CommunicationSetupTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_EVCC_CommunicationSetupTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}

				break;

			case DISCOVERING_SECC:
#if(CHRGM_SDP_USED == STD_ON)
				if(ChrgM_CommunicationSetupTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_ValidSECCReceived == FALSE)
					{
						if(ChrgM_SECCTimerElapsed == TRUE && ChrgM_SECCCounter < 50)
						{
							if(ChrgM_PdurRequestSuccessful == FALSE)
							{
								if(ChrgM_DataWritten == FALSE)
								{
									ChrgM_SECCDiscoveryProtocolReq(&SECCDiscoveryProtocolReq_Message);
									ChrgM_DataWritten = TRUE;
								}
								else
								{
									/* Do Nothing */
								}

								if(ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
								{
									if(ChrgM_EXIEncode() == E_OK)
									{
										ChrgM_DataEncoded = TRUE;
										ChrgM_WriteV2GTPHeader();
									}
									else
									{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
										ChrgM_TxErrorStatus = SET_BY_TX;
										ChrgM_RxErrorStatus = SET_BY_TX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
										/* Do Nothing */
									}
								}
								else
								{
									/* Do Nothing */
								}

								if(ChrgM_PdurRequestSuccessful == FALSE && ChrgM_DataEncoded == TRUE)
								{
									if(PduR_ChrgMTransmit(ChrgM_PduID, &ChrgM_PduInfo) == E_OK)
									{
										ChrgM_PdurRequestSuccessful = TRUE;
									}
									else
									{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
										ChrgM_TxErrorStatus = SET_BY_TX;
										ChrgM_RxErrorStatus = SET_BY_TX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
										/* Do Nothing */
									}
								}
								else
								{
									/* Do Nothing */
								}
							}
							else
							{
								if(ChrgM_TxConfirmationReceived == TRUE)
								{
									if(ChrgM_TransmissionSuccessful == TRUE/* && ChrgM_MessageTimerStarted == FALSE*/)
									{
										/* Reset SDP Timer*/
										/* Start SDP Timer */
										ChrgM_SECCCounter++;
										ChrgM_SECCTimerElapsed = FALSE;
										ChrgM_TransmissionSuccessful = FALSE;
										ChrgM_TxConfirmationReceived = FALSE;
										//ChrgM_MessageTimerStarted = TRUE;
									}
									else
									{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
										ChrgM_TxErrorStatus = SET_BY_TX;
										ChrgM_RxErrorStatus = SET_BY_TX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
#else
										ChrgM_PdurRequestSuccessful = FALSE;
#endif
									}
								}
								else
								{
									/* Do Nothing */
								}
							}
						}
						else if(ChrgM_SECCCounter >= 50)
						{
							ChrgM_ErrorIndication(CHRGM_InvalidSECC);
							ChrgM_TxErrorStatus = SET_BY_TX;
							ChrgM_RxErrorStatus = SET_BY_TX;
							ChrgM_TxErrorState = ChrgM_ModuleState;
							ChrgM_RxErrorState = ChrgM_ModuleState;
						}
						else
						{
							/* Do Nothing */
						}
					}
					else
					{
						ChrgM_ModuleState = ESTABLISHING_TCP_TLS;
						ChrgM_SECCCounter = 0;
						ChrgM_SECCTimerElapsed = TRUE;
						ChrgM_ValidSECCReceived = FALSE;
					}
				}
				else
				{
					if(ChrgM_CommunicationSetupTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_EVCC_CommunicationSetupTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
#else /* CHRGM SDP USED */
				ChrgM_ModuleState = ESTABLISHING_TCP_TLS;
				ChrgM_SECCCounter = 0;
				ChrgM_SECCTimerElapsed = TRUE;
				ChrgM_ValidSECCReceived = FALSE;
#endif /* CHRGM SDP USED */
				break;

			case ESTABLISHING_TCP_TLS:
				if(ChrgM_CommunicationSetupTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_OpenTCPSocketRequested == FALSE)
					{
						SoAd_OpenSoCon(ChrgM_SocketConID); /* TCP Socket*/
						ChrgM_OpenTCPSocketRequested = TRUE;
					}
					else
					{
						if(ChrgM_SocketIndicationReceived == TRUE)
						{
							if(ChrgM_TCPSoConMode == SOAD_SOCON_ONLINE)
							{
#if(CHRGM_SDP_USED == STD_ON)
								SoAd_CloseSoCon(ChrgM_SocketConID, TRUE); /* UDP Socket */
								ChrgM_OpenTCPSocketRequested = FALSE;
								ChrgM_TCPSoConMode = SOAD_SOCON_OFFLINE;
#endif
								ChrgM_ModuleState = ESTABLISHING_V2G_SESSION;
								ChrgM_RequestedMessage = SUPPORTED_APP_PROTOCOL;
							}
							else
							{
								ChrgM_ErrorIndication(CHRGM_SocketOffline);
								ChrgM_TxErrorStatus = SET_BY_TX;
								ChrgM_RxErrorStatus = SET_BY_TX;
								ChrgM_TxErrorState = ChrgM_ModuleState;
								ChrgM_RxErrorState = ChrgM_ModuleState;
							}
						}
						else
						{
							/* Do Nothing */
						}
					}
				}
				else
				{
					if(ChrgM_CommunicationSetupTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_EVCC_CommunicationSetupTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}

				break;

			case ESTABLISHING_V2G_SESSION:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_ReceptionDone == TRUE)
					{
						if(ChrgM_MessageRequested == FALSE)
						{
							if(ChrgM_DataWritten == FALSE)
							{
								switch(ChrgM_RequestedMessage)
								{
								case NO_MESSAGE:
									/* Do Nothing */
									break;
								case SUPPORTED_APP_PROTOCOL:
									ChrgM_SupportedAppProtocolReq(&SupportedAppProtocolReq_Message);
									ChrgM_DataWritten = TRUE;
									break;
								case SESSION_SETUP:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								default:
									/* Do Nothing, Det Error */
									break;
								}
							}
							else
							{
								/* Do Nothing */
							}
							if(ChrgM_RequestedMessage == SUPPORTED_APP_PROTOCOL && ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
							{
								ChrgM_DataEncoded = TRUE;
								ChrgM_WriteV2GTPHeader();
							}
							else
							{
								if(ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
								{
									if(ChrgM_EXIEncode(MessageBuffer + V2G_HEADER_SIZE, &Sent_Payload) == E_OK)
									{
										ChrgM_DataEncoded = TRUE;
										ChrgM_WriteV2GTPHeader();
									}
									else
									{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
										ChrgM_TxErrorStatus = SET_BY_TX;
										ChrgM_RxErrorStatus = SET_BY_TX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
										/* Do Nothing */
									}
								}
								else
								{
									/* Do Nothing */
								}
							}

							if(ChrgM_DataEncoded == TRUE && ChrgM_DataEncrypted == FALSE)
							{
								if(/*Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Sent_Payload) == E_OK*/1) /* Encrypt Data */
								{
									//ChrgM_PduInfo.SduLength = 50;
									ChrgM_DataEncrypted = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}

							if(ChrgM_PdurRequestSuccessful == FALSE && ChrgM_DataEncrypted == TRUE)
							{
								if(PduR_ChrgMTransmit(ChrgM_PduID, &ChrgM_PduInfo) == E_OK)
								{
									ChrgM_PdurRequestSuccessful = TRUE;
									ChrgM_MessageRequested = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							if(ChrgM_TxConfirmationReceived == TRUE)
							{
								if(ChrgM_TransmissionSuccessful == TRUE/* && ChrgM_MessageTimerStarted == FALSE*/)
								{
									if(ChrgM_RequestedMessage == SUPPORTED_APP_PROTOCOL)
									{
										/* Start Communication Setup Timer */
									}
									else
									{
										/* Do Nothing */
									}
									/* Start Message Timer */
									//ChrgM_MessageTimerStarted = TRUE;
									ChrgM_TransmissionSuccessful = FALSE;
									ChrgM_TxConfirmationReceived = FALSE;
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_DataWritten = FALSE;
									ChrgM_DataEncoded = FALSE;
									ChrgM_DataEncrypted = FALSE;
									ChrgM_ReceptionDone = FALSE;
									ChrgM_MessageRequested = FALSE;
									/* Reset Buffer Data */
									memset(MessageBuffer, 0, BUFFER_SIZE);
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#else
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_MessageRequested = FALSE;
#endif
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;

			case V2G_SESSION_ONGOING:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_ReceptionDone == TRUE)
					{
						if(ChrgM_MessageRequested == FALSE)
						{
							if(ChrgM_DataWritten == FALSE)
							{
								switch(ChrgM_RequestedMessage)
								{
								case NO_MESSAGE:
									/* Do Nothing */
									break;
								case SERVICE_DISCOVERY:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case PAYMENT_SELECTION:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case PAYMENT_DETAILS:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case AUTHORIZATION:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case CHARGE_PARAMETER_DISCOVERY:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case CABLE_CHECK:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case PRE_CHARGE:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case POWER_DELIVERY:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case CURRENT_DEMAND:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case WELDING_DETECTION:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								case SESSION_STOP:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								default:
									/* Do Nothing, Det Error */
									break;
								}
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
							{
								if(ChrgM_EXIEncode(MessageBuffer + V2G_HEADER_SIZE, &Sent_Payload) == E_OK)
								{
									ChrgM_DataEncoded = TRUE;
									ChrgM_WriteV2GTPHeader();
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_DataEncoded == TRUE && ChrgM_DataEncrypted == FALSE)
							{
								if(/*Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Sent_Payload) == E_OK*/1) /* Encrypt Data */
								{
									//ChrgM_PduInfo.SduLength = 50;
									ChrgM_DataEncrypted = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}

							if(ChrgM_PdurRequestSuccessful == FALSE && ChrgM_DataEncrypted == TRUE)
							{
								if(PduR_ChrgMTransmit(ChrgM_PduID, &ChrgM_PduInfo) == E_OK)
								{
									ChrgM_PdurRequestSuccessful = TRUE;
									ChrgM_MessageRequested = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							if(ChrgM_TxConfirmationReceived == TRUE)
							{
								if(ChrgM_TransmissionSuccessful == TRUE/* && ChrgM_MessageTimerStarted == FALSE*/)
								{
									/* Start Message Timer */
									//ChrgM_MessageTimerStarted = TRUE;
									ChrgM_TransmissionSuccessful = FALSE;
									ChrgM_TxConfirmationReceived = FALSE;
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_DataWritten = FALSE;
									ChrgM_DataEncoded = FALSE;
									ChrgM_DataEncrypted = FALSE;
									ChrgM_ReceptionDone = FALSE;
									ChrgM_MessageRequested = FALSE;
									/* Reset Buffer Data */
									memset(MessageBuffer, 0, BUFFER_SIZE);
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#else
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_MessageRequested = FALSE;
#endif
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}

				break;

			case V2G_SESSION_PAUSED:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_ReceptionDone == TRUE)
					{
						if(ChrgM_MessageRequested == FALSE)
						{
							if(ChrgM_DataWritten == FALSE)
							{
								switch(ChrgM_RequestedMessage)
								{
								case SESSION_STOP:
									/* Data already written */
									ChrgM_DataWritten = TRUE;
									break;
								default:
									/* Do Nothing, Det Error */
									break;
								}
							}
							else
							{
								/* Do Nothing */
							}
							if(ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
							{
								if(ChrgM_EXIEncode(MessageBuffer + V2G_HEADER_SIZE, &Sent_Payload) == E_OK)
								{
									ChrgM_DataEncoded = TRUE;
									ChrgM_WriteV2GTPHeader();
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_DataEncoded == TRUE && ChrgM_DataEncrypted == FALSE)
							{
								if(/*Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Sent_Payload) == E_OK*/1) /* Encrypt Data */
								{
									//ChrgM_PduInfo.SduLength = 50;
									ChrgM_DataEncrypted = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}

							if(ChrgM_PdurRequestSuccessful == FALSE && ChrgM_DataEncrypted == TRUE)
							{
								if(PduR_ChrgMTransmit(ChrgM_PduID, &ChrgM_PduInfo) == E_OK)
								{
									ChrgM_PdurRequestSuccessful = TRUE;
									ChrgM_MessageRequested = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							if(ChrgM_TxConfirmationReceived == TRUE)
							{
								if(ChrgM_TransmissionSuccessful == TRUE/* && ChrgM_MessageTimerStarted == FALSE*/)
								{
									/* Start Message Timer */
									//ChrgM_MessageTimerStarted = TRUE;
									ChrgM_TransmissionSuccessful = FALSE;
									ChrgM_TxConfirmationReceived = FALSE;
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_DataWritten = FALSE;
									ChrgM_DataEncoded = FALSE;
									ChrgM_DataEncrypted = FALSE;
									ChrgM_ReceptionDone = FALSE;
									ChrgM_MessageRequested = FALSE;
									/* Reset Buffer Data */
									memset(MessageBuffer, 0, BUFFER_SIZE);
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#else
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_MessageRequested = FALSE;
#endif
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;
			}
		}
		else
		{
			/* Do Nothing */
		}

		if(ChrgM_TxErrorStatus == SET_BY_TX || ChrgM_TxErrorStatus == SET_BY_RX)
		{
			switch(ChrgM_TxErrorState)
			{
			case INIT:
				/* Do Nothing */
				break;

			case ASSIGNING_IP_ADDRESS:
				ChrgM_TxErrorState = INIT;
				ChrgM_ModuleState = INIT;
				ChrgM_OpenUDPSocketRequested = FALSE;
				ChrgM_IpAddressIndicationReceived = FALSE;
				ChrgM_SocketIndicationReceived = FALSE;
				ChrgM_UDPSoConMode = SOAD_SOCON_OFFLINE;
				ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
				/* Reset Communication Setup Timer */
				ChrgM_CommunicationSetupTimerElapsed = FALSE;
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				break;

			case DISCOVERING_SECC:
				ChrgM_TxErrorState = INIT;
				if(ChrgM_TxErrorStatus == SET_BY_TX)
				{
					ChrgM_SECCCounter = 0;
					ChrgM_ModuleState = INIT;
					ChrgM_ProcessStarted = FALSE;
					ChrgM_ValidSECCReceived = FALSE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					/* Reset Communication Setup Timer */
					ChrgM_CommunicationSetupTimerElapsed = FALSE;
					/* Reset SDP Timer */
					ChrgM_SECCTimerElapsed = TRUE;
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE); /* UDP Socket */
					SoAd_ReleaseIpAddrAssignment();
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				break;

			case ESTABLISHING_TCP_TLS:
				ChrgM_TxErrorState = INIT;
				ChrgM_ModuleState = INIT;
				ChrgM_OpenTCPSocketRequested = FALSE;
				ChrgM_TCPSoConMode = SOAD_SOCON_OFFLINE;
				/* Reset Communication Setup Timer */
				ChrgM_CommunicationSetupTimerElapsed = FALSE;
				SoAd_CloseSoCon(ChrgM_SocketConID, TRUE); /* TCP Socket */
				SoAd_ReleaseIpAddrAssignment();
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				/* Reset Buffer Data */
				memset(MessageBuffer, 0, BUFFER_SIZE);
				break;

			case ESTABLISHING_V2G_SESSION:
			case V2G_SESSION_ONGOING:
			case V2G_SESSION_PAUSED:
				ChrgM_TxErrorState = INIT;
				if(ChrgM_TxErrorStatus == SET_BY_TX)
				{
					ChrgM_ModuleState = INIT;
					ChrgM_RequestedMessage = NO_MESSAGE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataEncrypted = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_MessageRequested = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_ReceptionDone = TRUE;
					ChrgM_ReceptionSuccessful = FALSE;
					/* Reset Message Timer */
					ChrgM_MessageTimerElapsed = FALSE;
					//ChrgM_MessageTimerStarted = FALSE;
					/* Reset Ongoing Timer */
					ChrgM_OngoingTimerElapsed = FALSE;
					ChrgM_OngoingTimerStarted = FALSE;
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE); /* TCP Socket */
					SoAd_ReleaseIpAddrAssignment();
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				break;

			default:
				/* Do Nothing, Det Error */
				break;
			}
		}
		else
		{
			/* Do Nothing */
		}
	}
	else
	{
		/* Do Nothing */
	}
}
