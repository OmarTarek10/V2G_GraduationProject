/*
 * WEth_Deviation_Sheet.h
 *
 *  Created on: 24 Nov 2023
 *      Author: Omen
 */

#ifndef WETH_DEVIATION_SHEET_H_
#define WETH_DEVIATION_SHEET_H_
/************************************************************************************
* Service Name: WEth_Init
* Requirement: SWS_WEth_00034
*  The function shall for all configured Wireless Ethernet controllers in the current WEthConfigSet:
	• Disable all controller
	• Clear pending Wireless Ethernet interrupts
	• Configure all controller configuration parameters (e.g. interrupts, frame length,
	frame filter, ...)
	• Configure all transmit / receive resources (e.g. buffer initialization)
	• delete all pending transmit and receive requests

* Requirements:SWS_WEth_00039
* The function shall check the access to the Wirless Ethernet
	controller. If the check fails, the function shall raise the production error WETH_E_
	ACCESS.

* Requirements:SWS_WEth_10002
* The function WEth_Init shall initialize all on-chip hardware resources that
* are used by the Wireless Ethernet controller.


************************************************************************************/

/************************************************************************************
* Service Name: WEth_SetControllerMode
* Requirements:SWS_WEth_00168
* The function shall check the access to the Wireless Ethernet
controller. If the check fails, the function shall raise the production error WETH_E_
ACCESS and return E_NOT_OK.
*
************************************************************************************/

/************************************************************************************
* Service Name: WEth_ProvideTxBuffer
* Requirements: SWS_WEth_00137
* All locked transmit buffers shall be released if the controller is
disabled via WEth_SetControllerMode.
*
************************************************************************************/

/************************************************************************************
* Service Name: WEth_Transmit
* Requirements: SWS_WEth_00088
* The function shall build the Ethernet header with the given physical target address (MAC address) and trigger the transmission of a previously filled
	transmit buffer.c()

	After transmission, the driver needs to release the allocated buffer. It is up to the
	implementation when the actual buffer release shall occur, e.g. within the context of
	the WEth_TxConfirmation, the WEth_MainFunction, or during the next WEth_Provide
	TxBuffer.
*
************************************************************************************/

/************************************************************************************
* Service Name: WEth_Transmit and WEth_TxConfirmation
* Requirements: SWS_WEth_00101
* The function shall check all filled transmit buffers for successful
transmission. The function issues transmit confirmation for each transmitted frame
using the callback function WEthIf_TxConfirmation if requested by the previous call of
WEth_Transmit service.
*
************************************************************************************/

/************************************************************************************
* Service Name: WEth_Receive
* Requirements: SWS_WEth_10061
* The module must ensure that within the interrupt/polling context
of this function call, reception parameters of the wireless channel for the current buffer
could be retrieved by the function WEth_GetBufWRxParams.
*
************************************************************************************/
#endif /* WETH_DEVIATION_SHEET_H_ */
