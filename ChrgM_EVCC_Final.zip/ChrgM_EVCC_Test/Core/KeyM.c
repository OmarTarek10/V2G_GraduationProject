/******************************************************************************
 *
 * Module: KeyM
 *
 * File Name: KeyM.c
 *
 * Description:
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "KeyM.h"

#if (KEYM_DEV_ERROR_DETECT == STD_ON)

#include "Det.h"
/*
 * AUTOSAR Version checking between Det and KeyM Modules
 */

#if ((DET_AR_MAJOR_VERSION != KEYM_AR_RELEASE_MAJOR_VERSION)\
|| (DET_AR_MINOR_VERSION != KEYM_AR_RELEASE_MINOR_VERSION)\
|| (DET_AR_PATCH_VERSION != KEYM_AR_RELEASE_PATCH_VERSION))
 #error "The AR version of Det.h does not match the expected version"
#endif

#endif /* (KEYM_DEV_ERROR_DETECT == STD_ON) */

STATIC uint8 KeyM_Status = KEYM_NOT_INITIALIZED;

/************************************************************************************
* Service Name: KeyM_GetCertificate
* Service ID[hex]: 0x0B
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CertId - Holds the identifier of the certificate
* Parameters (inout): CertificateDataPtr - Provides a pointer to a certificate data structure. The buffer
					  located by the pointer in the structure shall be provided by the caller of this function
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: Certificate data available and provided
								 E_NOT_OK: Operation not accepted due to an internal error
								 KEYM_E_PARAMETER_MISMATCH: Certificate ID invalid
								 KEYM_E_KEY_CERT_SIZE_MISMATCH: Provided buffer for the certificate too small
								 KEYM_E_KEY_CERT_EMPTY: No certificate data available, the certificate slot is empty
								 KEYM_E_KEY_CERT_READ_FAIL: Certificate cannot be provided, access denied
* Description: This function provides the certificate data
************************************************************************************/
Std_ReturnType KeyM_GetCertificate (KeyM_CertificateIdType CertId, KeyM_CertDataType* CertificateDataPtr)
{
	return 0;
}

/************************************************************************************
* Service Name: KeyM_SetCertificate
* Service ID[hex]: 0x0A
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CertId - Holds the identifier of the certificate
                   CertificateDataPtr - Pointer to a structure that provides the certificate data
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: Certificate accepted.
								 E_NOT_OK: Certificate could not be set.
								 KEYM_E_PARAMETER_MISMATCH: Parameter do not match with expected value.
								 KEYM_E_KEY_CERT_SIZE_MISMATCH: Parameter size doesn’t match
* Description: This function provides the certificate data to the key management module to temporarily store the certificate
************************************************************************************/
Std_ReturnType KeyM_SetCertificate (KeyM_CertificateIdType CertId, const KeyM_CertDataType* CertificateDataPtr)
{
	return 0;
}

/************************************************************************************
* Service Name: KeyM_VerifyCertificate
* Service ID[hex]: 0x0D
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): CertId - Holds the identifier of the certificate
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: Certificate verification request accepted.
                                       Operation will be performed in the background and response is given through a callback.
								 E_NOT_OK: Operation not accepted due to an internal error.
								 KEYM_E_BUSY: Validation cannot be performed yet. KeyM is currently busy with other jobs.
								 KEYM_E_PARAMETER_MISMATCH: Certificate ID invalid.
								 KEYM_E_KEY_CERT_EMPTY: One of the certificate slots are empty.
								 KEYM_E_CERT_INVALID_CHAIN_OF_TRUST: An upper certificate is not valid.
* Description: This function verifies a certificate that was previously provided with KeyM_SetCertificate()
			   against already stored and provided certificates stored with other certificate IDs
************************************************************************************/
Std_ReturnType KeyM_VerifyCertificate (KeyM_CertificateIdType CertId)
{
	return 0;
}
