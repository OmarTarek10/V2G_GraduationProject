/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_PBCfg.h
 *
 * Description: Post Build Configuration Header file - ChrgM Driver
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef CHRGM_PBCFG_H_
#define CHRGM_PBCFG_H_

extern const ChrgM_ConfigType ChrgM_Configuration;

#endif /* CHRGM_PBCFG_H_ */
