/*
 * StateMachineSwc.c
 * Created on: Feb 25, 2024
 * Author: Mohannad Sabry,Mahmoud Sharawy
 */
#include "Std_Types.h"
#include "V2G_Data_Types.h"
#include "Rte_StateMachineSwc.h"
#include "iso1EXIDatatypes.h"
#include <string.h>

struct iso1EXIDocument V2G_Document;

/*--------------------------------------------Used Global Variables-----------------------------------------------------------------------*/
uint8 State=UnConnected;
uint8 Message=NO_MESSAGE;
uint8 Is_Message_Sent=FALSE;
uint8 Indication_Val=FALSE;
void *V2G_Recived_Document;
volatile uint8 ChrgMErrorHandler;
volatile uint8 test;
uint8 counter;
uint8 percentage_value;
uint8 Is_Init_Values_Called=FALSE;
uint8 Is_EXI_Document_Intialized=0;
uint8 Session_Id[iso1MessageHeaderType_SessionID_BYTES_SIZE]={0};
uint8 Charging_Done = FALSE;
uint8 Session_Stop_Counter = 0;
const uint8 TARGET_VOLTAGE = 80;
/*--------------------------------------------Error Handle Function--------------------------------------------------------------------- */
void ErrorHandle(void)
{
	State=Init;
	Message=SUPPORTED_APP_PROTOCOL_MESSAGE;
	Is_Message_Sent=FALSE;
	Indication_Val=FALSE;
	ChrgMErrorHandler=CHRGM_NoError;
}
/*--------------------------------------------Header Preparation--------------------------------------------------------------------------*/
void Prepare_Header(void){
	V2G_Document.V2G_Message.Header.Notification_isUsed=FALSE;
	V2G_Document.V2G_Message.Header.Signature_isUsed=FALSE;
	V2G_Document.V2G_Message.Header.SessionID.bytesLen=1;
	for(int i=0;i<V2G_Document.V2G_Message.Header.SessionID.bytesLen;i++)
	{
		V2G_Document.V2G_Message.Header.SessionID.bytes[i]=Session_Id[i];
	}
}

/*--------------------------------------------Handling Messages--------------------------------------------------------------------------*/
void SupportedAppProtocolHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(SUPPORTED_APP_PROTOCOL_MESSAGE,FALSE);
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if( Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/*Do nothing*/
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			State=Init;
			Message=SESSION_SETUP_MESSAGE;
			Is_Message_Sent=FALSE;
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/*Do nothing*/
		}
	}
	else
	{
		/* Do nothing */
	}
}
void SessionSetupHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of SessionSetupReq_Message */
		V2G_Document.V2G_Message.Body.SessionSetupReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();
		for(int i=0;i<V2G_Document.V2G_Message.Header.SessionID.bytesLen;i++){
			V2G_Document.V2G_Message.Header.SessionID.bytes[i]=0;
		}

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.SessionSetupReq.EVCCID.bytesLen=1;
		V2G_Document.V2G_Message.Body.SessionSetupReq.EVCCID.bytes[0]=0xEC;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(SESSION_SETUP_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Clear Usage of SessionSetupReq_Message */
			V2G_Document.V2G_Message.Body.SessionSetupReq_isUsed=NOT_USED;

			/* Update Message vairable to next message */
			Message=SERVICE_DISCOVERY_MESSAGE;

			/* Save Session ID provided by the SECC */
			for(int i=0;i<V2G_Document.V2G_Message.Header.SessionID.bytesLen;i++){
				Session_Id[i]=((struct iso1EXIDocument *)V2G_Recived_Document)->V2G_Message.Header.SessionID.bytes[i];
			}

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;

		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}
void ServiceDiscoveryHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of ServiceDiscoveryReq_Message */
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceCategory_isUsed=USED;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceCategory=iso1serviceCategoryType_EVCharging;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceScope_isUsed=USED;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceScope.charactersLen=5;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceScope.characters[0]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceScope.characters[1]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceScope.characters[2]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceScope.characters[3]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.ServiceDiscoveryReq.ServiceScope.characters[4]=0xDEADBEAF;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(SERVICE_DISCOVERY_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of ServiceDiscoveryReq_Message */
			V2G_Document.V2G_Message.Body.ServiceDiscoveryReq_isUsed=NOT_USED;

			/* Update Message vairable to next message */
			Message=PAYMENT_SELECTION_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}

void PaymentSelectionHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of PaymentServiceSelectionReq_Message */
		V2G_Document.V2G_Message.Body.PaymentServiceSelectionReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.PaymentServiceSelectionReq.SelectedPaymentOption=iso1paymentOptionType_ExternalPayment;
		V2G_Document.V2G_Message.Body.PaymentServiceSelectionReq.SelectedServiceList.SelectedService.arrayLen=1;
		V2G_Document.V2G_Message.Body.PaymentServiceSelectionReq.SelectedServiceList.SelectedService.array[0].ServiceID=0xAA;
		V2G_Document.V2G_Message.Body.PaymentServiceSelectionReq.SelectedServiceList.SelectedService.array[0].ParameterSetID_isUsed=TRUE;
		V2G_Document.V2G_Message.Body.PaymentServiceSelectionReq.SelectedServiceList.SelectedService.array[0].ParameterSetID=0xBB;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(PAYMENT_SELECTION_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of PaymentServiceSelectionReq_Message */
			V2G_Document.V2G_Message.Body.PaymentServiceSelectionReq_isUsed=NOT_USED;

			/* Update Message vairable to next message */
			Message=PAYMENT_DETAILS_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}

void PaymentDetailsHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of PaymentDetailReq_Message */
		V2G_Document.V2G_Message.Body.PaymentDetailsReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.PaymentDetailsReq.eMAID.charactersLen=5;
		V2G_Document.V2G_Message.Body.PaymentDetailsReq.eMAID.characters[0]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.PaymentDetailsReq.eMAID.characters[1]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.PaymentDetailsReq.eMAID.characters[2]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.PaymentDetailsReq.eMAID.characters[3]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.PaymentDetailsReq.eMAID.characters[4]=0xDEADBEAF;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(PAYMENT_DETAILS_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of PaymentDetailReq_Message */
			V2G_Document.V2G_Message.Body.PaymentDetailsReq_isUsed=NOT_USED;

			/* Update Message vairable to next message */
			Message=AUTHORIZATION_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}

void AuthorizationHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of Authorization_Message */
		V2G_Document.V2G_Message.Body.AuthorizationReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.AuthorizationReq.GenChallenge_isUsed=TRUE;
		V2G_Document.V2G_Message.Body.AuthorizationReq.GenChallenge.bytesLen=2;
		V2G_Document.V2G_Message.Body.AuthorizationReq.GenChallenge.bytes[0]=0xAB;
		V2G_Document.V2G_Message.Body.AuthorizationReq.GenChallenge.bytes[1]=0xCD;
		V2G_Document.V2G_Message.Body.AuthorizationReq.Id_isUsed=TRUE;
		V2G_Document.V2G_Message.Body.AuthorizationReq.Id.charactersLen=5;
		V2G_Document.V2G_Message.Body.AuthorizationReq.Id.characters[0]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.AuthorizationReq.Id.characters[1]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.AuthorizationReq.Id.characters[2]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.AuthorizationReq.Id.characters[3]=0xDEADBEAF;
		V2G_Document.V2G_Message.Body.AuthorizationReq.Id.characters[4]=0xDEADBEAF;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(AUTHORIZATION_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of AuthorizationReq_Message */
			V2G_Document.V2G_Message.Body.AuthorizationReq_isUsed=NOT_USED;

			/* Update Message vairable to next message */
			Message=CHARGE_PARAMETER_DISCOVERY_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}

void ChargeParameterHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of ChargeParameterMessage */
		V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq.MaxEntriesSAScheduleTuple_isUsed=TRUE;
		V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq.MaxEntriesSAScheduleTuple=0xDEAD;
		V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq.RequestedEnergyTransferMode=iso1EnergyTransferModeType_DC_core;
		V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq.EVChargeParameter_isUsed=USED;
		V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq.EVChargeParameter.DepartureTime_isUsed=USED;
		V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq.EVChargeParameter.DepartureTime=0xDEADBEAF;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(CHARGE_PARAMETER_DISCOVERY_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of ChargeParameterMessage */
			V2G_Document.V2G_Message.Body.ChargeParameterDiscoveryReq_isUsed=NOT_USED;

			/* Update State Variable to next state */
			State=CableCheck_State;

			/* Update Message Variable to next Message */
			Message=CABLE_CHECK_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}

void CableCheckHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of CableCheck_Message */
		V2G_Document.V2G_Message.Body.CableCheckReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.CableCheckReq.DC_EVStatus.EVErrorCode=iso1DC_EVErrorCodeType_NO_ERROR;
		V2G_Document.V2G_Message.Body.CableCheckReq.DC_EVStatus.EVRESSSOC=0xBB;
		V2G_Document.V2G_Message.Body.CableCheckReq.DC_EVStatus.EVReady=TRUE;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(CABLE_CHECK_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Enable Usage of CableCheck_Message */
			V2G_Document.V2G_Message.Body.CableCheckReq_isUsed=NOT_USED;

			/* Update State Variable to next State */
			State=PreCharge_State;

			/* Update Message Variable to Next Message */
			Message=PRE_CHARGE_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}
void PreChargeHandle(void)
{
	if(Is_Message_Sent==FALSE){
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of PreChargeMessage */
		V2G_Document.V2G_Message.Body.PreChargeReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.PreChargeReq.DC_EVStatus.EVErrorCode=iso1DC_EVErrorCodeType_NO_ERROR;
		V2G_Document.V2G_Message.Body.PreChargeReq.DC_EVStatus.EVRESSSOC=0xAA;
		V2G_Document.V2G_Message.Body.PreChargeReq.DC_EVStatus.EVReady=TRUE;
		V2G_Document.V2G_Message.Body.PreChargeReq.EVTargetCurrent.Unit=iso1unitSymbolType_m;
		V2G_Document.V2G_Message.Body.PreChargeReq.EVTargetCurrent.Multiplier=0xBA;
		V2G_Document.V2G_Message.Body.PreChargeReq.EVTargetCurrent.Value=0xDEAD;
		V2G_Document.V2G_Message.Body.PreChargeReq.EVTargetVoltage.Unit=iso1unitSymbolType_m;
		V2G_Document.V2G_Message.Body.PreChargeReq.EVTargetVoltage.Multiplier=0xAB;
		V2G_Document.V2G_Message.Body.PreChargeReq.EVTargetVoltage.Value=0xABCD;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(PRE_CHARGE_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of PreChargeMessage */
			V2G_Document.V2G_Message.Body.PreChargeReq_isUsed=NOT_USED;

			/* Update Message to next Message */
			Message=POWER_DELIVERY_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}

void PowerDeliveryOnHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of PowerDeliveryMessage */
		V2G_Document.V2G_Message.Body.PowerDeliveryReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.PowerDeliveryReq.ChargeProgress=iso1chargeProgressType_Start;
		V2G_Document.V2G_Message.Body.PowerDeliveryReq.SAScheduleTupleID=0xAA;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(POWER_DELIVERY_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of PowerDeliveryMessage */
			V2G_Document.V2G_Message.Body.PowerDeliveryReq_isUsed=NOT_USED;

			/* Update State Variable to next state */
			State=Charging;

			/*Update Message Variable to next Message*/
			Message=CURRENT_DEMAND_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}

void CurrentDemandHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of CurrentDemandMessage */
		V2G_Document.V2G_Message.Body.CurrentDemandReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.CurrentDemandReq.DC_EVStatus.EVReady=TRUE;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.DC_EVStatus.EVRESSSOC=0xAA;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.DC_EVStatus.EVErrorCode=iso1DC_EVErrorCodeType_NO_ERROR;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVTargetCurrent.Unit=iso1unitSymbolType_A;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVTargetCurrent.Multiplier=0xBA;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVTargetCurrent.Value=0xDEAD;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumVoltageLimit_isUsed=USED;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumVoltageLimit.Multiplier=0xFF;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumVoltageLimit.Unit=iso1unitSymbolType_V;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumVoltageLimit.Value=0xBB;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumCurrentLimit_isUsed=USED;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumCurrentLimit.Multiplier=0xDE;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumCurrentLimit.Unit=iso1unitSymbolType_A;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumCurrentLimit.Value=0xAD;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumPowerLimit_isUsed=USED;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumPowerLimit.Multiplier=0xBE;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumPowerLimit.Unit=iso1unitSymbolType_Wh;
		V2G_Document.V2G_Message.Body.CurrentDemandReq.EVMaximumPowerLimit.Value=0xAF;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(CURRENT_DEMAND_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{

            Rte_Call_StateMachineSwc_RP_CS_BatteryVal_BatteryValue(&percentage_value);
            if(percentage_value >= TARGET_VOLTAGE)
            {
                // Disable Usage of CurrentDemandMessage
        		V2G_Document.V2G_Message.Body.CurrentDemandReq_isUsed=NOT_USED;

        		//Update State Vriable to next State
        		State=PowerDown;

        		// Update Message Vriable to next Messagee
        		Message=POWER_DELIVERY_MESSAGE;

            }
            else
            {
            	/* Do Nothing */
            }

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;

		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}
void PowerDeliveryOffHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of PowerDeliveryMessage */
		V2G_Document.V2G_Message.Body.PowerDeliveryReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.PowerDeliveryReq.ChargeProgress=iso1chargeProgressType_Stop;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(POWER_DELIVERY_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of PowerDeliveryMessage */
			V2G_Document.V2G_Message.Body.PowerDeliveryReq_isUsed=NOT_USED;

			/* Update Message Variable to next Message */
			Message=WELDING_DETECTION_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}
void WeldingDetectionHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Enable Usage of WeldingDetectionMessage */
		V2G_Document.V2G_Message.Body.WeldingDetectionReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		V2G_Document.V2G_Message.Body.WeldingDetectionReq.DC_EVStatus.EVErrorCode=iso1DC_EVErrorCodeType_NO_ERROR;
		V2G_Document.V2G_Message.Body.WeldingDetectionReq.DC_EVStatus.EVRESSSOC=0xAC;
		V2G_Document.V2G_Message.Body.WeldingDetectionReq.DC_EVStatus.EVReady=TRUE;

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(WELDING_DETECTION_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of WeldingDetectionMessage */
			V2G_Document.V2G_Message.Body.WeldingDetectionReq_isUsed=NOT_USED;

			/* Update Message Variable to next Message */
			Message=SESSION_STOP_MESSAGE;

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			//ShowChrgMError(ChrgMErrorHandler);
			ErrorHandle();
		}
	}
	else
	{
		/*do nothing*/
	}
}
void SessionStopHandle(void)
{
	if(Is_Message_Sent==FALSE)
	{
		/* Clear Document */
		memset(&V2G_Document,0,sizeof(V2G_Document));

		/* Enable Usage of V2G_Message */
		V2G_Document.V2G_Message_isUsed=USED;

		/* Disable Usage of SessionStopMessage*/
		V2G_Document.V2G_Message.Body.SessionStopReq_isUsed=USED;

		/* Prepare Header */
		Prepare_Header();

		/* Prepare Data */
		if(Session_Stop_Counter == 0) /* Pause */
		{
			V2G_Document.V2G_Message.Body.SessionStopReq.ChargingSession=iso1chargingSessionType_Pause;
		}
		else /* Terminate */
		{
			V2G_Document.V2G_Message.Body.SessionStopReq.ChargingSession=iso1chargingSessionType_Terminate;
		}

		/* Send Document to Rte in order to send it to service swc */
		Rte_Call_StateMachineSwc_RP_CS_State_IntilizeV2gStateMachine(SESSION_STOP_MESSAGE,&V2G_Document);

		/* Set Is_Message_Sent Variable to True */
		Is_Message_Sent=TRUE;
	}
	else if(Is_Message_Sent==TRUE)
	{
		if(Indication_Val==FALSE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Do nothing */
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler==CHRGM_NoError)
		{
			/* Disable Usage of SessionStopMessage*/
			V2G_Document.V2G_Message.Body.SessionStopReq_isUsed=NOT_USED;

			if(Session_Stop_Counter == 0)
			{
				Session_Stop_Counter++; /* Trigger Terminate Message */
			}
			else
			{
				/* Update State variable to next state */
				State=UnConnected;

				/* Update Message variable to next Message */
				Message=NO_MESSAGE;

				Session_Stop_Counter = 0;
			}

			/* Clear Is_Message_Sent Variable */
			Is_Message_Sent=FALSE;

			/* Clear Indication_Val Variable */
			Indication_Val=FALSE;
		}
		else if(Indication_Val==TRUE && ChrgMErrorHandler!=CHRGM_NoError)
		{
			/* Handle Error */
			ErrorHandle();
		}
		else
		{
			/* Do nothing */
		}
	}
	else
	{
		/* Do nothing */
	}
}
/*-----------------------------------------------Handling States-------------------------------------------------------------------------*/
void HandleInitState(uint8 Message_Value)
{
	switch(Message_Value)
	{
	case SUPPORTED_APP_PROTOCOL_MESSAGE:
		SupportedAppProtocolHandle();
		break;
	case SESSION_SETUP_MESSAGE:
		SessionSetupHandle();
		break;
	case SERVICE_DISCOVERY_MESSAGE:
		ServiceDiscoveryHandle();
		break;
	case PAYMENT_SELECTION_MESSAGE:
		PaymentSelectionHandle();
		break;
	case PAYMENT_DETAILS_MESSAGE:
		PaymentDetailsHandle();
		break;
	case AUTHORIZATION_MESSAGE:
		AuthorizationHandle();
		break;
	case CHARGE_PARAMETER_DISCOVERY_MESSAGE:
		ChargeParameterHandle();
		break;
	}
}

void HandleCableCheckState(uint8 Message_Value)
{
	if(Message_Value == CABLE_CHECK_MESSAGE)
	{
		CableCheckHandle();
	}
	else
	{
		/* Do nothing */
	}
}

void HandlePreChargeState(uint8 Message_Value)
{
	switch(Message_Value)
	{
	case PRE_CHARGE_MESSAGE:
		PreChargeHandle();
		break;
	case POWER_DELIVERY_MESSAGE:
		PowerDeliveryOnHandle();
		break;
	}
}

void HandleChargingState(uint8 Message_Value)
{
	if(Message_Value == CURRENT_DEMAND_MESSAGE)
	{
		CurrentDemandHandle();
	}
	else{
		/* Do nothing */
	}

}

void HandlerPowerDownState(uint8 Message_Value)
{
	switch(Message_Value)
	{
	case POWER_DELIVERY_MESSAGE:
		PowerDeliveryOffHandle();
		break;
	case WELDING_DETECTION_MESSAGE:
		WeldingDetectionHandle();
		break;
	case SESSION_STOP_MESSAGE:
		SessionStopHandle();
		break;
	}
}

/*----------------------------------------------------Runnables--------------------------------------------------------------------------*/

/*
 * Runnable that used to control state machine of EV
 */
void UpdateStateMachine(void)
{
	uint8 Connection_Status;
	Rte_Read_StateMachineSwc_RP_SR_ConnectionStatus_ConnectionStatus(&Connection_Status);

	//Connection_Status = TRUE;

	if(Charging_Done == TRUE && Connection_Status == FALSE)
	{
		Charging_Done = FALSE;
	}
	else
	{
		/* Do Nothing */
	}

	if(Charging_Done == FALSE)
	{
		//send line Status to ChrgM (By sending connection_Status to service swc and from service swc to chrgM
		Rte_Call_StateMachineSwc_RP_CS_State_SendLineStatus(Connection_Status);

		if(Connection_Status==TRUE)
		{
			if(State==UnConnected)
			{
				State=Init;
				Message=SUPPORTED_APP_PROTOCOL_MESSAGE;
			}
			if(Is_EXI_Document_Intialized==FALSE)
			{
				memset(&V2G_Document,0,sizeof(V2G_Document));
				Is_EXI_Document_Intialized=TRUE;
			}
			switch(State)
			{
			case Init:
				HandleInitState(Message);
				break;
			case CableCheck_State:
				HandleCableCheckState(Message);
				break;
			case PreCharge_State:
				HandlePreChargeState(Message);
				break;
			case Charging:
				HandleChargingState(Message);
				break;
			case PowerDown:
				HandlerPowerDownState(Message);
				break;
			}
		}
		else
		{
			/*this statement because if someone put the cable so state=Init if he removed so the state will be returned into Unconnected*/
			State=UnConnected;
		}
	}
	else
	{
		/* Charging is finished, Remove Cable */
	}

}

/*
 * Runnable that used to recive data from service swc
 */
void RE_GetChargingResponse(uint8 Indication, void* V2G_EXI_Document, uint8 ChrgM_Error)
{
	Indication_Val=Indication;
	V2G_Recived_Document=V2G_EXI_Document;
	ChrgMErrorHandler=ChrgM_Error;
}
