/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_SchM.h
 *
 * Description: Header file for Scheduler ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef CHRGM_SCHM_H_
#define CHRGM_SCHM_H_

void ChrgM_MainFunction_Tx (void);

#endif /* CHRGM_SCHM_H_ */
