#ifndef SOAD_CFG_H_
#define SOAD_CFG_H_


#define SoAdDevErrorDetect				FALSE

#define SoAdIPv6AddressEnabled			FALSE

#define SoAdMainFunctionPeriod			1		/*Range [0 - INF]*/

#define SoAdSoConMax					1

#define SoAdRoutingGroupMax				1

#define SoAdPduHeaderEnable				FALSE

#define SoAdSocketAutomaticSoConSetup   FALSE

#define SoAdTxPduId						100


#endif
