/*
 * Charging_Station_Service_Swc.c
 *
 *  Created on: Mar 21, 2024
 *  Author: Mohannad Sabry
 */
#include "Std_Types.h"
#include "Rte_Charging_Station_Service_Swc.h"
#include "ChrgM.h"


/*****************************************************
 * Port:        PP_CS_ResponseData
 * Interface:   CsIf_ResponseData
 * Operation:   SendResponse
 *****************************************************/
void RE_SendResponse(void* V2G_Document, uint8 Message_Name){
	switch(Message_Name){
	case SUPPORTED_APP_PROTOCOL_MESSAGE:
		ChrgM_SupportedAppProtocolRes(V2G_Document);
		break;

	case SESSION_SETUP_MESSAGE:
		ChrgM_SessionSetupRes(V2G_Document);
		break;

	case SERVICE_DISCOVERY_MESSAGE:
		ChrgM_ServiceDiscoveryRes(V2G_Document);
		break;

	case PAYMENT_SELECTION_MESSAGE:
		ChrgM_PaymentServiceSelectionRes(V2G_Document);
		break;

	case PAYMENT_DETAILS_MESSAGE:
		ChrgM_PaymentDetailsRes(V2G_Document);
		break;

	case AUTHORIZATION_MESSAGE:
		ChrgM_AuthorizationRes(V2G_Document);
		break;

	case CHARGE_PARAMETER_DISCOVERY_MESSAGE:
		ChrgM_ChargeParameterDiscoveryRes(V2G_Document);
		break;

	case CABLE_CHECK_MESSAGE:
		ChrgM_CableCheckRes(V2G_Document);
		break;

	case PRE_CHARGE_MESSAGE:
		ChrgM_PreChargeRes(V2G_Document);
		break;

	case POWER_DELIVERY_MESSAGE:
		ChrgM_PowerDeliveryRes(V2G_Document);
		break;

	case CURRENT_DEMAND_MESSAGE:
		ChrgM_CurrentDemandRes(V2G_Document);
		break;

	case WELDING_DETECTION_MESSAGE:
		ChrgM_WeldingDetectionRes(V2G_Document);
		break;

	case SESSION_STOP_MESSAGE:
		ChrgM_SessionStopRes(V2G_Document);
		break;
	}
}

/*****************************************************
 * Port:        RP_CS_ResponseData
 * Interface:   CsIf_RequestData
 * Operation:   SendRequest
 *****************************************************/
void RE_SendRequest(uint8 Message_Indication, uint8 Error_Indication, void* V2G_Document, uint8 Message_Name){
	Rte_Call_Charging_Station_Service_Swc_RP_CS_RequestedData_Process_Request(Message_Indication,Error_Indication,V2G_Document,Message_Name);
}
