/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_SoAd.c
 *
 * Description: Source file for provided ChrgM Callback notifications
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include"ChrgM.h"

extern boolean ChrgM_IpAddressIndicationReceived;
extern TcpIp_IpAddrStateType ChrgM_IpAddressState;
extern boolean ChrgM_SocketIndicationReceived;
extern SoAd_SoConModeType ChrgM_TCPSoConMode;
extern uint8_t RX_Flag;

/************************************************************************************
 * Service Name: ChrgM_V2GTpLocalIpAddrAssignmentChg
 * Service ID[hex]: 0x18
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): IpAddrId - IP address Identifier, representing an IP address specified in the TcpIp module configuraiton
 	 	 	 	   State - state of IP address assignment
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: The SoAd calls this API to inform the ChrgM about the status of the IP address
 * Requirments:[CP_RS_ChrgM_00012],[SRS_BSW_00310],[CP_SWS_ChrgM_00018],[CP_SWS_ChrgM_00020]
 ************************************************************************************/
void ChrgM_V2GTpLocalIpAddrAssignmentChg (TcpIp_LocalAddrIdType IpAddrId, TcpIp_IpAddrStateType State)
{
	ChrgM_IpAddressIndicationReceived = TRUE;
	ChrgM_IpAddressState = State;
}


/************************************************************************************
 * Service Name: ChrgM_V2GTpSoConModeChg
 * Service ID[hex]: 0x21
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different SoConIds. Non reentrant for the same SoConId
 * Parameters (in): SoConId - socket connection index specifying the socket connection with the mode change
 	 	 	 	   Mode - new socket connection mode
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: The SoAd calls this API to inform the ChrgM about the status of the socket connection
 * Requirments:[CP_RS_ChrgM_00012],[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_V2GTpSoConModeChg (SoAd_SoConIdType SoConId, SoAd_SoConModeType Mode)
{
	ChrgM_SocketIndicationReceived = TRUE;
	ChrgM_TCPSoConMode = Mode;
	RX_Flag = 0;
}
