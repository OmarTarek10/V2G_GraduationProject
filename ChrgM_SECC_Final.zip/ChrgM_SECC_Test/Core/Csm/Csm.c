/*
 ============================================================================
 Name        : CSM.c
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Source file for CSM module
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "../Platform_Types.h"
#include "../Crypto_GeneralTypes.h"
#include "../CryIf/CryIf.h"
#include "../CryptoDriver/Crypto.h"
#include "Csm.h"
#include "Csm_Cfg.h"
#include "../Compiler.h"
#include "../Det.h"
#include "../Std_Types.h"

static Csm_StateType Csm_State = CSM_STATE_UNINIT;


#if(COMMUINCATIONPARTYDEFINER == 1)
	uint8 V2G_CommunicationPartyValue = 1;
#else
	uint8 V2G_CommunicationPartyValue = 0;
#endif


/*
 * Initialization of CSM queue
 *
 */

CsmQueue queue;

/*******************************************************************************
 *                    Initializing CSM Job Primitive Info                      *
 ******************************************************************************/

const Crypto_AlgorithmInfoType aes_algo_info =
{       CRYPTO_ALGOFAM_AES,
		CRYPTO_ALGOFAM_NOT_SET,
		KEY_LENGTH_USED_AES,
		CRYPTO_ALGOMODE_GCM
};

const Crypto_AlgorithmInfoType ecdsa_algo_info =
{       CRYPTO_ALGOFAM_ECDSA,
		CRYPTO_ALGOFAM_NOT_SET,
		KEY_LENGTH_USED_ECDSA,
		CRYPTO_ALGOMODE_NOT_SET
};

const Crypto_AlgorithmInfoType hash_algo_info =
{       CRYPTO_ALGOFAM_SHA2_256,
		CRYPTO_ALGOFAM_SHA1,
		KEY_LENGTH_USED_HASH,
		CRYPTO_ALGOMODE_NOT_SET
};

const Crypto_PrimitiveInfoType Encrypt_primitiveInfo ={64, aes_algo_info, CRYPTO_ENCRYPT};

const Crypto_PrimitiveInfoType Decrypt_primitiveInfo ={64,aes_algo_info, CRYPTO_DECRYPT};

const Crypto_PrimitiveInfoType Signature_Generate_primitiveInfo ={64,ecdsa_algo_info, CRYPTO_SIGNATUREGENERATE};

const Crypto_PrimitiveInfoType Signature_Verify_primitiveInfo ={64,ecdsa_algo_info, CRYPTO_SIGNATUREVERIFY};

const Crypto_PrimitiveInfoType Hash_primitiveInfo ={64,hash_algo_info, CRYPTO_HASH};



const Crypto_JobPrimitiveInfoType Encrypt_info=
{2, &Encrypt_primitiveInfo, CRYIF_KEY_ID2, CRYPTO_PROCESSING_SYNC};

const Crypto_JobPrimitiveInfoType Decrypt_info=
{3, &Decrypt_primitiveInfo, CRYIF_KEY_ID3, CRYPTO_PROCESSING_SYNC};

const Crypto_JobPrimitiveInfoType signature_info=
{4, &Signature_Generate_primitiveInfo, CRYIF_KEY_ID4, CRYPTO_PROCESSING_SYNC};

const Crypto_JobPrimitiveInfoType verify_info=
{5, &Signature_Verify_primitiveInfo, CRYIF_KEY_ID5, CRYPTO_PROCESSING_SYNC};

const Crypto_JobPrimitiveInfoType Hash_info=
{6, &Hash_primitiveInfo, CRYIF_KEY_ID6, CRYPTO_PROCESSING_SYNC};


/*******************************************************************************
 *                      Initializing CSM Jobs                                  *
 **************************************************A****************************/


Crypto_JobType Crypto_JobType_Encrypt =
{ 	.jobId = CSM_JOB_Encrypt_ID,
	.jobState = CRYPTO_JOBSTATE_IDLE,
	.jobInfo = {CSM_JOB_Encrypt_ID,CSM_JOB_Encrypt_Priority},
	.jobPriority = CSM_JOB_Encrypt_Priority,
	.jobPrimitiveInfo = &Encrypt_info
};

Crypto_JobType Crypto_JobType_SignatureGenerate =
{	.jobId = CSM_JOB_Signature_Generate_ID,
	.jobState = CRYPTO_JOBSTATE_IDLE,
	.jobInfo = {CSM_JOB_Signature_Generate_ID,CSM_JOB_Signature_Generate_Priority},
	.jobPriority = CSM_JOB_Signature_Generate_Priority,
	.jobPrimitiveInfo = &signature_info
};

Crypto_JobType Crypto_JobType_SignatureVerify =
{	.jobId= CSM_JOB_Signature_Verify_ID,
	.jobState = CRYPTO_JOBSTATE_IDLE,
	.jobInfo={CSM_JOB_Signature_Verify_ID,CSM_JOB_Signature_Verify_Priority},
	.jobPriority= CSM_JOB_Signature_Verify_Priority,
	.jobPrimitiveInfo=&verify_info
};

Crypto_JobType Crypto_JobType_Decrypt =
{	.jobId=CSM_JOB_Decrypt_ID,
	.jobState = CRYPTO_JOBSTATE_IDLE,
	.jobInfo={CSM_JOB_Decrypt_ID,CSM_JOB_Decrypt_Priority},
	.jobPriority= CSM_JOB_Decrypt_Priority,
	.jobPrimitiveInfo=&Decrypt_info
};

Crypto_JobType Crypto_JobType_Hash =
{	.jobId=CSM_JOB_Hash_ID,
	.jobState = CRYPTO_JOBSTATE_IDLE,
	.jobInfo={CSM_JOB_Hash_ID,CSM_JOB_Hash_Priority},
	.jobPriority= CSM_JOB_Hash_Priority,
	.jobPrimitiveInfo=&Hash_info
};

/*
 * Initializing array of CSM_Jobs
 */

Crypto_JobType *CSM_Jobs[MAX_QUEUE_SIZE] = {
		&Crypto_JobType_Encrypt,
		&Crypto_JobType_Decrypt,
		&Crypto_JobType_Hash,
		&Crypto_JobType_SignatureGenerate,
		&Crypto_JobType_SignatureVerify,

};


/*******************************************************************************
 *                      Additional Helper Functions                            *
 ******************************************************************************/

STATIC boolean isJobinQueue(uint32 jobId){

	if(queue.currentjobs == 0)
		return FALSE;

	for(uint8 i= queue.front; i <= queue.rear; i++)
	{

		if(jobId == queue.jobInfo[i].jobId)
		{
			return TRUE;
		}
	}

	return FALSE;

}

STATIC boolean isJobHighestPriority(uint32 jobId){

	if(queue.currentjobs == 0)
		return TRUE;

	for(uint8 i= queue.front; i <= queue.rear; i++)
	{

		if(queue.jobInfo[jobId].jobPriority < queue.jobInfo[i].jobPriority)
		{
			return FALSE;
		}
	}

	return TRUE;

}

STATIC boolean insertJob( Crypto_JobInfoType jobInfo){


if(queue.currentjobs < MAX_QUEUE_SIZE)
   {
	boolean inserted=0;
	queue.rear +=1;
	Crypto_JobInfoType temp;
	uint8 pos;
       for(uint8 i=queue.front;i<=queue.currentjobs;i++)
       {
            if (jobInfo.jobPriority > queue.jobInfo[i].jobPriority )
            {
            	temp= queue.jobInfo[i];
			    queue.jobInfo[i] =jobInfo;
			    inserted =1;
			    pos = i;
			    break;

            }

        }

       if(inserted==0)
       {

			queue.jobInfo[queue.rear % MAX_QUEUE_SIZE] =jobInfo;
       }
       else {
    	   for(int j=queue.rear-1;j>=pos+1;j--)
			{

				queue.jobInfo[j+1] =queue.jobInfo[j];
			}
		  queue.jobInfo[pos+1] = temp;
       }
       queue.currentjobs +=1;

       return TRUE;

   }
   return FALSE;

}


STATIC Std_ReturnType Csm_processRequest(uint32 jobId, Crypto_JobPrimitiveInputOutputType NewJobPrimitiveInputOutput)
{
	CSM_Jobs[jobId]->jobPrimitiveInputOutput = NewJobPrimitiveInputOutput;

	if (CSM_Jobs[jobId]->jobState == CRYPTO_JOBSTATE_ACTIVE){

		Std_ReturnType CryIf_ProcessJob_Return = CryIf_ProcessJob(CYIFCHANNEL1,CSM_Jobs[jobId]);

		return CryIf_ProcessJob_Return;

	} else {

		if (CSM_Jobs[jobId]->jobPrimitiveInfo->processingType == CRYPTO_PROCESSING_SYNC){

			boolean isJobHighestPriorityinQueue = isJobHighestPriority(jobId);

			if (isJobHighestPriorityinQueue == TRUE) {

				Std_ReturnType CryIf_ProcessJob_Return = CryIf_ProcessJob(CYIFCHANNEL1,CSM_Jobs[jobId]);

				return CryIf_ProcessJob_Return;

			} else {

				return CRYPTO_E_BUSY;
			}



		} else {

			if (queue.currentjobs == 0) {

				Std_ReturnType CryIf_ProcessJob_Return = CryIf_ProcessJob(CYIFCHANNEL1,CSM_Jobs[jobId]);

				if (CryIf_ProcessJob_Return == CRYPTO_E_BUSY){

					if (queue.currentjobs == queue.capacity) {

						return CRYPTO_E_BUSY;

					} else {

						boolean insertJobReturn = insertJob(CSM_Jobs[jobId]->jobInfo);

						if (insertJobReturn == FALSE)
						{
							#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
												Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
												CSM_SIGNATURE_VERIFY_SID,
												CSM_E_QUEUE_FULL);
							#endif
							return CRYPTO_E_BUSY;
						}

						return E_OK;


					}

				} else {

					return E_OK;
				}


			}
		}

	}

	return E_OK;
}



/************************************************************************************
 * Service Name: Csm_Init
 * Service ID[hex]: 0x00
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): ConfigPtr - Pointer to a selected configuration structure
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Initializes the CSM module`
 * Requirements: SWS_Csm_00186, SWS_Csm_00659, [SWS_Csm_91009]
 ************************************************************************************/

void Csm_Init(const Csm_ConfigType* configPtr){

	/*
	 * [SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
corresponding input or output data are not re-directed to a key element, the operation
shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
when CsmDevErrorDetect is true
*/
	if (configPtr == NULL_PTR) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_INIT_SID,
		CSM_E_PARAM_POINTER);
#endif
		Csm_State = CSM_STATE_UNINIT;

	} else {

		queue.capacity = MAX_QUEUE_SIZE;
		queue.currentjobs = 0;
		queue.rear = -1;
		queue.front = 0;

		Csm_State = CSM_STATE_INIT;
	}

}

/************************************************************************************
 * Service Name: Csm_GetVersionInfo
 * Service ID[hex]: 0x3b
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): versioninfo - Pointer to where to store the version information of this module.
 * Return value: None
 * Description: Returns the version information of this module
 * Requirements: None
 ************************************************************************************/

#if (CSM_VERSION_INFO_API  == STD_ON)
void Csm_GetVersionInfo(Std_VersionInfoType* versioninfo) {

	versioninfo->vendorID = NULL;
	versioninfo->moduleID = CSM_MODULE_ID;
	versioninfo->sw_major_version = CSM_SW_MAJOR_VERSION;
	versioninfo->sw_minor_version = CSM_SW_MINOR_VERSION;
	versioninfo->sw_patch_version = CSM_SW_PATCH_VERSION;
//	versioninfo->ar_major_version = CSM_AR_RELEASE_MAJOR_VERSION;
//	versioninfo->ar_minor_version = CSM_AR_RELEASE_MINOR_VERSION;
//	versioninfo->ar_patch_version = CSM_AR_RELEASE_PATCH_VERSION;

}
#endif

/************************************************************************************
 * Service Name: Csm_Hash
 * Service ID[hex]: 0x5d
 * Sync/Async: Depends on configuration
 * Reentrancy: Reentrant
 * Parameters (in):  uint32 jobId,
					 Crypto_OperationModeType mode,
					 const uint8* dataPtr,
					 uint32 dataLength,
					 uint8* resultPtr,
					 uint32* resultLengthPtr

 * Parameters (inout): resultLengthPtr
 * Parameters (out): resultPtr
 * Return value: Std_ReturnType
 * Description: Uses the given data to perform the hash calculation and stores the hash.
 * Requirements: [SWS_Csm_91008], [SWS_Csm_91009], [SWS_Csm_91011]
 ************************************************************************************/

Std_ReturnType Csm_Hash(uint32 jobId, Crypto_OperationModeType mode, const uint8* dataPtr, uint32 dataLength, uint8* resultPtr, uint32* resultLengthPtr){

	/*   [SWS_Csm_91008] ⌈ While the CSM is not initialized and any function of the CSM
		 API is called, except of CSM_Init() and Csm_GetVersionInfo(), the operation
		 shall not be performed and CSM_E_UNINIT shall be reported to the DET when
		 CsmDevErrorDetect is true.

	 */

	if (Csm_State == CSM_STATE_UNINIT) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)
			Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
			CSM_HASH_SID,
			CSM_E_UNINIT);
#endif
			return E_NOT_OK;
		}

	/*	[SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
		corresponding input or output data are not re-directed to a key element, the operation
		shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
		when CsmDevErrorDetect is true
	*/

	if (dataPtr == NULL_PTR || resultPtr == NULL_PTR || resultLengthPtr == NULL_PTR) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_HASH_SID,
		CSM_E_PARAM_POINTER);
#endif
	        return E_NOT_OK;
	    }

	/*    [SWS_Csm_91011] ⌈If a CSM API with a ID handle in its interface is called and the
		  ID handle is out of range, the operation shall not be performed and
		  CSM_E_PARAM_HANDLE shall be reported to the DET when CsmDevErrorDetect
		  is true.⌋
	*/

	if(jobId > CSM_JOBS_NUM){
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_HASH_SID,
		CSM_E_PARAM_HANDLE);
#endif
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01091] If a CSM API with a job handle (called jobId) in its interface is
		 called and the Crypto_ServiceInfoType of the job does not match the requested
		 service, the operation shall not be performed and CSM_E_SERVICE_TYPE shall be
		 reported to the DET when CsmDevErrorDetect is true.
	 */

	if(CSM_Jobs[jobId]->jobPrimitiveInfo->primitiveInfo->service !=  CRYPTO_HASH) {

#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_HASH_SID,
		CSM_E_SERVICE_TYPE);
#endif

		return E_NOT_OK;

	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
		 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.

		 [SWS_Csm_00018] ⌈If a service of the CSM module is requested, and the
		 CSM job needs to be queued and the queue is full, the job request shall be rejected
		 with the return value CRYPTO_E_BUSY.⌋
	*/

	if (queue.currentjobs == queue.capacity) {
#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
			Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
			CSM_HASH_SID,
			CSM_E_QUEUE_FULL);
#endif
			return CRYPTO_E_BUSY;
		}

	Crypto_JobPrimitiveInputOutputType NewJobPrimitiveInputOutput = {
			.inputPtr = dataPtr,
			.inputLength = dataLength,
			.outputPtr = resultPtr,
			.outputLengthPtr = resultLengthPtr,
			.mode=mode
	};

	// check if jobId already in queue
	boolean isJobinQueueparam  = isJobinQueue(jobId);

	/*
		[SWS_Csm_00016] ⌈For each job just one instance shall be processed by CSM at a
		time.⌋

	*/

	// already in queue
	if(isJobinQueueparam == TRUE)
	{
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
			 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.
	*/


	Std_ReturnType process_hash_job = Csm_processRequest(jobId, NewJobPrimitiveInputOutput);

	return process_hash_job;


}


/************************************************************************************
 * Service Name: Csm_Encrypt
 * Service ID[hex]: 0x5e
 * Sync/Async: Depends on configuration
 * Reentrancy: Reentrant
 * Parameters (in): 	uint32 jobId,
 						Crypto_OperationModeType mode,
 						const uint8* dataPtr,
 						uint32 dataLength
 						uint8 resultPtr,
						uint32 resultLengthPtr
 * Parameters (inout): resultLengthPtr
 * Parameters (out): resultPtr
 * Return value: Std_ReturnType
 * Description: Encrypts the given data and store the ciphertext in the memory location pointed by the result pointer.
 ************************************************************************************/

Std_ReturnType Csm_Encrypt (uint32 jobId, Crypto_OperationModeType mode, const uint8* dataPtr, uint32 dataLength, uint8* resultPtr, uint32* resultLengthPtr)
{

	/*   [SWS_Csm_91008] ⌈ While the CSM is not initialized and any function of the CSM
			 API is called, except of CSM_Init() and Csm_GetVersionInfo(), the operation
			 shall not be performed and CSM_E_UNINIT shall be reported to the DET when
			 CsmDevErrorDetect is true.

	 */

	if (Csm_State == CSM_STATE_UNINIT) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)
			Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
			CSM_ENCRYPT_SID,
			CSM_E_UNINIT);
#endif
			return E_NOT_OK;
		}

	/*	[SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
		corresponding input or output data are not re-directed to a key element, the operation
		shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
		when CsmDevErrorDetect is true
	*/

	if (dataPtr == NULL_PTR || resultPtr == NULL_PTR || resultLengthPtr == NULL_PTR) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_ENCRYPT_SID,
		CSM_E_PARAM_POINTER);
#endif
			return E_NOT_OK;
		}

	/*    [SWS_Csm_91011] ⌈If a CSM API with a ID handle in its interface is called and the
		  ID handle is out of range, the operation shall not be performed and
		  CSM_E_PARAM_HANDLE shall be reported to the DET when CsmDevErrorDetect
		  is true.⌋
	*/

	if(jobId > CSM_JOBS_NUM){
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_ENCRYPT_SID,
		CSM_E_PARAM_HANDLE);
#endif
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01091] If a CSM API with a job handle (called jobId) in its interface is
		 called and the Crypto_ServiceInfoType of the job does not match the requested
		 service, the operation shall not be performed and CSM_E_SERVICE_TYPE shall be
		 reported to the DET when CsmDevErrorDetect is true.
	 */

	if(CSM_Jobs[jobId]->jobPrimitiveInfo->primitiveInfo->service !=  CRYPTO_ENCRYPT) {

#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_ENCRYPT_SID,
		CSM_E_SERVICE_TYPE);
#endif

		return E_NOT_OK;

	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
		 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.

		 [SWS_Csm_00018] ⌈If a service of the CSM module is requested, and the
		 CSM job needs to be queued and the queue is full, the job request shall be rejected
		 with the return value CRYPTO_E_BUSY.⌋
	*/

	if (queue.currentjobs == queue.capacity) {
#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
			Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
			CSM_ENCRYPT_SID,
			CSM_E_QUEUE_FULL);
#endif
			return CRYPTO_E_BUSY;
		}

	Crypto_JobPrimitiveInputOutputType NewJobPrimitiveInputOutput = {
			.inputPtr = dataPtr,
			.inputLength = dataLength,
			.outputPtr = resultPtr,
			.outputLengthPtr = resultLengthPtr,
			.mode=mode,
			.secondaryInputPtr = &V2G_CommunicationPartyValue

	};

	/*
		[SWS_Csm_00016] ⌈For each job just one instance shall be processed by CSM at a
		time.⌋

	*/

	// check if jobId already in queue
	boolean isJobinQueueparam  = isJobinQueue(jobId);

	// already in queue
	if(isJobinQueueparam == TRUE)
	{
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
			 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.
	*/


	Std_ReturnType process_encrypt_job = Csm_processRequest(jobId, NewJobPrimitiveInputOutput);

	return process_encrypt_job;


}

/************************************************************************************
 * Service Name: Csm_Decrypt
 * Service ID[hex]: 0x5f
 * Sync/Async: Depends on configuration
 * Reentrancy: Reentrant
 * Parameters (in): 	uint32 jobId,
 						Crypto_OperationModeType mode,
 						const uint8* dataPtr,
 						uint32 dataLength
 * Parameters (inout): resultLengthPtr
 * Parameters (out): resultPtr
 * Return value: Std_ReturnType
 * Description: Decrypts the given encrypted data and store the decrypted plaintext in the memory location pointed by the result pointer.
 ************************************************************************************/

Std_ReturnType Csm_Decrypt (
uint32 jobId,
Crypto_OperationModeType mode,
const uint8* dataPtr,
uint32 dataLength,
uint8* resultPtr,
uint32* resultLengthPtr
) {

	/*   [SWS_Csm_91008] ⌈ While the CSM is not initialized and any function of the CSM
		 API is called, except of CSM_Init() and Csm_GetVersionInfo(), the operation
		 shall not be performed and CSM_E_UNINIT shall be reported to the DET when
	     CsmDevErrorDetect is true.

	*/

	if (Csm_State == CSM_STATE_UNINIT) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_DECRYPT_SID,
		CSM_E_UNINIT);
#endif
		return E_NOT_OK;
		}

	/*	[SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
		corresponding input or output data are not re-directed to a key element, the operation
		shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
		when CsmDevErrorDetect is true
	*/

	if (dataPtr == NULL_PTR || resultPtr == NULL_PTR || resultLengthPtr == NULL_PTR) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_DECRYPT_SID,
		CSM_E_PARAM_POINTER);
#endif
			return E_NOT_OK;
		}

	/*    [SWS_Csm_91011] ⌈If a CSM API with a ID handle in its interface is called and the
		  ID handle is out of range, the operation shall not be performed and
		  CSM_E_PARAM_HANDLE shall be reported to the DET when CsmDevErrorDetect
		  is true.⌋
	*/

	if(jobId > CSM_JOBS_NUM){
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_DECRYPT_SID,
		CSM_E_PARAM_HANDLE);
#endif
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01091] If a CSM API with a job handle (called jobId) in its interface is
		 called and the Crypto_ServiceInfoType of the job does not match the requested
		 service, the operation shall not be performed and CSM_E_SERVICE_TYPE shall be
		 reported to the DET when CsmDevErrorDetect is true.
	 */

	if(CSM_Jobs[jobId]->jobPrimitiveInfo->primitiveInfo->service !=  CRYPTO_DECRYPT) {

#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_DECRYPT_SID,
		CSM_E_SERVICE_TYPE);
#endif

		return E_NOT_OK;

	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
		 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.

		 [SWS_Csm_00018] ⌈If a service of the CSM module is requested, and the
		 CSM job needs to be queued and the queue is full, the job request shall be rejected
		 with the return value CRYPTO_E_BUSY.⌋
	*/

	if (queue.currentjobs == queue.capacity) {
#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
			Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
			CSM_DECRYPT_SID,
			CSM_E_QUEUE_FULL);
#endif
			return CRYPTO_E_BUSY;
		}

	Crypto_JobPrimitiveInputOutputType NewJobPrimitiveInputOutput = {
			.inputPtr = dataPtr,
			.inputLength = dataLength,
			.outputPtr = resultPtr,
			.outputLengthPtr = resultLengthPtr,
			.mode=mode,
			.secondaryInputPtr = &V2G_CommunicationPartyValue
	};

	/*
		[SWS_Csm_00016] ⌈For each job just one instance shall be processed by CSM at a
		time.⌋

	*/
	// check if jobId already in queue
	boolean isJobinQueueparam  = isJobinQueue(jobId);

	// already in queue
	if(isJobinQueueparam == TRUE)
	{
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
			 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.
	*/


	Std_ReturnType process_decrypt_job = Csm_processRequest(jobId, NewJobPrimitiveInputOutput);

	return process_decrypt_job;
}


/************************************************************************************
 * Service Name: Csm_SignatureGenerate
 * Service ID[hex]: 0x76
 * Sync/Async: Depends on configuration
 * Reentrancy: Reentrant
 * Parameters (in): 	uint32 jobId,
 	 	 	 	 	 	Crypto_OperationModeType mode,
 	 	 	 	 	 	const uint8* dataPtr,
 	 	 	 	 	 	uint32 dataLength,

 * Parameters (inout): uint32* signatureLengthPtr
 * Parameters (out): uint8* signaturePtr,
 * Return value: Std_ReturnType
 * Description: Uses the given data to perform the signature calculation and stores the signature in the memory location pointed by the result pointer.
 * Requirements:
 ************************************************************************************/

Std_ReturnType Csm_SignatureGenerate (
uint32 jobId,
Crypto_OperationModeType mode,
const uint8* dataPtr,
uint32 dataLength,
uint8* signaturePtr,
uint32* signatureLengthPtr
) {

/*   [SWS_Csm_91008] ⌈ While the CSM is not initialized and any function of the CSM
		 API is called, except of CSM_Init() and Csm_GetVersionInfo(), the operation
		 shall not be performed and CSM_E_UNINIT shall be reported to the DET when
		 CsmDevErrorDetect is true.

	*/

	if (Csm_State == CSM_STATE_UNINIT) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_SIGNATURE_GENERATE_SID,
		CSM_E_UNINIT);
#endif
		return E_NOT_OK;
		}

	/*	[SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
		corresponding input or output data are not re-directed to a key element, the operation
		shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
		when CsmDevErrorDetect is true
	*/

	if (dataPtr == NULL_PTR || signaturePtr == NULL_PTR || signatureLengthPtr == NULL_PTR) {
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_SIGNATURE_GENERATE_SID,
		CSM_E_PARAM_POINTER);
#endif
		return E_NOT_OK;
		}

	/*    [SWS_Csm_91011] ⌈If a CSM API with a ID handle in its interface is called and the
		  ID handle is out of range, the operation shall not be performed and
		  CSM_E_PARAM_HANDLE shall be reported to the DET when CsmDevErrorDetect
		  is true.⌋
	*/

	if(jobId > CSM_JOBS_NUM){
#if (CSM_DEV_ERROR_DETECT == STD_ON)

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_SIGNATURE_GENERATE_SID,
		CSM_E_PARAM_HANDLE);
#endif
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01091] If a CSM API with a job handle (called jobId) in its interface is
		 called and the Crypto_ServiceInfoType of the job does not match the requested
		 service, the operation shall not be performed and CSM_E_SERVICE_TYPE shall be
		 reported to the DET when CsmDevErrorDetect is true.
	 */

	if(CSM_Jobs[jobId]->jobPrimitiveInfo->primitiveInfo->service !=  CRYPTO_SIGNATUREGENERATE) {

#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_SIGNATURE_GENERATE_SID,
		CSM_E_SERVICE_TYPE);
#endif

		return E_NOT_OK;

	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
		 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.

		 [SWS_Csm_00018] ⌈If a service of the CSM module is requested, and the
		 CSM job needs to be queued and the queue is full, the job request shall be rejected
		 with the return value CRYPTO_E_BUSY.⌋
	*/

	if (queue.currentjobs == queue.capacity) {
#if (CSM_RUNTIME_ERROR_DETECT == STD_ON)
			Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
			CSM_SIGNATURE_GENERATE_SID,
			CSM_E_QUEUE_FULL);
#endif
			return CRYPTO_E_BUSY;
		}

	Crypto_JobPrimitiveInputOutputType NewJobPrimitiveInputOutput = {
			.inputPtr = dataPtr,
			.inputLength = dataLength,
			.outputPtr = signaturePtr,
			.outputLengthPtr = signatureLengthPtr,
			.mode=mode
	};

	/*
		[SWS_Csm_00016] ⌈For each job just one instance shall be processed by CSM at a
		time.⌋

	*/
	// check if jobId already in queue
	boolean isJobinQueueparam  = isJobinQueue(jobId);

	// already in queue
	if(isJobinQueueparam == TRUE)
	{
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
			 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.
	*/


	Std_ReturnType process_signature_generate_job = Csm_processRequest(jobId, NewJobPrimitiveInputOutput);

	return process_signature_generate_job;

}

/************************************************************************************
 * Service Name: Csm_SignatureVerify
 * Service ID[hex]: 0x64
 * Sync/Async: Depends on configuration
 * Reentrancy: Reentrant
 * Parameters (in): 	uint32 jobId,
 	 	 	 	 	 	Crypto_OperationModeType mode,
 	 	 	 	 	 	const uint8* dataPtr,
 	 	 	 	 	 	uint32 dataLength,
 	 	 	 	 	 	uint8* signaturePtr,
 	 	 	 	 	 	uint32* signatureLengthPtr,
 * Parameters (inout): None
 * Parameters (out): Crypto_VerifyResultType* verifyPtr
 * Return value: Std_ReturnType
 * Description: Verifies the given MAC by comparing if the signature is generated with the given data.
 * Requirements:
 ************************************************************************************/

Std_ReturnType Csm_SignatureVerify (
uint32 jobId,
Crypto_OperationModeType mode,
const uint8* dataPtr,
uint32 dataLength,
const uint8* signaturePtr,
uint32 signatureLength,
Crypto_VerifyResultType* verifyPtr
) {

#if (CSM_DEV_ERROR_DETECT == STD_ON)

/*   [SWS_Csm_91008] ⌈ While the CSM is not initialized and any function of the CSM
		 API is called, except of CSM_Init() and Csm_GetVersionInfo(), the operation
		 shall not be performed and CSM_E_UNINIT shall be reported to the DET when
		 CsmDevErrorDetect is true.

	*/

	if (Csm_State == CSM_STATE_UNINIT) {
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_SIGNATURE_VERIFY_SID,
		CSM_E_UNINIT);
		return E_NOT_OK;
		}

	/*	[SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
		corresponding input or output data are not re-directed to a key element, the operation
		shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
		when CsmDevErrorDetect is true
	*/

	if (dataPtr == NULL_PTR || signaturePtr == NULL_PTR || verifyPtr == NULL_PTR) {

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_SIGNATURE_VERIFY_SID,
		CSM_E_PARAM_POINTER);

		return E_NOT_OK;
		}

	/*    [SWS_Csm_91011] ⌈If a CSM API with a ID handle in its interface is called and the
		  ID handle is out of range, the operation shall not be performed and
		  CSM_E_PARAM_HANDLE shall be reported to the DET when CsmDevErrorDetect
		  is true.⌋
	*/

	if(jobId > CSM_JOBS_NUM){

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_SIGNATURE_VERIFY_SID,
		CSM_E_PARAM_HANDLE);
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01091] If a CSM API with a job handle (called jobId) in its interface is
		 called and the Crypto_ServiceInfoType of the job does not match the requested
		 service, the operation shall not be performed and CSM_E_SERVICE_TYPE shall be
		 reported to the DET when CsmDevErrorDetect is true.
	 */

	if(CSM_Jobs[jobId]->jobPrimitiveInfo->primitiveInfo->service !=  CRYPTO_SIGNATUREVERIFY) {

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_SIGNATURE_VERIFY_SID,
		CSM_E_SERVICE_TYPE);

		return E_NOT_OK;

	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
		 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.

		 [SWS_Csm_00018] ⌈If a service of the CSM module is requested, and the
		 CSM job needs to be queued and the queue is full, the job request shall be rejected
		 with the return value CRYPTO_E_BUSY.⌋
	*/

	if (queue.currentjobs == queue.capacity) {

			Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
			CSM_SIGNATURE_GENERATE_SID,
			CSM_E_QUEUE_FULL);

			return CRYPTO_E_BUSY;
		}

#endif

	Crypto_JobPrimitiveInputOutputType NewJobPrimitiveInputOutput = {
			.inputPtr = dataPtr,
			.inputLength = dataLength,
			.secondaryInputPtr = signaturePtr,
			.secondaryInputLength = signatureLength,
			.verifyPtr = verifyPtr,
			.mode=mode
	};

	/*
		[SWS_Csm_00016] ⌈For each job just one instance shall be processed by CSM at a
		time.⌋

	*/

	// check if jobId already in queue
	boolean isJobinQueueparam  = isJobinQueue(jobId);

	// already in queue
	if(isJobinQueueparam == TRUE)
	{
		return E_NOT_OK;
	}

	/*   [SWS_Csm_01088] If a CSM job needs to be queued and the queue is full, the
			 runtime error CSM_E_QUEUE_FULL shall be reported to the DET.
	*/


	Std_ReturnType process_signature_verify_job = Csm_processRequest(jobId, NewJobPrimitiveInputOutput);

	return process_signature_verify_job;
}

/************************************************************************************
 * Service Name: Csm_KeyExchangeCalcSecret
 * Service ID[hex]: 0x6d
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant but not for same keyId
 * Parameters (in): 	uint32 keyId,
						const uint8* partnerPublicValuePtr,
						uint32 partnerPublicValueLength
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: Std_ReturnType
 * Description: Calculates the shared secret key for the key exchange with the key material of the
key identified by the keyId and the partner public key. The shared secret key is
stored as a key element in the same key.
 ************************************************************************************/


Std_ReturnType Csm_KeyExchangeCalcSecret (
uint32 keyId,
const uint8* partnerPublicValuePtr,
uint32 partnerPublicValueLength
) {

#if (CSM_DEV_ERROR_DETECT == STD_ON)

	/*   [SWS_Csm_91008] ⌈ While the CSM is not initialized and any function of the CSM
			 API is called, except of CSM_Init() and Csm_GetVersionInfo(), the operation
			 shall not be performed and CSM_E_UNINIT shall be reported to the DET when
			 CsmDevErrorDetect is true.

	*/

	if (Csm_State == CSM_STATE_UNINIT) {
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_KEYEXCHANGECALCSECRET_SID,
		CSM_E_UNINIT);
		return E_NOT_OK;
		}

	/*	[SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
			corresponding input or output data are not re-directed to a key element, the operation
			shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
			when CsmDevErrorDetect is true
		*/

	if (partnerPublicValuePtr == NULL_PTR) {

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_KEYEXCHANGECALCSECRET_SID,
		CSM_E_PARAM_POINTER);

		return E_NOT_OK;
		}




#endif

	Std_ReturnType result = CryIf_KeyExchangeCalcSecret(keyId, partnerPublicValuePtr, partnerPublicValueLength);
	return result;

}

/************************************************************************************
 * Service Name: Csm_KeyExchangeCalcPubVal
 * Service ID[hex]: 0x6c
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant but not for same keyId
 * Parameters (in): 	uint32 keyId,
 * Parameters (inout): uint32* publicValueLengthPtr
 * Parameters (out): uint8* publicValuePtr,
 * Return value: Std_ReturnType
 * Description:Calculates the public value of the current user for the key exchange and stores the
public key in the memory location pointed by the public value pointer.
 ************************************************************************************/

Std_ReturnType Csm_KeyExchangeCalcPubVal (
uint32 keyId,
uint8* publicValuePtr,
uint32* publicValueLengthPtr
) {

#if (CSM_DEV_ERROR_DETECT == STD_ON)

	/*   [SWS_Csm_91008] ⌈ While the CSM is not initialized and any function of the CSM
			 API is called, except of CSM_Init() and Csm_GetVersionInfo(), the operation
			 shall not be performed and CSM_E_UNINIT shall be reported to the DET when
			 CsmDevErrorDetect is true.

	*/

	if (Csm_State == CSM_STATE_UNINIT) {
		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID,
		CSM_KEYEXCHANGECALCSECRET_SID,
		CSM_E_UNINIT);
		return E_NOT_OK;
		}

	/*	[SWS_Csm_91009] ⌈ If a pointer to null is passed to an API function and the
			corresponding input or output data are not re-directed to a key element, the operation
			shall not be performed and CSM_E_PARAM_POINTER shall be reported to the DET
			when CsmDevErrorDetect is true
		*/

	if (publicValuePtr == NULL_PTR) {

		Det_ReportError(CSM_MODULE_ID, CSM_INSTANCE_ID, CSM_KEYEXCHANGECALCSECRET_SID,
		CSM_E_PARAM_POINTER);

		return E_NOT_OK;
		}


#endif

	Std_ReturnType result = CryIf_KeyExchangeCalcPubVal(keyId, publicValuePtr, publicValueLengthPtr);
	return result;

}













