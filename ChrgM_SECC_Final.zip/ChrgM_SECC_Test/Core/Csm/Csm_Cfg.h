/*
 ============================================================================
 Name        : Csm_Cfg.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Header file for CSM configuration
 ============================================================================
 */


#define COMMUINCATIONPARTYDEFINER 		  	1

#define CSM_JOBS_NUM (4U)
#define KEY_LENGTH_USED_AES (521)
#define KEY_LENGTH_USED_ECDSA (521)
#define KEY_LENGTH_USED_HASH (521)

/*
 * Module Version 1.0.0
 */
#define CSM_CFG_SW_MAJOR_VERSION           (1U)
#define CSM_CFG_SW_MINOR_VERSION           (0U)
#define CSM_CFG_SW_PATCH_VERSION           (0U)

#define MAX_QUEUE_SIZE 7


/*******************************************************************************
 *                   CsmGeneral Container Configuration Parameters                                   *
 *******************************************************************************/

/* Pre-compile option for Development Error Detect
 * SWS Item:
 * */
#define CSM_DEV_ERROR_DETECT                (STD_OFF)
#define CSM_RUNTIME_ERROR_DETECT            (STD_OFF)

/* Pre-compile option for Version Info API
 * SWS Item:
 * */
#define CSM_VERSION_INFO_API                (STD_ON)

/*******************************************************************************
 *                   CsmMainFunction Container Configuration Parameters                                   *
 *******************************************************************************/

/* Pre-compile option for Main Function Period
 * SWS Item:
 * */

#define CsmMainFunctionPeriod

/*******************************************************************************
 *                   CsmJob Container Configuration Parameters                                   *
 *******************************************************************************/

#define CSM_JOB_Encrypt_ID					(0U)
#define CSM_JOB_Decrypt_ID					(1U)
#define CSM_JOB_Hash_ID						(2U)
#define CSM_JOB_Signature_Generate_ID		(3U)
#define CSM_JOB_Signature_Verify_ID			(4U)
#define CSM_JOB_Key_Exchange_ID				(5U)

#define CSM_JOB_Encrypt_Priority				(0U)
#define CSM_JOB_Decrypt_Priority				(1U)
#define CSM_JOB_Hash_Priority					(2U)
#define CSM_JOB_Signature_Generate_Priority		(3U)
#define CSM_JOB_Signature_Verify_Priority		(4U)
#define CSM_JOB_Key_Exchange_Priority			(5U)

/*******************************************************************************
 *                   CsmQueue Container Configuration Parameters               *
 *******************************************************************************/

#define CsmQueueSize                ((uint32)7U)






