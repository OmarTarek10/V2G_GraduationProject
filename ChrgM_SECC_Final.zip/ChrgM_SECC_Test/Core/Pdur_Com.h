/******************************************************************************
 *
 * Module: PduR
 *
 * File Name: PduR_ComM.h
 *
 * Description: Header file for Pdu_Com.h
 *
 * Author: Kareem Azab / Alyeldeen Khaled
 ******************************************************************************/

#ifndef PDUR_COM_H_
#define PDUR_COM_H_



#include "PduR.h"


#if (PduRZeroCostOperation== STD_OFF) && (PduR_Com_Supported == TRUE)


Std_ReturnType PduR_ComTransmit (PduIdType TxPduId, const PduInfoType* PduInfoPtr);


#endif




#endif /* PDUR_COM_H_ */






