/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_SoAd.h
 *
 * Description: Header file for provided ChrgM Callback notifications
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef CHRGM_SOAD_H_
#define CHRGM_SOAD_H_

void ChrgM_V2GTpLocalIpAddrAssignmentChg (TcpIp_LocalAddrIdType IpAddrId, TcpIp_IpAddrStateType State);

void ChrgM_V2GTpSoConModeChg (SoAd_SoConIdType SoConId, SoAd_SoConModeType Mode);

#endif /* CHRGM_SOAD_H_ */
