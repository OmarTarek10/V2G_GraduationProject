/*
 *  Charging_Station_State_Machine_Swc.c
 *  Created on: Mar 21, 2024
 *  Author: Mohannad Sabry,Mahmoud Sharawy
 */

#include "Std_Types.h"
#include "Rte_Charging_Station_State_Machine_Swc.h"
#include "V2G_Data_Types.h"
#include "iso1EXIDatatypes.h"
#include "stm32f4xx_hal.h"

#define DATA_ERROR 0
#define SESSION_ID 10


SupportedAppProtocolResType Supported_App_Protocol_Res_Data;
struct iso1EXIDocument V2G_Doc;


/* errorTest variable is used to test that the functionality of the ShowChrgMError function is working correctly */
uint8 errorTest;


void ShowChrgMError(uint8 ChrgMErrorValue){
	switch(ChrgMErrorValue){
	case CHRGM_FAILED:errorTest=1;
	break;
	case CHRGM_SequenceError:errorTest=2;
	break;
	case CHRGM_SignatureError:errorTest=3;
	break;
	case CHRGM_UnknownSession:errorTest=4;
	break;
	case CHRGM_InvalidServiceID:errorTest=5;
	break;
	case CHRGM_PaymentSelectionInvalid:errorTest=6;
	break;
	case CHRGM_ServiceSelectionInvalid:errorTest=7;
	break;
	case CHRGM_NoChargeServiceSelected:errorTest=8;
	break;
	case CHRGM_CertificateExpired:errorTest=9;
	break;
	case CHRGM_CertificateRevoked:errorTest=10;
	break;
	case CHRGM_NoCertificateAvailable:errorTest=11;
	break;
	case CHRGM_CertificateNotAllowedAtThisEVSE:errorTest=12;
	break;
	case CHRGM_CertChainError:errorTest=13;
	break;
	case CHRGM_ContractCancelled:errorTest=14;
	break;
	case CHRGM_ChallengeInvalid:errorTest=15;
	break;
	case CHRGM_WrongEnergyTransferMode:errorTest=16;
	break;
	case CHRGM_WrongChargeParameter:errorTest=17;
	break;
	case CHRGM_ChargingProfileInvalid:errorTest=18;
	break;
	case CHRGM_TariffSelectionInvalid:errorTest=19;
	break;
	case CHRGM_PowerDeliveryNotApplied:errorTest=20;
	break;
	case CHRGM_ContactorError:errorTest=21;
	break;
	}
}

void Prepare_Header(void){
	V2G_Doc.V2G_Message.Header.SessionID.bytesLen=1;
	V2G_Doc.V2G_Message.Header.SessionID.bytes[0]=SESSION_ID;
	V2G_Doc.V2G_Message.Header.Notification_isUsed=NOT_USED;
	V2G_Doc.V2G_Message.Header.Signature_isUsed=NOT_USED;
}

/*****************************************************
 * Port:        PP_CS_RequestedData
 * Interface:   CsIf_RequestedData
 * Operation:   Process_Request
 *****************************************************/
void RE_ProcessRequest(uint8 Message_Indication,
		uint8 Error_Indication,
		void* V2G_Document,
		uint8 Message_Name)
{

	if( (Message_Indication==TRUE) && (Error_Indication==CHRGM_NoError) ){
		switch(Message_Name){
		/*Start of SUPPORTED_APP_PROTOCOL_MESSAGE*/
		case  SUPPORTED_APP_PROTOCOL_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				memset(&Supported_App_Protocol_Res_Data,0,sizeof(Supported_App_Protocol_Res_Data));

				/* Prepare Header */
				Supported_App_Protocol_Res_Data.MessageHeader.SessionID=SESSION_ID;
				Supported_App_Protocol_Res_Data.MessageHeader.NotificationUsed=NOT_USED;

				/* Prepare Data */
				Supported_App_Protocol_Res_Data.MessageName=SUPPORTED_APP_PROTOCOL_MESSAGE;
				Supported_App_Protocol_Res_Data.ResponseCode=OK;
				Supported_App_Protocol_Res_Data.SchemaIDUsed=USED;
				Supported_App_Protocol_Res_Data.SchemaID=0xEE;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse(&Supported_App_Protocol_Res_Data,SUPPORTED_APP_PROTOCOL_MESSAGE);
			}
			break;
		}/*End of SUPPORTED_APP_PROTOCOL_MESSAGE*/

		/*Start of SESSION_SETUP_MESSAGE*/
		case  SESSION_SETUP_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of Session Setup Response */
				V2G_Doc.V2G_Message.Body.SessionSetupRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.SessionSetupRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.SessionSetupRes.EVSEID.charactersLen=1;
				V2G_Doc.V2G_Message.Body.SessionSetupRes.EVSEID.characters[0]=0x10;
				V2G_Doc.V2G_Message.Body.SessionSetupRes.EVSETimeStamp_isUsed=NOT_USED;
				//V2G_Doc.V2G_Message.Body.SessionSetupRes.EVSETimeStamp=0xDEADBEAFDEADBEAF;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,SESSION_SETUP_MESSAGE);
			}
			break;
		}/*End of SESSION_SETUP_MESSAGE*/

		/*Start of SERVICE_DISCOVERY_MESSAGE*/
		case  SERVICE_DISCOVERY_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of ServiceDiscoveryRes Message */
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.PaymentOptionList.PaymentOption.arrayLen=2;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.PaymentOptionList.PaymentOption.array[0]=iso1paymentOptionType_ExternalPayment;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.PaymentOptionList.PaymentOption.array[1]=iso1paymentOptionType_Contract;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ChargeService.ServiceID=0xAABB;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ChargeService.ServiceName_isUsed=NOT_USED;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ChargeService.ServiceScope_isUsed=NOT_USED;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ChargeService.SupportedEnergyTransferMode.EnergyTransferMode.arrayLen=1;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ChargeService.SupportedEnergyTransferMode.EnergyTransferMode.array[0]=iso1EnergyTransferModeType_DC_core;
				V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ServiceList_isUsed=NOT_USED;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse(&V2G_Doc,SERVICE_DISCOVERY_MESSAGE);
			}
			break;
		}/*End of SERVICE_DISCOVERY_MESSAGE*/


		/*Start of PAYMENT_SELECTION_MESSAGE*/
		case  PAYMENT_SELECTION_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of PaymentServiceSelectionRes Message */
				V2G_Doc.V2G_Message.Body.PaymentServiceSelectionRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.PaymentServiceSelectionRes.ResponseCode=iso1responseCodeType_OK;


				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse(&V2G_Doc,PAYMENT_SELECTION_MESSAGE);
			}
			break;
		}/*End of PAYMENT_SELECTION_MESSAGE*/

		/*Start of PAYMENT_DETAILS_MESSAGE*/
		case PAYMENT_DETAILS_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of PaymentDetailsRes Message */
				V2G_Doc.V2G_Message.Body.PaymentDetailsRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.PaymentDetailsRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.PaymentDetailsRes.GenChallenge.bytesLen=1;
				V2G_Doc.V2G_Message.Body.PaymentDetailsRes.GenChallenge.bytes[0]=0xAA;
				V2G_Doc.V2G_Message.Body.PaymentDetailsRes.EVSETimeStamp=0xDEADBEAFDEADBEAF;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse(&V2G_Doc,PAYMENT_DETAILS_MESSAGE);
			}
			break;
		}/*End of PAYMENT_DETAILS_MESSAGE*/


		/*Start of AUTHORIZATION_MESSAGE*/
		case AUTHORIZATION_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of AuthorizationRes Message */
				V2G_Doc.V2G_Message.Body.AuthorizationRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.AuthorizationRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.AuthorizationRes.EVSEProcessing=iso1EVSEProcessingType_Finished;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,AUTHORIZATION_MESSAGE);
			}
			break;
		}/*End of AUTHORIZATION_MESSAGE*/


		/*Start of CHARGE_PARAMETER_DISCOVERY_MESSAGE*/
		case CHARGE_PARAMETER_DISCOVERY_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of ChargeParameterDiscoveryRes Message */
				V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes.EVSEProcessing=iso1EVSEProcessingType_Finished;
				V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes.SASchedules_isUsed=NOT_USED;
				V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes.SAScheduleList_isUsed=NOT_USED;
				V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes.EVSEChargeParameter_isUsed=USED;
				V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes.EVSEChargeParameter.noContent=1;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,CHARGE_PARAMETER_DISCOVERY_MESSAGE);
			}
			break;
		}/*End of CHARGE_PARAMETER_DISCOVERY_MESSAGE*/


		/*Start of CABLE_CHECK_MESSAGE*/
		case CABLE_CHECK_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of CableCheckRes Message */
				V2G_Doc.V2G_Message.Body.CableCheckRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.CableCheckRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.CableCheckRes.EVSEProcessing=iso1EVSEProcessingType_Finished;
				V2G_Doc.V2G_Message.Body.CableCheckRes.DC_EVSEStatus.EVSEIsolationStatus_isUsed=USED;
				V2G_Doc.V2G_Message.Body.CableCheckRes.DC_EVSEStatus.EVSEIsolationStatus=iso1isolationLevelType_Valid;
				V2G_Doc.V2G_Message.Body.CableCheckRes.DC_EVSEStatus.NotificationMaxDelay=0xAABB;
				V2G_Doc.V2G_Message.Body.CableCheckRes.DC_EVSEStatus.EVSENotification=iso1EVSENotificationType_None;
				V2G_Doc.V2G_Message.Body.CableCheckRes.DC_EVSEStatus.EVSEStatusCode=iso1DC_EVSEStatusCodeType_EVSE_Ready;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,CABLE_CHECK_MESSAGE);
			}
			break;
		}/*End of CABLE_CHECK_MESSAGE*/

		/*Start of PRE_CHARGE_MESSAGE*/
		case PRE_CHARGE_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of PreChargeRes Message */
				V2G_Doc.V2G_Message.Body.PreChargeRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.PreChargeRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.PreChargeRes.DC_EVSEStatus.EVSEIsolationStatus_isUsed=USED;
				V2G_Doc.V2G_Message.Body.PreChargeRes.DC_EVSEStatus.EVSEIsolationStatus=iso1isolationLevelType_Valid;
				V2G_Doc.V2G_Message.Body.PreChargeRes.DC_EVSEStatus.NotificationMaxDelay=0xAABB;
				V2G_Doc.V2G_Message.Body.PreChargeRes.DC_EVSEStatus.EVSENotification=iso1EVSENotificationType_None;
				V2G_Doc.V2G_Message.Body.PreChargeRes.DC_EVSEStatus.EVSEStatusCode=iso1DC_EVSEStatusCodeType_EVSE_Ready;
				V2G_Doc.V2G_Message.Body.PreChargeRes.EVSEPresentVoltage.Multiplier=0xBC;
				V2G_Doc.V2G_Message.Body.PreChargeRes.EVSEPresentVoltage.Unit=iso1unitSymbolType_m;
				V2G_Doc.V2G_Message.Body.PreChargeRes.EVSEPresentVoltage.Value=0xDEAD;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,PRE_CHARGE_MESSAGE);
			}
			break;
		} /*End of PRE_CHARGE_MESSAGE*/

		/*Start of POWER_DELIVERY_MESSAGE*/
		case POWER_DELIVERY_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of PowerDeliveryRes Message */
				V2G_Doc.V2G_Message.Body.PowerDeliveryRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				if( ((struct iso1EXIDocument *)V2G_Document)->V2G_Message.Body.PowerDeliveryReq.ChargeProgress==iso1chargeProgressType_Start){
					/* Open Relay Signal */
					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);

					V2G_Doc.V2G_Message.Body.PowerDeliveryRes.EVSEStatus.EVSENotification=iso1EVSENotificationType_None;
					V2G_Doc.V2G_Message.Body.PowerDeliveryRes.EVSEStatus.NotificationMaxDelay=0xEA;
				}
				// in case of evcc request to terminate power delivery
				else if(((struct iso1EXIDocument *)V2G_Document)->V2G_Message.Body.PowerDeliveryReq.ChargeProgress==iso1chargeProgressType_Stop){
					/* Close Relay Signal */
					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);

					V2G_Doc.V2G_Message.Body.PowerDeliveryRes.EVSEStatus.EVSENotification=iso1EVSENotificationType_StopCharging;
					V2G_Doc.V2G_Message.Body.PowerDeliveryRes.EVSEStatus.NotificationMaxDelay=0x00;
				}
				else{
					// Do nothing
				}
				V2G_Doc.V2G_Message.Body.PowerDeliveryRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.PowerDeliveryRes.EVSEStatus_isUsed=USED;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse(&V2G_Doc,POWER_DELIVERY_MESSAGE);
			}
			break;
		} /*End of POWER_DELIVERY_MESSAGE*/

		/*Start of CURRENT_DEMAND_MESSAGE*/
		case CURRENT_DEMAND_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of CurrentDemandRes Message */
				V2G_Doc.V2G_Message.Body.CurrentDemandRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.DC_EVSEStatus.EVSEIsolationStatus_isUsed=USED;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.DC_EVSEStatus.EVSEIsolationStatus=iso1isolationLevelType_Valid;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.DC_EVSEStatus.NotificationMaxDelay=0xAABB;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.DC_EVSEStatus.EVSENotification=iso1EVSENotificationType_None;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.DC_EVSEStatus.EVSEStatusCode=iso1DC_EVSEStatusCodeType_EVSE_Shutdown;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPresentVoltage.Multiplier=0xBC;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPresentVoltage.Unit=iso1unitSymbolType_V;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPresentVoltage.Value=0xDEAD;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPresentCurrent.Multiplier=0xBC;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPresentCurrent.Unit=iso1unitSymbolType_A;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPresentCurrent.Value=0xDEAD;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPowerLimitAchieved=FALSE;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSECurrentLimitAchieved=FALSE;
				V2G_Doc.V2G_Message.Body.CurrentDemandRes.EVSEPowerLimitAchieved=FALSE;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,CURRENT_DEMAND_MESSAGE);
			}
			break;
		}/*End of CURRENT_DEMAND_MESSAGE*/

		/* Start of WELDING_DETECTION_MESSAGE*/
		case WELDING_DETECTION_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of WeldingDetectionRes Message */
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.ResponseCode=iso1responseCodeType_OK;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.DC_EVSEStatus.EVSEIsolationStatus_isUsed=USED;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.DC_EVSEStatus.EVSEIsolationStatus=iso1isolationLevelType_Valid;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.DC_EVSEStatus.NotificationMaxDelay=0xAABB;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.DC_EVSEStatus.EVSENotification=iso1EVSENotificationType_None;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.DC_EVSEStatus.EVSEStatusCode=iso1DC_EVSEStatusCodeType_EVSE_Shutdown;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.EVSEPresentVoltage.Multiplier=0xBC;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.EVSEPresentVoltage.Unit=iso1unitSymbolType_m;
				V2G_Doc.V2G_Message.Body.WeldingDetectionRes.EVSEPresentVoltage.Value=0xDEAD;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,WELDING_DETECTION_MESSAGE);
			}
			break;

		}/* Start of WELDING_DETECTION_MESSAGE */

		/*Start of SESSION_STOP_MESSAGE*/
		case SESSION_STOP_MESSAGE:{
			/*Read Data*/
			if(DATA_ERROR){
				/* Future Work */
			}
			else{
				/* Clear Document */
				memset(&V2G_Doc,0,sizeof(V2G_Doc));

				/* Enable Usage of V2G_Message */
				V2G_Doc.V2G_Message_isUsed=USED;

				/* Enable Usage of SessionStopRes Message */
				V2G_Doc.V2G_Message.Body.SessionStopRes_isUsed=USED;

				/* Prepare Header */
				Prepare_Header();

				/* Prepare Data */
				V2G_Doc.V2G_Message.Body.SessionStopRes.ResponseCode=iso1responseCodeType_OK;

				/* Send data to rte in order to send it to service swc*/
				Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,SESSION_STOP_MESSAGE);
			}
			break;
		}/*End of SESSION_STOP_MESSAGE*/
		}

	}
	else if((Message_Indication==TRUE) && (Error_Indication==CHRGM_SequenceError) ){
		switch(Message_Name){
		case SUPPORTED_APP_PROTOCOL_MESSAGE:
			/* Intiate Response */
			memset(&Supported_App_Protocol_Res_Data,0,sizeof(Supported_App_Protocol_Res_Data));
			Supported_App_Protocol_Res_Data.MessageName=SUPPORTED_APP_PROTOCOL_MESSAGE;
			Supported_App_Protocol_Res_Data.ResponseCode=FAILED_SequenceError;

			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&Supported_App_Protocol_Res_Data,SUPPORTED_APP_PROTOCOL_MESSAGE);
			break;

		case SESSION_SETUP_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of Session Setup Response */
			V2G_Doc.V2G_Message.Body.SessionSetupRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.SessionSetupRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,SESSION_SETUP_MESSAGE);
			break;

		case SERVICE_DISCOVERY_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of ServiceDiscoveryRes Message */
			V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.ServiceDiscoveryRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,SERVICE_DISCOVERY_MESSAGE);
			break;

		case PAYMENT_SELECTION_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of PaymentServiceSelectionRes Message */
			V2G_Doc.V2G_Message.Body.PaymentServiceSelectionRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.PaymentServiceSelectionRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,PAYMENT_SELECTION_MESSAGE );
			break;

		case PAYMENT_DETAILS_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of PaymentDetailsRes Message */
			V2G_Doc.V2G_Message.Body.PaymentDetailsRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.PaymentDetailsRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,PAYMENT_DETAILS_MESSAGE);
			break;

		case AUTHORIZATION_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of AuthorizationRes Message */
			V2G_Doc.V2G_Message.Body.AuthorizationRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.AuthorizationRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,AUTHORIZATION_MESSAGE);
			break;

		case CHARGE_PARAMETER_DISCOVERY_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of ChargeParameterDiscoveryRes Message */
			V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.ChargeParameterDiscoveryRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,CHARGE_PARAMETER_DISCOVERY_MESSAGE);
			break;

		case CABLE_CHECK_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of CableCheckRes Message */
			V2G_Doc.V2G_Message.Body.CableCheckRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.CableCheckRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse ( &V2G_Doc,CABLE_CHECK_MESSAGE);
			break;

		case PRE_CHARGE_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of PreChargeRes Message */
			V2G_Doc.V2G_Message.Body.PreChargeRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.PreChargeRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,PRE_CHARGE_MESSAGE );
			break;

		case POWER_DELIVERY_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of PowerDeliveryRes Message */
			V2G_Doc.V2G_Message.Body.PowerDeliveryRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.PowerDeliveryRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,POWER_DELIVERY_MESSAGE );
			break;

		case CURRENT_DEMAND_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of CurrentDemandRes Message */
			V2G_Doc.V2G_Message.Body.CurrentDemandRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.CurrentDemandRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,CURRENT_DEMAND_MESSAGE );
			break;

		case WELDING_DETECTION_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of WeldingDetection Response Message */
			V2G_Doc.V2G_Message.Body.WeldingDetectionRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.WeldingDetectionRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,WELDING_DETECTION_MESSAGE);
			break;

		case SESSION_STOP_MESSAGE:
			/* Clear Document */
			memset(&V2G_Doc,0,sizeof(V2G_Doc));

			/* Enable Usage of V2G_Message */
			V2G_Doc.V2G_Message_isUsed=USED;

			/* Enable Usage of SessionStop Response Message */
			V2G_Doc.V2G_Message.Body.SessionStopRes_isUsed=USED;

			/* Prepare Header */
			Prepare_Header();

			/* Prepare Response Code */
			V2G_Doc.V2G_Message.Body.SessionStopRes.ResponseCode=iso1responseCodeType_FAILED_SequenceError;

			/* Send data to rte in order to send it to service swc*/
			Rte_Call_Charging_Station_State_Machine_Swc_RP_CS_ResponseData_SendResponse (&V2G_Doc,SESSION_STOP_MESSAGE);
			break;
		}
	}
	else if( (Message_Indication==FALSE) && (Error_Indication!=CHRGM_NoError) ){
		/*there is a chrgM error*/
		ShowChrgMError(Error_Indication);
	}
	else{
		/*do nothing*/
	}
}
