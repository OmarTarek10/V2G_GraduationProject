 /******************************************************************************
 *
 * Module: TcpIp
 *
 * File Name: IpSec.h
 *
 * Description: header file for the IP Security
 *
 * Author: Kareem Azab
 *
 *******************************************************************************/

#ifndef IPSEC_H_
#define IPSEC_H_

/*******************************************************************************
 *                              Includes                               *
 *******************************************************************************/
#include "TcpIp_Cfg.h"
#include "csmstub.h"
#include "Std_Types.h"
#include "Platform_Types.h"
#include "TcpIp.h"
#include <time.h>
#include "CryptoDriver/Crypto_Cfg.h"




typedef enum
{
   IPSEC_MODE_INVALID   = 0,
   IPSEC_MODE_TUNNEL    = 1,
   IPSEC_MODE_TRANSPORT = 2
} Ipsec_Mode;


typedef enum
{
   IPSEC_POLICY_ACTION_INVALID = 0,
   IPSEC_POLICY_ACTION_DISCARD = 1,
   IPSEC_POLICY_ACTION_BYPASS  = 2,
   IPSEC_POLICY_ACTION_PROTECT = 3
} Ipsec_Policy_Action;

typedef enum
{
   IPSEC_PROTOCOL_INVALID = 0,
   IPSEC_PROTOCOL_AH      = 2,
   IPSEC_PROTOCOL_ESP     = 3
} Ipsec_Protocol;


typedef enum
{
  IKE_AUTH_METHOD_RSA = 1,                ///< RSA Digital Signature
  IKE_AUTH_METHOD_SHARED_KEY = 2,         ///< Shared Key Message Integrity Code
  IKE_AUTH_METHOD_DSS = 3,                ///< DSS Digital Signature
  IKE_AUTH_METHOD_ECDSA_P256_SHA256 = 9,  ///< ECDSA with SHA-256 on the P-256 curve
  IKE_AUTH_METHOD_ECDSA_P384_SHA384 = 10, ///< ECDSA with SHA-384 on the P-384 curve
  IKE_AUTH_METHOD_ECDSA_P521_SHA512 = 11, ///< ECDSA with SHA-512 on the P-521 curve
  IKE_AUTH_METHOD_GSPAM = 12,             ///< Generic Secure Password Authentication Method
  IKE_AUTH_METHOD_NULL = 13,              ///< NULL Authentication
  IKE_AUTH_METHOD_DIGITAL_SIGN = 14       ///< Digital Signature
} IKE_Auth_Method;





typedef enum
{
  IKE_ID_TYPE_INVALID = 0,
  IKE_ID_TYPE_IPV4_ADDR = 1,
  IKE_ID_TYPE_FQDN = 2,
  IKE_ID_TYPE_RFC822_ADDR = 3,
  IKE_ID_TYPE_IPV6_ADDR = 5,
  IKE_ID_TYPE_DER_ASN1_DN = 9,
  IKE_ID_TYPE_DER_ASN1_GN = 10,
  IKE_ID_TYPE_KEY_ID = 11,
  IKE_ID_TYPE_FC_NAME = 12,
  IKE_ID_TYPE_NULL = 13
} IKE_Id_Type;







/**
 * @brief Transform attribute
 **/

typedef struct  __attribute__((packed))
{
   uint16 type;   //0-1
   uint16 length; //2-3
   uint32 value; //4
} IKE_Transform_Attr;


/**
 * @brief Transform substructure
 **/

typedef struct  __attribute__((packed))
{
   uint8 lastSubstruc;     //0
   uint8 reserved1;        //1
   uint16 transformLength; //2-3
   uint8 transformType;    //4
   uint8 reserved2;        //5
   uint16 transformId;     //6-7
} IKE_Transform;





typedef struct  __attribute__((packed))
{
   uint8 lastSubstruc;    //0
   uint8 reserved;        //1
   uint16 proposalLength; //2-3
   uint8 proposalNum;     //4
   uint8 protocolId;      //5
   uint8 spiSize;         //6
   uint8 numTransforms;   //7
   uint8 spi[];           //8

} IKE_Proposal;


typedef struct  __attribute__((packed))
{
   uint8 nextPayload;
   uint8 critical : 1;
   uint8 reserved : 7;
   uint16 payloadLength;
}IKE_Payload_Header;


typedef enum
{
   IKE_IP_PROTOCOL_ID_ICMP = 1,
   IKE_IP_PROTOCOL_ID_TCP = 6,
   IKE_IP_PROTOCOL_ID_UDP = 17,
   IKE_IP_PROTOCOL_ID_ICMPV6 = 58,
} IKE_Ip_Protocol_Id;


typedef enum
{
   IKE_TS_TYPE_IPV4_ADDR_RANGE = 7,
   IKE_TS_TYPE_IPV6_ADDR_RANGE = 8
} IKE_Ts_Type;






typedef struct  __attribute__((packed))
{
  uint8 tsType;          // 0
  uint8 ipProtocolId;    // 1
  uint16 selectorLength; // 2-3
  uint16 startPort;      // 4-5
  uint16 endPort;        // 6-7
  IPv6Addr startAddr;     // 8
  IPv6Addr endAddr;
}
IKE_Ts;


typedef struct  __attribute__((packed))
{
   uint8 authMethod;      // 4
   uint8 reserved[3];     // 4-7
   uint8 authData[32];      // 8
}
IKE_Auth_Payload;

typedef struct  __attribute__((packed))
{

  uint8 numTs;              // 4
  uint8 reserved[3];        // 5-7
  IKE_Ts trafficSelectors; // 8
}
IKE_Ts_Payload;

typedef struct  __attribute__((packed))
{
	IKE_Payload_Header header; // 0-3
   uint8 certEncoding;    // 4
   uint8 certData[];      // 5
}
IKE_Cert_Payload;



typedef struct  __attribute__((packed))
{
   uint8 idType;          // 4
   uint8 reserved[3];     // 5-7
   uint8 idData[16];        // 8
}
IKE_Id_Payload;


typedef struct  __attribute__((packed))
  {
   IKE_Proposal proposals;     // 4
  }
  IKE_Sa_Payload;


typedef struct  __attribute__((packed))
{
   uint16 dhGroupNum;       //4-5
   uint16 reserved;         //6-7
   uint8 keyExchangeData[32]; //8
} IKE_KE_Payload;



typedef enum {
    IKE_HEADER_FLAG_INITIATOR = 0x08, // Message from the initiator of an IKE SA
    IKE_HEADER_FLAG_VERSION = 0x10,   // Version flag
    IKE_HEADER_FLAG_RESPONSE = 0x20,  // Message is a response to a request
    // Additional flags can be added as needed
} IKE_Header_Flags;



typedef enum {
    IKE_PAYLOAD_TYPE_LAST = 0,     ///< No Next Payload
    IKE_PAYLOAD_TYPE_SA = 33,      ///< Security Association
    IKE_PAYLOAD_TYPE_KE = 34,      ///< Key Exchange
    IKE_PAYLOAD_TYPE_IDI = 35,     ///< Identification - Initiator
    IKE_PAYLOAD_TYPE_IDR = 36,     ///< Identification - Responder
    IKE_PAYLOAD_TYPE_CERT = 37,    ///< Certificate
    IKE_PAYLOAD_TYPE_CERTREQ = 38, ///< Certificate Request
    IKE_PAYLOAD_TYPE_AUTH = 39,    ///< Authentication
    IKE_PAYLOAD_TYPE_NONCE = 40,   ///< Nonce
    IKE_PAYLOAD_TYPE_N = 41,       ///< Notify
    IKE_PAYLOAD_TYPE_D = 42,       ///< Delete
    IKE_PAYLOAD_TYPE_V = 43,       ///< Vendor ID
    IKE_PAYLOAD_TYPE_TSI = 44,     ///< Traffic Selector - Initiator
    IKE_PAYLOAD_TYPE_TSR = 45,     ///< Traffic Selector - Responder
    IKE_PAYLOAD_TYPE_SK = 46,      ///< Encrypted and Authenticated
    IKE_PAYLOAD_TYPE_CP = 47,      ///< Configuration
    IKE_PAYLOAD_TYPE_EAP = 48,     ///< Extensible Authentication
    IKE_PAYLOAD_TYPE_GSPM = 49,    ///< Generic Secure Password Method
    IKE_PAYLOAD_TYPE_SKF = 53,     ///< Encrypted and Authenticated Fragment
    IKE_PAYLOAD_TYPE_PS = 54       ///< Puzzle Solution

} IKE_Payloads;




typedef enum {
    IKE_EXCHANGE_TYPE_NONE = 0, // No exchange type
    IKE_EXCHANGE_TYPE_SA_INIT = 34, // SA_INIT exchange
    IKE_EXCHANGE_TYPE_AUTH = 35, // Authentication exchange
    IKE_EXCHANGE_TYPE_CREATE_CHILD_SA = 36, // Create Child SA exchange
    IKE_EXCHANGE_TYPE_INFORMATIONAL = 37, // Informational exchange

} IKE_Exchange_Type;

typedef struct __attribute__((packed)){
    uint64 initiator_spi; // Initiator's Security Parameter Index
    uint64 responder_spi; // Responder's Security Parameter Index
    IKE_Payloads next_payload;   // Type of the first payload in the message
    uint8 minorVersion : 4; // 17
    uint8 majorVersion : 4;        // Version of the IKE protocol
    IKE_Exchange_Type exchange_type;  // Type of IKE exchange
    IKE_Header_Flags flags;          // Flags for this message
    uint32 message_id;    // Message ID
    uint32 length;        // Length of the total message (header + payloads)
} IKEv2Header;



typedef struct{
	 Ipsec_Policy_Action policyAction;
	 Ipsec_Mode mode;                 //<IPsec mode (tunnel or transport)
	 Ipsec_Protocol protocol;         //<Security protocol (AH or ESP)
	 IPv6Addr addr;
	 uint32 seq;
	 uint8 flag;
	 uint32 spi;


}IpsecSpdEntry;


typedef struct __attribute__((packed))
{
   uint32 spi;          //0-3
   uint32 seqNum;       //4-7
   uint8 payloadData[]; //8
} EspHeader;


typedef struct __attribute__((packed))
{
   uint8 padLength;  //0
   uint8 nextHeader; //1
   uint8 icv[];      //2
} EspTrailer;
typedef struct  {
    uint64 initiatorSpi;
    uint64 responderSpi;
    IPv6Addr address; // IPv6 address
    uint16 remotePort;
    uint16 encAlgId;  ///< Encryption algorithm
    uint16 prfAlgId;  ///< Pseudorandom function
    uint16 authAlgId; ///< Integrity algorithm
    uint16 dhGroupNum; ///< Diffie-Hellman group number

}SecurityAssociation;

typedef enum{
	NOT_INIT_TABLE,
	INIT_TABLE
}Table_State_Type;




/*******************************************************************************
 *   		          IKEV2 APIs Prototypes          	 	  	   *
 *******************************************************************************/

Std_ReturnType addSpdEntry(IPv6Addr addr);
void initializeSpdTable();
IpsecSpdEntry* findSpdEntry(IPv6Addr addr);
void initializeSACache();
Std_ReturnType addSA(uint64 initiatorSpi);
SecurityAssociation* findSA(uint64 initiatorSpi);

Std_ReturnType IKEV2_Init(IPv6Addr addr);

Std_ReturnType IpSec_Init();


Std_ReturnType IKEV2_SA_Req(SecurityAssociation* SA,uint8 * request);

Std_ReturnType IKEV2_SA_Res(SecurityAssociation* SA,uint8 * request);

Std_ReturnType IKEV2_Auth_Req_test(SecurityAssociation* SA,uint8 * request,uint8 * length);

Std_ReturnType IKEV2_Auth_Res_test(SecurityAssociation* SA,uint8 * request,uint8 * length);

Std_ReturnType IKEV2_Auth_Req(SecurityAssociation* SA,uint8 * request);

Std_ReturnType IKEV2_Auth_Res(SecurityAssociation* SA,uint8 * request);

Std_ReturnType espEncryptPacket(uint8 * data,uint8 datalen,uint8 *packet,uint8 *packet_len);

Std_ReturnType espDecryptPacket(uint8 * data, uint8 data_len,const uint8 *packet);

Std_ReturnType IKEV2_Create_ChildSa();

extern IPv6Addr addr;

#endif /* IPSEC_H_ */
