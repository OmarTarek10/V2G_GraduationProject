/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_Cfg.h
 *
 * Description: Charging Manager Pre-Compile Configurations
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef CHRGM_CFG_H_
#define CHRGM_CFG_H_

/*
 * Module Version 1.0.0
 */
#define CHRGM_CFG_SW_MAJOR_VERSION              (1U)
#define CHRGM_CFG_SW_MINOR_VERSION              (0U)
#define CHRGM_CFG_SW_PATCH_VERSION              (0U)

/*
 * AUTOSAR Version 1.0.0
 */
#define CHRGM_CFG_AR_RELEASE_MAJOR_VERSION      (1U)
#define CHRGM_CFG_AR_RELEASE_MINOR_VERSION      (0U)
#define CHRGM_CFG_AR_RELEASE_PATCH_VERSION      (0U)

/* Pre-compile option for Development Error Detect */
#define CHRGM_DEV_ERROR_DETECT                  (STD_ON)
/* Pre-compile option for Version Info API */
#define CHRGM_VERSION_INFO_API                  (STD_OFF)
/* Pre-compile option for Main Function Cycle Time */
#define CHRGM_MAIN_FUNCTION_CYCLE_TIME          (float32)(0.005)
/* Pre-compile configuration for Number of Timers used */
#define CHRGM_CONFIGURED_TIMERS                 (16U)
/* Pre-compile configuration for V2G Transport Protocol used */
#define CHRGM_V2G_TCP_TRANSPORT_PROTOCOL        (STD_ON)
/* Pre-compile configuration for V2G Security used */
#define CHRGM_V2G_TLS_SECURITY                  (STD_OFF)
/* Pre-compile configuration for Number of Supported App Protocols */
#define CHRGM_SUPPORTED_APP_PROTOCOL_NUMBER     (1u)
/* Pre-compile configuration for retransmission if error is found */
#define CHRGM_RETRY_IF_ERROR          			(STD_ON)
/* Pre-compile COnfiguration for the use of SECC Discovery Protocol (SDP)*/
#define CHRGM_SDP_USED                          (STD_OFF)

/* All timers Indices in ChrgM Config Structure */
#define V2G_SECC_COMMUNICATION_SETUP_TIMER_INDEX 				(0u)
#define V2G_SECC_CABLE_CHECK_TIMER_INDEX 						(1u)
#define V2G_SECC_PRE_CHARGE_TIMER_INDEX 						(2u)
#define V2G_SECC_ONGOING_TIMER_INDEX 							(3u)
#define CHRGM_V2G_SECC_SUPPORTED_APP_PROTOCOL_TIMER_INDEX 		(4u)
#define CHRGM_V2G_SECC_SESSION_SETUP_TIMER_INDEX 				(5u)
#define CHRGM_V2G_SECC_SERVICE_DISCOVERY_TIMER_INDEX 			(6u)
#define CHRGM_V2G_SECC_PAYMENT_SERVICE_SELECTION_TIMER_INDEX 	(7u)
#define CHRGM_V2G_SECC_PAYMENT_DETAILS_TIMER_INDEX 				(8u)
#define CHRGM_V2G_SECC_AUTHORIZATION_TIMER_INDEX 				(9u)
#define CHRGM_V2G_SECC_CHARGE_PARAMETER_DISCOVERY_TIMER_INDEX 	(10u)
#define CHRGM_V2G_SECC_POWER_DELIVERY_TIMER_INDEX 				(11u)
#define CHRGM_V2G_SECC_CURRENT_DEMAND_TIMER_INDEX 				(12u)
#define CHRGM_V2G_SECC_WELDING_DETECTION_TIMER_INDEX 			(13u)
#define CHRGM_V2G_SECC_SESSION_STOP_TIMER_INDEX 				(14u)
#define CHRGM_V2G_SECC_SEQUENCE_TIMER_INDEX                     (15u)

/* All Timers values in ChrgM Config Structure */
#define V2G_SECC_COMMUNICATION_SETUP_TIMER_VALUE				(float32)(18)
#define V2G_SECC_CABLE_CHECK_TIMER_VALUE						(float32)(1.5)
#define V2G_SECC_PRE_CHARGE_TIMER_VALUE							(float32)(1.5)
#define V2G_SECC_ONGOING_TIMER_VALUE							(float32)(55)
#define CHRGM_V2G_SECC_SUPPORTED_APP_PROTOCOL_TIMER_VALUE		(float32)(1.5)
#define CHRGM_V2G_SECC_SESSION_SETUP_TIMER_VALUE				(float32)(1.5)
#define CHRGM_V2G_SECC_SERVICE_DISCOVERY_TIMER_VALUE			(float32)(1.5)
#define CHRGM_V2G_SECC_PAYMENT_SERVICE_SELECTION_TIMER_VALUE	(float32)(1.5)
#define CHRGM_V2G_SECC_PAYMENT_DETAILS_TIMER_VALUE				(float32)(4.5)
#define CHRGM_V2G_SECC_AUTHORIZATION_TIMER_VALUE				(float32)(1.5)
#define CHRGM_V2G_SECC_CHARGE_PARAMETER_DISCOVERY_TIMER_VALUE	(float32)(1.5)
#define CHRGM_V2G_SECC_POWER_DELIVERY_TIMER_VALUE				(float32)(4.5)
#define CHRGM_V2G_SECC_CURRENT_DEMAND_TIMER_VALUE				(float32)(0.025)
#define CHRGM_V2G_SECC_WELDING_DETECTION_TIMER_VALUE			(float32)(1.5)
#define CHRGM_V2G_SECC_SESSION_STOP_TIMER_VALUE					(float32)(1.5)
#define CHRGM_V2G_SECC_SEQUENCE_TIMER_VALUE                     (float32)(60)

/* ChrgM Buffer Sizes */
#define BUFFER_SIZE                              (1024U)


#endif /* CHRGM_CFG_H_ */
