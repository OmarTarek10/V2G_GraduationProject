/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: SchM_ChrgM.h
 *
 * Description: Header file for Scheduler ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef SCHM_CHRGM_H_
#define SCHM_CHRGM_H_

void ChrgM_MainFunction_Rx (void);

#endif /* SCHM_CHRGM_H_ */
