/******************************************************************************
*
* Module: Wireless Ethernet
*
* File Name: Weth.h
*
* Description: Header File For the Wireless Ethernet Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/

#ifndef WETH_H_
#define WETH_H_


/* Id for the company in the AUTOSAR
* for example Ahmed Ehab El Gowely's ID = 1000 :) */
#define WETH_VENDOR_ID    (1000U)

/* WEth Module Id */
#define WETH_MODULE_ID    (87U)

/* WEth Instance Id */
#define WETH_INSTANCE_ID  (0U)


/*
* Module Version 1.0.0
*
*/
#define WETH_SW_MAJOR_VERSION           (1U)
#define WETH_SW_MINOR_VERSION           (0U)
#define WETH_SW_PATCH_VERSION           (0U)


/*
* AUTOSAR Version R22-11
*/
#define WETH_AR_RELEASE_MAJOR_VERSION   (1U)
#define WETH_AR_RELEASE_MINOR_VERSION   (0U)
#define WETH_AR_RELEASE_PATCH_VERSION   (0U)


#include "WEth_Cfg.h"
#include "WEth_PbCfg.h"

/* Standard AUTOSAR types */
#include "Std_Types.h"

/* AUTOSAR checking between Std_Types.h and WEth.h
*
*/

#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != WETH_AR_RELEASE_MAJOR_VERSION)\
||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != WETH_AR_RELEASE_MINOR_VERSION)\
  ||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != WETH_AR_RELEASE_PATCH_VERSION))
//#error "The AR version of Std_Types.h does not match the expected version"
#endif

#include "WEth_GeneralTypes.h"
/* AUTOSAR checking between WEth_GeneralTypes.h and WEth.h
*
*/

#if ((WETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != WETH_AR_RELEASE_MAJOR_VERSION)\
||  (WETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != WETH_AR_RELEASE_MINOR_VERSION)\
  ||  (WETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != WETH_AR_RELEASE_PATCH_VERSION))
#error "The AR version of WEth_GeneralTypes.h does not match the expected version"
#endif


#include "Eth_GeneralTypes.h"

/* AUTOSAR checking between Eth_GeneralTypes.h and WEth.h
*
*/

#if ((ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != WETH_AR_RELEASE_MAJOR_VERSION)\
||  (ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != WETH_AR_RELEASE_MINOR_VERSION)\
  ||  (ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != WETH_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Eth_GeneralTypes.h does not match the expected version"
#endif


/******************************************************************************
*                      API Service Id Macros                                 *
******************************************************************************/
/* Service ID for WEth Init */
#define WETH_INIT_SID						(0x01U)
/* Service ID for WEth Set Controller Mode */
#define WETH_SET_CONTROLLER_MODE_SID		                (0x03U)
/* Service ID for WEth Get Controller Mode */
#define WETH_GET_CONTROLLER_MODE_SID		                (0x04U)
/* Service ID for WEth Get Physical Address */
#define WETH_GET_PHYS_ADDR_SID				        (0x08U)
/* Service ID for WEth Set Physical Address*/
#define WETH_SET_PHYS_ADDR_SID				        (0x13U)
/* Service ID for WEth provide Tx buffer */
#define WETH_PROVIDE_TX_BUFFER_SID			        (0x09U)
/* Service ID for WEth Transmit */
#define WETH_TRANSMIT_SID					(0x14U)
/* Service ID for WEth Tx Confirmation */
#define WETH_TX_CONFIRMATION_SID			        (0x02U)
/* Service ID for WEth Receive */
#define WETH_RECEIVE_SID					(0x05U)
/* Service ID for WEth Get Buffer WRx Parameters */
#define WETH_GET_BUF_WRX_PARAMS_SID			        (0x34U)
/* Service ID for WEth Get Buffer WTx Parameters */
#define WETH_GET_BUF_WTX_PARAMS_SID			        (0x35U)
/* Service ID for WEth Set Buffer WTx Parameters */
#define WETH_SET_BUF_WTX_PARAMS_SID			        (0x36U)
/* Service ID for WEth Get Version Info */
#define WETH_GET_VERSION_INFO_SID			        (0x0DU)
/* Service ID for WEth Main Function Info */
#define WETH_MAIN_FUNCTION_SID				        (0x0AU)
/*******************************************************************************
*                      DET Error Codes                                        *
*******************************************************************************/
/* API service  called with invalid controller index*/
#define WETH_E_INV_CTRL_ID					(0x01U)
/*API service called when WEth module was not initialized*/
#define WETH_E_UNINIT						(0x02U)
/* API service called with invalid pointer in parameter list */
#define WETH_E_PARAM_POINTER				        (0x03U)
/* API service called with invalisd parameter in parameter list */
#define WETH_E_INV_PARAM					(0x04U)
/* API service called withController in  invalid Mode*/
#define	WETH_E_INV_MODE						(0x05U)

/*******************************************************************************
*                      DEM Error Codes                                        *
*******************************************************************************/
/*
SWS_WEth_00173
WETH_E_ACCESS
*/

/*******************************************************************************
*                      Module Definitions                                    *
*******************************************************************************/
#define MAX_FRAG_SIZE  (4U)

#define MAX_LAST_FRAG_SIZE (250)

#define RESERVED_BUFFER         TRUE

#define FREE_BUFFER             FALSE
/*******************************************************************************
*                              Module Data Types                              *
*******************************************************************************/

typedef enum
{
  WETH_UINITIALIZED, WETH_INITIALIZED
}WEth_State_Type;

/*
typedef struct {
WEth_CtrlConfigType_s CtrlConfig[WETH_CONTROLLER_SIZE];
}WEth_ConfigType;
*/

/*******************************************************************************
*                      Function Prototypes                                    *
*******************************************************************************/

/************************************************************************************
* Service Name: WEth_Init
* Service ID[hex]: 0x01
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CfgPtr - Pointer to post-build configuration data
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Initializes the Wireless Ethernet Driver.
* Requirements: SWS_WEth_00027,SWS_WEth_00028, SWS_WEth_00029,
*  			 ,SWS_WEth_00031
************************************************************************************/
void WEth_Init (const WEth_ConfigType* CfgPtr);

/************************************************************************************
* Service Name: WEth_SetControllerMode
* Service ID[hex]: 0x03
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					CtrlMode - ETH_MODE_DOWN: disable the controller
* 							   ETH_MODE_ACTIVE: enable the controller
* Parameters (inout): None
* Parameters (out): None
* Return value:Std_ReturnType - E_OK: success
E_NOT_OK: controller mode could not be changed
* Description:  Enables / disables the indexed controller
* Requirements: SWS_WEth_00041,SWS_WEth_00042, SWS_WEth_00043,
*  			 ,SWS_WEth_00044,SWS_WEth_00045,SWS_WEth_00168
************************************************************************************/
Std_ReturnType WEth_SetControllerMode (uint8 CtrlId,Eth_ModeType CtrlMode);

/************************************************************************************
* Service Name: WEth_GetControllerMode
* Service ID[hex]: 0x04
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): CtrlModePtr - ETH_MODE_DOWN: the controller is disabled
* 								   ETH_MODE_ACTIVE: the controller is enabled
* Return value:Std_ReturnType - E_OK: success
E_NOT_OK:  controller mode could not be obtained

* Description:  Obtains the state of the indexed controller
* Requirements: SWS_WEth_00046,SWS_WEth_00047, SWS_WEth_00048,
*  			 ,SWS_WEth_00049,SWS_WEth_00050,SWS_WEth_00051
************************************************************************************/
Std_ReturnType WEth_GetControllerMode (uint8 CtrlId,Eth_ModeType* CtrlModePtr);

/************************************************************************************
* Service Name: WEth_GetPhysAddr
* Service ID[hex]: 0x08
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): PhysAddrPtr - Physical source address (MAC address) in network byte order
* Return value: None
* Description:  Obtains the physical source address used by the indexed controller.
* Requirements: SWS_WEth_00052,SWS_WEth_00053, SWS_WEth_00054,
*  			 ,SWS_WEth_00055,SWS_WEth_00056,SWS_WEth_00057
************************************************************************************/
void WEth_GetPhysAddr (uint8 CtrlId,uint8* PhysAddrPtr);

/************************************************************************************
* Service Name: WEth_SetPhysAddr
* Service ID[hex]: 0x13
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					PhysAddrPtr - Pointer to memory containing the physical source address (MAC address) in network byte order.
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Sets the physical source address used by the indexed controller
* Requirements: SWS_WEth_00151,SWS_WEth_00139, SWS_WEth_00140,
*  			 ,SWS_WEth_00141,SWS_WEth_00142,SWS_WEth_00143
************************************************************************************/
void WEth_SetPhysAddr (uint8 CtrlId,const uint8* PhysAddrPtr);

/************************************************************************************
* Service Name: WEth_ProvideTxBuffer
* Service ID[hex]: 0x09
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					Priority Priority value used for selection of different wireless transmit queues
* Parameters (inout): LenBytePtr In: desired length in bytes, out: granted length in bytes
* Parameters (out): BufIdPtr - Index to the granted buffer resource. To be used for subsequent requests.
* 					 BufPtr - Pointer to the granted buffer.
* Return value: BufReq_ReturnType BUFREQ_OK: success
BUFREQ_E_NOT_OK: default error detected
BUFREQ_E_BUSY: all buffers in use
BUFREQ_E_OVFL: requested buffer too large
* Description: Provides access to a transmit buffer of the specified controller
* Requirements: SWS_WEth_00077,SWS_WEth_00078, SWS_WEth_00137
*  			 ,SWS_WEth_00079,SWS_WEth_00080,SWS_WEth_00081
*  			 ,SWS_WEth_00083,SWS_WEth_00084,SWS_WEth_00085,
*  			 ,SWS_WEth_00086,
************************************************************************************/
BufReq_ReturnType WEth_ProvideTxBuffer (uint8 CtrlId,uint8 Priority,Eth_BufIdxType* BufIdPtr,uint8** BufPtr,uint16* LenBytePtr);

/************************************************************************************
* Service Name: WEth_Transmit
* Service ID[hex]: 0x14
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					BufId - Index to the granted buffer resource. To be used for subsequent requests.
* 					FrameType - Ethernet frame type
* 					TxConfirmation - Activates transmission confirmation
* 					LenByte - Data length in byte (802.11 Header + Body, not including FCS)
* 					PhysAddrPtr - Physical target address (MAC address) in network byte order
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: transmission failed
* Description: Triggers transmission of a previously filled transmit buffer
* Requirements:  SWS_WEth_00087,SWS_WEth_00088, SWS_WEth_00138
*  			 ,SWS_WEth_00090,SWS_WEth_00091,SWS_WEth_00092
*  			 ,SWS_WEth_00093,SWS_WEth_00129,SWS_WEth_00094,
************************************************************************************/
Std_ReturnType WEth_Transmit (uint8 CtrlId,Eth_BufIdxType BufId,Eth_FrameType FrameType,boolean TxConfirmation,uint16 LenByte,const uint8* PhysAddrPtr);

/************************************************************************************
* Service Name: WEth_TxConfirmation
* Service ID[hex]: 0x02
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Triggers transmission of a previously filled transmit buffer
* Requirements:  SWS_WEth_00100,SWS_WEth_00101,SWS_WEth_00102
*  			 ,SWS_WEth_00103,SWS_WEth_00104,SWS_WEth_00134
*  			 ,SWS_WEth_00105,SWS_WEth_10063
************************************************************************************/
void WEth_TxConfirmation (uint8 CtrlId);

/************************************************************************************
* Service Name: WEth_Receive
* Service ID[hex]: 0x05
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* Parameters (inout): None
* Parameters (out): RxStatusPtr - Indicates whether a frame has been received and if so, whether more frames are available or frames got lost.
* Return value: None
* Description: Triggers frame reception
* Requirements:  SWS_WEth_00095,SWS_WEth_00096,SWS_WEth_00097
*  			 ,SWS_WEth_00132,SWS_WEth_00153,SWS_WEth_00099
*  			 ,SWS_WEth_10061
************************************************************************************/
void WEth_Receive (uint8 CtrlId,Eth_RxStatusType* RxStatusPtr);

/* !!!!ARE THESE FUNCS NEEDED!!!!*/
/************************************************************************************
* Service Name: WEth_GetBufWRxParams
* Service ID[hex]: 0x34
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					RxParamIds - IDs of the Parameter that are requested Parameters.
* 					NumParams - Number of Parameters that are requested
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: failed reading parameters
* Description: Read out values related to the receive direction for a received packet. For example, this could
be RSSI or Channel belonging to one single packet.This API is valid only within the context of
WEth_Receive
* Requirements:  SWS_WEth_10062,SWS_WEth_10039,SWS_WEth_10040
*  			 ,SWS_WEth_10041,SWS_WEth_10042
************************************************************************************/
Std_ReturnType WEth_GetBufWRxParams (uint8 CtrlId,const WEth_BufWRxParamIdType* RxParamIds,uint32* ParamValues,uint8 NumParams);

/************************************************************************************
* Service Name: WEth_GetBufWTxParams
* Service ID[hex]: 0x35
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					TxParamIds - IDs of the Parameter that are requested Parameters.
* 					NumParams - Number of Parameters that are requested
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: failed reading parameters
* Description: Read out values related to the transmit direction for a transmitted packet. For example, this
could be transaction ID belonging to one single packet.This API is valid only within the context
of WEth_TxConfirmation.
* Requirements:  SWS_WEth_10044,SWS_WEth_10046,SWS_WEth_10047
*  			 ,SWS_WEth_10048,SWS_WEth_10049
************************************************************************************/
Std_ReturnType WEth_GetBufWTxParams (uint8 CtrlId,const WEth_BufWTxParamIdType* TxParamIds,uint32* ParamValues,uint8 NumParams);
/************************************************************************************
* Service Name: WEth_SetBufWTxParams
* Service ID[hex]: 0x36
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlId - Index of the controller within the context of the Wireless Ethernet Driver.
* 					BufId - Index of the buffer resource
* 					TxParamIds - IDs of the Parameter that are requested Parameters.
* 					ParamValues - Values of the Parameters that are provided to the transmit radio
* 					NumParams - Number of Parameters that are requested
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: failed reading parameters
* Description: Set values related to the transmit direction for a specific buffer (packet to be sent). For example,
this can be the desired transmit power or the channel belonging to one single packet.
* Requirements:  SWS_WEth_10051,SWS_WEth_10053,SWS_WEth_10054
*  			 ,SWS_WEth_10055,SWS_WEth_10056,SWS_WEth_10057
************************************************************************************/
Std_ReturnType WEth_SetBufWTxParams (uint8 CtrlId,Eth_BufIdxType BufId,const WEth_BufWTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams);
/* !!!!ARE THESE FUNCS NEEDED!!!!*/

/************************************************************************************
* Service Name: WEth_GetVersionInfo
* Service ID[hex]: 0x0d
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): None
* Parameters (inout): None
* Parameters (out): VersionInfoPtr - Pointer to where to store the version information of this module.
* Return value: None
* Description: Returns the version information of this module.
* Requirements:  SWS_WEth_00106,SWS_WEth_00136
****************************************************************************************/
#if (WETH_WETH_VERSION_INFO_API	== STD_ON)
void WEth_GetVersionInfo (Std_VersionInfoType* VersionInfoPtr);
#endif


/*******************************************************************************
*                      Scheduled Functions Prototypes                         	*
*******************************************************************************/

/************************************************************************************
* Service Name: WEth_MainFunction
* Service ID[hex]: 0x0a
* Description: Support for indirect transmissions (extended frame timing constraints) and mechanisms for
channel selection when using multiple channels. Used for polling state changes. Calls EthIf_
CtrlModeIndication when the controller mode changed.
* Requirements:  SWS_WEth_00171
************************************************************************************/
void WEth_MainFunction (void);
//Available via SchM_WEth.h

/*******************************************************************************
*                      Private Functions Prototypes                         	*
*******************************************************************************/

/************************************************************************************
* Service Name: Fragment
* Description: The Function is used to fragment data into Frames of 250 Bytes.
* WARNING: This Function is Hardware Specific to this project as the MTU of the Wireless Module On ESP is 250 Bytes.
************************************************************************************/
Std_ReturnType Fragment(uint8* data ,uint16 Lenbyte);

/************************************************************************************
* Service Name: Defragment
* Description: The Function is used to Reassembly of data.
* WARNING: This Function is Hardware Specific to this project as the MTU of the Wireless Module On ESP is 250 Bytes.
************************************************************************************/
Std_ReturnType Defragment(uint8* data_out ,/* uint8* data_out,*/ uint16 Lenbyte ); //,size data in and out ,,ADD ARRAY SIZE)


/*******************************************************************************
*                      ISR Functions                                            *
*******************************************************************************/
/************************************************************************************
* Service Name: WEth_TxIrqHdlr
* Description: The Function is called by the hardware when a Transmission Interrupt Occurs.
************************************************************************************/
#if (ETHIF_ENABLE_TX_INTERRUPT == STD_ON)
void WEth_TxIrqHdlr (void);
#endif
/************************************************************************************
* Service Name: WEth_RxIrqHdlr
* Description: The Function is called by the hardware when a Recieve Interrupt Occurs.
************************************************************************************/
#if (ETHIF_ENABLE_RX_INTERRUPT == STD_ON)
void WEth_RxIrqHdlr (void);
#endif

void WEth_RxIrqHdlr (void);

#endif /* WETH_H_ */
