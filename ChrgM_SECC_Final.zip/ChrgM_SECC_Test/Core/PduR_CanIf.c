/******************************************************************************
 *
 * Module: PduR
 *
 * File Name: PduR_CanIf.c
 *
 * Description: Source file for PduR_CanIf.
 *
 * Author: Kareem Azab
 ******************************************************************************/

#include "PduR_CanIf.h"
#include "PduR_Pbcfg.h"
#include "PduR_Cfg.h"
#include "Com.h"
#include "Det.h"




#if(PduR_CanIfRxIndication_Supported)

void PduR_CanIfRxIndication (PduIdType RxPduId,const PduInfoType* PduInfoPtr){

	uint8 PduRRoutingPathIndex;

	if ( PduRState  == PDUR_ONLINE) {
		for (PduRRoutingPathIndex = 0; PduRRoutingPathIndex < PduRMaxRoutingPathCnt; PduRRoutingPathIndex++)
		{
			if (PduR.PduRRoutingTables.PduRRoutingTable[CanIf_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRSrcPdu.PduRSourcePduHandleId == RxPduId)
			{
				return Com_RxIndication( PduR.PduRRoutingTables.PduRRoutingTable[CanIf_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRDestPdu[0].PduRDestPduHandleId, PduInfoPtr);
			}
			else
			{
				/*MISRA Rule*/
			}
		}

	}
	else
	{
#if PduRDevErrorDetect
		Det_ReportError(PDUR_MODULE_ID, PDUR_INSTANCE_ID, PduR_CanIfRxIndication_SID, PDUR_E_UNINIT );

#endif
		return;
	}


}
#endif



#if(PduR_CanIfTriggerTransmit_Supported)

Std_ReturnType PduR_CanIfTriggerTransmit (PduIdType TxPduId,  PduInfoType* PduInfoPtr){

	uint8 PduRRoutingPathIndex;
	Std_ReturnType result=E_OK;
	if ( PduRState  == PDUR_ONLINE) {
		for (PduRRoutingPathIndex = 0; PduRRoutingPathIndex < PduRMaxRoutingPathCnt; PduRRoutingPathIndex++)
		{
			if (PduR.PduRRoutingTables.PduRRoutingTable[CanIf_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRSrcPdu.PduRSourcePduHandleId == TxPduId)
			{
				return Com_TriggerTransmit( PduR.PduRRoutingTables.PduRRoutingTable[CanIf_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRDestPdu[0].PduRDestPduHandleId, PduInfoPtr);
			}
			else
			{
				/*MISRA Rule*/
			}
		}

	}
	else
	{
#if PduRDevErrorDetect
		Det_ReportError(PDUR_MODULE_ID, PDUR_INSTANCE_ID, PduR_CanIfTriggerTransmit_SID, PDUR_E_UNINIT );

#endif
		return E_NOT_OK;
	}

}
#endif


#if(PduR_CanIfTxConfrimation_Supported)

void PduR_CanIfTxConfirmation (PduIdType TxPduId,  Std_ReturnType result){

	uint8 PduRRoutingPathIndex;
	if ( PduRState  == PDUR_ONLINE) {
		for (PduRRoutingPathIndex = 0; PduRRoutingPathIndex < PduRMaxRoutingPathCnt; PduRRoutingPathIndex++)
		{
			if (PduR.PduRRoutingTables.PduRRoutingTable[CanIf_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRSrcPdu.PduRSourcePduHandleId == TxPduId)
			{
				return Com_TxConfirmation( PduR.PduRRoutingTables.PduRRoutingTable[CanIf_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRDestPdu[0].PduRDestPduHandleId, result);
			}
			else
			{
				/*MISRA Rule*/
			}
		}

	}
	else
	{
#if PduRDevErrorDetect
		Det_ReportError(PDUR_MODULE_ID, PDUR_INSTANCE_ID, PduR_CanIfTxConfirmation_SID, PDUR_E_UNINIT );

#endif
		return;
	}


}
#endif


