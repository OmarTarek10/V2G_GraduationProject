#include "SoAd.h"

#define SERVER

#ifdef CLIENT
SoAd_ConfigType SoAdConfigPtr = {
		.SoAd_SockConnGroup =
		{
				{
						.SoAdSocketLocalPort = 49155,
						.SoAdSocketLocalAddressRef = {
								.TcpIpAddressType_t = 0,
								.TcpIpAddrId = 0,
								.TcpIpDomainType_t = 0,
								.TcpIpStaticIpAddressConfig_t = {
									.TcpIpDefaultRouter = 0,
									.TcpIpNetmask = 0,
									.TcpIpStaticIpAddress = {16,32,48,64}
								}
						},
						.SoAd_SocketConnection = {
								.SoAdSocketId = 0,
								.SoAd_SocketRemoteAddress = {
										.Domain = TCPIP_AF_INET6,
										.SoAdSocketRemotePort = 80,
										.SoAdSocketRemoteIpAddress = {0,0,0,0}
								}
						},
						.SoAd_SocketProtocol = {
								.SoAd_SocketTcpConfig = {
										.SoAdSocketTcpImmediateTpTxConfirmation = FALSE,
										.SoAdSocketTcpInitiate = TRUE,
										.SoAdSocketTcpKeepAlive = FALSE,
										.SoAdSocketTcpKeepAliveTime = 0,
										.SoAdSocketTcpRetransmissionTimeout = 0
								}
						}
				}
		}
};
#endif

#ifdef SERVER
SoAd_ConfigType SoAdConfigPtr = {
		.SoAd_SockConnGroup =
		{
				{
						.SoAdSocketLocalPort = 15118,
						.SoAdSocketLocalAddressRef = {
								.TcpIpAddressType_t = 0,
								.TcpIpAddrId = 0,
								.TcpIpDomainType_t = 0,
								.TcpIpStaticIpAddressConfig_t = {
									.TcpIpDefaultRouter = 0,
									.TcpIpNetmask = 0,
									.TcpIpStaticIpAddress = {16,32,48,64}
								}
						},
						.SoAd_SocketConnection = {
								.SoAdSocketId = 0,
								.SoAd_SocketRemoteAddress = {
										.Domain = TCPIP_AF_INET6,
										.SoAdSocketRemotePort = 49155,
										.SoAdSocketRemoteIpAddress = {16,32,48,64}
								}
						},
						.SoAd_SocketProtocol = {
								.SoAd_SocketTcpConfig = {
										.SoAdSocketTcpImmediateTpTxConfirmation = FALSE,
										.SoAdSocketTcpInitiate = FALSE,
										.SoAdSocketTcpKeepAlive = FALSE,
										.SoAdSocketTcpKeepAliveTime = 0,
										.SoAdSocketTcpRetransmissionTimeout = 0
								}
						}
				}
		}
};


#endif
