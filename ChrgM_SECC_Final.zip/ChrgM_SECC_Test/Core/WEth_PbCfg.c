
/******************************************************************************
*
* Module: Wireless Ethernet
*
* File Name: WEth_PbCfg.c
*
* Description: Source File For the Wireless Ethernet Module Post Build Configurations
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/ 
#include "WEth_PbCfg.h"

//#include "UL_Callbacks.h"

uint8 My_MAC_Addr[MAC_ADDR_SIZE] ={0xAA,0xBB,0xCC,0xDD ,0xEE};

WEth_ConfigType WEthConfigurationSet =
{
  .CtrlConfig[WETH_CTRL_ID_1] =
  {
    .WEthCtrlId = WETH_CTRL_ID_1,
    .WEthCtrlPhyAddress = My_MAC_Addr,
    .WEthCtrlRxBufLenByte = 250, /*1200?*/
    .WEthCtrlTxBufLenByte = 250,
    .WEthRxBufTotal = 5,
    .WEthTxBufTotal = 5,
  }
};
