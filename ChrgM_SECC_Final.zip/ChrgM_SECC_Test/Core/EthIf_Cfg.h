/******************************************************************************
*
* Module: Ethernet Interface
*
* File Name: EthIf_Cfg.h
*
* Description: Header File For the Ethernet Interface General Configurations Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/
#ifndef ETHIF_CFG_H_
#define ETHIF_CFG_H_

/*
 * SWS Item: [ECUC_EthIf_00004]
 * Description: Switches the development error detection and notification on or off.
				• true: detection and notification is enabled.
				• false: detection and notification is disabled.
 * Type: EcucBooleanParamDef
*/

#define ETHIF_DEV_ERROR_DETECT  				(STD_ON)

/*
 * SWS Item: [ECUC_EthIf_000091]
 * Description: Enables / Disables API’s for CV2x
				Tags: atp.Status=draft
 * Type: EcucBooleanParamDef
*/

#define ETHIF_ENABLE_CV2X_API   				(STD_OFF)
/*
 * SWS Item: [ECUC_EthIf_00005]
 * Description: Enables / Disables receive interrupt.
 * Type: EcucBooleanParamDef
*/

#define ETHIF_ENABLE_RX_INTERRUPT				(STD_OFF) // MAYBE IF INTERRUPTS IS USED

/*
 * SWS Item: [ECUC_EthIf_00079]
 * Description: Switches the reporting of security events to the IdsM: - true: reporting is enabled. -
				false: reporting is disabled.
				Tags: atp.Status=draft
 * Type: EcucBooleanParamDef
*/
#define ETHIF_ENABLE_SECURITY_EVENT_REPORTING	(STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00076]
 * Description: Enable/disable the APIs read and clear the signal quality.
 * Type: EcucBooleanParamDef
*/
#define ETHIF_ENABLE_SIGNAL_QUALITY_API         	(STD_OFF) //MAYBE

/*
 * SWS Item: [ECUC_EthIf_00006]
 * Description: Enables / Disables the transmit interrupt.
 * Type: EcucBooleanParamDef
*/
#define ETHIF_ENABLE_TX_INTERRUPT					 (STD_OFF) // MAYBE IF INTERRUPTS IS USED

/*
 * SWS Item: [ECUC_EthIf_00075]
 * Description: Enables / Disables API’s for WEth / WEthTrcv
 * Type: EcucBooleanParamDef
*/
#define ETHIF_ENABLE_WETH_API						 (STD_ON)

/*
 * SWS Item: [ECUC_EthIf_00072]
 * Description: Enables / Disables the Get and Reset Measurement Data API
 * Type: EcucBooleanParamDef
*/
#define ETHIF_GET_AND_RESET_MEASUREMENT_DATA_API		  (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00034]
 * Description: Enables / Disables GetBaudRate API.
 * Type: EcucBooleanParamDef
*/
#define ETHIF_GET_BAUD_RATE						  (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00035]
 * Description: Enables / Disables GetCounterState API.
 * Type: EcucBooleanParamDef
*/
#define ETHIF_GET_COUNTER_STATE					   (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00070]
 * Description: Enables / Disables GetCtrlIdxList API.
 * Type: EcucBooleanParamDef
*/
#define ETHIF_GET_CTRL_IDX_LIST					 	  (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00071]
 * Description: Enables / Disables GetVlanId API.
 * Type: EcucBooleanParamDef
*/
#define ETHIF_GET_VLAN_ID_SUPPORT					  (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00039]
 * Description: Enables/Disables the Global Time APIs used amongst others by Global Time
				Synchronization over Ethernet.
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_GLOBAL_TIME_SUPPORT  				  (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00023]
 * Description: Specifies the period of main function EthIf_MainFunctionRx and EthIf_MainFunctionTx
				in seconds. Ethernet Interface does not require this information but the BSW scheduler.
 * Type: EcucFloatParamDef
*/	
#define ETHIF_MAIN_FUNCTION_PERIOD  				  (0.01F)

/*
 * SWS Item: [ECUC_EthIf_00056]
 * Description: Specifies the period of main function EthIf_MainFunctionState in seconds. Ethernet
				Interface does not require this information but the BSW scheduler.
 * Type: EcucFloatParamDef
*/	
#define ETHIF_MAIN_FUNCTION_STATE_PERIOD 			  (0.01F)

/*
 * SWS Item: [ECUC_EthIf_00003]
 * Description: Limits the total number of transceivers.
 * Type: EcucIntegerParamDef
*/	
#define ETHIF_MAX_TRCVS_TOTAL			 			  (0x01U)

/*
 * SWS Item: [ECUC_EthIf_00055]
 * Description: Denote the time delay after the mode "ETH_MODE_ACTIVE" of all EthIfSwitchPorts
				are requested via EthIf_StartAllPorts.
				This is only used for ports in EthIfSwtPortGroups which are not referenced by any EthIf
				Controller.
 * Type: EcucFloatParamDef
*/	
#define ETHIF_PORT_STARTUP_ACTIVE_TIME			   	  (0.01F)

/*
 * SWS Item: [ECUC_EthIf_00024]
 * Description: Defines header files for callback functions which shall be included in case of CDDs.
				Range of characters is 1.. 32.
 * Type: EcucStringParamDef

*/	
#define ETHIF_PUBLIC_CDD_HEADER_FILE			 	   ('\x01') // CAN BE STRUCT

/*
 * SWS Item: [ECUC_EthIf_00030]
 * Description: Maximum number of Ethernet frames per Ethernet controller polled from the Ethernet
				driver within EthIf_MainFunctionRx.
 * Type: EcucIntegerParamDef

*/	
#define ETHIF_RX_INDICATION_ITERATIONS			 	   (0x04U)

/*
 * SWS Item: [ECUC_EthIf_00062]
 * Description: Enables /disables EthIf_SetForwardingMode API.
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_SET_FORWARDING_MODE_API			 	   (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00077]
 * Description: Specifies the period in units of seconds in which the signal quality it polled in the
				context of EthIf_MainfunctionState. The value shall be an integral multiple of EthIfMain
				FunctionStatePeriod.
 * Type: EcucFloatParamDef
*/	
#define ETHIF_SIGNAL_QUALITY_CHECK_PERIOD			    (0.01F)

/*
 * SWS Item: [ECUC_EthIf_00033]
 * Description: Enables / Disables StartAutoNegotiation API.
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_START_AUTO_NEGOTIATION			        (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00064]
 * Description: Enables/Disables the Switch management APIs to support a Switch-port specific
				communication attribute access.
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_SWITCH_MANAGEMENT_SUPPORT			    (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00054]
 * Description: Denote the time delay after the mode "ETH_MODE_DOWN" of a EthIfSwitchPortGroup
				will be executed.
				This is only used for EthIfSwtPortGroups which are not referenced by any EthIf
				Controller.
				The time delay shall be greater than the UdpNm timings, because UdpNm shall finish
				its shutdown handling. (Repeat Message State, Prepare Bus-Sleep state, Bus-Sleep
				state).
 * Type: EcucFloatParamDef
*/	
#define ETHIF_SWITCH_OFF_PORT_TIME_DELAY				    (0.01F)

/*
 * SWS Item: [ECUC_EthIf_00009]
 * Description: Specifies the frequency of transceiver link state change checks in each period of main
				function EthIf_MainFunctionTx.
 * Type: EcucIntegerParamDef
*/	
#define ETHIF_TRCV_LINK_STATE_CHG_MAIN_RELOAD			    (0x01U) //MAYBE

/*
 * SWS Item: [ECUC_EthIf_00063]
 * Description: Enables /disables EthIf_VerifyConfig API.
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_VERIFY_CONFIG_API			  		    (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00007]
 * Description: Enables / Disables version info API
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_VERSION_INFO_API 			  		    (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00008]
 * Description: Enables / Disables version info API macro implementation.
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_VERSION_INFO_API_MACRO 			  	    (STD_OFF)

/*
 * SWS Item: [ECUC_EthIf_00040]
 * Description: Configures if wake-up handling is supported or not:
				TRUE: wake-up handling is supported
				FALSE: wake-up handling is not supported
				This configuration parameter also enables particular other the API at
				Pre-Compile-Time, e.g. EthIf_CheckWakeup.
 * Type: EcucBooleanParamDef
*/	
#define ETHIF_WAKE_UP_SUPPORT 					  	    (STD_OFF)

/*
 * EthIfSecurityEventRefs
 * Description: Container for the references to IdsMEvent elements representing the security events
				that the EthIf module shall report to the IdsM in case the coresponding security related
				event occurs (and if EthIfEnableSecurityEventReporting is set to "true"). The
				standardized security events in this container can be extended by vendor-specific
				security events.
 */
#endif /* ETHIF_CFG_H_ */
