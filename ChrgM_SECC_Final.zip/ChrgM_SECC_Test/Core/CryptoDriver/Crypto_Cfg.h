/*
 ============================================================================
 Name        : Crypto_Cfg.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "Crypto.h"

extern CryptoPrimitive signatureGenerateCryptoPrimitive;
extern CryptoPrimitive signatureVerifyCryptoPrimitive;
extern CryptoPrimitive hashGenerateCryptoPrimitive;
extern CryptoPrimitive encryptionCryptoPrimitive;
extern CryptoPrimitive decryptionCryptoPrimitive;

/*******************************************************************************
 *                   CryptoGeneral Container Configuration Parameters            *
 *******************************************************************************/


#define CryptoDevErrorDetect		(STD_OFF)

#define CryptoVersionInfoApi		(STD_OFF)

#define CRYPTODRIVER1_INSTANCE_ID     (uint8)1U
#define CRYPTODRIVER2_INSTANCE_ID     (uint8)2U
#define CRYPTODRIVER3_INSTANCE_ID     (uint8)3U

#define CryptoQueueSize

