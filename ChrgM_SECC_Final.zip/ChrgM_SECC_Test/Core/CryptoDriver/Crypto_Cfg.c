/*
 ============================================================================
 Name        : Crypto_Cfg.c
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "Crypto.h"

/* struct for cryptoPrimitives used through signature process*/
 CryptoPrimitive signatureGenerateCryptoPrimitive =
{		CRYPTO_ALGOFAM_ECDSA, /* Primitive algorithm family  */
		CRYPTO_ALGOMODE_NOT_SET,
		CRYPTO_ALGOFAM_NOT_SET,/* Secondary family */
		CRYPTO_SIGNATUREGENERATE,
		TRUE
};

/* struct for cryptoPrimitives used through verification process*/
 CryptoPrimitive signatureVerifyCryptoPrimitive =
{
		CRYPTO_ALGOFAM_ECDSA, /* Primitive algorithm family  */
		CRYPTO_ALGOMODE_NOT_SET,
		CRYPTO_ALGOFAM_NOT_SET, /* Secondary family */
		CRYPTO_SIGNATUREVERIFY,
		TRUE
};

/* struct for cryptoPrimitives used through HASH process*/
 CryptoPrimitive hashGenerateCryptoPrimitive =
{
		CRYPTO_ALGOFAM_SHA1,  /* Primitive algorithm family  */
		CRYPTO_ALGOMODE_NOT_SET,
		CRYPTO_ALGOFAM_NOT_SET, /* Secondary family */
		CRYPTO_HASH,
		TRUE
};

/* struct for cryptoPrimitives used through HASH process*/
 CryptoPrimitive encryptionCryptoPrimitive =
{
	CRYPTO_ALGOFAM_3DES,  /* Primitive algorithm family  */
	CRYPTO_ALGOMODE_NOT_SET,
	CRYPTO_ALGOFAM_NOT_SET, /* Secondary family */
	CRYPTO_ENCRYPT,
	TRUE
};

 /* struct for cryptoPrimitives used through HASH process*/
  CryptoPrimitive decryptionCryptoPrimitive =
 {
 	CRYPTO_ALGOFAM_3DES,  /* Primitive algorithm family  */
 	CRYPTO_ALGOMODE_NOT_SET,
 	CRYPTO_ALGOFAM_NOT_SET, /* Secondary family */
 	CRYPTO_DECRYPT,
 	TRUE
 };
