/*
 ============================================================================
 Name        : Crypto.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */

#ifndef CRYPTO_H
#define CRYPTO_H

#include "../Crypto_GeneralTypes.h"
#include "../Std_Types.h"
#include "../Compiler.h"

#define QUEUE_MAX_SIZE							3

/******************************************************************************
 *                      API Service Id Macros                                 *
 ******************************************************************************/
#define CRYPTO_INIT_SID 					    0x00
#define CRYPTO_GETVERSIONINFO_SID				0X01
#define CRYPTO_PROCESSJOB_SID					0X03

/*******************************************************************************
 *                      ID - VersionInfo                                       *
 ******************************************************************************/

#define CRYPTO_MODULE_ID       (uint8)(1U)
#define CRYPTO_VENDOR_ID       (uint8)(2U)

/*
 * Module Version 1.0.0
 */
#define CRYPTO_SW_MAJOR_VERSION                   (1U)
#define CRYPTO_SW_MINOR_VERSION                   (0U)
#define CRYPTO_SW_PATCH_VERSION                   (0U)

/*
 * AUTOSAR Version 4.0.3
 */
#define CRYPTO_AR_RELEASE_MAJOR_VERSION           (4U)
#define CRYPTO_AR_RELEASE_MINOR_VERSION           (7U)
#define CRYPTO_AR_RELEASE_PATCH_VERSION           (0U)


/*******************************************************************************
 *                      DEV Error Codes                                        *
 ******************************************************************************/

#define CRYPTO_E_UNINIT 					0x00
#define CRYPTO_E_INIT_FAILED 			 	0x01
#define CRYPTO_E_PARAM_POINTER 				0x02
#define CRYPTO_E_PARAM_HANDLE 				0x04
#define CRYPTO_E_PARAM_VALUE 				0x05
#define CRYPTO_E_SMALL_BUFFER    			0x06

#define CRYPTO_E_RE_ENTROPY_EXHAUSTED		0x03
#define CRYPTO_E_RE_NVM_ACCESS_FAILED		0x04

/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef struct {
	uint8 dummy;

}Crypto_ConfigType;

typedef enum {
	CRYPTO_STATE_UNINIT, CRYPTO_STATE_INIT
} Crypto_StateType;

typedef enum {

	CRYPTO_IDLE_STATE, CRYPTO_ACTIVE_STATE

}Crypto_State;

typedef struct {
	Crypto_JobType * jobPtr;
	uint32 jobPriority;

}CryptoSavedJobInfoType;

typedef struct
{
  uint8 front, rear;
  uint8 size;
  CryptoSavedJobInfoType arr[QUEUE_MAX_SIZE];
} Crypto_Queue;

/*********************************************************************
 * 					Crypto Driver configurations datatypes
 *********************************************************************/

typedef enum {

	CRYPTO_KE_FORMAT_BIN_IDENT_PRIVATEKEY_PKCS8,
	CRYPTO_KE_FORMAT_BIN_IDENT_PUBLICKEY,
	CRYPTO_KE_FORMAT_BIN_OCTET,
	CRYPTO_KE_FORMAT_BIN_RSA_PRIVATEKEY,
	CRYPTO_KE_FORMAT_BIN_RSA_PUBLICKEY,
	CRYPTO_KE_FORMAT_BIN_SHEKEYS

} CryptoKeyElementFormat;

typedef enum {
	CRYPTO_RA_ALLOWED,
	CRYPTO_RA_DENIED,
	CRYPTO_RA_ENCRYPTED,
	CRYPTO_RA_INTERNAL_COPY

} CryptoKeyElementReadAccess;

typedef enum {
	CRYPTO_WA_ALLOWED,
	CRYPTO_WA_DENIED,
	CRYPTO_WA_ENCRYPTED,
	CRYPTO_WA_INTERNAL_COPY

} CryptoKeyElementWriteAccess;

typedef enum {
	CRYPTO_NV_BLOCK_DEFERRED,
	CRYPTO_NV_BLOCK_IMMEDIATE

}CryptoNvBlockProcessing;

typedef struct {
	uint32 CryptoNvBlockFailedRetries;
	CryptoNvBlockProcessing CryptoNvBlockProcessing;

}CryptoNvBlock;

/* CRYPTOKEY CONTAINER DATA TYPES*/

typedef struct {

	Crypto_AlgorithmFamilyType CryptoPrimitiveAlgorithmFamily;
	Crypto_AlgorithmModeType CryptoPrimitiveAlgorithmMode;
	Crypto_AlgorithmFamilyType CryptoPrimitiveAlgorithmSecondaryFamily;
	Crypto_ServiceInfoType CryptoPrimitiveService;
	boolean CryptoPrimitiveSupportContext;

} CryptoPrimitive;

/* CRYPTOKEY CONTAINER DATA TYPES*/

typedef struct {

	uint32 CryptoKeyId;
	CryptoNvBlock *CryptoKeyNvBlockRef;

}CryptoKey;

/* CRYPTOKEYELEMENT CONTAINER DATA TYPES*/

typedef struct {
	boolean CryptoKeyElementAllowPartialAccess;
	CryptoKeyElementFormat KeyElementFormat;
	uint32 CryptoKeyElementId;
	boolean CryptoKeyElementPersist;
	uint32 CryptoKeyElementSize;
	char CryptoKeyElementInitValue[];


}CryptoKeyElement;

/* CRYPTOKEYTYPE CONTAINER DATA TYPES*/

typedef struct {
	CryptoKeyElement CryptoKeyElementRef;

}CryptoKeyType;


/* CRYPTODRIVEROBJECT CONTAINER DATA TYPES*/

typedef struct {

	uint32 CryptoDriverObjectId;
	uint32 CryptoQueueSize;
	CryptoKey *CryptoDefaultRandomKeyRef;
	CryptoPrimitive *CryptoDefaultRandomPrimitiveRef;
	//CryptoDriverObjectEcucPartitionRef;
	CryptoPrimitive *CryptoPrimitiveRef;

} CryptoDriverObject;

/*******************************************************************************
 *                      Function Prototypes                                    *
 *******************************************************************************/

void Crypto_Init (const Crypto_ConfigType* configPtr);
void Crypto_GetVersionInfo (Std_VersionInfoType* versioninfo);
Std_ReturnType Crypto_ProcessJob (uint32 objectId, Crypto_JobType* job);
Std_ReturnType Crypto_Aes_Gcm_Decrypt(const unsigned char *key,
                const unsigned char *iv,
                const unsigned char *ciphertext,
                uint64 ct_len,
                const unsigned char *tag,
                uint64 tag_len,
                unsigned char *plaintext);
Std_ReturnType Crypto_Aes_Gcm_Encrypt(const unsigned char *key,
                const unsigned char *iv,
                const unsigned char *plaintext,
                uint64 pt_len,
                unsigned char *ciphertext,
                unsigned char *tag,
                uint64 tag_len);
Std_ReturnType Crypto_sha256_hash(const unsigned char *message, uint64 message_len, unsigned char *hash);
Std_ReturnType Crypto_Ecdsa_signature_generate(const unsigned char *message, uint64 message_len,
                             unsigned char *signature, uint64 signature_len);
Std_ReturnType Crypto_Ecdsa_signature_verify(const unsigned char *message, uint64 message_len,
                           const unsigned char *signature, uint64 signature_len);


#endif //CRYPTO_H

