/*
 ============================================================================
 Name        : Crypto.c
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "Crypto.h"
#include "Crypto_Cfg.h"
#include "../Compiler.h"
#include "../Std_Types.h"
#include "../library/mbedtls/gcm.h"
#include "../library/mbedtls/entropy.h"
#include "../library/mbedtls/ctr_drbg.h"
#include "../library/mbedtls/pk.h"
#include "../library/mbedtls/md.h"
#include "../library/mbedtls/sha256.h"
#include "../library/mbedtls/ecdsa.h"
#include "../library/mbedtls/sha1.h"
#include "../library/mbedtls/ecdh.h"
#include "../library/mbedtls/rsa.h"
#include "../library/tripleDES.h"

static Crypto_StateType Crypto_Status;
static Crypto_State CryptoState;
STATIC Crypto_Queue jobQueue;

unsigned char tag[16];
uint64 tag_len = 16;

// Define constants
#define SHARED_SECRET_LENGTH 32
#define LOCAL_PUBLIC_VALUE_LENGTH 65

#define KEY_SIZE_BYTES 32 // Assuming a 256-bit key
#define KEY_SIZE 2048 // You can adjust the key size as needed


//RSA Variables
mbedtls_rsa_context rsa_context_partyA;
mbedtls_rsa_context rsa_context_partyB;
mbedtls_ctr_drbg_context ctr_drbg;
boolean rsa_initialized = FALSE;


// Define global ECDH contexts
mbedtls_ecdh_context ctxA, ctxB;
mbedtls_entropy_context entropy;
mbedtls_ctr_drbg_context ctr_drbg;


#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

static int custom_entropy_source(void *data, unsigned char *output, size_t len, size_t *olen) {
    (void)data;
    for (size_t i = 0; i < len; i++) {
        output[i] = rand() % 256;
    }
    *olen = len;
    return 0;
}

void initialize_rsa_contexts() {
    if (rsa_initialized) {
        return;
    }

    int ret;
    const char *pers = "rsa_genkey";
    mbedtls_entropy_context entropy;
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);

    // Add custom entropy source
	if ((ret = mbedtls_entropy_add_source(&entropy, custom_entropy_source, NULL, 32, MBEDTLS_ENTROPY_SOURCE_STRONG)) != 0) {
		printf("Failed to add custom entropy source: -0x%04x\n", -ret);
		exit(1);
	}

	printf("Seeding the random number generator...\n");

	// Seed and set up the RNG
	if ((ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, (const unsigned char *)pers, strlen(pers))) != 0) {
		printf("Failed to initialize RNG: -0x%04x\n", -ret);
		exit(1);
	}

    printf("Generating RSA key pair for party A...\n");

    // Initialize RSA context for party A
    mbedtls_rsa_init(&rsa_context_partyA);
    if ((ret = mbedtls_rsa_gen_key(&rsa_context_partyA, mbedtls_ctr_drbg_random, &ctr_drbg, 2048, 65537)) != 0) {
        printf("Failed to generate RSA key pair for party A: -0x%04x\n", -ret);
        exit(1);
    }

    printf("Generating RSA key pair for party B...\n");

    // Initialize RSA context for party B
    mbedtls_rsa_init(&rsa_context_partyB);
    if ((ret = mbedtls_rsa_gen_key(&rsa_context_partyB, mbedtls_ctr_drbg_random, &ctr_drbg, 2048, 65537)) != 0) {
        printf("Failed to generate RSA key pair for party B: -0x%04x\n", -ret);
        exit(1);
    }

    printf("RSA contexts and keys successfully initialized.\n");

    // Clean up temporary contexts
    mbedtls_entropy_free(&entropy);

    // Set the flag to indicate that RSA keys have been initialized
    rsa_initialized = TRUE;
}



Std_ReturnType rsa_encrypt(mbedtls_rsa_context *ctx, const unsigned char *input, size_t input_len, unsigned char *output) {
    int ret;
    size_t key_len = mbedtls_rsa_get_len(ctx);

    // Ensure the input length is less than the key length minus padding overhead
    if (input_len > key_len - 11) {
        printf("Input data too long for the given key size\n");
        return E_NOT_OK;
    }

    if ((ret = mbedtls_rsa_pkcs1_encrypt(ctx, mbedtls_ctr_drbg_random, &ctr_drbg, input_len, input, output)) != 0) {
        printf("Encryption failed: -0x%04x\n", -ret);
        return E_NOT_OK;
    }

    return E_OK;
}

Std_ReturnType rsa_decrypt(mbedtls_rsa_context *ctx, const unsigned char *input, size_t input_len, unsigned char *output, size_t *output_len) {
    int ret;

    // Ensure the input length is appropriate for the key
    size_t key_len = mbedtls_rsa_get_len(ctx);
    if (input_len > key_len || input_len == 0) {
        printf("Input data length is invalid\n");
        return E_NOT_OK;
    }

    if ((ret = mbedtls_rsa_pkcs1_decrypt(ctx, mbedtls_ctr_drbg_random, &ctr_drbg, output_len, input, output, key_len)) != 0) {
        printf("Decryption failed: -0x%04x\n", -ret);
        return E_NOT_OK;
    }

    return E_OK;
}
// Function to compute SHA-256 hash of a message
Std_ReturnType Crypto_sha256_hash(const unsigned char *message, uint64 message_len, unsigned char *hash) {


	// Initialize SHA-256 context
    mbedtls_sha256_context ctx;
    mbedtls_sha256_init(&ctx);

    // Start SHA-256 hash computation
    if (mbedtls_sha256_starts(&ctx, 0) != 0){
    	return E_NOT_OK;
    } // Use SHA-256 (not SHA-224)

    // Feed input buffer into SHA-256 hash computation
    if (mbedtls_sha256_update(&ctx, message, message_len) != 0){
    	return E_NOT_OK;
    }

    // Finish SHA-256 hash computation and obtain the hash
    if (mbedtls_sha256_finish(&ctx, hash) != 0){
    	return E_NOT_OK;
    }

    // Free resources
    mbedtls_sha256_free(&ctx);

    return E_OK; // Success


}

// Function to perform SHA-1 hashing
Std_ReturnType Crypto_sha1_hash(const unsigned char *message, uint64 message_len, unsigned char *hash) {

    int ret;
    mbedtls_sha1_context ctx;

    // Initialize SHA-1 context
    mbedtls_sha1_init(&ctx);

    // Perform SHA-1 hashing
    ret = mbedtls_sha1(message, message_len, hash);

    // Free SHA-1 context
    mbedtls_sha1_free(&ctx);

    if (ret != 0){
    	return E_NOT_OK;
    }

    return E_OK;
}

Std_ReturnType Crypto_Process_hash(const unsigned char *message, uint64 message_len, unsigned char *hash) {

	if (hashGenerateCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_SHA2_256) {

		return Crypto_sha256_hash(message, message_len, hash);

	} else if (hashGenerateCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_SHA1){

		return Crypto_sha1_hash(message, message_len, hash);

	}

}

/* Function for ECDSA signature generation */
Std_ReturnType Crypto_Ecdsa_signature_generate(const unsigned char *message, uint64 message_len,
                             unsigned char *signature, uint64 signature_len)
{

    int ret;
    mbedtls_ecdsa_context ctx;
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;

    // Initialize contexts
    mbedtls_ecdsa_init(&ctx);
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);

    // Setup RNG
    const char *pers = "ecdsa_example";
    ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy,
                                 (const unsigned char *) pers, strlen(pers));
    if (ret != 0) {
        // Handle error
        return E_NOT_OK;
    }

    //Generate ECDSA key pair
    ret = mbedtls_ecdsa_genkey(&ctx, MBEDTLS_ECP_DP_SECP256R1,
                                mbedtls_ctr_drbg_random, &ctr_drbg);
    if (ret != 0) {
        //Handle error
        return E_NOT_OK;
    }

    //Compute ECDSA signature
    size_t sig_len;
    ret = mbedtls_ecdsa_write_signature(&ctx, MBEDTLS_MD_SHA256, message,
                                        message_len, signature, signature_len, &sig_len,
                                        mbedtls_ctr_drbg_random, &ctr_drbg);
    if (ret != 0) {
        //Handle error
        return E_NOT_OK;
    }

    //Free resources
    mbedtls_ecdsa_free(&ctx);
    mbedtls_entropy_free(&entropy);
    mbedtls_ctr_drbg_free(&ctr_drbg);

    return E_OK;

}

/* Function for ECDSA signature verification */
Std_ReturnType Crypto_Ecdsa_signature_verify(const unsigned char *message, uint64 message_len,
                           const unsigned char *signature, uint64 signature_len)
{

    int ret;
    mbedtls_ecdsa_context ctx;

    //Initialize context
    mbedtls_ecdsa_init(&ctx);

    //Setup ECDSA context from a key pair
    mbedtls_ecp_keypair keypair;
    mbedtls_ecp_keypair_init(&keypair);
    //Set up key pair - This step would vary based on how your keys are stored
    //Assuming key pair setup here

    //Convert key pair to ECDSA context
    ret = mbedtls_ecdsa_from_keypair(&ctx, &keypair);
    if (ret != 0) {
        //Handle error
        return E_NOT_OK;
    }

    //Verify ECDSA signature
    ret = mbedtls_ecdsa_read_signature(&ctx, message, message_len, signature,
                                       signature_len);
    if (ret != 0) {
        //Handle error
        return E_NOT_OK;
    }

    //Free resources
    mbedtls_ecdsa_free(&ctx);
    mbedtls_ecp_keypair_free(&keypair);

    return E_OK;


}

/**
 * \brief           Encrypts a plaintext using GCM mode.
 *
 * \param key       The encryption key.
 * \param iv        The initialization vector (IV).
 * \param plaintext The plaintext to encrypt.
 * \param pt_len    The length of the plaintext in bytes.
 * \param ciphertext    Output buffer to store the encrypted ciphertext.
 * \param tag       Output buffer to store the authentication tag.
 * \param tag_len   The length of the authentication tag to generate.
 * \return          \c 0 on success, or an error code.
 */

Std_ReturnType Crypto_Aes_Gcm_Encrypt(const unsigned char *key,
                const unsigned char *iv,
                const unsigned char *plaintext,
                uint64 pt_len,
                unsigned char *ciphertext,
                unsigned char *tag,
                uint64 tag_len)
{


    mbedtls_gcm_context ctx;
    mbedtls_gcm_init(&ctx);
    mbedtls_gcm_setkey(&ctx, MBEDTLS_CIPHER_ID_AES, key, 128);

    int ret = mbedtls_gcm_crypt_and_tag(&ctx, MBEDTLS_GCM_ENCRYPT, pt_len, iv, 12, NULL, 0, plaintext, ciphertext, tag_len, tag);

    mbedtls_gcm_free(&ctx);

    if (ret != 0) {
        return E_NOT_OK;
    }

    return E_OK;

}

Std_ReturnType Crypto_Process_Encryption(const unsigned char *key,
                const unsigned char *iv,
                const unsigned char *plaintext,
                uint64 pt_len,
                unsigned char *ciphertext,
                unsigned char *tag,
                uint64 tag_len,
                uint8 *V2G_CommunicationParty)
{
    // Check for valid V2G_CommunicationParty pointer
    if (V2G_CommunicationParty == NULL) {
        return E_NOT_OK;
    }

    if (encryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_AES) {
        return Crypto_Aes_Gcm_Encrypt(key, iv, plaintext, pt_len, ciphertext, tag, tag_len);
    } else if (encryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_3DES) {
        return tripleDesEncrypt(plaintext, ciphertext ,pt_len , &pt_len);
    } else if (encryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_RSA) {
        if (*V2G_CommunicationParty == 1) {
            return rsa_encrypt(&rsa_context_partyB, plaintext, pt_len, ciphertext);
        } else {
            return rsa_encrypt(&rsa_context_partyA, plaintext, pt_len, ciphertext);
        }
    }

    return E_NOT_OK; // Return E_NOT_OK if no matching algorithm is found
}

/**
 * \brief           Decrypts a ciphertext using GCM mode.
 *
 * \param key       The decryption key.
 * \param iv        The initialization vector (IV).
 * \param ciphertext    The ciphertext to decrypt.
 * \param ct_len    The length of the ciphertext in bytes.
 * \param tag       The authentication tag.
 * \param tag_len   The length of the authentication tag.
 * \param plaintext Output buffer to store the decrypted plaintext.
 * \return          \c 0 on success, or an error code.
 */

Std_ReturnType Crypto_Aes_Gcm_Decrypt(const unsigned char *key,
                const unsigned char *iv,
                const unsigned char *ciphertext,
                uint64 ct_len,
                const unsigned char *tag,
                uint64 tag_len,
                unsigned char *plaintext)
{

    mbedtls_gcm_context ctx;
    mbedtls_gcm_init(&ctx);
    mbedtls_gcm_setkey(&ctx, MBEDTLS_CIPHER_ID_AES, key, 128);

    int ret = mbedtls_gcm_auth_decrypt(&ctx, ct_len, iv, 12, NULL, 0, tag, tag_len, ciphertext, plaintext);

    mbedtls_gcm_free(&ctx);

    return E_OK;

}

// Function to process decryption
Std_ReturnType Crypto_Process_Decryption(const unsigned char *key,
                const unsigned char *iv,
                const unsigned char *ciphertext,
                uint64 ct_len,
                const unsigned char *tag,
                uint64 tag_len,
                unsigned char *plaintext,
                uint8 *V2G_CommunicationParty)
{
    // Initialize RSA contexts only once
    initialize_rsa_contexts();

    // Check for valid V2G_CommunicationParty pointer
    if (V2G_CommunicationParty == NULL) {
        return E_NOT_OK;
    }

    if (decryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_AES) {
        return Crypto_Aes_Gcm_Decrypt(key, iv, ciphertext, ct_len, tag, tag_len, plaintext);
    } else if (decryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_3DES) {
        return tripleDesDecrypt(ciphertext, plaintext, ct_len, &ct_len);
    } else if (decryptionCryptoPrimitive.CryptoPrimitiveAlgorithmFamily == CRYPTO_ALGOFAM_RSA) {
        size_t output_len;
        if (*V2G_CommunicationParty == 1) {
            return rsa_decrypt(&rsa_context_partyB, ciphertext, ct_len, plaintext, &output_len);
        } else {
            return rsa_decrypt(&rsa_context_partyA, ciphertext, ct_len, plaintext, &output_len);
        }
    }

    return E_NOT_OK; // Return E_NOT_OK if no matching algorithm is found
}

STATIC sint8 getJob(uint32 jobId){
    if( jobQueue.size ==0)
            return -1;

    for(uint8 i=jobQueue.front;i <= (jobQueue.rear % QUEUE_MAX_SIZE);i++)
    {

        if(jobId == jobQueue.arr[i].jobPtr->jobId)
        {
            return i;
        }
    }
    return -1;

}

boolean insertJob(Crypto_JobType* job){


if(jobQueue.size < QUEUE_MAX_SIZE)
   {
	boolean inserted=0;
	jobQueue.rear +=1;
	CryptoSavedJobInfoType temp;
	uint8 pos;
       for(uint8 i=jobQueue.front;i<=jobQueue.size;i++)
       {
            if (job->jobInfo.jobPriority > jobQueue.arr[i].jobPriority )
            {
            	temp= jobQueue.arr[i];
			    jobQueue.arr[i].jobPriority =job->jobInfo.jobPriority;
			    jobQueue.arr[i].jobPtr = job;
			    inserted =1;
			    pos = i;
			    break;

            }

        }

       if(inserted==0)
       {

			jobQueue.arr[jobQueue.rear % QUEUE_MAX_SIZE].jobPriority =job->jobInfo.jobPriority;
			jobQueue.arr[jobQueue.rear % QUEUE_MAX_SIZE].jobPtr = job;
       }
       else {
    	   for(int j=jobQueue.rear-1;j>=pos+1;j--)
			{

				jobQueue.arr[j+1].jobPriority =jobQueue.arr[j].jobPriority;
				jobQueue.arr[j+1].jobPtr = jobQueue.arr[j].jobPtr;
			}
		  jobQueue.arr[pos+1] = temp;
       }
       jobQueue.size +=1;

       return TRUE;

   }
   return FALSE;

}

void deleteNextJob()
{
	if(jobQueue.size > 0)
	{
		jobQueue.front += 1;
		jobQueue.front %= QUEUE_MAX_SIZE;
		jobQueue.size -= 1;
	}
}




/************************************************************************************
 * Service Name: Crypto_Init
 * Service ID[hex]: 0x00
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): ConfigPtr - Pointer to a selected configuration structure
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Initializes the Crypto Driver
 * Requirements: SWS_Csm_00186, SWS_Csm_00659, [SWS_Csm_91009]
 ************************************************************************************/

void Crypto_Init (const Crypto_ConfigType* configPtr) {

	/*
	 * [SWS_Crypto_00215] ⌈ The Configuration pointer configPtr shall always have a
		null pointer value.⌋ (SWS_BSW_00050)
	 */

	if (configPtr != NULL_PTR){
#if (CryptoDevErrorDetect == STD_ON)
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_INIT_SID, CRYPTO_E_INIT_FAILED);
#endif
		Crypto_Status = CRYPTO_STATE_UNINIT;
	} else {

		Crypto_Status = CRYPTO_STATE_INIT;

		/*
		 * [SWS_Crypto_00019] ⌈ After initialization the crypto driver is in “idle” state.
		⌋()
		*/

		CryptoState = CRYPTO_IDLE_STATE;

		jobQueue.front = 0;
		jobQueue.rear = -1;
		jobQueue.size = 0;
	}

}

/************************************************************************************
 * Service Name: Crypto_GetVersionInfo
 * Service ID[hex]: 0x01
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): versioninfo - Pointer to where to store the version information of this module.
 * Return value: None
 * Description: Returns the version information of this module
 * Requirements: None
 ************************************************************************************/

#if (CryptoVersionInfoApi == STD_ON)
void Crypto_GetVersionInfo (Std_VersionInfoType* versioninfo) {

}
#endif

/************************************************************************************
 * Service Name: Crypto_ProcessJob
 * Service ID[hex]: 0x03
 * Sync/Async: Synchronous or Asynchronous depending on the configuration
 * Reentrancy: Reentrant
 * Parameters (in): uint32 objectId
 * Parameters (inout): Crypto_JobType* job
 * Parameters (out): None
 * Return value: Std-ReturnType
 * Description: This interface dispatches the received jobs to the configured crypto driver object.
 ************************************************************************************/

Std_ReturnType Crypto_ProcessJob (uint32 objectId, Crypto_JobType* job) {



#if (CRYPTO_DEV_ERROR_DETECT == STD_ON)

	/*
	 * [SWS_Crypto_00057] ⌈ If the module is not initialized and if development error
		detection for the Crypto Driver is enabled, the function Crypto_ProcessJob shall
		report CRYPTO_E_UNINIT to the DET and return E_NOT_OK.
		⌋()
	*/

	if( Crypto_Status != CRYPTO_STATE_INIT)
	{
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_PROCESSJOB_SID, CRYPTO_E_UNINIT);
		return E_NOT_OK;
	}

	/*
	 * [SWS_Crypto_00058] ⌈If the parameter objectId is out of range and if
		development error detection for the Crypto Driver is enabled, the function
		Crypto_ProcessJob shall report CRYPTO_E_PARAM_HANDLE to the DET and
		return E_NOT_OK.
		⌋()
	*/

	if ( objectid != CRYPTODRIVER1_INSTANCE_ID){

		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_PROCESSJOB_SID, CRYPTO_E_PARAM_HANDLE);
		return E_NOT_OK;

	}

	/*
	 * [SWS_Crypto_00059] ⌈If the parameter job is a null pointer and if development
		error detection for the Crypto Driver is enabled, the function Crypto_ProcessJob
		shall report CRYPTO_E_PARAM_POINTER to the DET and return E_NOT_OK.
		⌋()

	*/

	if (job == NULL_PTR)
	{
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_PROCESSJOB_SID, CRYPTO_E_PARAM_POINTER);
		return E_NOT_OK;

	}

	/*
	 * [SWS_Crypto_00064] ⌈ If the parameter job->jobPrimitiveInfo-
		>primitiveInfo->service is not supported by the Crypto Driver Object and
		if development error detection for the Crypto Driver is enabled, the function
		Crypto_ProcessJob shall report CRYPTO_E_PARAM_HANDLE to the DET and
		return E_NOT_OK
		⌋()
	 */


	if (job->jobPrimitiveInfo->primitiveInfo->service != CRYPTO_ENCRYPT &&
		job->jobPrimitiveInfo->primitiveInfo->service != CRYPTO_DECRYPT &&
		job->jobPrimitiveInfo->primitiveInfo->service != CRYPTO_SIGNATUREGENERATE &&
		job->jobPrimitiveInfo->primitiveInfo->service != CRYPTO_SIGNATUREVERIFY &&
		job->jobPrimitiveInfo->primitiveInfo->service != CRYPTO_HASH)
	{
		 Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_PROCESSJOB_SID, CRYPTO_E_PARAM_HANDLE );
		 return E_NOT_OK;
	}

	/*
	 * [SWS_Crypto_00202]⌈ If the parameter job->jobPrimitiveInfo->primitiveInfo->service
		is set to CRYPTO_KEYDERIVE, the parameter job->targetCryptoKeyId must be in
		range; else the function Crypto_ProcessJob shall report
		CRYPTO_E_PARAM_HANDLE to DET and return E_NOT_OK
		⌋()
	*/

	if (job->jobPrimitiveInfo->primitiveInfo->service == CRYPTO_KEYDERIVE && job->targetCryptoKeyId /*not in range*/)
	{
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_PROCESSJOB_SID, CRYPTO_E_PARAM_HANDLE );
		return E_NOT_OK;

	}

	if ((job->jobPrimitiveInfo->primitiveInfo->service == CRYPTO_HASH ||
		job->jobPrimitiveInfo->primitiveInfo->service == CRYPTO_MACGENERATE) &&
		job->>jobPrimitiveInputOutput->outputLengthPtr /*smaller than the result length of the chosen algorithm, the most significant bits of the result shall be
placed to the available buffer referenced by job->jobPrimitiveInputOutput-
>outputPtr as a truncated output.*/

	if ()





#endif

	initialize_rsa_contexts();

	const unsigned char key[] = {0x5d, 0xd6, 0x12, 0x29, 0xce, 0xd9,
								 0x2d, 0xb4, 0x76, 0x8e, 0x6a, 0xe1,
								 0x43, 0x63, 0xeb, 0x1e, 0xec, 0x55,
								 0x25, 0x32, 0xd8, 0x24, 0x7f, 0xa9,
								 0x70, 0x63, 0xb8, 0x1e, 0xac, 0x3a,
								 0x31, 0x33};

	const unsigned char iv[] = {0x01, 0x23, 0x45, 0x67, 0x89,
								0xAB, 0xCD, 0xEF, 0x01, 0x23,
								0x45, 0x67};





	/*
	 * [SWS_Crypto_00020] ⌈ If Crypto_ProcessJob() is called while in “Idle” or
		“Active” state and with the operation mode “START”, the previous request shall be
		cancelled. That means, that all previously buffered data for this job shall be reset,
		and the job shall switch to “Active” state and process the new one.⌋()
	 *
	*/

	sint8 result = getJob(job->jobId);

	if (result != -1 && job->jobPrimitiveInputOutput.mode == CRYPTO_OPERATIONMODE_START){

		jobQueue.arr[result].jobPriority = job->jobInfo.jobPriority;
		jobQueue.arr[result].jobPtr = job;

	}

	/*
	 * [SWS_Crypto_00118] ⌈ If Crypto_ProcessJob() is called while the job is in state
	   “Idle” and the “START” flag in the operation mode is not set, the function shall return
		with E_NOT_OK.⌋()
	 */

	if (job->jobState == CRYPTO_JOBSTATE_IDLE && job->jobPrimitiveInputOutput.mode != CRYPTO_OPERATIONMODE_START) {

		return E_NOT_OK;

	}

	if (job->jobPrimitiveInfo->processingType == CRYPTO_PROCESSING_SYNC ) {

		if (CryptoState == CRYPTO_ACTIVE_STATE)
		{
			return E_NOT_OK;

		} else {

			switch(job->jobPrimitiveInfo->primitiveInfo->service){

			case CRYPTO_ENCRYPT:
				return Crypto_Process_Encryption(key, iv, job->jobPrimitiveInputOutput.inputPtr, job->jobPrimitiveInputOutput.inputLength, job->jobPrimitiveInputOutput.outputPtr, tag, tag_len, job->jobPrimitiveInputOutput.secondaryInputPtr);
				break;

			case CRYPTO_DECRYPT:
				return Crypto_Process_Decryption(key, iv, job->jobPrimitiveInputOutput.inputPtr, job->jobPrimitiveInputOutput.inputLength, tag, tag_len, job->jobPrimitiveInputOutput.outputPtr, job->jobPrimitiveInputOutput.secondaryInputPtr);
				break;

			case CRYPTO_SIGNATUREGENERATE:
				return Crypto_Ecdsa_signature_generate(job->jobPrimitiveInputOutput.inputPtr, job->jobPrimitiveInputOutput.inputLength, job->jobPrimitiveInputOutput.outputPtr, job->jobPrimitiveInputOutput.outputLengthPtr);
				break;

			case CRYPTO_SIGNATUREVERIFY:
				return Crypto_Ecdsa_signature_verify(job->jobPrimitiveInputOutput.inputPtr, job->jobPrimitiveInputOutput.inputLength, job->jobPrimitiveInputOutput.outputPtr, job->jobPrimitiveInputOutput.outputLengthPtr);
				break;

			case CRYPTO_HASH:
				return Crypto_Process_hash(job->jobPrimitiveInputOutput.inputPtr, job->jobPrimitiveInputOutput.inputLength, job->jobPrimitiveInputOutput.outputPtr);
				break;

			}


		}

	} else if (job->jobPrimitiveInfo->processingType == CRYPTO_PROCESSING_ASYNC)

	{

		return E_NOT_OK;
	}


}

/************************************************************************************
 * Service Name: Crypto_KeyExchangeCalcSecret
 * Service ID[hex]: 0x0a
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant but not for the same cryptoKeyId
 * Parameters (in): uint32 cryptoKeyId,
					const uint8* partnerPublicValuePtr,
					uint32 partnerPublicValueLength
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: Std-ReturnType
 * Description: Calculates the shared secret key for the key exchange with the key material of the
 * key identified by the cryptoKeyId and the partner public key. The shared secret key
is stored as a key element in the same key.
 ************************************************************************************/

Std_ReturnType Crypto_KeyExchangeCalcSecret (
    uint32 cryptoKeyId,
    const uint8* partnerPublicValuePtr,
    uint32 partnerPublicValueLength
) {
	mbedtls_ecdh_context ecdh;
	mbedtls_ctr_drbg_context ctr_drbg;
	mbedtls_entropy_context entropy;
	mbedtls_ecp_point Qp;
	mbedtls_mpi z; // Shared secret
	uint8 shared_secret[32]; // Adjust size as needed
	unsigned char pub[65];
	size_t olen;
	int ret;

	mbedtls_ecdh_init(&ecdh);
	mbedtls_ecp_point_init(&Qp);
	mbedtls_mpi_init(&z);
	mbedtls_ctr_drbg_init(&ctr_drbg);
	mbedtls_entropy_init(&entropy);

	const char *pers = "ecdh";

	// Add custom entropy source
	if ((ret = mbedtls_entropy_add_source(&entropy, custom_entropy_source, NULL, 32, MBEDTLS_ENTROPY_SOURCE_STRONG)) != 0) {
		printf("Failed to add custom entropy source, error code: %d\n", ret);
		return E_NOT_OK;
	}

	if ((ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, (const unsigned char *) pers, strlen(pers))) != 0) {
		printf("Failed to seed RNG, error code: %d\n", ret);
		return E_NOT_OK;
	}

#if (CRYPTO_DEV_ERROR_DETECT == STD_ON)
	if (Crypto_Status != CRYPTO_STATE_INIT) {
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_PROCESSJOB_SID, CRYPTO_E_UNINIT);
		return E_NOT_OK;
	}
	if (partnerPublicValuePtr == NULL) {
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYIF_KEYEXCHANGECALCSECRET_SID, CRYPTO_E_PARAM_POINTER);
		return E_NOT_OK;
	}
	if (partnerPublicValueLength == 0) {
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYIF_KEYEXCHANGECALCSECRET_SID, CRYPTO_E_PARAM_VALUE);
		return E_NOT_OK;
	}
#endif

#if defined(MBEDTLS_ECDH_LEGACY_CONTEXT)
	mbedtls_ecp_group *grp = &ecdh.grp;
	mbedtls_mpi *d = &ecdh.d;
	mbedtls_ecp_point *Q = &ecdh.Q;
#else
	mbedtls_ecp_group *grp = &ecdh.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(grp);
	mbedtls_mpi *d = &ecdh.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(d);
	mbedtls_ecp_point *Q = &ecdh.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(Q);
#endif

	// Set up ECDH context and load the group
	if ((ret = mbedtls_ecdh_setup(&ecdh, MBEDTLS_ECP_DP_SECP256R1)) != 0) {
		printf("Failed to setup ECDH context, error code: %d\n", ret);
		mbedtls_ecdh_free(&ecdh);
		return E_NOT_OK;
	}

	// Verify the public key length and format
	printf("Partner public key length: %u\n", partnerPublicValueLength);
	if (partnerPublicValueLength != 65 || partnerPublicValuePtr[0] != 0x04) {
		printf("Invalid partner public key length or format\n");
		mbedtls_ecdh_free(&ecdh);
		return E_NOT_OK;
	}

	// Load the partner's public key
	if ((ret = mbedtls_ecp_point_read_binary(grp, &Qp, partnerPublicValuePtr, partnerPublicValueLength)) != 0) {
		printf("Failed to read partner's public key, error code: %d\n", ret);
		mbedtls_ecdh_free(&ecdh);
		return E_NOT_OK;
	}

	// Generate our own public/private key pair
	if ((ret = mbedtls_ecdh_gen_public(grp, d, Q, mbedtls_ctr_drbg_random, &ctr_drbg)) != 0) {
		printf("Failed to generate public key, error code: %d\n", ret);
		mbedtls_ecdh_free(&ecdh);
		return E_NOT_OK;
	}

	if ((ret = mbedtls_ecp_point_write_binary(grp, Q, MBEDTLS_ECP_PF_UNCOMPRESSED, &olen, pub, sizeof(pub))) != 0) {
		printf("Failed to write public key, error code: %d\n", ret);
		mbedtls_ecdh_free(&ecdh);
		return E_NOT_OK;
	}

	// Compute the shared secret
	if ((ret = mbedtls_ecdh_compute_shared(grp, &z, &Qp, d, mbedtls_ctr_drbg_random, &ctr_drbg)) != 0) {
		printf("Failed to compute shared secret, error code: %d\n", ret);
		mbedtls_ecdh_free(&ecdh);
		return E_NOT_OK;
	}

	// Export the shared secret
	if ((ret = mbedtls_mpi_write_binary(&z, shared_secret, sizeof(shared_secret))) != 0) {
		printf("Failed to write shared secret, error code: %d\n", ret);
		mbedtls_ecdh_free(&ecdh);
		return E_NOT_OK;
	}

	// Print the shared secret
	printf("Shared secret: ");
	for (size_t i = 0; i < sizeof(shared_secret); i++) {
		printf("%02X", shared_secret[i]);
	}
	printf("\n");

	// Cleanup
	mbedtls_ecdh_free(&ecdh);
	mbedtls_ecp_point_free(&Qp);
	mbedtls_mpi_free(&z);
	mbedtls_ctr_drbg_free(&ctr_drbg);
	mbedtls_entropy_free(&entropy);

	return E_OK;
}

/************************************************************************************
 * Service Name: Crypto_KeyExchangeCalcPubVal
 * Service ID[hex]: 0x09
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant but not for the same cryptoKeyId
 * Parameters (in): uint32 cryptoKeyId,
 * Parameters (inout): uint32 partnerPublicValueLengthPtr
 * Parameters (out): const uint8* partnerPublicValuePtr,
 * Return value: Std-ReturnType
 * Description: Calculates the public value for the key exchange and stores the public key in the
memory location pointed by the public value pointer
 ************************************************************************************/

Std_ReturnType Crypto_KeyExchangeCalcPubVal (
uint32 cryptoKeyId,
uint8* publicValuePtr,
uint32* publicValueLengthPtr
) {

#if (CRYPTO_DEV_ERROR_DETECT == STD_ON)
	if (Crypto_Status != CRYPTO_STATE_INIT) {
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYPTO_PROCESSJOB_SID, CRYPTO_E_UNINIT);
		return E_NOT_OK;
	}
	if (publicValuePtr == NULL) {
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYIF_KEYEXCHANGECALCSECRET_SID, CRYPTO_E_PARAM_POINTER);
		return E_NOT_OK;
	}
	if (publicValueLengthPtr == NULL) {
		Det_ReportError(CRYPTO_MODULE_ID, CRYPTO_INSTANCE_ID, CRYIF_KEYEXCHANGECALCSECRET_SID, CRYPTO_E_PARAM_VALUE);
		return E_NOT_OK;
	}
#endif

	mbedtls_ecdh_context ctx;
	mbedtls_ctr_drbg_context ctr_drbg;
	mbedtls_entropy_context entropy;
	int ret;

	mbedtls_ecdh_init(&ctx);
	mbedtls_ctr_drbg_init(&ctr_drbg);
	mbedtls_entropy_init(&entropy);

	const char *pers = "ecdh";

	// Add custom entropy source
	if ((ret = mbedtls_entropy_add_source(&entropy, custom_entropy_source, NULL, 32, MBEDTLS_ENTROPY_SOURCE_STRONG)) != 0) {
		printf("Failed to add custom entropy source, error code: %d\n", ret);
		return E_NOT_OK;
	}

	if ((ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, (const unsigned char *) pers, strlen(pers))) != 0) {
		printf("Failed to seed RNG, error code: %d\n", ret);
		return E_NOT_OK;
	}

	// Set up ECDH context and load the group
	if ((ret = mbedtls_ecdh_setup(&ctx, MBEDTLS_ECP_DP_SECP256R1)) != 0) {
		printf("Failed to setup ECDH context, error code: %d\n", ret);
		mbedtls_ecdh_free(&ctx);
		return E_NOT_OK;
	}

	// Generate the public/private key pair
	if ((ret = mbedtls_ecdh_gen_public(&ctx.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(grp),
									   &ctx.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(d),
									   &ctx.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(Q),
									   mbedtls_ctr_drbg_random, &ctr_drbg)) != 0) {
		printf("Failed to generate public key, error code: %d\n", ret);
		mbedtls_ecdh_free(&ctx);
		return E_NOT_OK;
	}

	// Write the public key to the provided buffer
	size_t olen;
	if ((ret = mbedtls_ecp_point_write_binary(&ctx.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(grp),
											  &ctx.MBEDTLS_PRIVATE(ctx).MBEDTLS_PRIVATE(mbed_ecdh).MBEDTLS_PRIVATE(Q),
											  MBEDTLS_ECP_PF_UNCOMPRESSED, &olen, publicValuePtr, *publicValueLengthPtr)) != 0) {
		printf("Failed to write public key, error code: %d\n", ret);
		mbedtls_ecdh_free(&ctx);
		return E_NOT_OK;
	}

	*publicValueLengthPtr = (uint32)olen;

	// Cleanup
	mbedtls_ecdh_free(&ctx);
	mbedtls_ctr_drbg_free(&ctr_drbg);
	mbedtls_entropy_free(&entropy);

	return E_OK;

}
