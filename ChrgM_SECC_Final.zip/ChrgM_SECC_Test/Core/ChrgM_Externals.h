/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_Externals.h
 *
 * Description: Header file for external ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef CHRGM_EXTERNALS_H_
#define CHRGM_EXTERNALS_H_

#include "V2G_Data_Types.h"

void ChrgM_ErrorIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_PaymentServiceSelectionIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_SessionSetupIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_SessionStopIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_SupportedAppProtocolIndication(ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_ServiceDiscoveryIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_ServiceDetailIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_PaymentDetailsIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_AuthorizationIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_ChargeParameterDiscoveryIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_CableCheckIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_PreChargeIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_PowerDeliveryIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_CurrentDemandIndication (ChrgM_ErrorHandlerType ErrorHandler);

void ChrgM_WeldingDetectionIndication (ChrgM_ErrorHandlerType ErrorHandler);

#endif /* CHRGM_EXTERNALS_H_ */
