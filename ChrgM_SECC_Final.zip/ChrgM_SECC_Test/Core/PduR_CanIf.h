/******************************************************************************
 *
 * Module: PduR
 *
 * File Name: PduR_CanIf.h
 *
 * Description: Routing logic implementation of the CanIf module
 *
 * Author: Kareem Azab
 ******************************************************************************/

#ifndef PDUR_CANIF_H_
#define PDUR_CANIF_H_



#include "PduR.h"

#define PduR_CanIfRxIndication_SID				(uint8)0x42
#define PduR_CanIfTriggerTransmit_SID			(uint8)0x43
#define PduR_CanIfTxConfirmation_SID    		(uint8)0x48




#if (PduRZeroCostOperation== STD_OFF) && (PduR_CanIf_Supported== TRUE)


Std_ReturnType PduR_CanIfTriggerTransmit (PduIdType TxPduId,  PduInfoType* PduInfoPtr);


void PduR_CanIfTxConfirmation (PduIdType TxPduId,  Std_ReturnType result);

void PduR_CanIfRxIndication (PduIdType RxPduId,  const PduInfoType* PduInfoPtr);




#endif


#endif /* PDUR_CANIF_H_ */
