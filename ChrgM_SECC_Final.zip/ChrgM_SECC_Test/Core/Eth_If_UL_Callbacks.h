/******************************************************************************
*
* Module: Ethernet Interface
*
* File Name: Eth_If_UL_Callbacks.h
*
* Description: Source File For the Ethernet Interface Callback Functions Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/

#ifndef ETH_IF_UL_CALLBACKS_H_
#define ETH_IF_UL_CALLBACKS_H_

extern void TcpIp_RxIndication (uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast,const uint8* PhysAddrPtr, const Eth_DataType* DataPtr, uint16 LenByte);
extern void ChargeM_RxIndication (uint8 CtrlIdx, Eth_FrameType FrameType, boolean IsBroadcast,const uint8* PhysAddrPtr, const Eth_DataType* DataPtr, uint16 LenByte);
/* extern void TcpIp_TxConfirmation (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result); */
extern void ChargeM_TxConfirmation (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result);

#endif /* UL_CALLBACKS_H_ */
