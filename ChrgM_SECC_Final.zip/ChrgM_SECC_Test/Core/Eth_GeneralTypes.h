/******************************************************************************
*
* Module: Ethernet
*
* File Name: Eth_GeneralTypes.h
*
* Description:  Header File For Ethernet Gerneral Types Needed.
*
* Author:
******************************************************************************/

#ifndef ETH_GENERALTYPES_H_
#define ETH_GENERALTYPES_H_


#define ETH_GENERAL_TYPES_VENDOR_ID                                  (1000U)
/*
* Module Version 1.0.0
*/
#define ETH_GENERAL_TYPES_SW_MAJOR_VERSION                           (1U)
#define ETH_GENERAL_TYPES_SW_MINOR_VERSION                           (0U)
#define ETH_GENERAL_TYPES_SW_PATCH_VERSION                           (0U)
/*
* AUTOSAR Version R22-11
*/
#define ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION                   (1U)//(4U)
#define ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION                   (0U)//(7U)
#define ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION                   (0U)//(0U)

/* Standard AUTOSAR types */
#include "Std_Types.h"
/* AUTOSAR checking between Std_Types.h and Eth_GeneralTypes.h
*
*/
#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION)\
||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION)\
  ||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Std_Types.h does not match the expected version"
#endif

/* ComStack_Types */
#include "ComStack_Types.h"
/* AUTOSAR checking between ComStack_Types.hand Eth_GeneralTypes.h
*
*/
#if ((COMSTACK_TYPES_AR_RELEASE_MAJOR_VERSION != ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION)\
||  (COMSTACK_TYPES_AR_RELEASE_MINOR_VERSION != ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION)\
  ||  (COMSTACK_TYPES_AR_RELEASE_PATCH_VERSION != ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ComStack_Types.h does not match the expected version"
#endif

/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef uint16 Eth_FrameType ;
typedef uint32 Eth_BufIdxType ;
typedef uint8 Eth_DataType;


typedef enum {
  ETH_RECEIVED,
  ETH_NOT_RECEIVED,
  ETH_RECEIVED_MORE_DATA_AVAILABLE,
  ETH_RECEIVED_FRAMES_LOST /* not available in 4.2.2 version on */
}Eth_RxStatusType;

typedef enum {
  ETH_MODE_DOWN,
  ETH_MODE_ACTIVE,
  ETH_MODE_TX_OFFLINE,
  ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST
}Eth_ModeType;

typedef enum
{
	ETHTRCV_LINK_STATE_DOWN,
	ETHTRCV_LINK_STATE_ACTIVE
}EthTrcv_LinkStateType;


#endif /* ETH_GENERALTYPES_H_ */
