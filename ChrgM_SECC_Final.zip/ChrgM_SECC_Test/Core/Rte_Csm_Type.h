/*
 ============================================================================
 Name        : Rte_Csm_Type.h
 Author      : Mazen Tarek
 Version     :
 Copyright   : Your copyright notice
 Description : Header file for Rte Csm
 ============================================================================
 */

typedef enum {
	CRYPTO_E_VER_OK,
	CRYPTO_E_VER_NOT_OK
}Crypto_VerifyResultType;

typedef enum {

	CRYPTO_E_BUSY,
	CRYPTO_E_ENTROPY_EXHAUSTED,
	CRYPTO_E_KEY_READ_FAIL,
	CRYPTO_E_KEY_WRITE_FAIL,
	CRYPTO_E_KEY_NOT_AVAILABLE,
	CRYPTO_E_KEY_NOT_VALID,
	CRYPTO_E_KEY_SIZE_MISMATCH,
	CRYPTO_E_JOB_CANCELED,
	CRYPTO_E_KEY_EMPTY,

}Crypto_ResultType;
