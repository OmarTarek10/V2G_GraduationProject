

Std_ReturnType tripleDesEncrypt(const uint8* message, uint8 * outputPtr,uint32 messageLength , uint32 * outputLength);
Std_ReturnType tripleDesDecrypt(const uint8 * message, uint8 * outputPtr, uint32 messageLength, uint32 * outputLength);
