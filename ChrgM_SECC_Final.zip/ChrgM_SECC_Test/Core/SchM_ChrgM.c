/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: SchM_ChrgM.h
 *
 * Description: Source file for Scheduler ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM.h"

extern uint8 MessageBuffer[BUFFER_SIZE];
extern struct iso1EXIDocument V2G_EXI_Document;

extern void *ChrgM_MessagePtr;

extern V2GMessageHeaderType V2G_Request_Header;

extern SECCDiscoveryProtocolReqType SECCDiscoveryProtocolReq_Message;
extern SECCDiscoveryProtocolResType SECCDiscoveryProtocolRes_Message;
extern SessionStopReqType SessionStopReq_Message;


extern ChrgM_ModuleStateType ChrgM_ModuleState;
extern ChrgM_ErrorStatusType ChrgM_TxErrorStatus;
extern ChrgM_ErrorStatusType ChrgM_RxErrorStatus;
extern ChrgM_ModuleStateType ChrgM_TxErrorState;
extern ChrgM_ModuleStateType ChrgM_RxErrorState;
extern EthTrcv_LinkStateType ChrgM_TransceiverLinkState;
extern uint8 ChrgM_CpLine;
extern boolean ChrgM_IpAddressIndicationReceived;
extern TcpIp_IpAddrStateType ChrgM_IpAddressState;
extern boolean ChrgM_OpenUDPSocketRequested;
extern boolean ChrgM_OpenTCPSocketRequested;
extern SoAd_SoConModeType ChrgM_TCPSoConMode;
extern boolean ChrgM_SocketIndicationReceived;
extern SoAd_SoConModeType ChrgM_UDPSoConMode;
extern boolean ChrgM_PdurRequestSuccessful;
extern boolean ChrgM_DataWritten;
extern boolean ChrgM_DataEncoded;
extern boolean ChrgM_DataEncrypted;
extern boolean ChrgM_TxConfirmationReceived;
extern boolean ChrgM_TransmissionSuccessful;
extern ChrgM_MessageStateType ChrgM_RequestedMessage;
extern boolean ChrgM_OngoingTimerStarted;
extern boolean ChrgM_OngoingTimerElapsed;
extern SoAd_SoConIdType ChrgM_SocketConID;
extern PduInfoType ChrgM_PduInfo;
extern PduIdType ChrgM_PduID;
extern boolean ChrgM_MessageRequested;
extern boolean ChrgM_MessageReceived;
extern boolean ChrgM_ValidEVCCReceived;
extern boolean ChrgM_SequenceTimerElapsed;
extern boolean ChrgM_PerformanceTimerElapsed;
extern boolean ChrgM_ReceptionSuccessful;
extern ChrgM_MessageStateType ChrgM_PreviousMessage;
extern chargingSessionType ChrgM_SessionStopCommand;
extern boolean ChrgM_ReceptionDone;
extern sessionIDType ChrgM_CurrentSessionID;
extern boolean ChrgM_CommunicationSetupTimerElapsed;
extern PayloadLengthType Received_Payload;
MessageType ChrgM_IncomingMessage;

/************************************************************************************
 * Service Name: ChrgM_MainFunction_Rx
 * Service ID[hex]: 0x24
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different instances. Non reentrant for the same instance
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the processing of the AUTOSAR ChrgM module’s receive processing
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_MainFunction_Rx (void)
{
	if(ChrgM_ModuleState != NOT_INITIALIZED)
	{
		if(ChrgM_RxErrorStatus == NO_ERROR_STATUS)
		{
			if(ChrgM_PerformanceTimerElapsed == FALSE && ChrgM_SequenceTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
			{
				switch(ChrgM_ModuleState)
				{
				case INIT:
				case ASSIGNING_IP_ADDRESS:
				case ESTABLISHING_TCP_TLS:
					/* Do Nothing */
					break;

				case SECC_IDLE: /* Waiting for SupportedAppProtocol Request */
					if(ChrgM_MessageReceived == TRUE)
					{
						if(ChrgM_ReceptionSuccessful == TRUE)
						{
							if(/*Csm_Decrypt(1, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Received_Payload) == E_OK*/1) /* Decrypt Data */
							{
								if(ChrgM_ReadV2GTPHeader() == E_OK)
								{
									/* Start Communication Setup Timer */
									if(ChrgM_PreviousMessage == NO_MESSAGE)
									{
										ChrgM_SupportedAppProtocolReq();
										ChrgM_IncomingMessage = SUPPORTED_APP_PROTOCOL_MESSAGE;
										ChrgM_SupportedAppProtocolIndication(CHRGM_NoError);
										ChrgM_PreviousMessage = SUPPORTED_APP_PROTOCOL;
										ChrgM_ModuleState = V2G_SESSION_ONGOING;
									}
									else
									{
										/* Sequence Error */
										ChrgM_ErrorIndication(CHRGM_SequenceError);
										ChrgM_TxErrorStatus = SET_BY_RX;
										ChrgM_RxErrorStatus = SET_BY_RX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
									}
									ChrgM_MessageRequested = FALSE;
									ChrgM_MessageReceived = FALSE;
									ChrgM_ReceptionSuccessful = FALSE;
								}
								else
								{
									/* V2G Header Error */
									ChrgM_ErrorIndication(V2G_Header_Check_Error);
									ChrgM_TxErrorStatus = SET_BY_RX;
									ChrgM_RxErrorStatus = SET_BY_RX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							/* Do Nothing */
						}
						ChrgM_ReceptionDone = TRUE;
						/* Reset Buffer Data */
						memset(MessageBuffer, 0, BUFFER_SIZE);
					}
					else
					{
						/* Do Nothing */
					}

					break;
				case V2G_SESSION_ONGOING:
				case V2G_SESSION_PAUSED:
					if(ChrgM_MessageReceived == TRUE)
					{
						if(ChrgM_ReceptionSuccessful == TRUE)
						{
							if(/*Csm_Decrypt(1, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Received_Payload) == E_OK*/1) /* Decrypt Data */
							{
								if(ChrgM_ReadV2GTPHeader() == E_OK)
								{
									/* Reset V2G Document Data */
									memset(&V2G_EXI_Document, 0, sizeof(V2G_EXI_Document));
									if(ChrgM_EXIDecode(MessageBuffer + V2G_HEADER_SIZE, Received_Payload, &V2G_EXI_Document) == E_OK)
									{
										/* Reset Sequence Timer */
										ChrgM_IncomingMessage = NO_MESSAGE;
										ChrgM_MessageReceived = FALSE;
										ChrgM_ReceptionSuccessful = FALSE;
										if(V2G_Request_Header.PayloadType == V2G_MESSAGE_PAYLOAD_TYPE_VALUE)
										{
											if(ChrgM_ModuleState != V2G_SESSION_PAUSED)
											{
												ChrgM_ModuleState = V2G_SESSION_ONGOING;
											}
											else
											{
												/* Do Nothing */
											}
											ChrgM_IncomingMessage = ChrgM_ReadMessageName();
										}
#if(CHRGM_SDP_USED == STD_ON)
										else if(V2G_Request_Header.PayloadType == SDP_REQUEST_PAYLOAD_TYPE_VALUE)
										{
											ChrgM_ModuleState = DISCOVERING_EVCC;
										}
#endif /* CHRGM SDP USED */
										else
										{
											/* Do Nothing Invalid Message */
										}

										switch(ChrgM_IncomingMessage)
										{
										case SESSION_SETUP_MESSAGE:
											if(ChrgM_PreviousMessage == SUPPORTED_APP_PROTOCOL)
											{
												/* Data Already Written */
												ChrgM_SessionSetupIndication(CHRGM_NoError);
												ChrgM_PreviousMessage = SESSION_SETUP;
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case SERVICE_DISCOVERY_MESSAGE:
											if(ChrgM_PreviousMessage == SESSION_SETUP)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_ServiceDiscoveryIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = SERVICE_DISCOVERY;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case PAYMENT_SELECTION_MESSAGE:
											if(ChrgM_PreviousMessage == SERVICE_DISCOVERY)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_PaymentServiceSelectionIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = PAYMENT_SELECTION;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case PAYMENT_DETAILS_MESSAGE:
											if(ChrgM_PreviousMessage == PAYMENT_SELECTION)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_PaymentDetailsIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = PAYMENT_DETAILS;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case AUTHORIZATION_MESSAGE:
											if(ChrgM_PreviousMessage == PAYMENT_DETAILS || ChrgM_PreviousMessage == AUTHORIZATION)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_AuthorizationIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = AUTHORIZATION_MESSAGE;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case CHARGE_PARAMETER_DISCOVERY_MESSAGE:
											if(ChrgM_PreviousMessage == AUTHORIZATION || ChrgM_PreviousMessage == CHARGE_PARAMETER_DISCOVERY || ChrgM_PreviousMessage == POWER_DELIVERY)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_ChargeParameterDiscoveryIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = CHARGE_PARAMETER_DISCOVERY;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case CABLE_CHECK_MESSAGE:
											if(ChrgM_PreviousMessage == CHARGE_PARAMETER_DISCOVERY || ChrgM_PreviousMessage == CABLE_CHECK)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_CableCheckIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = CABLE_CHECK;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case PRE_CHARGE_MESSAGE:
											if(ChrgM_PreviousMessage == CABLE_CHECK || ChrgM_PreviousMessage == PRE_CHARGE)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_PreChargeIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = PRE_CHARGE;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case POWER_DELIVERY_MESSAGE:
											if(ChrgM_PreviousMessage == PRE_CHARGE || ChrgM_PreviousMessage == POWER_DELIVERY || ChrgM_PreviousMessage == CURRENT_DEMAND)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_PowerDeliveryIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = POWER_DELIVERY;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case CURRENT_DEMAND_MESSAGE:
											if(ChrgM_PreviousMessage == POWER_DELIVERY || ChrgM_PreviousMessage == CURRENT_DEMAND)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_CurrentDemandIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = CURRENT_DEMAND;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case WELDING_DETECTION_MESSAGE:
											if(ChrgM_PreviousMessage == POWER_DELIVERY)
											{
												/* Data Already Written */
												if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
												{
													ChrgM_WeldingDetectionIndication(CHRGM_NoError);
													ChrgM_PreviousMessage = WELDING_DETECTION;
												}
												else
												{
													/* Unknown Session */
													ChrgM_ErrorIndication(CHRGM_UnknownSession);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Sequence Error */
												ChrgM_ErrorIndication(CHRGM_SequenceError);
												ChrgM_TxErrorStatus = SET_BY_RX;
												ChrgM_RxErrorStatus = SET_BY_RX;
												ChrgM_TxErrorState = ChrgM_ModuleState;
												ChrgM_RxErrorState = ChrgM_ModuleState;
											}
											break;

										case SESSION_STOP_MESSAGE:
											if(ChrgM_ModuleState == V2G_SESSION_ONGOING)
											{
												if(ChrgM_PreviousMessage == POWER_DELIVERY || ChrgM_PreviousMessage == WELDING_DETECTION)
												{
													/* Data Already Written */
													if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
													{
														ChrgM_SessionStopIndication(CHRGM_NoError);
														ChrgM_PreviousMessage = SESSION_STOP;
														ChrgM_SessionStopCommand = V2G_EXI_Document.V2G_Message.Body.SessionStopReq.ChargingSession;
														if(ChrgM_SessionStopCommand == Terminate)
														{
															ChrgM_PreviousMessage = NO_MESSAGE;
														}
														else
														{
															/* Do Nothing */
														}
													}
													else
													{
														/* Unknown Session */
														ChrgM_ErrorIndication(CHRGM_UnknownSession);
														ChrgM_TxErrorStatus = SET_BY_RX;
														ChrgM_RxErrorStatus = SET_BY_RX;
														ChrgM_TxErrorState = ChrgM_ModuleState;
														ChrgM_RxErrorState = ChrgM_ModuleState;
													}
												}
												else
												{
													/* Sequence Error */
													ChrgM_ErrorIndication(CHRGM_SequenceError);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else if(ChrgM_ModuleState == V2G_SESSION_PAUSED)
											{
												if(ChrgM_PreviousMessage == SESSION_STOP)
												{
													/* Data Already Written */
													if(V2G_EXI_Document.V2G_Message.Header.SessionID.bytes[0] == ChrgM_CurrentSessionID)
													{
														ChrgM_SessionStopIndication(CHRGM_NoError);
														ChrgM_SessionStopCommand = V2G_EXI_Document.V2G_Message.Body.SessionStopReq.ChargingSession;
														if(ChrgM_SessionStopCommand == Terminate)
														{
															ChrgM_PreviousMessage = NO_MESSAGE;
														}
														else
														{
															/* Do Nothing */
														}
													}
													else
													{
														/* Unknown Session */
														ChrgM_ErrorIndication(CHRGM_UnknownSession);
														ChrgM_TxErrorStatus = SET_BY_RX;
														ChrgM_RxErrorStatus = SET_BY_RX;
														ChrgM_TxErrorState = ChrgM_ModuleState;
														ChrgM_RxErrorState = ChrgM_ModuleState;
													}
												}
												else
												{
													/* Sequence Error */
													ChrgM_ErrorIndication(CHRGM_SequenceError);
													ChrgM_TxErrorStatus = SET_BY_RX;
													ChrgM_RxErrorStatus = SET_BY_RX;
													ChrgM_TxErrorState = ChrgM_ModuleState;
													ChrgM_RxErrorState = ChrgM_ModuleState;
												}
											}
											else
											{
												/* Do Nothing */
											}

											break;

										default: /* DISCOVERING EVCC */
											/* Do Nothing */
											break;
										}
									}
									else
									{
										/* Decode Error */
									}
									ChrgM_MessageRequested = FALSE;
									ChrgM_MessageReceived = FALSE;
									ChrgM_ReceptionSuccessful = FALSE;
								}
								else
								{
									/* V2G Header Error */
									ChrgM_ErrorIndication(V2G_Header_Check_Error);
									ChrgM_TxErrorStatus = SET_BY_RX;
									ChrgM_RxErrorStatus = SET_BY_RX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							/* Reception Error */
						}
						ChrgM_ReceptionDone = TRUE;
						/* Reset Buffer Data */
						memset(MessageBuffer, 0, BUFFER_SIZE);
					}
					else
					{
						/* No Message Received */
					}

					break;

#if(CHRGM_SDP_USED == STD_ON)
				case DISCOVERING_EVCC:
					ChrgM_SECCDiscoveryProtocolReq();
					if(SECCDiscoveryProtocolReq_Message.SECCTransportProtocol == TCP)
					{
						SECCDiscoveryProtocolRes_Message.SECCTransportProtocol = TCP;
						if(SECCDiscoveryProtocolReq_Message.SECCSecurity == TLS)
						{
							SECCDiscoveryProtocolRes_Message.SECCSecurity = TLS;
							ChrgM_ValidEVCCReceived = TRUE;
						}
						else if(SECCDiscoveryProtocolReq_Message.SECCSecurity == NO_TLS)
						{
							SECCDiscoveryProtocolRes_Message.SECCSecurity = NO_TLS;
							ChrgM_ValidEVCCReceived = TRUE;
						}
						else
						{
							/* Dont Respond Invalid Request */
						}
					}
					else if(SECCDiscoveryProtocolReq_Message.SECCTransportProtocol == UDP && SECCDiscoveryProtocolReq_Message.SECCSecurity == NO_TLS)
					{
						SECCDiscoveryProtocolRes_Message.SECCTransportProtocol = UDP;
						SECCDiscoveryProtocolRes_Message.SECCSecurity = NO_TLS;
						ChrgM_ValidEVCCReceived = TRUE;
					}
					else
					{
						/* Dont Respond Invalid Request */
					}

					break;
#endif
				}
			}
			else
			{
				/* Check which error */
				if(ChrgM_SequenceTimerElapsed == TRUE)
				{
					ChrgM_ErrorIndication(V2G_SECC_SequenceTimeout);
				}
				else if(ChrgM_PerformanceTimerElapsed == TRUE)
				{
					ChrgM_ErrorIndication(V2G_SECC_PerformanceTimeout);
				}
				else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
				{
					ChrgM_ErrorIndication(CHRGM_EthLinkDown);
				}
				else if(ChrgM_CpLine == INACTIVE)
				{
					ChrgM_ErrorIndication(CHRGM_CpLineInactive);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_TxErrorStatus = SET_BY_RX;
				ChrgM_RxErrorStatus = SET_BY_RX;
				ChrgM_TxErrorState = ChrgM_ModuleState;
				ChrgM_RxErrorState = ChrgM_ModuleState;
			}
		}
		else
		{
			/* Do Nothing */
		}

		if(ChrgM_TxErrorStatus == SET_BY_TX || ChrgM_TxErrorStatus == SET_BY_RX)
		{
			switch(ChrgM_RxErrorState)
			{
			case INIT:
				/* Do Nothing */
				break;

			case ASSIGNING_IP_ADDRESS:
			case ESTABLISHING_TCP_TLS:
				ChrgM_RxErrorState = INIT;
				ChrgM_ModuleState = INIT;
				ChrgM_OpenUDPSocketRequested = FALSE;
				ChrgM_IpAddressIndicationReceived = FALSE;
				ChrgM_SocketIndicationReceived = FALSE;
				ChrgM_UDPSoConMode = SOAD_SOCON_OFFLINE;
				ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
				break;
#if(CHRGM_SDP_USED == STD_OFF)
			case SECC_IDLE:
				ChrgM_RxErrorState = INIT;
				if(ChrgM_RxErrorStatus == SET_BY_RX)
				{
					ChrgM_ModuleState = INIT;
					ChrgM_RequestedMessage = NO_MESSAGE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataEncrypted = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_MessageRequested = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_OngoingTimerElapsed = FALSE;
					ChrgM_OngoingTimerStarted = FALSE;
					ChrgM_SequenceTimerElapsed = FALSE;
					ChrgM_ReceptionDone = TRUE;
					ChrgM_ReceptionSuccessful = FALSE;
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_RxErrorStatus = NO_ERROR_STATUS;
				break;
#else
			case DISCOVERING_EVCC:
				ChrgM_RxErrorState = INIT;
				if(ChrgM_RxErrorStatus == SET_BY_TX)
				{
					ChrgM_ModuleState = DISCOVERING_EVCC;
					ChrgM_ValidEVCCReceived = FALSE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_ReceptionSuccessful = FALSE;
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_RxErrorStatus = NO_ERROR_STATUS;
				break;
#endif
			case V2G_SESSION_ONGOING:
			case V2G_SESSION_PAUSED:
				ChrgM_RxErrorState = INIT;
				if(ChrgM_RxErrorStatus == SET_BY_TX)
				{
#if(CHRGM_SDP_USED == STD_ON)
					ChrgM_ModuleState = DISCOVERING_EVCC;
#else
					ChrgM_ModuleState = INIT;
#endif
					ChrgM_RequestedMessage = NO_MESSAGE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataEncrypted = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_MessageRequested = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_OngoingTimerElapsed = FALSE;
					ChrgM_OngoingTimerStarted = FALSE;
					ChrgM_SequenceTimerElapsed = FALSE;
					ChrgM_ReceptionDone = TRUE;
					ChrgM_ReceptionSuccessful = FALSE;
					/* Reset Sequence Timer */
					/* Reset Performance Timer */
					/* Reset Ongoing Timer */
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_RxErrorStatus = NO_ERROR_STATUS;
				break;
			}
		}
		else
		{
			/* Do Nothing */
		}
	}
	else
	{
		/* Do Nothing DET Error */
	}
}

