/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_SchM.c
 *
 * Description: Source file for Scheduler ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM.h"

extern uint8 MessageBuffer[BUFFER_SIZE];
extern struct iso1EXIDocument V2G_EXI_Document;
extern struct iso1EXIDocument* ChrgM_DocumentPtr;

extern void *ChrgM_MessagePtr;

extern ChrgM_ModuleStateType ChrgM_ModuleState;
extern ChrgM_ErrorStatusType ChrgM_TxErrorStatus;
extern ChrgM_ErrorStatusType ChrgM_RxErrorStatus;
extern ChrgM_ModuleStateType ChrgM_TxErrorState;
extern ChrgM_ModuleStateType ChrgM_RxErrorState;
extern EthTrcv_LinkStateType ChrgM_TransceiverLinkState;
extern uint8 ChrgM_CpLine;
extern boolean ChrgM_IpAddressIndicationReceived;
extern TcpIp_IpAddrStateType ChrgM_IpAddressState;
extern boolean ChrgM_OpenUDPSocketRequested;
extern boolean ChrgM_OpenTCPSocketRequested;
extern SoAd_SoConModeType ChrgM_TCPSoConMode;
extern boolean ChrgM_SocketIndicationReceived;
extern SoAd_SoConModeType ChrgM_UDPSoConMode;
extern boolean ChrgM_PdurRequestSuccessful;
extern boolean ChrgM_DataWritten;
extern boolean ChrgM_DataEncoded;
extern boolean ChrgM_DataEncrypted;
extern boolean ChrgM_TxConfirmationReceived;
extern boolean ChrgM_TransmissionSuccessful;
extern ChrgM_MessageStateType ChrgM_RequestedMessage;
extern boolean ChrgM_OngoingTimerStarted;
extern boolean ChrgM_OngoingTimerElapsed;
extern SoAd_SoConIdType ChrgM_SocketConID;
extern PduInfoType ChrgM_PduInfo;
extern PduIdType ChrgM_PduID;
extern boolean ChrgM_MessageRequested;
extern boolean ChrgM_MessageReceived;
extern boolean ChrgM_ValidEVCCReceived;
extern boolean ChrgM_SequenceTimerElapsed;
extern boolean ChrgM_PerformanceTimerStarted;
extern boolean ChrgM_PerformanceTimerElapsed;
extern chargingSessionType ChrgM_SessionStopCommand;
extern boolean ChrgM_ReceptionDone;
extern boolean ChrgM_ReceptionSuccessful;
extern sessionIDType ChrgM_CurrentSessionID;
extern boolean ChrgM_CommunicationSetupTimerElapsed;
extern PayloadLengthType Sent_Payload;

/************************************************************************************
 * Service Name: ChrgM_MainFunction_Tx
 * Service ID[hex]: 0x23
 * Sync/Async:
 * Reentrancy:
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the processing of the AUTOSAR ChrgM module’s transmit processing
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_MainFunction_Tx (void)
{
	if(ChrgM_ModuleState != NOT_INITIALIZED)
	{
		if(ChrgM_TxErrorStatus == NO_ERROR_STATUS)
		{
			switch(ChrgM_ModuleState)
			{
			case NOT_INITIALIZED:
				/* Impossible case, Do Nothing */
				break;
			case INIT:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE)
				{
					if(SoAd_RequestIpAddrAssignment() == E_OK)
					{
						ChrgM_ModuleState = ASSIGNING_IP_ADDRESS;
						/* Call Function Manually since IP is static to proceed with states */
						ChrgM_V2GTpLocalIpAddrAssignmentChg (0, TCPIP_IPADDR_STATE_ASSIGNED);
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					/* Do Nothing */
				}
				break;

			case ASSIGNING_IP_ADDRESS:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_IpAddressIndicationReceived == TRUE)
					{
						if(ChrgM_IpAddressState == TCPIP_IPADDR_STATE_ASSIGNED)
						{
#if(CHRGM_SDP_USED == STD_ON)
							if(ChrgM_OpenUDPSocketRequested == FALSE)
							{
								SoAd_OpenSoCon(ChrgM_SocketConID); /* UDP Socket */
								ChrgM_OpenUDPSocketRequested = TRUE;
							}
							else
							{
								if(ChrgM_SocketIndicationReceived == TRUE)
								{
									if(ChrgM_UDPSoConMode == SOAD_SOCON_ONLINE)
									{

										ChrgM_ModuleState = DISCOVERING_EVCC;
										ChrgM_OpenUDPSocketRequested = FALSE;
										ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
										ChrgM_UDPSoConMode = SOAD_SOCON_OFFLINE;
										ChrgM_IpAddressIndicationReceived = FALSE;
										ChrgM_SocketIndicationReceived = FALSE;
									}
									else
									{
										ChrgM_ErrorIndication(CHRGM_SocketOffline);
										ChrgM_TxErrorStatus = SET_BY_TX;
										ChrgM_RxErrorStatus= SET_BY_TX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
									}
								}
								else
								{
									/* Do Nothing */
								}
							}
#else
							ChrgM_ModuleState = ESTABLISHING_TCP_TLS;
							ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
							ChrgM_IpAddressIndicationReceived = FALSE;
#endif
						}
						else
						{
							ChrgM_ErrorIndication(CHRGM_IPAddressUnassigned);
							ChrgM_TxErrorStatus = SET_BY_TX;
							ChrgM_RxErrorStatus = SET_BY_TX;
							ChrgM_TxErrorState = ChrgM_ModuleState;
							ChrgM_RxErrorState = ChrgM_ModuleState;
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;

			case ESTABLISHING_TCP_TLS:
				if(ChrgM_CommunicationSetupTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_OpenTCPSocketRequested == FALSE)
					{
						SoAd_OpenSoCon(ChrgM_SocketConID); /* TCP Socket*/
						ChrgM_OpenTCPSocketRequested = TRUE;
					}
					else
					{
						if(ChrgM_SocketIndicationReceived == TRUE)
						{
							if(ChrgM_TCPSoConMode == SOAD_SOCON_ONLINE)
							{
#if(CHRGM_SDP_USED == STD_ON)
								SoAd_CloseSoCon(ChrgM_SocketConID, TRUE); /* UDP Socket */
								ChrgM_OpenTCPSocketRequested = FALSE;
								ChrgM_TCPSoConMode = SOAD_SOCON_OFFLINE;
#endif
								ChrgM_ModuleState = SECC_IDLE;
							}
							else
							{
								ChrgM_ErrorIndication(CHRGM_SocketOffline);
								ChrgM_TxErrorStatus = SET_BY_TX;
								ChrgM_RxErrorStatus = SET_BY_TX;
								ChrgM_TxErrorState = ChrgM_ModuleState;
								ChrgM_RxErrorState = ChrgM_ModuleState;
							}
						}
						else
						{
							/* Do Nothing */
						}
					}
				}
				else
				{
					if(ChrgM_CommunicationSetupTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_SECC_CommunicationSetupTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;

#if(CHRGM_SDP_USED == STD_OFF)
			case SECC_IDLE:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					/* Do Nothing */
				}
				else
				{
					if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}

				break;
#else
			case DISCOVERING_EVCC:
				if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_ValidEVCCReceived == TRUE)
					{
						if(ChrgM_PdurRequestSuccessful == FALSE)
						{
							if(ChrgM_DataWritten == FALSE)
							{
								ChrgM_SECCDiscoveryProtocolRes();
								ChrgM_DataWritten = TRUE;
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
							{
								if(ChrgM_EXIEncode() == E_OK)
								{
									ChrgM_DataEncoded = TRUE;
									ChrgM_WriteV2GTPHeader();
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_PdurRequestSuccessful == FALSE && ChrgM_DataEncoded == TRUE)
							{
								if(PduR_ChrgMTransmit(ChrgM_PduID, &ChrgM_PduInfo) == E_OK)
								{
									ChrgM_PdurRequestSuccessful = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							if(ChrgM_TxConfirmationReceived == TRUE)
							{
								if(ChrgM_TransmissionSuccessful == TRUE)
								{
									ChrgM_TransmissionSuccessful = FALSE;
									ChrgM_TxConfirmationReceived = FALSE;
									ChrgM_ValidEVCCReceived = FALSE;
									ChrgM_DataWritten = FALSE;
									ChrgM_DataEncoded = FALSE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#else
									ChrgM_PdurRequestSuccessful = FALSE;
#endif
								}
							}
							else
							{
								/* Do Nothing */
							}
						}

					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;
#endif
			case V2G_SESSION_ONGOING:
				if(ChrgM_OngoingTimerElapsed == FALSE && ChrgM_SequenceTimerElapsed == FALSE && ChrgM_PerformanceTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_ReceptionDone == TRUE)
					{
						if(ChrgM_MessageRequested == FALSE)
						{
							if(ChrgM_DataWritten == FALSE)
							{
								switch(ChrgM_RequestedMessage)
								{
								case NO_MESSAGE:
									/* Do Nothing */
									break;
								case SUPPORTED_APP_PROTOCOL:
									ChrgM_WriteSupportedAppProtocolRes();
									ChrgM_DataWritten = TRUE;
									break;
								case SESSION_SETUP:
									/* Data Already Written */
									ChrgM_CurrentSessionID = ChrgM_DocumentPtr->V2G_Message.Header.SessionID.bytes[0]; /* Only first byte is used */
									ChrgM_DataWritten = TRUE;
									break;
								case SERVICE_DISCOVERY:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								case PAYMENT_SELECTION:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								case PAYMENT_DETAILS:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								case AUTHORIZATION:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									if((EVSEProcessingType)ChrgM_DocumentPtr->V2G_Message.Body.AuthorizationRes.EVSEProcessing == Ongoing)
									{
										if(ChrgM_OngoingTimerStarted == FALSE)
										{
											/* Start Ongoing Timer */
											ChrgM_OngoingTimerStarted = TRUE;
										}
										else
										{
											/* Do Nothing */
										}
									}
									else
									{
										/* Reset Ongoing Timer */
										ChrgM_OngoingTimerStarted = FALSE;
									}
									break;
								case CHARGE_PARAMETER_DISCOVERY:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									if((EVSEProcessingType)ChrgM_DocumentPtr->V2G_Message.Body.ChargeParameterDiscoveryRes.EVSEProcessing == Ongoing)
									{
										if(ChrgM_OngoingTimerStarted == FALSE)
										{
											/* Start Ongoing Timer */
											ChrgM_OngoingTimerStarted = TRUE;
										}
										else
										{
											/* Do Nothing */
										}
									}
									else
									{
										/* Reset Ongoing Timer */
										ChrgM_OngoingTimerStarted = FALSE;
									}
									break;
								case CABLE_CHECK:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									if((EVSEProcessingType)ChrgM_DocumentPtr->V2G_Message.Body.CableCheckRes.EVSEProcessing == Ongoing)
									{
										if(ChrgM_OngoingTimerStarted == FALSE)
										{
											/* Start Ongoing Timer */
											ChrgM_OngoingTimerStarted = TRUE;
										}
										else
										{
											/* Do Nothing */
										}
									}
									else
									{
										/* Reset Ongoing Timer */
										ChrgM_OngoingTimerStarted = FALSE;
									}
									break;
								case PRE_CHARGE:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								case POWER_DELIVERY:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								case CURRENT_DEMAND:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								case WELDING_DETECTION:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								case SESSION_STOP:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;
								default:
									/* Do Nothing, Det Error */
									break;
								}
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_RequestedMessage == SUPPORTED_APP_PROTOCOL && ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
							{
								ChrgM_DataEncoded = TRUE;
								ChrgM_WriteV2GTPHeader();
							}
							else
							{
								if(ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
								{
									if(ChrgM_EXIEncode(MessageBuffer + V2G_HEADER_SIZE, &Sent_Payload) == E_OK)
									{
										ChrgM_DataEncoded = TRUE;
										ChrgM_WriteV2GTPHeader();
									}
									else
									{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
										ChrgM_TxErrorStatus = SET_BY_TX;
										ChrgM_RxErrorStatus = SET_BY_TX;
										ChrgM_TxErrorState = ChrgM_ModuleState;
										ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
										/* Do Nothing */
									}
								}
								else
								{
									/* Do Nothing */
								}
							}

							if(ChrgM_DataEncoded == TRUE && ChrgM_DataEncrypted == FALSE)
							{
								if(/*Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Sent_Payload) == E_OK*/1) /* Encrypt Data */
								{
									//ChrgM_PduInfo.SduLength = 50;
									ChrgM_DataEncrypted = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}

							if(ChrgM_PdurRequestSuccessful == FALSE && ChrgM_DataEncoded == TRUE)
							{
								if(PduR_ChrgMTransmit(ChrgM_PduID, &ChrgM_PduInfo) == E_OK)
								{
									ChrgM_PdurRequestSuccessful = TRUE;
									ChrgM_MessageRequested = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							if(ChrgM_TxConfirmationReceived == TRUE)
							{
								if(ChrgM_TransmissionSuccessful == TRUE)
								{
									if(ChrgM_RequestedMessage == SESSION_SETUP)
									{
										/* Reset Communication Setup Timer */
									}
									else if(ChrgM_RequestedMessage == SESSION_STOP)
									{
										if(ChrgM_SessionStopCommand == Terminate)
										{
#if(CHRGM_SDP_USED == STD_OFF)
											SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
											ChrgM_ModuleState = INIT;
#else
											ChrgM_ModuleState = DISCOVERING EVCC;
#endif
										}
										else /* Pause */
										{
											ChrgM_ModuleState = V2G_SESSION_PAUSED;
										}
									}
									else
									{
										/* Do Nothing */
									}
									ChrgM_TransmissionSuccessful = FALSE;
									ChrgM_TxConfirmationReceived = FALSE;
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_DataWritten = FALSE;
									ChrgM_DataEncoded = FALSE;
									ChrgM_DataEncrypted = FALSE;
									/* Reset Performance Timer */
									//ChrgM_PerformanceTimerStarted = FALSE;
									ChrgM_ReceptionDone = FALSE;
									ChrgM_MessageRequested = FALSE;
									/* Start Sequence Timer */
									/* Reset Buffer Data */
									memset(MessageBuffer, 0, BUFFER_SIZE);
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#else
									ChrgM_PdurRequestSuccessful = FALSE;
									ChrgM_MessageRequested = FALSE;
#endif
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_SequenceTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_SECC_SequenceTimeout);
					}
					else if(ChrgM_OngoingTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_SECC_OngoingTimeout);
					}
					else if(ChrgM_PerformanceTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_SECC_PerformanceTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}

				break;
			case V2G_SESSION_PAUSED:
				if(ChrgM_SequenceTimerElapsed == FALSE && ChrgM_PerformanceTimerElapsed == FALSE && ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_ACTIVE && ChrgM_CpLine == ACTIVE)
				{
					if(ChrgM_ReceptionDone == TRUE)
					{
						if(ChrgM_MessageRequested == FALSE)
						{
							if(ChrgM_DataWritten == FALSE)
							{
								switch(ChrgM_RequestedMessage)
								{
								case SESSION_STOP:
									/* Data Already Written */
									ChrgM_DataWritten = TRUE;
									break;

								default:
									/* Do Nothing, Det error */
									break;
								}
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_DataEncoded == FALSE && ChrgM_DataWritten == TRUE)
							{
								if(ChrgM_EXIEncode(MessageBuffer + V2G_HEADER_SIZE, &Sent_Payload) == E_OK)
								{
									ChrgM_DataEncoded = TRUE;
									ChrgM_WriteV2GTPHeader();
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}

							if(ChrgM_DataEncoded == TRUE && ChrgM_DataEncrypted == FALSE)
							{
								if(/*Csm_Encrypt(0, CRYPTO_OPERATIONMODE_START, MessageBuffer, 50, MessageBuffer, &Sent_Payload) == E_OK*/1) /* Encrypt Data */
								{
									//ChrgM_PduInfo.SduLength = 50;
									ChrgM_DataEncrypted = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}

							if(ChrgM_PdurRequestSuccessful == FALSE && ChrgM_DataEncrypted == TRUE)
							{
								if(PduR_ChrgMTransmit(ChrgM_PduID, &ChrgM_PduInfo) == E_OK)
								{
									ChrgM_PdurRequestSuccessful = TRUE;
									ChrgM_MessageRequested = TRUE;
								}
								else
								{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
									ChrgM_TxErrorStatus = SET_BY_TX;
									ChrgM_RxErrorStatus = SET_BY_TX;
									ChrgM_TxErrorState = ChrgM_ModuleState;
									ChrgM_RxErrorState = ChrgM_ModuleState;
#endif
									/* Do Nothing */
								}
							}
							else
							{
								/* Do Nothing */
							}
						}
						else
						{
							/* Do Nothing */
						}
						if(ChrgM_TxConfirmationReceived == TRUE)
						{
							if(ChrgM_TransmissionSuccessful == TRUE)
							{
								if(ChrgM_RequestedMessage == SESSION_STOP)
								{
									if(ChrgM_SessionStopCommand == Terminate)
									{
#if(CHRGM_SDP_USED == STD_OFF)
										SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
										ChrgM_ModuleState = INIT;
#else
										ChrgM_ModuleState = DISCOVERING_EVCC;
#endif
									}
									else /* Pause */
									{
										ChrgM_ModuleState = V2G_SESSION_PAUSED;
									}
								}
								else
								{
									/* Do Nothing */
								}
								ChrgM_TransmissionSuccessful = FALSE;
								ChrgM_TxConfirmationReceived = FALSE;
								ChrgM_PdurRequestSuccessful = FALSE;
								ChrgM_DataWritten = FALSE;
								ChrgM_DataEncoded = FALSE;
								ChrgM_DataEncrypted = FALSE;
								/* Reset Performance Timer */
								//ChrgM_PerformanceTimerStarted = FALSE;
								ChrgM_ReceptionDone = FALSE;
								ChrgM_MessageRequested = FALSE;
								/* Start Sequence Timer */
								/* Reset Buffer Data */
								memset(MessageBuffer, 0, BUFFER_SIZE);
							}
							else
							{
#if(CHRGM_RETRY_IF_ERROR == STD_OFF)
								ChrgM_TxErrorStatus = SET_BY_TX;
								ChrgM_RxErrorStatus = SET_BY_TX;
								ChrgM_TxErrorState = ChrgM_ModuleState;
								ChrgM_RxErrorState = ChrgM_ModuleState;
#else
								ChrgM_PdurRequestSuccessful = FALSE;
								ChrgM_MessageRequested = FALSE;
#endif
							}
						}
						else
						{
							/* Do Nothing */
						}
					}
					else
					{
						/* Do Nothing */
					}
				}
				else
				{
					if(ChrgM_PerformanceTimerElapsed == TRUE)
					{
						ChrgM_ErrorIndication(V2G_SECC_PerformanceTimeout);
					}
					else if(ChrgM_TransceiverLinkState == ETHTRCV_LINK_STATE_DOWN)
					{
						ChrgM_ErrorIndication(CHRGM_EthLinkDown);
					}
					else if(ChrgM_CpLine == INACTIVE)
					{
						ChrgM_ErrorIndication(CHRGM_CpLineInactive);
					}
					else
					{
						/* Do Nothing */
					}
					ChrgM_TxErrorStatus = SET_BY_TX;
					ChrgM_RxErrorStatus = SET_BY_TX;
					ChrgM_TxErrorState = ChrgM_ModuleState;
					ChrgM_RxErrorState = ChrgM_ModuleState;
				}
				break;
			}

		}
		else
		{
			/* Do Nothing */
		}

		if(ChrgM_TxErrorStatus == SET_BY_TX || ChrgM_TxErrorStatus == SET_BY_RX)
		{
			switch(ChrgM_TxErrorState)
			{
			case INIT:
				/* Do Nothing */
				break;

			case ASSIGNING_IP_ADDRESS:
			case ESTABLISHING_TCP_TLS:
				ChrgM_TxErrorState = INIT;
				ChrgM_ModuleState = INIT;
				ChrgM_OpenUDPSocketRequested = FALSE;
				ChrgM_IpAddressIndicationReceived = FALSE;
				ChrgM_SocketIndicationReceived = FALSE;
				ChrgM_UDPSoConMode = SOAD_SOCON_OFFLINE;
				ChrgM_TCPSoConMode = SOAD_SOCON_OFFLINE;
				ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
				break;
#if(CHRGM_SDP_USED == STD_OFF)
			case SECC_IDLE:
				ChrgM_TxErrorState = INIT;
				if(ChrgM_TxErrorStatus == SET_BY_TX)
				{
					ChrgM_ModuleState = INIT;
					ChrgM_RequestedMessage = NO_MESSAGE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_MessageRequested = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_OngoingTimerElapsed = FALSE;
					ChrgM_OngoingTimerStarted = FALSE;
					ChrgM_SequenceTimerElapsed = FALSE;
					ChrgM_ReceptionDone = TRUE;
					ChrgM_ReceptionSuccessful = FALSE;
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				break;
#else
			case DISCOVERING_EVCC:
				ChrgM_TxErrorState = INIT;
				if(ChrgM_TxErrorStatus == SET_BY_TX)
				{
					ChrgM_ModuleState = DISCOVERING_EVCC;
					ChrgM_ValidEVCCReceived = FALSE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_ReceptionSuccessful = FALSE;
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				break;
#endif
			case V2G_SESSION_ONGOING:
			case V2G_SESSION_PAUSED:
				ChrgM_TxErrorState = INIT;
				if(ChrgM_TxErrorStatus == SET_BY_TX)
				{
#if(CHRGM_SDP_USED == STD_ON)
					ChrgM_ModuleState = DISCOVERING_EVCC;
#else
					ChrgM_ModuleState = INIT;
#endif
					ChrgM_RequestedMessage = NO_MESSAGE;
					ChrgM_DataEncoded = FALSE;
					ChrgM_DataWritten = FALSE;
					ChrgM_PdurRequestSuccessful = FALSE;
					ChrgM_MessageReceived = FALSE;
					ChrgM_MessageRequested = FALSE;
					ChrgM_TxConfirmationReceived = FALSE;
					ChrgM_TransmissionSuccessful = FALSE;
					ChrgM_OngoingTimerElapsed = FALSE;
					ChrgM_OngoingTimerStarted = FALSE;
					ChrgM_SequenceTimerElapsed = FALSE;
					ChrgM_ReceptionSuccessful = FALSE;
					/* Reset Sequence Timer */
					/* Reset Performance Timer */
					/* Reset Ongoing Timer */
					/* Reset Buffer Data */
					memset(MessageBuffer, 0, BUFFER_SIZE);
					SoAd_CloseSoCon(ChrgM_SocketConID, TRUE);
				}
				else
				{
					/* Do Nothing */
				}
				ChrgM_TxErrorStatus = NO_ERROR_STATUS;
				break;
			}
		}
		else
		{
			/* Do Nothing */
		}
	}
	else
	{
		/* Do Nothing */
	}
}
