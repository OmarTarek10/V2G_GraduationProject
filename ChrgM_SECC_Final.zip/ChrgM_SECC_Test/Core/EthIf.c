/******************************************************************************
*
* Module: Ethernet Interface
*
* File Name: EthIf.c
*
* Description: Source File For the Ethernet Interface Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/

#include "EthIf.h"

#include "WEth.h"

#define ETHIF_SM_ALLOWED  FALSE

/* AUTOSAR checking between WEth.h and EthIf.h
* * Requirement: SWS_EthIf_00007
*/
#if ((WETH_AR_RELEASE_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
||  (WETH_AR_RELEASE_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
  ||  (WETH_AR_RELEASE_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Std_Types.h does not match the expected version"
#endif

#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
/* AUTOSAR checking between Det.h and WEth.h
*
*/

#if ((DET_AR_MAJOR_VERSION != ETHIF_AR_RELEASE_MAJOR_VERSION)\
  ||  (DET_AR_MINOR_VERSION != ETHIF_AR_RELEASE_MINOR_VERSION)\
  ||  (DET_AR_PATCH_VERSION != ETHIF_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Det.h does not match the expected version"
#endif
#endif

#if ETHIF_SM_ALLOWED != 0
/*******************************************************************************
*                      Ethernet State Manager Function?!                       *
*******************************************************************************/
extern void EthSM_CtrlModeIndication (uint8 CtrlIdx,Eth_ModeType CtrlMode);
#endif

/*******************************************************************************
*                      Global Variables                                    *
*******************************************************************************/
/*Variable for Storing Configuration Struct*/
const EthIf_ConfigType* EthIf_Stored_Config_Struct;
/*Variable for Storing Initializtion State*/
EthIf_State_Type EthIf_Init_State = ETHIF_UINITIALIZED ;
/*Variable for Storing Controllers Current Mode*/
Eth_ModeType Eth_Controller_Current_Mode[ETH_IF_CONTROLLER_SIZE];

/*******************************************************************************
*                      Function Definitions                                    *
*******************************************************************************/


/************************************************************************************
* Service Name: EthIf_Init
* Service ID[hex]: 0x01
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CfgPtr - Pointer to post-build configuration data
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Function to Initialize the Ethernet Interface module.
* Requirements: SWS_EthIf_00024,SWS_EthIf_00025, SWS_EthIf_00114
************************************************************************************/

void EthIf_Init ( const EthIf_ConfigType* CfgPtr)
{
  /* Requirement: SWS_EthIf_00008 */
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* check if the input configuration pointer is not a NULL_PTR */
  if (NULL_PTR == CfgPtr)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_INIT_SID ,ETHIF_E_PARAM_POINTER);
  }
  else
#endif
  {
    /* Requirement: SWS_EthIf_00025 */
    EthIf_Stored_Config_Struct = CfgPtr;
    /* Requirement: SWS_EthIf_00114 */
    EthIf_Init_State = ETHIF_INITIALIZED;
  }
}


/************************************************************************************
* Service Name: EthIf_SetControllerMode
* Service ID[hex]: 0x03
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
* CtrlMode - ETH_MODE_DOWN: disable the controller
ETH_MODE_ACTIVE: enable the controller
ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST: enable thecontroller and request a wake-up on the network.
ETH_MODE_TX_OFFLINE: disable transmission handling in EthIf. Please note, the according Ethernet controller is not affected.
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller mode could not be changed
* Description:  Enables / disables the indexed controller
* Requirements: SWS_EthIf_00034, SWS_EthIf_00114
************************************************************************************/

Std_ReturnType EthIf_SetControllerMode (uint8 CtrlIdx,Eth_ModeType CtrlMode)
{
  Std_ReturnType Value = E_NOT_OK;
  
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00036 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CONTROLLER_MODE_SID, ETHIF_E_UNINIT);
    return Value;
  }
  /* Requirement: SWS_EthIf_00037 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_CONTROLLER_MODE_SID, ETHIF_E_INV_CTRL_IDX);
    return Value;
  }
  
  
#endif
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  /* Requirement: SWS_EthIf_00035 */
  if ( ((CtrlMode == ETH_MODE_ACTIVE) || (CtrlMode == ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST)) && (Eth_Controller_Current_Mode[CtrlIdx] != ETH_MODE_ACTIVE))
  {
    Value = WEth_SetControllerMode(Lower_Layer_Idx,ETH_MODE_ACTIVE);
    Eth_Controller_Current_Mode[CtrlIdx] = CtrlMode;
  }
  /* Requirement: SWS_EthIf_00263 */
  else if (CtrlMode == ETH_MODE_DOWN)
  {
    Value = WEth_SetControllerMode(Lower_Layer_Idx,CtrlMode);
    Eth_Controller_Current_Mode[CtrlIdx] = CtrlMode;
  }
  /* Requirement: SWS_EthIf_00504*/
  else if ( (CtrlMode == ETH_MODE_TX_OFFLINE) && ( (Eth_Controller_Current_Mode[CtrlIdx] == ETH_MODE_ACTIVE) || (Eth_Controller_Current_Mode[CtrlIdx] == ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST) ) )
  {
    Eth_Controller_Current_Mode[CtrlIdx] = CtrlMode;
    Value = E_OK;
  }
  else
  {
    Value = E_NOT_OK;
  }
  
  return Value;
}

/************************************************************************************
* Service Name: EthIf_GetControllerMode
* Service ID[hex]: 0x04
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
* Parameters (inout): None
* Parameters (out): CtrlMode - ETH_MODE_DOWN: disable the controller
ETH_MODE_ACTIVE: enable the controller
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description:  Obtains the state of the indexed controller
* Requirements: SWS_EthIf_00039
************************************************************************************/

Std_ReturnType EthIf_GetControllerMode (uint8 CtrlIdx,Eth_ModeType* CtrlModePtr)
{
  Std_ReturnType Value = E_NOT_OK;
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00041 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CONTROLLER_MODE_SID, ETHIF_E_UNINIT);
    return Value;
  }
  /* Requirement: SWS_EthIf_00042 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CONTROLLER_MODE_SID, ETHIF_E_INV_CTRL_IDX);
    return Value;
  }
  /* Requirement: SWS_EthIf_00043 */
  /*check the parameter CtrlModePtr for being valid*/
  if ( NULL_PTR == CtrlModePtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CONTROLLER_MODE_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
#endif
  
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_00040*/
  Value = WEth_GetControllerMode(Lower_Layer_Idx, CtrlModePtr);
  return Value;
}


/************************************************************************************
* Service Name: EthIf_GetPhysAddr
* Service ID[hex]: 0x08
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
* Parameters (inout): None
* Parameters (out): PhysAddrPtr Physical source address (MAC address) in network byte order.
* Return value: None
* Description:  Obtains the physical source address used by the indexed controller
* Requirements: SWS_EthIf_00061
************************************************************************************/
void EthIf_GetPhysAddr (uint8 CtrlIdx,uint8* PhysAddrPtr)
{
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00063 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_PHYS_ADDR_SID, ETHIF_E_UNINIT);
  }
  /* Requirement: SWS_EthIf_00064 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_PHYS_ADDR_SID, ETHIF_E_INV_CTRL_IDX);
  }
  /* Requirement: SWS_EthIf_00065 */
  /*check the parameter PhysAddrPtr for being valid*/
  if ( NULL_PTR == PhysAddrPtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_PHYS_ADDR_SID, ETHIF_E_PARAM_POINTER);
  }
#endif
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_00062 */
  WEth_GetPhysAddr (Lower_Layer_Idx,PhysAddrPtr);
}

/************************************************************************************
* Service Name: EthIf_SetPhysAddr
* Service ID[hex]: 0x0D
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant for the same CtrlIdx, reentrant for different
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
PhysAddrPtr - Pointer to memory containing the physical source address (MACaddress) in network byte order.
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description:  Obtains the physical source address used by the indexed controller
* Requirements: SWS_EthIf_00132
************************************************************************************/

void EthIf_SetPhysAddr (uint8 CtrlIdx,const uint8* PhysAddrPtr)
{
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00135 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_PHYS_ADDR_SID, ETHIF_E_UNINIT);
  }
  /* Requirement: SWS_EthIf_00136 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_PHYS_ADDR_SID, ETHIF_E_INV_CTRL_IDX);
  }
  /* Requirement: SWS_EthIf_00137 */
  /*check the parameter PhysAddrPtr for being valid*/
  if ( NULL_PTR == PhysAddrPtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_PHYS_ADDR_SID, ETHIF_E_PARAM_POINTER);
  }
#endif
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_000134 */
  WEth_SetPhysAddr (Lower_Layer_Idx,PhysAddrPtr);
}

/************************************************************************************
* Service Name: EthIf_GetCtrlIdxList
* Service ID[hex]: 0x44
* Sync/Async: Asynchronous
* Reentrancy: Non Reentrant
* Parameters (in): None
* Parameters (inout): NumberOfCtrlIdx - in: maximum number of controllers in CtrlIdxListPtr,
*                                           0 to return the number of controllers but without filling CtrlIdxListPtr.
*                                       out: number of active controllers.
* Parameters (out): CtrlIdxListPtr - List of active controller indexes
* Return value: Std_ReturnType E_OK: success
E_NOT_OK: failure
* Description:  Returns the number and index of all active Ethernet controllers
* Requirements: SWS_EthIf_91053
************************************************************************************/
Std_ReturnType EthIf_GetCtrlIdxList (uint8* NumberOfCtrlIdx,uint8* CtrlIdxListPtr)
{
  Std_ReturnType Value = E_NOT_OK;
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00299 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CTRL_IDX_LIST_SIC, ETHIF_E_UNINIT);
    return Value;
  }
  
  /*check the parameter NumberOfCtrlIdx for being valid*/
  if (NULL_PTR == NumberOfCtrlIdx )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CTRL_IDX_LIST_SIC, ETHIF_E_PARAM_POINTER);
    return Value;
  }
  /* Requirement: SWS_EthIf_00300 */
  if (*NumberOfCtrlIdx > 0 )
  {
    /*check the parameter CtrlIdxListPtr for being valid*/
    if (NULL_PTR == CtrlIdxListPtr )
    {
      Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_CTRL_IDX_LIST_SIC, ETHIF_E_PARAM_POINTER);
      return Value;
    }
  }
#endif
  uint8 Num_of_indexes_req = *NumberOfCtrlIdx;
  /* Requirement: SWS_EthIf_00298 */
  if (*NumberOfCtrlIdx > 0 )
  {    
    if (*NumberOfCtrlIdx > ETH_IF_CONTROLLER_SIZE)
    {
      *NumberOfCtrlIdx = 0;
      for (uint8 i = 0 ; i < ETH_IF_CONTROLLER_SIZE ; i++)
      {
        if (Eth_Controller_Current_Mode[i] == ETH_MODE_ACTIVE)
        {
          CtrlIdxListPtr[*NumberOfCtrlIdx] = i;
          (*NumberOfCtrlIdx)++;
        }
        else
        {
        }
      }
    }
    
    else if (*NumberOfCtrlIdx <= ETH_IF_CONTROLLER_SIZE)
    {
      *NumberOfCtrlIdx = 0;
      for (uint8 i = 0 ; i < Num_of_indexes_req ; i++)
      {
        if (Eth_Controller_Current_Mode[i] == ETH_MODE_ACTIVE)
        {
          CtrlIdxListPtr[*NumberOfCtrlIdx] = i;
          (*NumberOfCtrlIdx)++;
        }
        else
        {
        }
      }
    }
    
  }
  else if (*NumberOfCtrlIdx == 0 )
  {
    for (uint8 i = 0 ; i < ETH_IF_CONTROLLER_SIZE ; i++)
    {
      if (Eth_Controller_Current_Mode[i] == ETH_MODE_ACTIVE)
      {
        (*NumberOfCtrlIdx)++;
      }
      else
      {
      }
    }
  }
  
  return Value;
}

/* !!!!ARE THESE FUNCS NEEDED!!!!*/
/* Requirement: SWS_EthIf_00342 */
#if (ETHIF_ENABLE_WETH_API==STD_ON)
/************************************************************************************
* Service Name: EthIf_GetBufWRxParams
* Service ID[hex]: 0x32
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
RxParamIds - IDs of the Parameters to read
NumParams - Number of Parameters
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description:  Read out values related to the receive direction of the transceiver for a received packet. For
example, this could be RSSI or Channel belonging to one single packet.
* Requirements: SWS_EthIf_91002
* Note: The function requires previous reception (EthIf_RxIndication).
************************************************************************************/

Std_ReturnType EthIf_GetBufWRxParams (uint8 CtrlIdx,const WEth_BufWRxParamIdType* RxParamIds,uint32* ParamValues,uint8 NumParams)
{
  Std_ReturnType Value = E_NOT_OK;
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00343 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_UNINIT);
    return Value;
  }
  /* Requirement: SWS_EthIf_00344 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_INV_CTRL_IDX);
    return Value;
  }
  /* Requirement: SWS_EthIf_00345 */
  /*check the parameter RxParamIds for being valid*/
  if ( NULL_PTR == RxParamIds )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
  /* Requirement: SWS_EthIf_00346 */
  /*check the parameter ParamValues for being valid*/
  if ( NULL_PTR == ParamValues )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WRX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
#endif
  
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_00341 */
  Value = WEth_GetBufWRxParams(Lower_Layer_Idx,RxParamIds,ParamValues,NumParams);
  return Value;
}
#endif

/* Requirement: SWS_EthIf_00347 */
#if (ETHIF_ENABLE_WETH_API==STD_ON)
/************************************************************************************
* Service Name: EthIf_GetBufWTxParams
* Service ID[hex]: 0x31
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
TxParamIds - IDs of the Parameters to read
NumParams - Number of Parameters
* Parameters (inout): None
* Parameters (out): ParamValues - Values of the Parameters requested
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description: Read out values related to the transmit direction of the transceiver for a transmitted packet. For
example, this could be transaction ID belonging to one single packet.
* Requirements: SWS_EthIf_91054
* Note: The function requires previous transmission (EthIf_Transmit).
************************************************************************************/

Std_ReturnType EthIf_GetBufWTxParams (uint8 CtrlIdx,const WEth_BufWTxParamIdType* TxParamIds,uint32* ParamValues,uint8 NumParams)
{
  Std_ReturnType Value = E_NOT_OK;
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00349 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_UNINIT);
    return Value;
  }
  /* Requirement: SWS_EthIf_00350 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_INV_CTRL_IDX);
    return Value;
  }
  /* Requirement: SWS_EthIf_00351 */
  /*check the parameter TxParamIds for being valid*/
  if ( NULL_PTR == TxParamIds )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
  /* Requirement: SWS_EthIf_00352 */
  /*check the parameter ParamValues for being valid*/
  if ( NULL_PTR == ParamValues )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
#endif
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_00347 */
  Value = WEth_GetBufWTxParams(Lower_Layer_Idx,TxParamIds,ParamValues,NumParams);
  return Value;
}
#endif

/* Requirement: SWS_EthIf_00353 */
#if (ETHIF_ENABLE_WETH_API == STD_ON)
/************************************************************************************
* Service Name: EthIf_SetBufWTxParams
* Service ID[hex]: 0x33
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
BufIdx - Index of the buffer resource
TxParamIds - IDs of the Parameters to read
ParamValues - Values of the Parameters requested
NumParams - Number of Parameters
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description: Set values related to the transmit direction of the transceiver for a specific buffer (packet to be
sent). For example, this can be the desired transmit power or the channel belonging to one
single packet.
* Requirements: SWS_EthIf_91017
* Note: The function requires previous buffer request (EthIf_ProvideTxBuffer)
************************************************************************************/

Std_ReturnType EthIf_SetBufWTxParams (uint8 CtrlIdx,Eth_BufIdxType BufIdx,const WEth_BufWTxParamIdType* TxParamIds,const uint32* ParamValues,uint8 NumParams)
{
  Std_ReturnType Value = E_NOT_OK;
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00355 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_UNINIT);
    return Value;
  }
  /* Requirement: SWS_EthIf_00356 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_INV_CTRL_IDX);
    return Value;
  }
  /* Requirement: SWS_EthIf_00357 */
  /*check the parameter BufIdx for being valid*/
  if ( BufIdx >  EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfMaxTxBufsTotal )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_INV_PARAM	);
    return Value;
  }
  /* Requirement: SWS_EthIf_00358 */
  /*check the parameter TxParamIds for being valid*/
  if ( NULL_PTR == TxParamIds )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
  /* Requirement: SWS_EthIf_00359 */
  /*check the parameter ParamValues for being valid*/
  if ( NULL_PTR == ParamValues )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_SET_BUF_WTX_PARAMS_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
#endif
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_00353 */
  Value = WEth_SetBufWTxParams(Lower_Layer_Idx,BufIdx,TxParamIds,ParamValues,NumParams);
  return Value;
}
#endif
/* !!!!ARE THESE FUNCS NEEDED!!!!*/


/************************************************************************************
* Service Name: EthIf_ProvideTxBuffer
* Service ID[hex]: 0x09
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
FrameType - Ethernet Frame Type (EtherType)
Priority - Priority value which shall be used for the 3-bit PCP field of theVLAN tag
ParamValues - Values of the Parameters requested
NumParams - Number of Parameters
* Parameters (inout): LenBytePtr - in: desired length in bytes, out: granted length in bytes
* Parameters (out): BufIdxPtr - Index to the granted buffer resource. To be used for subsequent requests
* 					 BufPtr - Pointer to the granted buffer
* Return value: BufReq_ReturnType BUFREQ_OK: success
BUFREQ_E_NOT_OK: development error detected
BUFREQ_E_BUSY: all buffers in use
BUFREQ_E_OVFL: requested buffer too large
* Description: Provides access to a transmit buffer of the specified Ethernet controller.
* Requirements: SWS_EthIf_00067
************************************************************************************/
BufReq_ReturnType EthIf_ProvideTxBuffer (uint8 CtrlIdx,Eth_FrameType FrameType,uint8 Priority,Eth_BufIdxType* BufIdxPtr,uint8** BufPtr,uint16* LenBytePtr)
{
  BufReq_ReturnType Value = BUFREQ_E_NOT_OK;
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00069 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_UNINIT);
    return Value;
  }
  /* Requirement: SWS_EthIf_00070 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_INV_CTRL_IDX);
    return Value;
  }
  /* Requirement: SWS_EthIf_00071 */
  /*check the parameter BufIdxPtr for being valid*/
  if ( NULL_PTR ==  BufIdxPtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_PARAM_POINTER	);
    return Value;
  }
  /* Requirement: SWS_EthIf_00072 */
  /*check the parameter BufPtr for being valid*/
  if ( NULL_PTR == BufPtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
  /* Requirement: SWS_EthIf_00073 */
  /*check the parameter LenBytePtr for being valid*/
  if ( NULL_PTR == LenBytePtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_PROVIDE_TX_BUFFER_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
#endif
  
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_00068 */
  if ( (Eth_Controller_Current_Mode[CtrlIdx] == ETH_MODE_ACTIVE) || (Eth_Controller_Current_Mode[CtrlIdx] == ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST) )
  {
    
    Value = WEth_ProvideTxBuffer(Lower_Layer_Idx,Priority,BufIdxPtr,BufPtr,LenBytePtr);
    
  }
  else
  {
    Value = BUFREQ_E_NOT_OK;
  }
  return Value;
}


/************************************************************************************
* Service Name: EthIf_Transmit
* Service ID[hex]: 0x0A
* Sync/Async: Synchronous
* Reentrancy: Reentrant for different buffer indexes and Ctrl indexes
* Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the EthernetInterface
BufIdx - Index of the buffer resource
FrameType - Ethernet frame type
TxConfirmation - Activates transmission confirmation
LenByte - Data length in byte
PhysAddrPtr - Physical target address (MAC address) in network byte order
* Parameters (inout): None
* Parameters (out): None
* Return value: Std_ReturnType - E_OK: success
E_NOT_OK: controller could not be initialized
* Description: Triggers transmission of a previously filled transmit buffer.
* Requirements: SWS_EthIf_00075
************************************************************************************/
Std_ReturnType EthIf_Transmit (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Eth_FrameType FrameType,boolean TxConfirmation,uint16 LenByte,const uint8* PhysAddrPtr)
{
  Std_ReturnType Value = E_NOT_OK;
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00077 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID, ETHIF_E_UNINIT);
    return Value;
  }
  /* Requirement: SWS_EthIf_00078 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID, ETHIF_E_INV_CTRL_IDX);
    return Value;
  }
  /* Requirement: SWS_EthIf_00079 */
  /*check the parameter BufIdx for being valid*/
  if ( BufIdx >  EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfMaxTxBufsTotal )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID, ETHIF_E_INV_PARAM	);
    return Value;
  }
  /* Requirement: SWS_EthIf_00080 */
  /*check the parameter PhysAddrPtr for being valid*/
  if ( NULL_PTR == PhysAddrPtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TRANSMIT_SID, ETHIF_E_PARAM_POINTER);
    return Value;
  }
  
#endif
  
  
  uint8 Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
  
  /* Requirement: SWS_EthIf_00076 */
  if ( (Eth_Controller_Current_Mode[CtrlIdx] == ETH_MODE_ACTIVE) || (Eth_Controller_Current_Mode[CtrlIdx] == ETH_MODE_ACTIVE_WITH_WAKEUP_REQUEST) )
  {
    Value = WEth_Transmit(Lower_Layer_Idx, BufIdx, FrameType, TxConfirmation, LenByte, PhysAddrPtr);
  }
  else
  {
    Value = E_NOT_OK;
  }
  return Value;
}

#if (ETHIF_VERSION_INFO_API == STD_ON)
/************************************************************************************
* Service Name: EthIf_GetVersionInfo
* Service ID[hex]: 0x0B
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): None
* Parameters (inout): None
* Parameters (out): VersionInfoPtr Version information of this module
* Return value: None
* Description: Returns the version information of this module
* Requirements: SWS_EthIf_00082
************************************************************************************/
void EthIf_GetVersionInfo (Std_VersionInfoType* VersionInfoPtr)
{
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00127 */
  /*check the parameter VersionInfoPtr for being valid*/
  if ( NULL_PTR == VersionInfoPtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_GET_VERSION_INFO_SID, ETHIF_E_PARAM_POINTER);
  }
  
#endif
  VersionInfoPtr->moduleID = ETHIF_MODULE_ID;
  VersionInfoPtr->sw_major_version = ETHIF_SW_MAJOR_VERSION; // OR ETHIF_AR_RELEASE_MAJOR_VERSION
  VersionInfoPtr->sw_minor_version = ETHIF_SW_MINOR_VERSION; // OR ETHIF_AR_RELEASE_MINOR_VERSION
  VersionInfoPtr->sw_patch_version = ETHIF_SW_PATCH_VERSION; // OR ETHIF_AR_RELEASE_PATCH_VERSION
  VersionInfoPtr->vendorID = ETHIF_VENDOR_ID;
}
#endif


/*******************************************************************************
*                      Callback Functions Definitions                                   *
*******************************************************************************/

/************************************************************************************
* Service Name: EthIf_RxIndication
* Service ID[hex]: 0x10
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the physical Ethernet controller within the context of the Ethernet Interface
* 					FrameType - Frame type of received Ethernet frame
* 					IsBroadcast - parameter to indicate a broadcast frame
* 					PhysAddrPtr - Pointer to Physical source address (MAC address in network byte order) of received Ethernet frame
* 					DataPtr - Pointer to payload of received Ethernet frame
* 					LenByte - Length (bytes) of the payload in received frame.
* Parameters (inout): None
* Parameters (out):  None
* Return value: None
* Description: Handles a received frame received by the indexed controller
* Requirements: SWS_EthIf_00085
************************************************************************************/
void EthIf_RxIndication (uint8 CtrlIdx,Eth_FrameType FrameType,boolean IsBroadcast,const uint8* PhysAddrPtr,const Eth_DataType* DataPtr,uint16 LenByte)
{
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00086 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_RX_INDICATION_SID, ETHIF_E_UNINIT);
  }
  /* Requirement: SWS_EthIf_00087 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_RX_INDICATION_SID, ETHIF_E_INV_CTRL_IDX);
  }
  /* Requirement: SWS_EthIf_00088 */
  /*check the parameter DataPtr for being valid*/
  if ( NULL_PTR == DataPtr )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_RX_INDICATION_SID,  ETHIF_E_PARAM_POINTER);
  }
  
#endif
  
  EthIf_Stored_Config_Struct->RxInd_Func_Structs[CtrlIdx].EthIfRxIndicationFunction( CtrlIdx,FrameType, IsBroadcast,PhysAddrPtr,DataPtr,LenByte);
  
}
/************************************************************************************
* Service Name: EthIf_TxConfirmation
* Service ID[hex]: 0x11
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant
* Parameters (in): CtrlIdx - Index of the physical Ethernet controller within the context of the Ethernet Interface
* 					BufIdx - Index of the transmitted buffer
* 					Result E_OK: The transmission was successful, E_NOT_OK: The transmission failed.
* Parameters (inout): None
* Parameters (out):  None
* Return value: None
* Description: Confirms frame transmission by the indexed controller
* Requirements: SWS_EthIf_00091
************************************************************************************/
// CALLED BY LOWER LAYER WEth
void EthIf_TxConfirmation (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result)
{
#if (ETHIF_DEV_ERROR_DETECT == STD_ON)
  /* Requirement: SWS_EthIf_00092 */
  /* check if the EthIf Module is Initialized */
  if (ETHIF_UINITIALIZED == EthIf_Init_State)
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TX_CONFIRMATION_SID, ETHIF_E_UNINIT);
  }
  /* Requirement: SWS_EthIf_00093 */
  /*check the parameter CtrlIdx for being valid*/
  if (CtrlIdx >= ETH_IF_CONTROLLER_SIZE )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TX_CONFIRMATION_SID, ETHIF_E_INV_CTRL_IDX);
  }
  /* Requirement: SWS_EthIf_00094 */
  /*check the parameter BufIdx for being valid*/
  if ( BufIdx >  EthIf_Stored_Config_Struct->ControllerConfigStructs[CtrlIdx].EthIfMaxTxBufsTotal )
  {
    Det_ReportError(ETHIF_MODULE_ID, ETHIF_INSTANCE_ID, ETHIF_TX_CONFIRMATION_SID,  ETHIF_E_INV_PARAM);
  }
  
#endif 
  /* Requirement: SWS_EthIf_00255 */
  if(NULL_PTR!= EthIf_Stored_Config_Struct->TxInd_Func_Structs[CtrlIdx].EthIfTxConfirmationFunction)
  {
    EthIf_Stored_Config_Struct->TxInd_Func_Structs[CtrlIdx].EthIfTxConfirmationFunction( CtrlIdx,BufIdx, Result);
  }
  else
  {

  }
}
/************************************************************************************
* Service Name: EthIf_CtrlModeIndication
* Service ID[hex]: 0x0E
* Sync/Async: Synchronous
* Reentrancy: Non Reentrant for the same CtrlIdx, reentrant for different
* Parameters (in): CtrlIdx - Index of the physical Ethernet controller within the context of the Ethernet Interface
* 					CtrlMode - Notified Ethernet controller mode
* Parameters (inout): None
* Parameters (out):  None
* Return value: None
* Description:Called asynchronously when mode has been read out. Triggered by previous <EthDrv>_SetControllerMode call. Can directly be called within the trigger functions.
* Requirements: SWS_EthIf_00231
************************************************************************************/

void EthIf_CtrlModeIndication (uint8 CtrlIdx,Eth_ModeType CtrlMode)
{
  
  /* Requirement: SWS_EthIf_000252 */
#if ETHIF_SM_ALLOWED != 0
  EthSM_CtrlModeIndication (CtrlIdx,CtrlMode);
#endif
}

/*******************************************************************************
*                      Scheduled Functions Definitions                        *
*******************************************************************************/
/* Requirement: SWS_EthIf_00099 */
#if (ETHIF_ENABLE_RX_INTERRUPT == STD_OFF)
/************************************************************************************
* Service Name: EthIf_MainFunctionRx
* Service ID[hex]: 0x20
* Description:The function checks for new received frames and issues reception indications in polling mode.
* Requirements: SWS_EthIf_00097
************************************************************************************/
void EthIf_MainFunctionRx (void)
{
  uint8 Lower_Layer_Idx;
  
  Eth_RxStatusType RxStatusPtr;
  for (uint8 Ctrl_Idx = 0 ; Ctrl_Idx < ETH_IF_CONTROLLER_SIZE;Ctrl_Idx++)
  {
    Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[Ctrl_Idx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
    WEth_Receive(Lower_Layer_Idx, &RxStatusPtr);
    
    for (uint8 i = 0 ; i < ETHIF_RX_INDICATION_ITERATIONS ;i++)
    {
      if (ETH_RECEIVED_MORE_DATA_AVAILABLE==RxStatusPtr)
      {
        WEth_Receive(Lower_Layer_Idx , &RxStatusPtr);
      }
      else
      {
        break;
      }
    }
    
  }
}
#endif

/* Requirement: SWS_EthIf_00100 */
#if (ETHIF_ENABLE_TX_INTERRUPT == STD_OFF)
/************************************************************************************
* Service Name: EthIf_MainFunctionTx
* Service ID[hex]: 0x21
* Description:The function issues transmission confirmations in polling mode. It checks also for transceiverstate changes.
* * Requirements: SWS_EthIf_00113
************************************************************************************/

void EthIf_MainFunctionTx (void)
{
  uint8 Lower_Layer_Idx;
  for (uint8 Ctrl_Idx = 0 ; Ctrl_Idx < ETH_IF_CONTROLLER_SIZE;Ctrl_Idx++)
  {
    Lower_Layer_Idx = EthIf_Stored_Config_Struct->ControllerConfigStructs[Ctrl_Idx].EthIfPhysControllerRef.EthIfPhysControllerIdx;
    
    WEth_TxConfirmation(Lower_Layer_Idx);
    
  }
}
#endif


