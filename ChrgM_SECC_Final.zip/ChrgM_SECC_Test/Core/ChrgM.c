/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM.c
 *
 * Description: Charging Manager enables the charging process between the supply equipment (EVSE) and the vehicle (EV)
 *
 * Author: Mahmoud Shaarawy,Mohannad Sabry
 ******************************************************************************/

#include "ChrgM.h"

#if (CHRGM_DEV_ERROR_DETECT == STD_ON)

#include "Det.h"
/*
 * AUTOSAR Version checking between Det and ChrgM Modules
 */

#if ((DET_AR_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		|| (DET_AR_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		|| (DET_AR_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Det.h does not match the expected version"
#endif

#endif /* (CHRGM_DEV_ERROR_DETECT == STD_ON) */

static uint8 ChrgM_Status = CHRGM_NOT_INITIALIZED;

/*******************************************************************************
 *                              Module variables                               *
 *******************************************************************************/
uint8 MessageBuffer[BUFFER_SIZE];
uint8 *MessageBuffer_Ptr = MessageBuffer;

V2GMessageHeaderType V2G_Request_Header;

struct iso1EXIDocument V2G_EXI_Document;
struct iso1EXIDocument* ChrgM_DocumentPtr;

void* ChrgM_MessagePtr;

SECCDiscoveryProtocolReqType SECCDiscoveryProtocolReq_Message;
SECCDiscoveryProtocolResType SECCDiscoveryProtocolRes_Message;

SupportedAppProtocolReqType SupportedAppProtocolReq_Message;

ChrgM_MessageStateType ChrgM_RequestedMessage = NO_MESSAGE;
ChrgM_MessageStateType ChrgM_PreviousMessage = NO_MESSAGE;
ChrgM_ModuleStateType ChrgM_ModuleState = NOT_INITIALIZED;
EthTrcv_LinkStateType ChrgM_TransceiverLinkState = ETHTRCV_LINK_STATE_DOWN;
TcpIp_IpAddrStateType ChrgM_IpAddressState = TCPIP_IPADDR_STATE_UNASSIGNED;
SoAd_SoConModeType ChrgM_UDPSoConMode = SOAD_SOCON_OFFLINE;
SoAd_SoConModeType ChrgM_TCPSoConMode = SOAD_SOCON_OFFLINE;

ChrgM_ModuleStateType ChrgM_TxErrorState = NOT_INITIALIZED;
ChrgM_ModuleStateType ChrgM_RxErrorState = NOT_INITIALIZED;
ChrgM_ErrorStatusType ChrgM_TxErrorStatus = NO_ERROR_STATUS;
ChrgM_ErrorStatusType ChrgM_RxErrorStatus = NO_ERROR_STATUS;
boolean ChrgM_ValidEVCCReceived = FALSE;
boolean ChrgM_MessageRequested = FALSE;
boolean ChrgM_MessageReceived = FALSE;
boolean ChrgM_ReceptionSuccessful = FALSE;
boolean ChrgM_TxConfirmationReceived = FALSE;
boolean ChrgM_TransmissionSuccessful = FALSE;
boolean ChrgM_OngoingTimerStarted = FALSE;
boolean ChrgM_OngoingTimerElapsed = FALSE;
boolean ChrgM_DataWritten = FALSE;
boolean ChrgM_DataEncoded = FALSE;
boolean ChrgM_DataEncrypted = FALSE;
boolean ChrgM_PdurRequestSuccessful = FALSE;
boolean ChrgM_SequenceTimerElapsed = FALSE;
boolean ChrgM_PerformanceTimerStarted = FALSE;
boolean ChrgM_PerformanceTimerElapsed = FALSE;
boolean ChrgM_ReceptionDone = TRUE;
boolean ChrgM_ProcessStarted = FALSE;
boolean ChrgM_OpenUDPSocketRequested = FALSE;
boolean ChrgM_OpenTCPSocketRequested = FALSE;
boolean ChrgM_SocketIndicationReceived = FALSE;
boolean ChrgM_IpAddressIndicationReceived = FALSE;
boolean ChrgM_CommunicationSetupTimerElapsed = FALSE;

uint8 ChrgM_CpLine = INACTIVE;

boolean Message_Received_Indication = TRUE;
ChrgM_ErrorHandlerType Error_Indication = CHRGM_NoError;

/* Initialise variable to store Payload length */
PayloadLengthType Sent_Payload = 0;
PayloadLengthType Received_Payload = 0;

PduInfoType ChrgM_PduInfo;
PduIdType ChrgM_PduID;
SoAd_SoConIdType ChrgM_SocketConID;
chargingSessionType ChrgM_SessionStopCommand;

sessionIDType ChrgM_CurrentSessionID = 0;

/*******************************************************************************
 *                              Module Functions                               *
 *******************************************************************************/

/************************************************************************************
 * Service Name: ChrgM_Init
 * Service ID[hex]: 0x01
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): ConfigPtr - Pointer to Initialization Configuration Structure
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This service initializes the ChrgM module
 * Requirments:[SRS_BSW_00310],[SRS_BSW_00101],[SRS_BSW_00358],[SRS_BSW_00414]
 ************************************************************************************/
void ChrgM_Init (const ChrgM_ConfigType* ConfigPtr)
{
	/* Initialize Module Variables */
	ChrgM_ModuleState = INIT;
	ChrgM_RequestedMessage = NO_MESSAGE;
	ChrgM_Status = CHRGM_INITIALIZED;
	/* SocketID */
	ChrgM_SocketConID = ConfigPtr->ChrgM_V2GTP.ChrgMV2GSrcTcpDataRef->SoAd_SockConnGroup->SoAd_SocketConnection.SoAdSocketId;
	/* ChrgM PDU ID*/
	ChrgM_PduID = ConfigPtr->ChrgM_V2GTP.ChrgM_V2GTPPdu.ChrgMV2GTPPduHandleId;
	/* PDU Pointer to PDU ID */
	//ChrgM_PduInfo.MetaDataPtr = 1; /* Should be a pointer from PduR routing table*/
	/* PDU Pointer to Data Buffer */
	ChrgM_PduInfo.SduDataPtr = MessageBuffer;
	/* PDU Length variable with message type */
	ChrgM_PduInfo.SduLength = 0;
	/* Initialise EXI Document with zeros */
	memset(&V2G_EXI_Document, 0, sizeof(V2G_EXI_Document));

	/* Manual Call for now */
	ChrgM_DataLinkIndication(0, ETHTRCV_LINK_STATE_ACTIVE);
	ChrgM_CpLineStatus(ACTIVE);
}

/********************************************************************************************************************************
 * Service Name: ChrgM_StartProcess
 * Service ID[hex]: 0x25
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): Process - It is a boolean value to start the Charge Process
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This API gets called by the upper layer to start the Charging Process
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00017],[CP_SWS_ChrgM_00018],[CP_SWS_ChrgM_00020],[CP_SWS_ChrgM_00021],
			  [CP_SWS_ChrgM_00022],[CP_SWS_ChrgM_00023],[CP_SWS_ChrgM_00024],[CP_SWS_ChrgM_00025],[CP_SWS_ChrgM_00026]
 *********************************************************************************************************************************/
void ChrgM_StartProcess(boolean Process)
{
	ChrgM_ProcessStarted = Process;
}

/************************************************************************************
 * Service Name: ChrgM_CpLineStatus
 * Service ID[hex]: 0x1E
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): CpLineStatus - This it the status of the CP line
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Upper layer calls this API to inform ChrgM about CP line status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00020],[CP_SWS_ChrgM_00022],[CP_SWS_ChrgM_00024]
 ************************************************************************************/
void ChrgM_CpLineStatus (char CpLineStatus)
{
	ChrgM_CpLine = CpLineStatus;
}

/************************************************************************************
 * Service Name: ChrgM_DataLinkIndication
 * Service ID[hex]: 0x02
 * Sync/Async: Synchronous
 * Reentrancy: Non Reentrant
 * Parameters (in): CtrlIdx - Index of the Ethernet controller within the context of the Ethernet Interface
 * 				   TransceiverLinkState - Actual transceiver link state of the specific network handle
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This API is called by the EthSM to inform the ChrgM about the state of the data link connection
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00020],[CP_SWS_ChrgM_00022],[CP_SWS_ChrgM_00024]
 ************************************************************************************/
void ChrgM_DataLinkIndication (uint8 CtrlIdx, EthTrcv_LinkStateType TransceiverLinkState)
{
	ChrgM_TransceiverLinkState = TransceiverLinkState;
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpCopyRxData
 * Service ID[hex]: 0x44
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in):  PduIdType id,
					 const PduInfoType* info,

 * Parameters (inout): None
 * Parameters (out): PduLengthType* bufferSizePtr
 * Return value: BufReq_ReturnType
 * Description: This function is called to provide the received data of an I-PDU segment (N-PDU) to the upper
   layer. Each call to this function provides the next part of the I-PDU data. The size of the
   remaining buffer is written to the position indicated by bufferSizePtr.
 ************************************************************************************/
BufReq_ReturnType ChrgM_V2GTpCopyRxData (PduIdType id, const PduInfoType* info, PduLengthType bufferSize)
{
	BufReq_ReturnType BufReq_Return = BUFREQ_OK;

	if (ChrgM_ModuleState == CHRGM_NOT_INITIALIZED)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_UNINIT);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	else if (info == NULL_PTR/* || bufferSizePtr == NULL_PTR*/)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_PARAM_POINTER);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	if (info->SduDataPtr == NULL_PTR || info->SduLength == 0)
	{
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	else if(bufferSize < info->SduLength)
	{
		/* Not enough space available */
		BufReq_Return = BUFREQ_E_NOT_OK;
	}
	else
	{
		memcpy(MessageBuffer, info->SduDataPtr, info->SduLength);

		//Received_Payload = info->SduLength - V2G_HEADER_SIZE;

		//*bufferSizePtr = *bufferSizePtr - info->SduLength;
	}

	return BufReq_Return;
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpCopyTxData
 * Service ID[hex]: 0x43
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in):  PduIdType id,
					 const PduInfoType* info,
					 const RetryInfoType* retry,

 * Parameters (inout): None
 * Parameters (out): PduLengthType* availableDataPtr
 * Return value: BufReq_ReturnType
 * Description: This function is called to acquire the transmit data of an I-PDU segment (N-PDU). Each call to
   this function provides the next part of the I-PDU data unless retry->TpDataState is TP_
   DATARETRY. In this case the function restarts to copy the data beginning at the offset from the
   current position indicated by retry->TxTpDataCnt. The size of the remaining data is written to
   the position indicated by availableDataPtr.
 ************************************************************************************/

BufReq_ReturnType ChrgM_V2GTpCopyTxData (PduIdType id, const PduInfoType* info, const RetryInfoType* retry, PduLengthType* availableDataPtr)
{
	BufReq_ReturnType BufReq_Return = BUFREQ_OK;

	if (ChrgM_ModuleState == CHRGM_NOT_INITIALIZED)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_UNINIT);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	else if (info == NULL_PTR || availableDataPtr == NULL_PTR || retry == NULL_PTR)
	{
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_PARAM_POINTER);
#endif
		BufReq_Return = BUFREQ_E_NOT_OK;
	}

	if (*availableDataPtr < info->SduLength)
	{
		/* Not enough space available */
		BufReq_Return =  BUFREQ_E_BUSY;
	}
	else
	{
		/* If the retry parameter is not NULL, we need to handle the data copying accordingly */
		if (retry != NULL_PTR && retry->TpDataState == TP_DATARETRY)
		{
			/* Retry copy from where it previously failed (indicated by retry->TxTpDataCnt) */
			//memcpy(ChrgM_transmitBuffer + retry->TxTpDataCnt, info->SduDataPtr, info->SduLength);
		}
		else
		{
			/* Normal copy operation */
			//memcpy(ChrgM_transmitBuffer, info->SduDataPtr, info->SduLength);
		}
		/* Update the available buffer size */
		*availableDataPtr -= info->SduLength;
	}

	/* Return success */
	return BufReq_Return;
}

/*******************************************************************************
 *                        Callback Notifications Definitions                   *
 *******************************************************************************/


/************************************************************************************
 * Service Name: ChrgM_V2GTpRxIndication
 * Service ID[hex]: 0x45
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): id - Identification of the received I-PDU
 	 	 	 	   result - E_OK: The PDU was received.
 	 	 	 	 	 	 	E_NOT_OK: Reception of the PDU failed.
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Called by the lower layer after an I-PDU has been received or after the final I-PDU has been
			   received in case of segmentation
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_V2GTpRxIndication (PduIdType id, Std_ReturnType result)
{
	ChrgM_MessageReceived = TRUE;
	if(result == E_OK)
	{
		ChrgM_ReceptionSuccessful = TRUE;
	}
	else if(result == E_NOT_OK)
	{
		ChrgM_ReceptionSuccessful = FALSE;
	}
	else
	{
		/* Do Nothing */
	}
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpTxConfirmation
 * Service ID[hex]: 0x48
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): id - Identification of the transmitted I-PDU
                   result - E_OK: The PDU was transmitted
                   	   	    E_NOT_OK: Transmission of the PDU failed
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: The lower layer calls this API of the ChrgM to inform the ChrgM about the status of the
			   transmitted PDU
 * Requirments:[CP_RS_ChrgM_00012],[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_V2GTpTxConfirmation (PduIdType id, Std_ReturnType result)
{
	ChrgM_TxConfirmationReceived = TRUE;
	if(result == E_OK)
	{
		ChrgM_TransmissionSuccessful = TRUE;
	}
	else if(result == E_NOT_OK)
	{
		ChrgM_TransmissionSuccessful = FALSE;
	}
	else
	{
		/* Do Nothing */
	}
}

/************************************************************************************
 * Service Name: ChrgM_V2GTpStartOfReception
 * Service ID[hex]: 0x46
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): id - Identification of the I-PDU
				   info - Pointer to a PduInfoType structure containing the payload data
				          (without protocol information) and payload length of the first
				          frame or single frame of a transport protocol I-PDU reception, and
				          the MetaData related to this PDU
				   TpSduLength - Total length of the N-SDU to be received
 * Parameters (inout): None
 * Parameters (out): bufferSizePtr - Available receive buffer in the receiving module. This parameter
									will be used to compute the Block Size (BS) in the transport protocol module
 * Return value: BufReq_ReturnType - BUFREQ_OK: Connection has been accepted. bufferSizePtr
											   indicates the available receive buffer; reception is continued. If no
											   buffer of the requested size is available, a receive buffer size of 0
											   shall be indicated by bufferSizePtr
									BUFREQ_E_NOT_OK: Connection has been rejected; reception is
												     aborted. bufferSizePtr remains unchanged
									BUFREQ_E_OVFL: No buffer of the required length can be provided;
												   reception is aborted. bufferSizePtr remains unchanged
 * Description: This function is called at the start of receiving an N-SDU, The service shall provide the currently
 	 	 	   available maximum buffer size when invoked with TpSduLength equal to 0
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
BufReq_ReturnType ChrgM_V2GTpStartOfReception (PduIdType id, const PduInfoType* info, PduLengthType TpSduLength, PduLengthType* bufferSizePtr)
{
	if (ChrgM_ModuleState == CHRGM_NOT_INITIALIZED) {
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_UNINIT);
#endif
		return BUFREQ_E_NOT_OK;
	}

	if (info == NULL_PTR || bufferSizePtr == NULL_PTR) {
#if (CHRGM_DEV_ERROR_DETECT == STD_ON)
		Det_ReportError(CHRGM_MODULE_ID, CHRGM_INSTANCE_ID, CHRGM_INIT_SID,
				CHRGM_E_PARAM_POINTER);
#endif

	}

	return BUFREQ_OK;
}

/*******************************************************************************
 *                               Non SWS API'S                                 *
 *******************************************************************************/
#if(CHRGM_SDP_USED == STD_ON)
/************************************************************************************
 * Service Name: ChrgM_SECCDiscoveryProtocolReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): void
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for receiving SECC Discovery Protocol Message
 * Requirments:
 ************************************************************************************/
void ChrgM_SECCDiscoveryProtocolReq(void)
{
	/* Set Pointer to location of V2G Payload */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;
	/* Read data from buffer */
	/* V2g Payload */
	/* SECC Security*/
	SECCDiscoveryProtocolReq_Message.SECCSecurity = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += SDP_SECURITY_SIZE;
	/* SECC Transport Protocol */
	SECCDiscoveryProtocolReq_Message.SECCTransportProtocol = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += SDP_TRANSPORT_PROTOCOL_SIZE;
}
#endif
/************************************************************************************
 * Service Name: ChrgM_SupportedAppProtocolReq
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): void
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for receiving SupportedAppProtocolReq Message
 * Requirments:
 ************************************************************************************/
void ChrgM_SupportedAppProtocolReq(void)
{
	/* Set Pointer to location of V2G Payload */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;
	/* Read data from buffer */
	/* V2g Payload */
	/* V2G Payload Header */
	/* Session ID */
	SupportedAppProtocolReq_Message.MessageHeader.SessionID = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += SESSION_ID_SIZE;
	SupportedAppProtocolReq_Message.MessageHeader.NotificationUsed = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	//	if(Request_Header.NotificationUsed == USED)
	//	{
	//		/* Fault Code */
	//		Request_Header.Notification.FaultCode = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += FAULT_CODE_SIZE;
	//		Request_Header.Notification.FaultMsgUsed = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	//		/* Check if Notification Message element is used */
	//		if(Request_Header.Notification.FaultMsgUsed == USED)
	//		{
	//			/* Fault Message */
	//			uint8 Index = 0;
	//			while(Index < FAULT_MESSAGE_SIZE - 1 && *((uint8*)MessageBuffer_Ptr) != '\0')
	//			{
	//				Request_Header.Notification.FaultMsg[Index] = *((uint8*)MessageBuffer_Ptr);
	//				MessageBuffer_Ptr += FAULT_MESSAGE_ELEMENT_SIZE;
	//				Index++;
	//			}
	//			/* Insert NULL Character */
	//			Request_Header.Notification.FaultMsg[Index] = *((uint8*)MessageBuffer_Ptr);
	//			MessageBuffer_Ptr += FAULT_MESSAGE_ELEMENT_SIZE;
	//		}
	//		else
	//		{
	//			/* Do Nothing */
	//		}
	//	}
	//	else
	//	{
	//		/* Do Nothing */
	//	}

	SupportedAppProtocolReq_Message.MessageHeader.SignatureUsed = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	//	/* Check if Signature element is used*/
	//	if(Request_Header.SignatureUsed == USED)
	//	{
	//		/* Canonicalization Method Algorithm */
	//		Request_Header.Signature.SignedInfo.CanonicalizationMethod.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += CANONICALIZATION_ALGORITHM_SIZE;
	//		/* HMAC Output Length */
	//		Request_Header.Signature.SignedInfo.SignatureMethod.HMACOutputLength = *((uint32*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += SIGNATURE_HMAC_SIZE;
	//		/* Signature Method Algorithm */
	//		Request_Header.Signature.SignedInfo.SignatureMethod.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += SIGNATURE_ALGORITHM_SIZE;
	//		/* Transform Algorithm */
	//		Request_Header.Signature.SignedInfo.Reference.Transforms.Transform.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += TRANSFORM_ALGORITHM_SIZE;
	//		/* Digest Method Algorithm */
	//		Request_Header.Signature.SignedInfo.Reference.DigestMethod.Algorithm = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += DIGEST_METHOD_ALGORITHM_SIZE;
	//		/* Reference Digest Value */
	//		Request_Header.Signature.SignedInfo.Reference.DigestValue = *((uint8*)MessageBuffer_Ptr);
	//		MessageBuffer_Ptr += DIGEST_VALUE_SIZE;
	//		/* Reference ID */
	//		Request_Header.Signature.SignedInfo.Reference.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += REFERENCE_ID_SIZE;
	//		/* Signed Info ID */
	//		Request_Header.Signature.SignedInfo.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += SIGNED_INFO_ID_SIZE;
	//		/* Signature Value ID */
	//		Request_Header.Signature.SignatureValue.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += SIGNATURE_VALUE_ID_SIZE;
	//		/* Key Info ID */
	//		Request_Header.Signature.KeyInfo.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += KEY_INFO_ID_SIZE;
	//		/* Object ID */
	//		Request_Header.Signature.Object.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += OBJECT_ID_SIZE;
	//		/* Signature ID */
	//		Request_Header.Signature.Id = (char*)(*((uint32*)MessageBuffer_Ptr));
	//		MessageBuffer_Ptr += SIGNATURE_ID_SIZE;
	//	}
	//	else
	//	{
	//		/* Do Nothing */
	//	}

	/* V2G Payload Body */
	/* Message Name */
	SupportedAppProtocolReq_Message.MessageName = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += MESSAGE_NAME_SIZE;
	/* Number of Protocols to be sent */
	SupportedAppProtocolReq_Message.NumberOfProtocols = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += NUMBER_OF_PROTOCOLS_SIZE;
	uint8 Index = SupportedAppProtocolReq_Message.NumberOfProtocols;
	for(uint8 i = 0; i < Index; i++)
	{
		/* Protocol Name */
		uint8 j = 0;
		SupportedAppProtocolReq_Message.AppProtocol[i].ProtocolNamespaceLength = *((uint8*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += PROTOCOL_NAMESPACE_SIZE;
		while(j < SupportedAppProtocolReq_Message.AppProtocol[i].ProtocolNamespaceLength)
		{
			SupportedAppProtocolReq_Message.AppProtocol[i].ProtocolNamespace[j] = *((uint8*)MessageBuffer_Ptr);
			MessageBuffer_Ptr += PROTOCOL_NAMESPACE_SIZE;
			j++;
		}
		/* Major Version Number */
		SupportedAppProtocolReq_Message.AppProtocol[i].VersionNumberMajor = *((uint32*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += MAJOR_VERSION_NUMBER_SIZE;
		/* Minor Version Number */
		SupportedAppProtocolReq_Message.AppProtocol[i].VersionNumberMinor = *((uint32*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += MINOR_VERSION_NUMBER_SIZE;
		/* SchemaID */
		SupportedAppProtocolReq_Message.AppProtocol[i].SchemaID = *((uint8*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += SCHEMA_ID_SIZE;
		/* Priority */
		SupportedAppProtocolReq_Message.AppProtocol[i].Priority = *((uint8*)MessageBuffer_Ptr);
		MessageBuffer_Ptr += PRIORITY_SIZE;
	}
}
#if(CHRGM_SDP_USED == STD_ON)
/************************************************************************************
 * Service Name: ChrgM_SECCDiscoveryProtocolRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving SECC Discovery Protocol Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_SECCDiscoveryProtocolRes(void)
{
	/* Set Pointer to location of V2G Payload */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;
	/* Read data from buffer */
	/* V2g Payload */
	/* IP Address */
	for(uint8 i = 0; i < SDP_IP_ADDRESS_SIZE; i++)
	{
		*((uint8*)MessageBuffer_Ptr) = SECCDiscoveryProtocolRes_Message.SECCIPAddress[i];
		MessageBuffer_Ptr += SDP_IP_ADDRESS_ELEMENT_SIZE;
	}
	/* Port Number */
	*((uint32*)MessageBuffer_Ptr) = SECCDiscoveryProtocolRes_Message.SECCPortNumber;
	MessageBuffer_Ptr += SDP_PORT_NUMBER_SIZE;
	/* SECC Security*/
	*((uint8*)MessageBuffer_Ptr) = SECCDiscoveryProtocolRes_Message.SECCSecurity;
	MessageBuffer_Ptr += SDP_SECURITY_SIZE;
	/* SECC Transport Protocol */
	*((uint8*)MessageBuffer_Ptr) = SECCDiscoveryProtocolRes_Message.SECCTransportProtocol;
	MessageBuffer_Ptr += SDP_TRANSPORT_PROTOCOL_SIZE;
}
#endif
/************************************************************************************
 * Service Name: ChrgM_SupportedAppProtocolRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving SupportedAppProtocolRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_SupportedAppProtocolRes(void* SupportedAppProtocolResData)
{
	/* Set Module Message State to Supported App Protocol Message */
	ChrgM_RequestedMessage = SUPPORTED_APP_PROTOCOL;
	/* Save Header and Data Address */
	ChrgM_MessagePtr = SupportedAppProtocolResData;
}


/************************************************************************************
 * Service Name: ChrgM_SessionSetupRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving SessionSetupRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_SessionSetupRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Session Setup Message */
	ChrgM_RequestedMessage = SESSION_SETUP;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDiscoveryRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving ServiceDiscoveryRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_ServiceDiscoveryRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Service Discovery Message */
	ChrgM_RequestedMessage = SERVICE_DISCOVERY;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDetailRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving ServiceDetailRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
//void ChrgM_ServiceDetailRes(ServiceDetailResType* ServiceDetailResData, MessageHeaderType* Response_Header)
//{
//  /* Set Module Message State to Service Detail Message */
//  ChrgM_RequestedMessage = PAYMENT_SELECTION;
//  /* Save Header and Data Address */
//  ChrgM_MessagePtr = ServiceDetailResData;
//  ChrgM_HeaderPtr = Response_Header;
//}

/************************************************************************************
 * Service Name: ChrgM_PaymentServiceSelectionRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving PaymentServiceSelectionRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_PaymentServiceSelectionRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Payment Selection Message */
	ChrgM_RequestedMessage = PAYMENT_SELECTION;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_PaymentDetailsRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving AuthorizationRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_PaymentDetailsRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Payment Details Message */
	ChrgM_RequestedMessage = PAYMENT_DETAILS;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_AuthorizationRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving AuthorizationRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_AuthorizationRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Authorization Message */
	ChrgM_RequestedMessage = AUTHORIZATION;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_ChargeParameterDiscoveryRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving ChargeParameterDiscoveryRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_ChargeParameterDiscoveryRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Charge Parameter Discovery Message */
	ChrgM_RequestedMessage = CHARGE_PARAMETER_DISCOVERY;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_CableCheckRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving CableCheckRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_CableCheckRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Cable Check Message */
	ChrgM_RequestedMessage = CABLE_CHECK;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_PreChargeRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving PreChargeRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_PreChargeRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Pre Charge Message */
	ChrgM_RequestedMessage = PRE_CHARGE;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_PowerDeliveryRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving PowerDeliveryRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_PowerDeliveryRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Power Delivery Message */
	ChrgM_RequestedMessage = POWER_DELIVERY;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_CurrentDemandRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving CurrentDemandRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_CurrentDemandRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Current Demand Message */
	ChrgM_RequestedMessage = CURRENT_DEMAND;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_WeldingDetectionRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving WeldingDetectionRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_WeldingDetectionRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Welding Detection Message */
	ChrgM_RequestedMessage = WELDING_DETECTION;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_SessionStopRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function Responsible for Receiving SessionStopRes Message
 * 			   and sending the data to application layer
 * Requirments:
 ************************************************************************************/
void ChrgM_SessionStopRes(struct iso1EXIDocument* V2G_Document)
{
	/* Set Module Message State to Session Stop Message */
	ChrgM_RequestedMessage = SESSION_STOP;
	/* Save Document Address */
	ChrgM_DocumentPtr = V2G_Document;
}

/************************************************************************************
 * Service Name: ChrgM_WriteV2GTPHeader
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy:
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function is responsible for writing the V2GTP Message Header
 * Requirments:
 ************************************************************************************/
void ChrgM_WriteV2GTPHeader(void)
{
	/* Set Data Pointer to first byte of Data Buffer */
	MessageBuffer_Ptr = MessageBuffer;
	/* Write V2GTP header*/
	/* Protocol Version */
	*((uint8*)MessageBuffer_Ptr) = PROTOCOL_VERSION;
	MessageBuffer_Ptr += PROTOCOL_VERSION_SIZE;
	/* Inverse Protocol Version */
	*((uint8*)MessageBuffer_Ptr) = INVERSE_PROTOCOL_VERSION;
	MessageBuffer_Ptr += INVERSE_PROTOCOL_VERSION_SIZE;
	/* Payload Type depending on SDP or V2G Message */
	if(ChrgM_ModuleState == DISCOVERING_EVCC)
	{
		*((uint16*)MessageBuffer_Ptr) = SDP_REQUEST_PAYLOAD_TYPE_VALUE;
		MessageBuffer_Ptr += PAYLOAD_TYPE_SIZE;
	}
	else
	{
		*((uint16*)MessageBuffer_Ptr) = V2G_MESSAGE_PAYLOAD_TYPE_VALUE;
		MessageBuffer_Ptr += PAYLOAD_TYPE_SIZE;
	}
	/* Payload Length */
	*((uint32*)MessageBuffer_Ptr) = Sent_Payload;
	MessageBuffer_Ptr += PAYLOAD_LENGTH_SIZE;

	/* Store PDU Length */
	ChrgM_PduInfo.SduLength = Sent_Payload + V2G_HEADER_SIZE;
}

/************************************************************************************
 * Service Name: ChrgM_ReadV2GTPHeader
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy:
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): Std_ReturnType - Validation if there is an error or not
 * Return value: None
 * Description: This function is responsible for reading and checking V2GTP Header errors
 * Requirments:
 ************************************************************************************/
Std_ReturnType ChrgM_ReadV2GTPHeader(void)
{
	Std_ReturnType Header_Check = E_OK;
	/* Set Data Pointer to first byte of Data Buffer */
	MessageBuffer_Ptr = MessageBuffer;
	/* V2G Header */
	/* Protocol Version */
	V2G_Request_Header.ProtocolVersion = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += PROTOCOL_VERSION_SIZE;
	/* Inverse Protocol Version */
	V2G_Request_Header.InverseProtocolVersion = *((uint8*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += INVERSE_PROTOCOL_VERSION_SIZE;
	/* Payload Type */
	V2G_Request_Header.PayloadType = *((uint16*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += PAYLOAD_TYPE_SIZE;
	/* Payload Length */
	V2G_Request_Header.PayloadLength = *((uint32*)MessageBuffer_Ptr);
	MessageBuffer_Ptr += PAYLOAD_LENGTH_SIZE;

	Received_Payload = V2G_Request_Header.PayloadLength;

	/* Check Protocol Version */
	if(V2G_Request_Header.ProtocolVersion != PROTOCOL_VERSION || V2G_Request_Header.InverseProtocolVersion != INVERSE_PROTOCOL_VERSION)
	{
		Header_Check = E_NOT_OK;
	}
	/* Check Payload Length */
	else if(V2G_Request_Header.PayloadLength != Received_Payload)
	{
		Header_Check = E_NOT_OK;
	}
	/* Check Payload Type */
	else if(V2G_Request_Header.PayloadType != SDP_REQUEST_PAYLOAD_TYPE_VALUE && V2G_Request_Header.PayloadType != V2G_MESSAGE_PAYLOAD_TYPE_VALUE)
	{
		Header_Check = E_NOT_OK;
	}
	else
	{
		/* Do Nothing No error */
	}

	return Header_Check;
}

/************************************************************************************
 * Service Name: ChrgM_WriteSupportedAppProtocolRes
 * Sync/Async: Synchronous
 * Reentrancy: Non-Reentrant
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: Function is responsible for writing V2G Payload to Message Buffer
 * Requirments:
 ************************************************************************************/
void ChrgM_WriteSupportedAppProtocolRes(void)
{
	/* Set Pointer to location of V2G Payload */
	MessageBuffer_Ptr = MessageBuffer + V2G_HEADER_SIZE;
	/* Send header and Message data to buffer */
	/* V2G Payload Header */
	/* Session ID */
	*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.SessionID;
	MessageBuffer_Ptr += SESSION_ID_SIZE;
	*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.NotificationUsed;
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	if(((MessageHeaderType*)ChrgM_MessagePtr)->NotificationUsed == USED)
	{
		/* Fault Code */
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Notification.FaultCode;
		MessageBuffer_Ptr += FAULT_CODE_SIZE;
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Notification.FaultMsgUsed;
		MessageBuffer_Ptr += ELEMENT_USED_SIZE;
		/* Check if Notification Message element is used */
		if(((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Notification.FaultMsgUsed == USED)
		{
			/* Fault Message */
			uint8 Index = 0;
			while(Index < FAULT_MESSAGE_SIZE - 1 && *((uint8*)MessageBuffer_Ptr) != '\0')
			{
				*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Notification.FaultMsg[Index];
				MessageBuffer_Ptr += FAULT_MESSAGE_ELEMENT_SIZE;
				Index++;
			}
			/* Insert NULL Character */
			*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Notification.FaultMsg[Index];
			MessageBuffer_Ptr += FAULT_MESSAGE_ELEMENT_SIZE;
		}
		else
		{
			/* Do Nothing */
		}
	}
	else
	{
		/* Do Nothing */
	}

	*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.SignatureUsed;
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	/* Check if Signature element is used*/
	if(((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.SignatureUsed == USED)
	{
		/* Canonicalization Method Algorithm */
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.CanonicalizationMethod.Algorithm;
		MessageBuffer_Ptr += CANONICALIZATION_ALGORITHM_SIZE;
		/* HMAC Output Length */
		*((uint32*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.SignatureMethod.HMACOutputLength;
		MessageBuffer_Ptr += SIGNATURE_HMAC_SIZE;
		/* Signature Method Algorithm */
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.SignatureMethod.Algorithm;
		MessageBuffer_Ptr += SIGNATURE_ALGORITHM_SIZE;
		/* Transform Algorithm */
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.Reference.Transforms.Transform.Algorithm;
		MessageBuffer_Ptr += TRANSFORM_ALGORITHM_SIZE;
		/* Digest Method Algorithm */
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.Reference.DigestMethod.Algorithm;
		MessageBuffer_Ptr += DIGEST_METHOD_ALGORITHM_SIZE;
		/* Reference Digest Value */
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.Reference.DigestValue;
		MessageBuffer_Ptr += DIGEST_VALUE_SIZE;
		/* Reference ID */
		*((uint32*)MessageBuffer_Ptr) = (uint32)((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.Reference.Id;
		MessageBuffer_Ptr += REFERENCE_ID_SIZE;
		/* Signed Info ID */
		*((uint32*)MessageBuffer_Ptr) = (uint32)((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignedInfo.Id;
		MessageBuffer_Ptr += SIGNED_INFO_ID_SIZE;
		/* Signature Value ID */
		*((uint32*)MessageBuffer_Ptr) = (uint32)((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.SignatureValue.Id;
		MessageBuffer_Ptr += SIGNATURE_VALUE_ID_SIZE;
		/* Key Info ID */
		*((uint32*)MessageBuffer_Ptr) = (uint32)((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.KeyInfo.Id;
		MessageBuffer_Ptr += KEY_INFO_ID_SIZE;
		/* Object ID */
		*((uint32*)MessageBuffer_Ptr) = (uint32)((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.Object.Id;
		MessageBuffer_Ptr += OBJECT_ID_SIZE;
		/* Signature ID */
		*((uint32*)MessageBuffer_Ptr) = (uint32)((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageHeader.Signature.Id;
		MessageBuffer_Ptr += SIGNATURE_ID_SIZE;
	}
	else
	{
		/* Do Nothing */
	}

	/* V2G Payload Body */
	/* Message Name */
	*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->MessageName;
	MessageBuffer_Ptr += MESSAGE_NAME_SIZE;
	/* Response Code */
	*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->ResponseCode;
	MessageBuffer_Ptr += RESPONSE_CODE_SIZE;
	*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->SchemaIDUsed;
	MessageBuffer_Ptr += ELEMENT_USED_SIZE;
	/* Check if Schema ID element is used */
	if(((SupportedAppProtocolResType*)ChrgM_MessagePtr)->SchemaIDUsed == USED)
	{
		/* Schema ID */
		*((uint8*)MessageBuffer_Ptr) = ((SupportedAppProtocolResType*)ChrgM_MessagePtr)->SchemaID;
		MessageBuffer_Ptr += SCHEMA_ID_SIZE;
	}
	else
	{
		/* Do Nothing */
	}

	/* Calculate Payload Length */
	Sent_Payload = MessageBuffer_Ptr - MessageBuffer - V2G_HEADER_SIZE;
}

/************************************************************************************
 * Service Name: ChrgM_ReadMessageName
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different instances. Non reentrant for the same instance
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): MessageType - Message Name Type
 * Return value: None
 * Description: This function is responsible for reading the incomming message name
 * Requirments:
 ************************************************************************************/
MessageType ChrgM_ReadMessageName(void)
{
	MessageType MessageName;

	if(V2G_EXI_Document.V2G_Message.Body.SessionSetupReq_isUsed)
	{
		MessageName = SESSION_SETUP_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.ServiceDiscoveryReq_isUsed)
	{
		MessageName = SERVICE_DISCOVERY_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.ServiceDetailReq_isUsed)
	{
		MessageName = SERVICE_DETAIL_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.PaymentServiceSelectionReq_isUsed)
	{
		MessageName = PAYMENT_SELECTION_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.PaymentDetailsReq_isUsed)
	{
		MessageName = PAYMENT_DETAILS_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.AuthorizationReq_isUsed)
	{
		MessageName = AUTHORIZATION_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.ChargeParameterDiscoveryReq_isUsed)
	{
		MessageName = CHARGE_PARAMETER_DISCOVERY_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.CableCheckReq_isUsed)
	{
		MessageName = CABLE_CHECK_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.PreChargeReq_isUsed)
	{
		MessageName = PRE_CHARGE_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.PowerDeliveryReq_isUsed)
	{
		MessageName = POWER_DELIVERY_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.CurrentDemandReq_isUsed)
	{
		MessageName = CURRENT_DEMAND_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.WeldingDetectionReq_isUsed)
	{
		MessageName = WELDING_DETECTION_MESSAGE;
	}
	else if(V2G_EXI_Document.V2G_Message.Body.SessionStopReq_isUsed)
	{
		MessageName = SESSION_STOP_MESSAGE;
	}
	else
	{
		/* Invalid */
		MessageName = NO_MESSAGE;
	}

	/* Return Message Name */
	return MessageName;
}

/************************************************************************************
 * Service Name: ChrgM_EXIEncode
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different instances. Non reentrant for the same instance
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the XML Encoding required
 * Requirments:
 ************************************************************************************/
Std_ReturnType ChrgM_EXIEncode(uint8 *output_buffer, uint32 *output_size)
{
	int errn = 0;
	bitstream_t oStream;
	size_t pos = 0;

	/* Setup output stream */
	oStream.size = BUFFER_SIZE;
	oStream.data = output_buffer;
	oStream.pos = &pos;
	oStream.buffer = 0;
	oStream.capacity = 8;

#if DEPLOY_ISO1_CODEC == SUPPORT_YES
	errn = encode_iso1ExiDocument(&oStream, ChrgM_DocumentPtr);
	*output_size = pos;
	if (errn == 0)
	{

		return E_OK;
	}
	else
	{
		return E_NOT_OK;
	}
#endif /* DEPLOY_ISO1_CODEC == SUPPORT_YES */
}

/************************************************************************************
 * Service Name: ChrgM_EXIDecode
 * Service ID[hex]:
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant for different instances. Non reentrant for the same instance
 * Parameters (in): None
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: This function performs the XML Decoding required
 * Requirments:
 ************************************************************************************/
Std_ReturnType ChrgM_EXIDecode(uint8 *input_buffer, uint32 input_size, struct iso1EXIDocument *V2G_Document)
{
	int errn = 0;
	bitstream_t iStream;
	size_t pos = 0; // Initialize the position to the start of the buffer

	/* Setup input stream */
	iStream.size = input_size;
	iStream.data = input_buffer;
	iStream.pos = &pos;  // Set pos as the pointer to the current position
	iStream.buffer = 0;
	iStream.capacity = 0;

#if DEPLOY_ISO1_CODEC == SUPPORT_YES
	errn = decode_iso1ExiDocument(&iStream, V2G_Document);
	if (errn == 0)
	{
		return E_OK;
	}
	else
	{
		return E_NOT_OK;
	}
#endif /* DEPLOY_ISO1_CODEC == SUPPORT_YES */
}



