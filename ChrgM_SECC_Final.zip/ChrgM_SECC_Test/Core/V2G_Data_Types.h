/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: V2G_Data_Types.h
 *
 * Description: Standard V2G Types using ISO 15118-2 Document
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef V2G_DATA_TYPES_H_
#define V2G_DATA_TYPES_H_

#include "Std_Types.h"

typedef uint16 SECCPortNumberType;

typedef uint8 SECCIPAddressType;

typedef char percentValueType;

typedef char faultMsgType;

typedef char serviceNameType;

typedef char serviceScopeType;

typedef char maxNumPhasesType;

typedef short meterStatusType;

typedef char genChallengeType;

typedef char certificateType;

typedef char dHpublickeyType;

typedef char privateKeyType;

typedef char sigMeterReadingType;

typedef char sessionIDType;

typedef char evccIDType;

typedef char evseIDType;

typedef unsigned short serviceIDType;

typedef char eMAIDType;

typedef char meterIDType;

typedef unsigned char SAIDType;

typedef char tariffDescriptionType;

typedef char unitMultiplierType;

typedef int HMACOutputLengthType;

typedef char DigestValueType;

typedef uint8 ProtocolVersionType;

typedef uint8 InverseProtocolVersionType;

typedef unsigned short PayloadtypeType;

typedef uint32 PayloadLengthType;

typedef unsigned char idType;

typedef char protocolNameType;

typedef char protocolNamespaceType;

typedef unsigned char priorityType;

typedef enum
{
	CHRGM_NoError,

	V2G_Header_Check_Error,

	V2G_SECC_SequenceTimeout,

	V2G_SECC_PerformanceTimeout,

	V2G_SECC_CommunicationSetupTimeout,

	V2G_SECC_OngoingTimeout,

	CHRGM_EthLinkDown,

	CHRGM_CpLineInactive,

	CHRGM_IPAddressUnassigned,

	CHRGM_SocketOffline,

	CHRGM_InvalidEVCC,

	CHRGM_FAILED,

	CHRGM_SequenceError,

	CHRGM_SignatureError,

	CHRGM_UnknownSession,

	CHRGM_InvalidServiceID,

	CHRGM_PaymentSelectionInvalid,

	CHRGM_ServiceSelectionInvalid,

	CHRGM_NoChargeServiceSelected,

	CHRGM_CertificateExpired,

	CHRGM_CertificateRevoked,

	CHRGM_NoCertificateAvailable,

	CHRGM_CertificateNotAllowedAtThisEVSE,

	CHRGM_CertChainError,

	CHRGM_ContractCancelled,

	CHRGM_ChallengeInvalid,

	CHRGM_WrongEnergyTransferMode,

	CHRGM_WrongChargeParameter,

	CHRGM_ChargingProfileInvalid,

	CHRGM_TariffSelectionInvalid,

	CHRGM_PowerDeliveryNotApplied,

	CHRGM_ContactorError

}ChrgM_ErrorHandlerType;

typedef enum
{

    OK,

    OK_NewSessionEstablished,

    OK_OldSessionJoined,

    OK_CertificateExpiresSoon,

    FAILED,

    FAILED_SequenceError,

    FAILED_ServiceIDInvalid,

    FAILED_UnknownSession,

    FAILED_ServiceSelectionInvalid,

    FAILED_PaymentSelectionInvalid,

    FAILED_CertificateExpired,

    FAILED_SignatureError,

    FAILED_NoCertificateAvailable,

    FAILED_CertChainError,

    FAILED_ChallengeInvalid,

    FAILED_ContractCanceled,

    FAILED_WrongChargeParameter,

    FAILED_PowerDeliveryNotApplied,

    FAILED_TariffSelectionInvalid,

    FAILED_ChargingProfileInvalid,

    FAILED_MeteringSignatureNotValid,

    FAILED_NoChargeServiceSelected,

    FAILED_WrongEnergyTransferMode,

    FAILED_ContactorError,

    FAILED_CertificateNotAllowedAtThisEVSE,

    FAILED_CertificateRevoked,

}ChrgM_ResponseCodeType;

typedef enum
{
	NO_ERROR_STATUS,

	SET_BY_TX,

	SET_BY_RX

}ChrgM_ErrorStatusType;

typedef enum
{

	SUPPORTED_APP_PROTOCOL_MESSAGE = 1,

	SESSION_SETUP_MESSAGE,

	SERVICE_DISCOVERY_MESSAGE,

	SERVICE_DETAIL_MESSAGE,

	PAYMENT_SELECTION_MESSAGE,

	PAYMENT_DETAILS_MESSAGE,

	AUTHORIZATION_MESSAGE,

	CHARGE_PARAMETER_DISCOVERY_MESSAGE,

	CABLE_CHECK_MESSAGE,

	PRE_CHARGE_MESSAGE,

	POWER_DELIVERY_MESSAGE,

	CURRENT_DEMAND_MESSAGE,

	WELDING_DETECTION_MESSAGE,

	SESSION_STOP_MESSAGE,


}MessageType;

typedef enum
{
	NOT_USED,

	USED,

}ElementUsedType;

typedef enum
{

    Finished,

    Ongoing,

    Ongoing_WaitingForCustomerInteraction,

} EVSEProcessingType;

typedef enum
{

    None,

    StopCharging,

    ReNegotiation,

} EVSENotificationType;

typedef enum
{

    Start,

    Stop,

    Renegotiate

} chargeProgressType;

typedef enum
{

    Terminate,

    Pause

} chargingSessionType;

typedef enum
{

    EVCharging,

    Internet,

    ContractCertificate,

    OtherCustom

} serviceCategoryType;

typedef enum
{

    BOOL,

    BYTE,

    SHORT,

    INT,

    PHYSICALVALUE,

    STRING

} valueType;

typedef enum
{

    AC_single_phase_core,

    AC_three_phase_core,

    DC_core,

    DC_extended,

    DC_combo_core,

    DC_unique

} EnergyTransferModeType;

typedef enum
{

    relativePricePercentage,

    RenewableGenerationPercentage,

    CarbonDioxideEmission

} costKindType;

typedef enum
{

    Contract,

    ExternalPayment

} paymentOptionType;

typedef enum
{

    ParsingError,

    NoTLSRootCertificatAvailable,

    UnknownError

} faultCodeType;


typedef enum
{

    EVSE_NotReady,

    EVSE_Ready,

    EVSE_Shutdown,

    EVSE_UtilityInterruptEvent,

    EVSE_IsolationMonitoringActive,

    EVSE_EmergencyShutdown,

    EVSE_Malfunction,

    Reserved_8,

    Reserved_9,

    Reserved_A,

    Reserved_B,

    Reserved_C

} DC_EVSEStatusCodeType;

typedef enum
{

    Invalid,

    Valid,

    Warning,

    Fault,

    No_IMD

} isolationLevelType;

typedef enum
{

    NO_ERROR,

    FAILED_RESSTemperatureInhibit,

    FAILED_EVShiftPosition,

    FAILED_ChargerConnectorLockFault,

    FAILED_EVRESSMalfunction,

    FAILED_ChargingCurrentdifferential,

    FAILED_ChargingVoltageOutOfRange,

    //Reserved_A,

    //Reserved_B,

    //Reserved_C,

    FAILED_ChargingSystemIncompatibility,

    NoData

} DC_EVErrorCodeType;

typedef enum
{

    h,

    m,

    s,

    A,

    V,

    W,

    Wh

} unitSymbolType;

typedef enum
{
	TLS = 0x00,

	NO_TLS = 0x10
}SECCSecurityType;

typedef enum
{
	TCP = 0x00,

	UDP = 0x10
}SECCTransportProtocolType;

typedef struct
{
	ProtocolVersionType ProtocolVersion;

	InverseProtocolVersionType InverseProtocolVersion;

	PayloadtypeType PayloadType;

	PayloadLengthType PayloadLength;

} V2GMessageHeaderType;

typedef struct
{

    char Algorithm;

} CanonicalizationMethodType;

typedef struct
{

    HMACOutputLengthType HMACOutputLength;

    char Algorithm;

} SignatureMethodType;

typedef struct
{

    char Algorithm;

} TransformType;

typedef struct
{

    TransformType Transform;

} TransformsType;

typedef struct
{

    char Algorithm;

} DigestMethodType;

typedef struct
{

    TransformsType Transforms;

    DigestMethodType DigestMethod;

    DigestValueType DigestValue;

    char* Id;

} ReferenceType;

typedef struct
{

    CanonicalizationMethodType CanonicalizationMethod;

    SignatureMethodType SignatureMethod;

    ReferenceType Reference;

    char* Id;

} SignedInfoType;

typedef struct
{

    char* Id;

} SignatureValueType;

typedef struct
{

    char* Id;

} KeyInfoType;

typedef struct
{

    char* Id;

} ObjectType;

typedef struct
{

    SignedInfoType SignedInfo;

    SignatureValueType SignatureValue;

    KeyInfoType KeyInfo;

    ObjectType Object;

    char* Id;

} SignatureType;

typedef struct
{

    faultCodeType FaultCode;

    ElementUsedType FaultMsgUsed;

    faultMsgType FaultMsg[64];

} NotificationType;

typedef struct
{

    sessionIDType SessionID;

    ElementUsedType NotificationUsed;

    NotificationType Notification;

    ElementUsedType SignatureUsed;

    SignatureType Signature;

} MessageHeaderType;

typedef struct
{
    /* This struct is empty for Future Use. Placeholder to comply with C standards that disallow empty structs. */
    char _reserved;
} SASchedulesType;

typedef struct
{
    /* This struct is empty for Future Use. Placeholder to comply with C standards that disallow empty structs. */
    char _reserved;
} IntervalType;

typedef struct
{
    /* This struct is empty for Future Use. Placeholder to comply with C standards that disallow empty structs. */
    char _reserved;
} EVStatusType;

typedef struct
{
    /* This struct is empty for Future Use. Placeholder to comply with C standards that disallow empty structs. */
    char _reserved;
} EVSEChargeParameterType;

typedef struct
{
    /* This struct is empty for Future Use. Placeholder to comply with C standards that disallow empty structs. */
    char _reserved;
} EVPowerDeliveryParameterType;

typedef struct
{

    unitMultiplierType Multiplier;

    unitSymbolType Unit;

    short Value;

} PhysicalValueType;

typedef struct
{

    serviceIDType ServiceID;

    ElementUsedType ServiceNameUsed;

    serviceNameType ServiceName[32];

    serviceCategoryType ServiceCategory;

    ElementUsedType ServiceScopeUsed;

    serviceScopeType ServiceScope[64];

    boolean FreeService;

} ServiceType;

typedef struct
{

	uint8 NumberOfServices;

    ServiceType Service[8];

} ServiceListType;

typedef struct
{

    serviceIDType ServiceID;

    ElementUsedType ParameterSetIDUsed;

    short ParameterSetID;

} SelectedServiceType;

typedef struct
{

	uint8 NumberOfSelectedService;

    SelectedServiceType SelectedService[16];

} SelectedServiceListType;

typedef struct
{

    char Name;

    /* Only one of the following elements can be used as type of parameter:
     * Bool
     * Byte
     * Short
     * Int
     * PhysicalValueType
     * String
     */

} ParameterType;

typedef struct
{

    short ParameterSetID;

    uint8 NumberOfParameter;

    ParameterType Parameter[16];

} ParameterSetType;

typedef struct
{

	uint8 NumberOfParameterSet;

    ParameterSetType ParameterSet[255];

} ServiceParameterListType;

typedef struct
{

    EnergyTransferModeType EnergyTransferMode;

} SupportedEnergyTransferModeType;

typedef struct
{

	uint8 NumberofSupportedEnergyTransferMode;

    SupportedEnergyTransferModeType SupportedEnergyTransferMode[6];

} ChargeServiceType;

typedef struct
{

    costKindType costKind;

    unsigned int amount;

    ElementUsedType amountMultiplierUsed;

    unitMultiplierType amountMultiplier;

} CostType;

typedef struct
{

    PhysicalValueType startValue;

    uint8 NumberOfCost;

    CostType Cost[3];

} ConsumptionCostType;

typedef struct
{

	ElementUsedType EPriceLevelUsed;

    unsigned char EPriceLevel;

    ElementUsedType ConsumptionCostUsed;

    uint8 NumberOfConsumptionCost;

    ConsumptionCostType ConsumptionCost[3];

} SalesTariffEntryType;

typedef struct
{

    SAIDType SalesTariffID;

    ElementUsedType SalesTariffDescriptionUsed;

    tariffDescriptionType SalesTariffDescription[32];

    ElementUsedType NumEPriceLevelsUsed;

    unsigned char NumEPriceLevels;

    uint16 NumberOfSalesTariffEntry;

    SalesTariffEntryType SalesTariffEntry[1024];

    char *Id;

} SalesTariffType;

typedef struct
{

    PhysicalValueType PMax;

} PMaxScheduleEntryType;

typedef struct
{

	uint16 NumberOfPMaxScheduleEntry;

    PMaxScheduleEntryType PMaxScheduleEntry[1024];

} PMaxScheduleType;

typedef struct
{

    SAIDType SAScheduleTupleID;

    PMaxScheduleType PMaxSchedule;

    ElementUsedType SalesTariffUsed;

    SalesTariffType SalesTariff;

} SAScheduleTupleType;

typedef struct
{

	uint8 NumberOfSAScheduleTuple;

    SAScheduleTupleType SAScheduleTuple[3];

} SAScheduleListType;

typedef struct
{

    IntervalType TimeInterval;

} EntryType;

typedef struct
{

    unsigned int start;

    ElementUsedType durationUsed;

    unsigned int duration;

} RelativeTimeIntervalType;

typedef struct
{

    unsigned short NotificationMaxDelay;

    EVSENotificationType EVSENotification;

} EVSEStatusType;

typedef struct
{

    boolean RCD;

} AC_EVSEStatusType;

typedef struct
{

	ElementUsedType EVSEIsolationStatusUsed;

    isolationLevelType EVSEIsolationStatus;

    DC_EVSEStatusCodeType EVSEStatusCode;

} DC_EVSEStatusType;

typedef struct
{

    boolean EVReady;

    DC_EVErrorCodeType EVErrorCode;

    percentValueType EVRESSSOC;

} DC_EVStatusType;

typedef struct
{

    unsigned int DepartureTime;

} EVChargeParameterType;

typedef struct
{

    PhysicalValueType EAmount;

    PhysicalValueType EVMaxVoltage;

    PhysicalValueType EVMaxCurrent;

    PhysicalValueType EVMinCurrent;

} AC_EVChargeParameterType;

typedef struct
{

    DC_EVStatusType DC_EVStatus;

    PhysicalValueType EVMaximumCurrentLimit;

    ElementUsedType EVMaximumPowerLimitUsed;

    PhysicalValueType EVMaximumPowerLimit;

    PhysicalValueType EVMaximumVoltageLimit;

    ElementUsedType EVEnergyCapacityUsed;

    PhysicalValueType EVEnergyCapacity;

    ElementUsedType EVEnergyRequestUsed;

    PhysicalValueType EVEnergyRequest;

    ElementUsedType FullSOCUsed;

    percentValueType FullSOC;

    ElementUsedType BulkSOCUsed;

    percentValueType BulkSOC;

} DC_EVChargeParameterType;

typedef struct
{

    AC_EVSEStatusType AC_EVSEStatus;

    PhysicalValueType EVSENominalVoltage;

    PhysicalValueType EVSEMaxCurrent;

} AC_EVSEChargeParameterType;

typedef struct
{

    DC_EVSEStatusType DC_EVSEStatus;

    PhysicalValueType EVSEMaximumCurrentLimit;

    PhysicalValueType EVSEMaximumPowerLimit;

    PhysicalValueType EVSEMaximumVoltageLimit;

    PhysicalValueType EVSEMinimumCurrentLimit;

    PhysicalValueType EVSEMinimumVoltageLimit;

    ElementUsedType EVSECurrentRegulationToleranceUsed;

    PhysicalValueType EVSECurrentRegulationTolerance;

    PhysicalValueType EVSEPeakCurrentRipple;

    ElementUsedType EVSEEnergyToBeDeliveredUsed;

    PhysicalValueType EVSEEnergyToBeDelivered;

} DC_EVSEChargeParameterType;

typedef struct
{

    DC_EVStatusType DC_EVStatus;

    ElementUsedType BulkChargingCompleteUsed;

    boolean BulkChargingComplete;

    boolean ChargingComplete;

} DC_EVPowerDeliveryParameterType;

typedef struct
{

    unsigned int ChargingProfileEntryStart;

    PhysicalValueType ChargingProfileEntryMaxPower;

    ElementUsedType ChargingProfileEntryMaxNumberOfPhasesInUseUsed;

    maxNumPhasesType ChargingProfileEntryMaxNumberOfPhasesInUse;

} ProfileEntryType;

typedef struct
{

	uint8 NumberOfProfileEntry;

    ProfileEntryType ProfileEntry[24];

} ChargingProfileType;

typedef struct
{

  uint8 NumberOfPaymentOption;

  paymentOptionType PaymentOption[2];

} PaymentOptionListType;

typedef struct
{

	uint8 ProtocolNamespaceLength;

    protocolNamespaceType ProtocolNamespace[100];

    unsigned int VersionNumberMajor;

    unsigned int VersionNumberMinor;

    idType SchemaID;

    priorityType Priority;

} AppProtocolType;

typedef struct
{

    meterIDType MeterID[32];

    ElementUsedType MeterReadingUsed;

    unsigned long MeterReading;

    ElementUsedType SigMeterReadingUsed;

    sigMeterReadingType SigMeterReading[64];

    ElementUsedType MeterStatusUsed;

    meterStatusType MeterStatus;

    ElementUsedType TMeterUsed;

    long TMeter;

} MeterInfoType;

typedef struct
{

	uint8 NumberOfCertificate;

    certificateType Certificate[4][800];

} SubCertificatesType;

typedef struct
{

    certificateType Certificate[800];

    ElementUsedType SubCertificatesUsed;

    SubCertificatesType SubCertificates;

    char *Id;

} CertificateChainType;

/*******************************************************************************
 *                             Message Body                                    *
 *******************************************************************************/

typedef struct
{
	SECCSecurityType SECCSecurity;

	SECCTransportProtocolType SECCTransportProtocol;

}SECCDiscoveryProtocolReqType;

typedef struct
{
	SECCIPAddressType SECCIPAddress[16];

	SECCPortNumberType SECCPortNumber;

	SECCSecurityType SECCSecurity;

	SECCTransportProtocolType SECCTransportProtocol;

}SECCDiscoveryProtocolResType;

typedef struct
{

	MessageHeaderType MessageHeader;

	MessageType MessageName;

	uint8 NumberOfProtocols;

    AppProtocolType AppProtocol[2];


} SupportedAppProtocolReqType;

typedef struct
{

	MessageHeaderType MessageHeader;

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    ElementUsedType SchemaIDUsed;

    idType SchemaID;

} SupportedAppProtocolResType;

typedef struct
{

	MessageType MessageName;

	evccIDType EVCCID;

} SessionSetupReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    evseIDType EVSEID;

    ElementUsedType EVSETimeStampUsed;

    long EVSETimeStamp;

} SessionSetupResType;

typedef struct
{

	MessageType MessageName;

	ElementUsedType ServiceScopeUsed;

    serviceScopeType ServiceScope;

    ElementUsedType ServiceCategoryUsed;

    serviceCategoryType ServiceCategory;

} ServiceDiscoveryReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    PaymentOptionListType PaymentOptionList;

    ChargeServiceType ChargeService;

    ElementUsedType ServiceListUsed;

    ServiceListType ServiceList;

} ServiceDiscoveryResType;

typedef struct
{

	MessageType MessageName;

    serviceIDType ServiceID;

} ServiceDetailReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    serviceIDType ServiceID;

    ElementUsedType ServiceParameterListUsed;

    ServiceParameterListType ServiceParameterList;

} ServiceDetailResType;

typedef struct
{

	MessageType MessageName;

    paymentOptionType SelectedPaymentOption;

    SelectedServiceListType SelectedServiceList;

} PaymentServiceSelectionReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

} PaymentServiceSelectionResType;

typedef struct
{

	MessageType MessageName;

    eMAIDType eMAID;

    CertificateChainType ContractSignatureCertChain;

} PaymentDetailsReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    genChallengeType GenChallenge;

    long EVSETimeStamp;

} PaymentDetailsResType;

typedef struct
{

	MessageType MessageName;

	ElementUsedType GenChallengeUsed;

    genChallengeType GenChallenge;

} AuthorizationReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    EVSEProcessingType EVSEProcessing;

} AuthorizationResType;

typedef struct
{

	MessageType MessageName;

	ElementUsedType MaxEntriesSAScheduleTupleUsed;

    unsigned short MaxEntriesSAScheduleTuple;

    EnergyTransferModeType RequestedEnergyTransferMode;

    EVChargeParameterType EVChargeParameter;

} ChargeParameterDiscoveryReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    EVSEProcessingType EVSEProcessing;

    ElementUsedType SASchedulesUsed;

    SASchedulesType SASchedules;

    EVSEChargeParameterType EVSEChargeParameter;

} ChargeParameterDiscoveryResType;

typedef struct
{

	MessageType MessageName;

    chargeProgressType ChargeProgress;

    SAIDType SAScheduleTupleID;

    ElementUsedType ChargingProfileUsed;

    ChargingProfileType ChargingProfile;

    ElementUsedType EVPowerDeliveryParameterUsed;

    EVPowerDeliveryParameterType EVPowerDeliveryParameter;

} PowerDeliveryReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    EVSEStatusType EVSEStatus;

} PowerDeliveryResType;


typedef struct
{

	MessageType MessageName;

    chargingSessionType ChargingSession;

} SessionStopReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

} SessionStopResType;

typedef struct
{

	MessageType MessageName;

    DC_EVStatusType DC_EVStatus;

} CableCheckReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    DC_EVSEStatusType DC_EVSEStatus;

    EVSEProcessingType EVSEProcessing;

} CableCheckResType;

typedef struct
{

	MessageType MessageName;

    DC_EVStatusType DC_EVStatus;

    PhysicalValueType EVTargetVoltage;

    PhysicalValueType EVTargetCurrent;

} PreChargeReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    DC_EVSEStatusType DC_EVSEStatus;

    PhysicalValueType EVSEPresentVoltage;

} PreChargeResType;

typedef struct
{

	MessageType MessageName;

    DC_EVStatusType DC_EVStatus;

    PhysicalValueType EVTargetCurrent;

    ElementUsedType EVMaximumVoltageLimitUsed;

    PhysicalValueType EVMaximumVoltageLimit;

    ElementUsedType EVMaximumCurrentLimitUsed;

    PhysicalValueType EVMaximumCurrentLimit;

    ElementUsedType EVMaximumPowerUsed;

    PhysicalValueType EVMaximumPowerLimit;

    ElementUsedType BulkChargingCompleteUsed;

    boolean BulkChargingComplete;

    boolean ChargingComplete;

    ElementUsedType RemainingTimeToFullSoCUsed;

    PhysicalValueType RemainingTimeToFullSoC;

    ElementUsedType RemainingTimeToBulkSoCUsed;

    PhysicalValueType RemainingTimeToBulkSoC;

    PhysicalValueType EVTargetVoltage;

} CurrentDemandReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    DC_EVSEStatusType DC_EVSEStatus;

    PhysicalValueType EVSEPresentVoltage;

    PhysicalValueType EVSEPresentCurrent;

    boolean EVSECurrentLimitAchieved;

    boolean EVSEVoltageLimitAchieved;

    boolean EVSEPowerLimitAchieved;

    ElementUsedType EVSEMaximumVoltageLimitUsed;

    PhysicalValueType EVSEMaximumVoltageLimit;

    ElementUsedType EVSEMaximumCurrentLimitUsed;

    PhysicalValueType EVSEMaximumCurrentLimit;

    ElementUsedType EVSEMaximumPowerLimitUsed;

    PhysicalValueType EVSEMaximumPowerLimit;

    evseIDType EVSEID;

    SAIDType SAScheduleTupleID;

    ElementUsedType MeterInfoUsed;

    MeterInfoType MeterInfo;

    ElementUsedType ReceiptRequiredUsed;

    boolean ReceiptRequired;

} CurrentDemandResType;

typedef struct
{

	MessageType MessageName;

    DC_EVStatusType DC_EVStatus;

} WeldingDetectionReqType;

typedef struct
{

	MessageType MessageName;

    ChrgM_ResponseCodeType ResponseCode;

    DC_EVSEStatusType DC_EVSEStatus;

    PhysicalValueType EVSEPresentVoltage;

} WeldingDetectionResType;

#endif /* V2G_DATA_TYPES_H_ */
