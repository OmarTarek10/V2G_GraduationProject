/******************************************************************************
 *
 * Module: CanIf
 *
 * File Name: CanIf.c
 *
 * Description: Stub for PduR
 *
 * Author: Kareem Azab
 ******************************************************************************/




#include "CanIf.h"


Std_ReturnType CanIf_Transmit (PduIdType TxPduId,const PduInfoType* PduInfoPtr){
	return E_OK;

}
