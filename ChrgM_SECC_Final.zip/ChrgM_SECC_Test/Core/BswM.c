/******************************************************************************
 *
 * Module: BswM
 *
 * File Name: BswM.c
 *
 * Description:
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "BswM.h"

#if (BSWM_DEV_ERROR_DETECT == STD_ON)

#include "Det.h"
/*
 * AUTOSAR Version checking between Det and BswM Modules
 */

#if ((DET_AR_MAJOR_VERSION != BSWM_AR_RELEASE_MAJOR_VERSION)\
|| (DET_AR_MINOR_VERSION != BSWM_AR_RELEASE_MINOR_VERSION)\
|| (DET_AR_PATCH_VERSION != BSWM_AR_RELEASE_PATCH_VERSION))
 #error "The AR version of Det.h does not match the expected version"
#endif

#endif /* (BSWM_DEV_ERROR_DETECT == STD_ON) */

//static uint8 BswM_Status = BSWM_NOT_INITIALIZED;



/************************************************************************************
* Service Name: BswM_RequestMode
* Service ID[hex]: 0x02
* Sync/Async: Synchronous
* Reentrancy: Reentrant
* Parameters (in): requesting_user - The user that requests the mode
				   requested_mode - The requested mode
* Parameters (inout): None
* Parameters (out): None
* Return value: None
* Description: Generic function call to request modes
************************************************************************************/
void BswM_RequestMode (BswM_UserType requesting_user, BswM_ModeType requested_mode)
{

}
