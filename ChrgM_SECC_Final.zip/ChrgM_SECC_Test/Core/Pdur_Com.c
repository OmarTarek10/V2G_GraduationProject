/******************************************************************************
 *
 * Module: PduR
 *
 * File Name: PduR_Com.c
 *
 * Description: Source file for PduR_Com.c
 *
 * Author: Kareem Azab
 ******************************************************************************/



#include "Pdur_Com.h"

#include "PduR_Pbcfg.h"
#include "PduR_Cfg.h"
#include "CanIf.h"


Std_ReturnType PduR_ComTransmit (PduIdType TxPduId, const PduInfoType* PduInfoPtr)
{
	Std_ReturnType returnValue = E_NOT_OK;
	if(PduRState == PDUR_ONLINE){
		uint8 PduRRoutingPathIndex;
		for (PduRRoutingPathIndex = 0; PduRRoutingPathIndex < PduRMaxRoutingPathCnt; PduRRoutingPathIndex++){
			if (PduR.PduRRoutingTables.PduRRoutingTable[Com_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRSrcPdu.PduRSourcePduHandleId == TxPduId)
				{
					returnValue =  CanIf_Transmit(PduR.PduRRoutingTables.PduRRoutingTable[Com_RoutingTable_ID].PduRRoutingPath[PduRRoutingPathIndex].PduRDestPdu[0].PduRDestPduHandleId,PduInfoPtr);
				}
			else
				{
					/*MISRA Rule*/
				}
			}
	}
	else{

	}
	return returnValue;
}
