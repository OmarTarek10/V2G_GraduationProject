/******************************************************************************
*
* Module: Ethernet Interface
*
* File Name: EthIf_PbCfg.c
*
* Description: Source File For the Ethernet Interface Post Build Configurations Module
*
* Author: Ahmed Ehab El Gowely
******************************************************************************/
#include "EthIf.h"

#include "Eth_If_UL_Callbacks.h"

EthIf_ConfigType EthIfConfigurationSet =
{
  .ControllerConfigStructs[ETH_IF_CTRL_IDX_1] =
  {
    .EthIfCtrlIdx = ETH_IF_CTRL_IDX_1,
    .EthIfCtrlMtu = 250,
    .EthIfMacSecSupport = NO_MACSEC,
    .EthIfMaxTxBufsTotal = 5,
    .Is_PhysController = TRUE,
    .EthIfPhysControllerRef =
    {
      .EthIfPhysControllerIdx = ETH_IF_PHYS_CONTROLLER_IDX_1,	
    }
    
  },
  
  .OwnerConfigStructs[ETH_IF_CTRL_IDX_1] =
  {
    .EthIfFrameType = 0x800,
    .EthIfOwner = ETH_IF_CTRL_IDX_1 // CHARGE MANAGER IDX
  },
  
  .RxInd_Func_Structs[ETH_IF_CTRL_IDX_1] =
  {//FOR TCP
    .EthIfRxIndicationFunction = &TcpIp_RxIndication
  },
  
  .TxInd_Func_Structs  [ETH_IF_CTRL_IDX_1] =
  {//FOR TCP
    .EthIfTxConfirmationFunction = NULL_PTR
  }
};

