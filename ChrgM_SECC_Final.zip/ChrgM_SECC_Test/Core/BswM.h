/******************************************************************************
 *
 * Module: BswM
 *
 * File Name: BswM.h
 *
 * Description:
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#ifndef BSWM_H_
#define BSWM_H_

/* ID for the company in the AUTOSAR
 * for example Mahmoud Shaarawy's ID = 7022 */
#define BSWM_VENDOR_ID                  (7022U)

/* BswM Module ID */
#define BSWM_MODULE_ID                  (42U)

/* BswM Instance ID */
#define BSWM_INSTANCE_ID                (0U)

/*
 * Module Version 1.0.0
 */
#define BSWM_SW_MAJOR_VERSION           (1U)
#define BSWM_SW_MINOR_VERSION           (0U)
#define BSWM_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 1.0.0
 */
#define BSWM_AR_RELEASE_MAJOR_VERSION   (1U)
#define BSWM_AR_RELEASE_MINOR_VERSION   (0U)
#define BSWM_AR_RELEASE_PATCH_VERSION   (0U)

/*
 * Macros for BswM Status
 */
#define BSWM_INITIALIZED                (1U)
#define BSWM_NOT_INITIALIZED            (0U)


/* Standard AUTOSAR types */
#include "Std_Types.h"

/*
 * AUTOSAR checking between Std Types and BswM Modules
 */

#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != BSWM_AR_RELEASE_MAJOR_VERSION)\
||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != BSWM_AR_RELEASE_MINOR_VERSION)\
||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != BSWM_AR_RELEASE_PATCH_VERSION))
 #error "The AR version of Std_Types.h does not match the expected version"
#endif


/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef uint16 BswM_ModeType;

typedef uint16 BswM_UserType;


/*******************************************************************************
 *                              Mandatory Interfaces                           *
 *******************************************************************************/

void BswM_RequestMode (BswM_UserType requesting_user, BswM_ModeType requested_mode);

#endif /* BSWM_H_ */
