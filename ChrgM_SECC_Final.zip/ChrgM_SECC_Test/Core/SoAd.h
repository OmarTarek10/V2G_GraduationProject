#ifndef SOAD_H_
#define SOAD_H_

#include "Std_Types.h"
#include "ComStack_Types.h"
#include "SoAd_cfg.h"
#include "TcpIp.h"

/*
 * Module Version 1.0.0
 */
#define SOAD_SW_MAJOR_VERSION           (1U)
#define SOAD_SW_MINOR_VERSION           (0U)
#define SOAD_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 1.0.0
 */
#define SOAD_AR_RELEASE_MAJOR_VERSION   (1U)
#define SOAD_AR_RELEASE_MINOR_VERSION   (0U)
#define SOAD_AR_RELEASE_PATCH_VERSION   (0U)

typedef uint16 SoAd_SoConIdType;

typedef enum{
	SOAD_SOCON_ONLINE,
	SOAD_SOCON_RECONNECT,
	SOAD_SOCON_OFFLINE
}SoAd_SoConModeType;


typedef struct{

	uint8	SoAdSocketTcpImmediateTpTxConfirmation;
	uint8	SoAdSocketTcpInitiate;
	uint8	SoAdSocketTcpKeepAlive;
	uint32	SoAdSocketTcpKeepAliveTime;
	uint32	SoAdSocketTcpRetransmissionTimeout;

}SoAd_SocketTcpType;

typedef enum{
	SOCKET_InUse,
	SOCKET_CREATE,
	SOCKET_Aquired,
	SOCKET_NOT_USED
}Soad_SocketState;

typedef struct{

	SoAd_SocketTcpType	SoAd_SocketTcpConfig;

}SoAd_SocketProtocolType;

typedef struct{

	TcpIp_DomainType	Domain;
	uint16	SoAdSocketRemotePort;
	uint32 SoAdSocketRemoteIpAddress[4];

}SoAd_SocketRemoteAddressType;

typedef struct{

	SoAd_SoConIdType	SoAdSocketId;
	SoAd_SocketRemoteAddressType	SoAd_SocketRemoteAddress;

}SoAd_SocketConnectionType;


typedef struct{

	uint16 SoAdSocketLocalPort;
	TcpIp_LocalAddr SoAdSocketLocalAddressRef;
	SoAd_SocketConnectionType	SoAd_SocketConnection;
	SoAd_SocketProtocolType	SoAd_SocketProtocol;

}SoAd_SocketConnectionGroupType;

typedef enum{
	IF,
	TP
}SoAdTxUpperLayerType;

typedef struct{

	uint16	SoAdRxPduId;

}SoAd_SocketRouteDestType;

typedef struct{

	uint32	SoAdRxPduHeaderId;
	SoAd_SocketConnectionType SoAdTxSocketConn;

}SoAd_PduRouteDestType;

typedef struct{

	SoAdTxUpperLayerType	upperLayer;
	SoAd_PduRouteDestType	SoAdTxPduRef;

}SoAd_PduRouteType;

typedef struct{


	SoAd_SocketConnectionGroupType	SoAd_SockConnGroup[SoAdRoutingGroupMax];

}SoAd_ConfigType;

void SoAd_Init (const SoAd_ConfigType* SoAdConfigPtr);
Std_ReturnType SoAd_OpenSoCon(SoAd_SoConIdType SoConId);
Std_ReturnType ExtractDataTo_SoAdBuffer(SoAd_SoConIdType socketInd, const uint8* DataPtr, uint32 DataLength);
Std_ReturnType SoAd_TcpAccepted (TcpIp_SocketIdType SocketId, TcpIp_SocketIdType SocketIdConnected,const TcpIp_SockAddrType* RemoteAddrPtr);
Std_ReturnType SoAd_IfTransmit (PduIdType TxPduId, const PduInfoType* PduInfoPtr);
Std_ReturnType SoAd_TpCancelTransmit (PduIdType TxPduId );
Std_ReturnType SoAd_TpCancelReceive ( PduIdType RxPduId );
Std_ReturnType SoAd_TcpAccepted (TcpIp_SocketIdType SocketId, TcpIp_SocketIdType SocketIdConnected, const TcpIp_SockAddrType* RemoteAddrPtr);
void SoAd_TcpConnected (TcpIp_SocketIdType SocketId);
void SoAd_TxConfirmation(TcpIp_SocketIdType SocketId, uint16 Length);
void SoAd_RxIndication (TcpIp_SocketIdType SocketId, const TcpIp_SockAddrType* RemoteAddrPtr, const uint8* BufPtr, uint16 Length);
Std_ReturnType SoAd_CloseSoCon (SoAd_SoConIdType SoConId, boolean abort);
void SoAd_ReleaseIpAddrAssignment(void);
Std_ReturnType SoAd_RequestIpAddrAssignment(void);
void SoAd_MainFunction(void);

extern SoAd_ConfigType SoAdConfigPtr;

#endif
