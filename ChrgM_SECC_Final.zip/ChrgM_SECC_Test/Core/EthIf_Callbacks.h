/******************************************************************************
*
* Module: Ethernet Interface / Wireless Ethernet
*
* File Name: EthIf_Callbacks.h
*
* Description:  Header File For Ethernet Interface Callbacks Called by the Wireless Ethernet.
*
* Author:
******************************************************************************/
#ifndef ETHIF_CALLLBACKS_H_
#define ETHIF_CALLLBACKS_H_


#define ETHIF_CALLLBACKS_VENDOR_ID                                  (1000U)
/*
* Module Version 1.0.0
*/
#define ETHIF_CALLLBACKS_SW_MAJOR_VERSION                           (1U)
#define ETHIF_CALLLBACKS_SW_MINOR_VERSION                           (0U)
#define ETHIF_CALLLBACKS_SW_PATCH_VERSION                           (0U)
/*
* AUTOSAR Version R22-11
*/
#define ETHIF_CALLLBACKS_AR_RELEASE_MAJOR_VERSION                   (1U)//(4U)
#define ETHIF_CALLLBACKS_AR_RELEASE_MINOR_VERSION                   (0U)//(7U)
#define ETHIF_CALLLBACKS_AR_RELEASE_PATCH_VERSION                   (0U)//(0U)


/*******************************************************************************
 *                      Function Prototypes                                    *
 *******************************************************************************/
void EthIf_RxIndication (uint8 CtrlIdx,Eth_FrameType FrameType,boolean IsBroadcast,const uint8* PhysAddrPtr,const Eth_DataType* DataPtr,uint16 LenByte);

void EthIf_TxConfirmation (uint8 CtrlIdx,Eth_BufIdxType BufIdx,Std_ReturnType Result);

void EthIf_CtrlModeIndication (uint8 CtrlIdx,Eth_ModeType CtrlMode);


#endif
