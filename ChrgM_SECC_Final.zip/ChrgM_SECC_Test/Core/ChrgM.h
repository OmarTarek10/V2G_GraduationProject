/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM.h
 *
 * Description: Charging Manager enables the charging process between the supply equipment (EVSE) and the vehicle (EV)
 *
 * Author: Mahmoud Shaarawy,Mohannad Sabry
 ******************************************************************************/

#ifndef CHRGM_H_
#define CHRGM_H_

/* ID for the company in the AUTOSAR
 * for example Mahmoud Shaarawy's ID = 7022 */
#define CHRGM_VENDOR_ID                  (7022U)

/* ChrgM Module ID */
#define CHRGM_MODULE_ID                  (0U) /*Unknown*/

/* ChrgM Instance ID */
#define CHRGM_INSTANCE_ID                (0U)

/*
 * Module Version 1.0.0
 */
#define CHRGM_SW_MAJOR_VERSION           (1U)
#define CHRGM_SW_MINOR_VERSION           (0U)
#define CHRGM_SW_PATCH_VERSION           (0U)

/*
 * AUTOSAR Version 1.0.0
 */
#define CHRGM_AR_RELEASE_MAJOR_VERSION   (1U)
#define CHRGM_AR_RELEASE_MINOR_VERSION   (0U)
#define CHRGM_AR_RELEASE_PATCH_VERSION   (0U)

/*
 * Macros for ChrgM Status
 */
#define CHRGM_INITIALIZED                (1U)
#define CHRGM_NOT_INITIALIZED            (0U)


/*******************************************************************************
 *                              Module Definitions                             *
 *******************************************************************************/

/* If required */


/* Standard AUTOSAR types */
#include "Std_Types.h"

/*
 * AUTOSAR checking between Std Types and ChrgM Modules
 */

#if ((STD_TYPES_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (STD_TYPES_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (STD_TYPES_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of Std_Types.h does not match the expected version"
#endif


/* ChrgM Pre-Compile Configuration Header file */
#include "ChrgM_Cfg.h"

/* AUTOSAR Version checking between ChrgM_Cfg.h and ChrgM.h files */
#if ((CHRGM_CFG_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (CHRGM_CFG_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (CHRGM_CFG_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between ChrgM_Cfg.h and ChrgM.h files */
#if ((CHRGM_CFG_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (CHRGM_CFG_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (CHRGM_CFG_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Non AUTOSAR files */
#include "Common_Macros.h"

/*******************************************************************************
 *                             Imported Modules                                *
 *******************************************************************************/

#include "BswM.h"

/* AUTOSAR Version checking between BswM.h and ChrgM.h files */
#if ((BSWM_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (BSWM_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (BSWM_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between BswM.h and ChrgM.h files */
#if ((BSWM_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (BSWM_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (BSWM_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "ComStack_Types.h"

/* AUTOSAR Version checking between ComStack_Types.h and ChrgM.h files */
#if ((COMSTACK_TYPES_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (COMSTACK_TYPES_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (COMSTACK_TYPES_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between ComStack_Types.h and ChrgM.h files */
#if ((COMSTACK_TYPES_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (COMSTACK_TYPES_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (COMSTACK_TYPES_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "Csm/Csm.h"

/* AUTOSAR Version checking between Csm.h and ChrgM.h files */
#if ((CSM_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (CSM_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (CSM_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between Csm.h and ChrgM.h files */
#if ((CSM_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (CSM_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (CSM_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "Eth_GeneralTypes.h"

/* AUTOSAR Version checking between Eth_GeneralTypes.h and ChrgM.h files */
#if ((ETH_GENERAL_TYPES_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (ETH_GENERAL_TYPES_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (ETH_GENERAL_TYPES_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between Eth_GeneralTypes.h and ChrgM.h files */
#if ((ETH_GENERAL_TYPES_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (ETH_GENERAL_TYPES_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (ETH_GENERAL_TYPES_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "KeyM.h"

/* AUTOSAR Version checking between KeyM.h and ChrgM.h files */
#if ((KEYM_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (KEYM_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (KEYM_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between KeyM.h and ChrgM.h files */
#if ((KEYM_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (KEYM_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (KEYM_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "SoAd.h"

/* AUTOSAR Version checking between SoAd.h and ChrgM.h files */
#if ((SOAD_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (SOAD_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (SOAD_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between SoAd.h and ChrgM.h files */
#if ((SOAD_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (SOAD_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (SOAD_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "TcpIp.h"

/* AUTOSAR Version checking between TcpIp.h and ChrgM.h files */
#if ((TCPIP_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (TCPIP_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (TCPIP_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between TcpIp.h and ChrgM.h files */
#if ((TCPIP_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (TCPIP_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (TCPIP_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif


#include "PduR.h"

/* AUTOSAR Version checking between PduR.h and ChrgM.h files */
#if ((PDUR_AR_RELEASE_MAJOR_VERSION != CHRGM_AR_RELEASE_MAJOR_VERSION)\
		||  (PDUR_AR_RELEASE_MINOR_VERSION != CHRGM_AR_RELEASE_MINOR_VERSION)\
		||  (PDUR_AR_RELEASE_PATCH_VERSION != CHRGM_AR_RELEASE_PATCH_VERSION))
#error "The AR version of ChrgM_Cfg.h does not match the expected version"
#endif

/* Software Version checking between PduR.h and ChrgM.h files */
#if ((PDUR_SW_MAJOR_VERSION != CHRGM_SW_MAJOR_VERSION)\
		||  (PDUR_SW_MINOR_VERSION != CHRGM_SW_MINOR_VERSION)\
		||  (PDUR_SW_PATCH_VERSION != CHRGM_SW_PATCH_VERSION))
#error "The SW version of ChrgM_Cfg.h does not match the expected version"
#endif

/* SoAd Callback Functions */
#include "ChrgM_SoAd.h"

/* Main Function Rx */
#include "SchM_ChrgM.h"

/* Main Function Tx */
#include "ChrgM_SchM.h"

/* ChrgM Indication APIs */
#include "ChrgM_Externals.h"

#include "iso1EXIDatatypes.h"
#include "iso1EXIDatatypesEncoder.h"
#include "iso1EXIDatatypesDecoder.h"
#include "iso2EXIDatatypes.h"
#include "iso2EXIDatatypesEncoder.h"
#include "iso2EXIDatatypesDecoder.h"
#include "ByteStream.h"
#include <string.h>

#include "../CryIf/CryIf.h"
#include "../Crypto_GeneralTypes.h"
#include "../CryIf/Cryif.h"
#include "../CryptoDriver/Crypto.h"

/* Service SWC */
//#include "Rte_Charging_Station_Service_Swc.h"

/******************************************************************************
 *                      API Service Id Macros                                 *
 ******************************************************************************/

#define CHRGM_INIT_SID 									(uint8)0x01

#define CHRGM_START_PROCESS_SID 						(uint8)0x25

#define CHRGM_CP_LINE_STATUS_SID 						(uint8)0x1E

#define CHRGM_DATA_LINK_INDICATION_SID 					(uint8)0x02

#define CHRGM_ERROR_INDICATION 							(uint8)0x1D

#define CHRGM_MAIN_FUNCTION_RX_SID 						(uint8)0x24

#define CHRGM_MAIN_FUNCTION_TX_SID 						(uint8)0x23

#define CHRGM_PAYMENT_SERVICE_SELECTION_INDICATION_SID 	(uint8)0x15

#define CHRGM_SESSION_SETUP_INDICATION_SID 				(uint8)0x12

#define CHRGM_SESSION_STOP_INDICATION_SID 				(uint8)0x1C

#define CHRGM_V2GTP_COPY_RX_DATA 						(uint8)0x44

#define CHRGM_V2GTP_COPY_TX_DATA 						(uint8)0x43


/******************************************************************************
 *                 Callback Notification Service Id Macros                    *
 ******************************************************************************/

#define CHRGM_V2GTP_LOCAL_IP_ADDR_ASSIGNMENT_CHG_SID 	(uint8)0x18

#define CHRGM_V2GTP_RX_INDICATION_SID 					(uint8)0x45

#define CHRGM_V2GTP_SO_CON_MODE_CHG_SID 				(uint8)0x21

#define CHRGM_V2GTP_START_OF_RECEPTION_SID 				(uint8)0x46

#define CHRGM_V2GTP_TX_CONFIRMATION_SID 				(uint8)0x48


/*******************************************************************************
 *                               DET Error Codes                               *
 *******************************************************************************/

#define CHRGM_E_UNINIT 									(uint8)0x01

#define CHRGM_E_PARAM_POINTER 							(uint8)0x02

#define CHRGM_E_INV_ARG 								(uint8)0x03

#define CHRGM_E_INIT_FAILED 							(uint8)0x06


/*******************************************************************************
 *                               DEM Error Codes                               *
 *******************************************************************************/

#define CHRGM_E_NOBUFS 									(uint8)0x07


/*******************************************************************************
 *                              Module Data Types                              *
 *******************************************************************************/

typedef float ChrgM_TimerType;

typedef uint32 ChrgMV2GTPPduPayloadTypeType;

typedef uint8 ChrgMV2GTPPduProtocolVersionType;

typedef uint32 ChrgMV2GTPPduHandleIdType;

typedef enum
{
	NOT_INITIALIZED,

	INIT,

	ASSIGNING_IP_ADDRESS,

	SECC_IDLE,

	DISCOVERING_EVCC,

	ESTABLISHING_TCP_TLS,

	V2G_SESSION_ONGOING,

	V2G_SESSION_PAUSED

}ChrgM_ModuleStateType;

typedef enum
{
	NO_MESSAGE,

	SUPPORTED_APP_PROTOCOL,

	SESSION_SETUP,

	SERVICE_DISCOVERY,

	SERVICE_DETAIL,

	PAYMENT_SELECTION,

	PAYMENT_DETAILS,

	AUTHORIZATION,

	CHARGE_PARAMETER_DISCOVERY,

	CABLE_CHECK,

	PRE_CHARGE,

	POWER_DELIVERY,

	CURRENT_DEMAND,

	WELDING_DETECTION,

	SESSION_STOP

}ChrgM_MessageStateType;

typedef struct
{
	ChrgMV2GTPPduPayloadTypeType ChgMV2GTPPduPayloadType;

	ChrgMV2GTPPduProtocolVersionType ChrgMV2GTPPduProtocolVersion;

	ChrgMV2GTPPduHandleIdType ChrgMV2GTPPduHandleId;

	/* ChrgMV2GTPPduRef Pointer to Pdu Structure Not defined yet */

}ChrgM_V2GTPPduType;

typedef struct
{
	/* Pointer ChrgMSoAdSocketConnectionRef */
}ChrgM_ServiceType;

typedef struct
{
	/* Pointer ChrgMV2GUdpSdpClientRef */
	/* Pointer ChrgMV2GSrcTcpDataRef */
	SoAd_ConfigType* ChrgMV2GSrcTcpDataRef;
	ChrgM_V2GTPPduType ChrgM_V2GTPPdu;
}ChrgM_V2GTPType;

typedef struct
{
	//ChrgM_ServiceType ChrgM_Service; /* Not used as IP Address is statically Configured */
	ChrgM_TimerType ChrgM_Timer[CHRGM_CONFIGURED_TIMERS];
	ChrgM_V2GTPType ChrgM_V2GTP;

} ChrgM_ConfigType;

/*******************************************************************************
 *                               V2G Datatypes                                 *
 *******************************************************************************/

#include "V2G_Data_Types.h"

/*******************************************************************************
 *                             Magic Numbers                                   *
 *******************************************************************************/
#define INACTIVE                                (0u)

#define ACTIVE                                  (1u)

#define SECC_PORT_NUMBER                        (15118)

#define PROTOCOL_VERSION                        (0x01)

#define INVERSE_PROTOCOL_VERSION                (0xFE)

#define V2G_MESSAGE_PAYLOAD_TYPE_VALUE          (0x8001)

#define SDP_RESPONSE_PAYLOAD_TYPE_VALUE         (0x9001)

#define SDP_REQUEST_PAYLOAD_TYPE_VALUE          (0x9000)

#define SDP_SECURITY_SIZE                       (1u)

#define SDP_TRANSPORT_PROTOCOL_SIZE             (1u)

#define SDP_PORT_NUMBER_SIZE                    (4u)

#define SDP_IP_ADDRESS_SIZE                     (16u)

#define SDP_IP_ADDRESS_ELEMENT_SIZE             (1u)

#define PROTOCOL_VERSION_SIZE                   (1u)

#define INVERSE_PROTOCOL_VERSION_SIZE           (1u)

#define PAYLOAD_TYPE_SIZE                       (2u)

#define PAYLOAD_LENGTH_SIZE                     (4u)

#define SESSION_ID_SIZE                         (1u)

#define EVCC_ID_SIZE                      		(1u)

#define RESPONSE_CODE_SIZE                 		(1u)

#define EVSE_ID_SIZE                       		(1u)

#define EVSE_TIME_STAMP_SIZE                	(4u)

#define SERVICE_SCOPE_SIZE                 		(64u)

#define SERVICE_CATEGORY_SIZE              		(1u)

#define PAYMENT_OPTION_LIST_SIZE            	(4U)

#define CHARGE_SERVICE_SIZE                		(4u)

#define SERVICE_LIST_SIZE                  		(103u)

#define SERVICE_ID_SIZE                    		(2U)

#define SERVICE_PARAMETER_LIST_SIZE         	(3u)

#define SELECTED_PAYMENT_OPTION_SIZE        	(1u)

#define SELECTED_SERVICE_LIST_SIZE          	(4u)

#define GEN_CHALLENGE_SIZE                 		(1u)

#define MAX_ENTRIES_SA_SCHEDULE_TUPLE_SIZE    	(2u)

#define REQUESTED_ENERGY_TRANSFER_MODE_SIZE  	(1u)

#define EV_CHARGE_PARAMETER_SIZE            	(4u)

#define SA_SCHEDULES_SIZE                  		(1u)

#define EVSE_CHARGE_PARAMETER_SIZE          	(1u)

#define DC_EV_STATUS_SIZE                 		(3u)

#define EV_TARGET_VOLTAGE_SIZE            		(4u)

#define EV_TARGET_CURRENT_SIZE            		(4u)

#define CHARGE_PROCESS_SIZE 			  		(1u)

#define SA_SCHEDULE_TUPLE_ID_SIZE         		(1u)

#define EV_POWER_DELIVERY_PARAMETER_SIZE  		(1u)

#define EV_MAXIMUM_VOLTAGE_LIMIT_SIZE     		(4u)

#define EV_MAXIMUM_CURRENT_LIMIT_SIZE     		(4u)

#define EV_MAXIMUM_POWER_LIMIT_SIZE       		(4u)

#define BULK_CHARGING_COMPLETE_SIZE       		(1u)

#define CHARGING_COMPLETE_SIZE            		(1u)

#define REMAINING_TIME_TO_FULL_SOC_SIZE   		(4u)

#define REMAINING_TIME_TO_BULK_SOC_SIZE   		(4u)

#define CHARGING_SESSION_SIZE             		(1u)

#define DC_EVSE_STATUS_SIZE                 	(2u)

#define EVSE_PROCESSING_SIZE                    (1u)

#define EVSE_PRESENT_VOLTAGE_SIZE 				(4u)

#define EVSE_PRESENT_CURRENT_SIZE 				(4u)

#define EVSE_STATUS_SIZE						(3u)

#define EVSE_CURRENT_LIMIT_ACHIEVED_SIZE        (1u)

#define EVSE_VOLTAGE_LIMIT_ACHIEVED_SIZE        (1u)

#define EVSE_POWER_LIMIT_ACHIEVED_SIZE 			(1u)

#define EVSE_MAXIMUM_VOLTAGE_LIMIT_SIZE			(4u)

#define EVSE_MAXIMUM_CURRENT_LIMIT_SIZE			(4u)

#define EVSE_MAXIMUM_POWER_LIMIT_SIZE			(4u)

#define RECEIPT_REQUIRED_SIZE                	(1u)

#define PAYMENT_OPTION_SIZE                     (1u)

#define ENERGY_TRANSFER_MODE_SIZE               (1u)

#define SERVICE_NAME_SIZE                       (32u)

#define FREE_SERVICE_SIZE                       (1u)

#define NAME_SIZE                               (1u)

#define PARAMETER_SET_ID_SIZE                   (2u)

#define DEPARTURE_TIME_SIZE                     (4u)

#define EV_READY_SIZE 							(1u)

#define EV_ERROR_CODE_SIZE 						(1u)

#define EV_RESSSOC_SIZE 						(1u)

#define MULTIPLIER_SIZE 						(1u)

#define UNIT_SIZE 								(1u)

#define VALUE_SIZE 								(2u)

#define CHARGING_PROFILE_ENTRY_SIZE             (4u)

#define MAX_NUMBER_OF_PHASES_SIZE               (1u)

#define RESERVED_SIZE                           (1u)

#define EVSE_ISOLATION_STATUS_SIZE              (1u)

#define EVSE_STATUS_CODE_SIZE                   (1u)

#define NOTIFICATION_MAX_DELAY_SIZE             (2u)

#define EVSE_NOTIFICATION_SIZE                  (1u)

#define METER_ID_SIZE                           (1u)

#define METER_ID_ARRAY_SIZE                     (32u)

#define METER_READING_SIZE                      (4u)

#define SIG_METER_READING_SIZE                  (1u)

#define SIG_METER_READING_ARRAY_SIZE            (64u)

#define METER_STATUS_SIZE                       (2u)

#define TMETER_SIZE                             (4u)

#define SERVICE_NAME_ELEMENT_SIZE               (1u)

#define SERVICE_SCOPE_ELEMENT_SIZE              (1u)

#define FAULT_CODE_SIZE                         (1u)

#define FAULT_MESSAGE_SIZE                      (64u)

#define FAULT_MESSAGE_ELEMENT_SIZE              (1u)

#define CANONICALIZATION_ALGORITHM_SIZE         (1u)

#define SIGNATURE_HMAC_SIZE                     (4u)

#define SIGNATURE_ALGORITHM_SIZE                (1u)

#define TRANSFORM_ALGORITHM_SIZE                (1u)

#define DIGEST_METHOD_ALGORITHM_SIZE            (1u)

#define DIGEST_VALUE_SIZE                       (1u)

#define REFERENCE_ID_SIZE                       (4u)

#define SIGNED_INFO_ID_SIZE                     (4u)

#define SIGNATURE_VALUE_ID_SIZE                 (4u)

#define KEY_INFO_ID_SIZE                        (4u)

#define OBJECT_ID_SIZE                          (4u)

#define SIGNATURE_ID_SIZE                       (4u)

#define MAJOR_VERSION_NUMBER_SIZE				(4u)

#define MINOR_VERSION_NUMBER_SIZE				(4u)

#define SCHEMA_ID_SIZE							(1u)

#define PRIORITY_SIZE							(1u)

#define ELEMENT_USED_SIZE                       (1u)

#define MESSAGE_NAME_SIZE                       (1u)

#define PROTOCOL_NAMESPACE_SIZE                 (1u)

#define NUMBER_OF_PROTOCOLS_SIZE				(1u)

#define V2G_HEADER_SIZE                         (8u)

#define SELECTED_SERVICE_SIZE                   (1u)

#define NUMBER_OF_PROFILE_ENTERY_SIZE           (1u)

#define NUMBER_OF_PAYMENT_OPTION_SIZE           (1u)

#define NUMBER_OF_ENERGY_TRANSFER_MODE_SIZE		(1u)

#define NUMBER_OF_PARAMETER_SET_SIZE            (1u)

#define NUMBER_OF_PARAMETER_SIZE                (1u)

#define PROTOCOL_NAMESPACE_MAX_SIZE             (100u)

#define EMAID_SIZE                              (1u)

#define CERTIFICATE_SIZE                        (800u)

#define CERTIFICATE_ELEMENT_SIZE                (1u)

#define GEN_CHALLENGE_SIZE                      (1u)

/*******************************************************************************
 *                             Function Prototypes                             *
 *******************************************************************************/

void ChrgM_Init (const ChrgM_ConfigType* ConfigPtr);

void ChrgM_StartProcess (boolean Process);

void ChrgM_CpLineStatus (char CpLineStatus);

void ChrgM_DataLinkIndication (uint8 CtrlIdx, EthTrcv_LinkStateType TransceiverLinkState);

BufReq_ReturnType ChrgM_V2GTpCopyRxData (PduIdType id, const PduInfoType* info,PduLengthType bufferSize);

BufReq_ReturnType ChrgM_V2GTpCopyTxData (PduIdType id, const PduInfoType* info, const RetryInfoType* retry, PduLengthType* availableDataPtr);


/*******************************************************************************
 *                        Callback Notifications Prototypes                    *
 *******************************************************************************/

void ChrgM_V2GTpRxIndication (PduIdType id, Std_ReturnType result);

BufReq_ReturnType ChrgM_V2GTpStartOfReception (PduIdType id, const PduInfoType* info, PduLengthType TpSduLength, PduLengthType* bufferSizePtr);

void ChrgM_V2GTpTxConfirmation (PduIdType id, Std_ReturnType result);

/*******************************************************************************
 *                               Non SWS API'S                                 *
 *******************************************************************************/
#if(CHRGM_SDP_USED == STD_ON)
void ChrgM_SECCDiscoveryProtocolReq(void);

void ChrgM_SECCDiscoveryProtocolRes(void);
#endif
void ChrgM_SupportedAppProtocolReq(void);

void ChrgM_SupportedAppProtocolRes(void* SupportedAppProtocolResData);

void ChrgM_SessionSetupRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_ServiceDiscoveryRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_ServiceDetailRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_PaymentServiceSelectionRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_PaymentDetailsRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_AuthorizationRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_ChargeParameterDiscoveryRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_CableCheckRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_PreChargeRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_PowerDeliveryRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_CurrentDemandRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_WeldingDetectionRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_SessionStopRes(struct iso1EXIDocument* V2G_Document);

void ChrgM_WriteV2GTPHeader(void);

void ChrgM_WriteSupportedAppProtocolRes(void);

MessageType ChrgM_ReadMessageName(void);

Std_ReturnType ChrgM_EXIEncode(uint8 *output_buffer, uint32 *output_size);

Std_ReturnType ChrgM_EXIDecode(uint8 *input_buffer, uint32 input_size, struct iso1EXIDocument *V2G_Document);

Std_ReturnType ChrgM_ReadV2GTPHeader(void);

/*******************************************************************************
 *                       External Variables                                    *
 *******************************************************************************/

/* ChrgM Configuration Structure extern header file */
#include "ChrgM_PBCfg.h"

#endif /* CHRGM_H_ */
