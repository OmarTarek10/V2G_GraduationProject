/******************************************************************************
 *
 * Module: ChrgM
 *
 * File Name: ChrgM_Externals.c
 *
 * Description: Header file for external ChrgM APIs
 *
 * Author: Mahmoud Shaarawy
 ******************************************************************************/

#include "ChrgM_Externals.h"

#include "Rte_Charging_Station_Service_Swc.h"

extern boolean Message_Received_Indication;
extern MessageHeaderType Request_Header;
extern SupportedAppProtocolResType SupportedAppProtocolReq_Message;
extern struct iso1EXIDocument V2G_EXI_Document;
extern MessageType ChrgM_IncomingMessage;

/************************************************************************************
 * Service Name: ChrgM_ErrorIndication
 * Service ID[hex]: 0x1D
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ErrorHandler - Defines the type of error
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about errors
 * Requirments:[SRS_BSW_00310]
 ************************************************************************************/
void ChrgM_ErrorIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	switch(ErrorHandler)
	{
	case V2G_Header_Check_Error:
	case V2G_SECC_SequenceTimeout:
	case V2G_SECC_PerformanceTimeout:
	case V2G_SECC_CommunicationSetupTimeout:
	case V2G_SECC_OngoingTimeout:
	case CHRGM_EthLinkDown:
	case CHRGM_CpLineInactive:
	case CHRGM_IPAddressUnassigned:
	case CHRGM_SocketOffline:
	case CHRGM_InvalidEVCC:
		RE_SendRequest(FALSE, ErrorHandler, NULL_PTR, 0);
		break;

	case CHRGM_SequenceError:
	case CHRGM_UnknownSession:
		RE_SendRequest(TRUE, ErrorHandler, NULL_PTR, 0);
		break;

	default:
		/* Do Nothing */
		break;
	}
}

/************************************************************************************
 * Service Name: ChrgM_PaymentServiceSelectionIndication
 * Service ID[hex]: 0x15
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Payment method offered by SECC
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PaymentServiceSelectionIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_SessionSetupIndication
 * Service ID[hex]: 0x12
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about V2G session setup information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_SessionSetupIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_SessionStopIndication
 * Service ID[hex]: 0x1C
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs the upper layer about status of V2G session
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_SessionStopIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_SupportedAppProtocolIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Supported App Protocol Status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_SupportedAppProtocolIndication(ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDiscoveryIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Service Discovery information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_ServiceDiscoveryIndication(ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_ServiceDetailIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Service Details information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
//void ChrgM_ServiceDetailIndication(ChrgM_ErrorHandlerType ErrorHandler)
//{
//	Message_Received_Indication = TRUE;
//
//	if(ResponseCode == OK)
//	{
//		RE_SendRequest(Message_Received_Indication, &Request_Header, &ServiceDetailReq_Message, CHRGM_NoError);
//	}
//	else
//	{
//		/*Inform the upper layer with an error message*/
//		switch (ResponseCode)
//		{
//		case FAILED:
//			ChrgM_ErrorIndication(CHRGM_FAILED);
//			break;
//		case FAILED_SequenceError:
//			ChrgM_ErrorIndication(CHRGM_SequenceError);
//			break;
//		case FAILED_UnknownSession:
//			ChrgM_ErrorIndication(CHRGM_UnknownSession);
//			break;
//		case FAILED_SignatureError:
//			ChrgM_ErrorIndication(CHRGM_SignatureError);
//			break;
//		case FAILED_ServiceIDInvalid:
//			ChrgM_ErrorIndication(CHRGM_InvalidServiceID);
//			break;
//		default:
//			break;
//		}
//		RE_SendRequest(Message_Received_Indication, &Request_Header, &ServiceDiscoveryReq_Message, Error_Indication);
//	}
//}

/************************************************************************************
 * Service Name: ChrgM_PaymentDetailsIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Payment Details
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PaymentDetailsIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_AuthorizationIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Authorization
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_AuthorizationIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_ChargeParameterDiscoveryIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Charging Parameters
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_ChargeParameterDiscoveryIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_CableCheckIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Cable check status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_CableCheckIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_PreChargeIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about PreCharge Information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PreChargeIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);

}

/************************************************************************************
 * Service Name: ChrgM_PowerDeliveryIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about PowerDelivery Information
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_PowerDeliveryIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_CurrentDemandIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Current Demand
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_CurrentDemandIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}

/************************************************************************************
 * Service Name: ChrgM_WeldingDetectionIndication
 * Sync/Async: Synchronous
 * Reentrancy: Reentrant
 * Parameters (in): ResponseCode - ResponseCode indicating the acknowledgement status of
                                  any of the V2G messages received by the SECC
 * Parameters (inout): None
 * Parameters (out): None
 * Return value: None
 * Description: ChrgM informs upper layer about Welding Detection Status
 * Requirments:[SRS_BSW_00310],[CP_SWS_ChrgM_00013]
 ************************************************************************************/
void ChrgM_WeldingDetectionIndication (ChrgM_ErrorHandlerType ErrorHandler)
{
	Message_Received_Indication = TRUE;

	RE_SendRequest(Message_Received_Indication, ErrorHandler, &V2G_EXI_Document, ChrgM_IncomingMessage);
}
